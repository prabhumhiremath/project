﻿//-----------------------------------------------------------------------
// <copyright file="DBhelperexceptions.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>File for creating all the exception objects that may be thrown by DataAccessHelper library</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Using - Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace AmericanExpress.GDU.Util.DataAccessHelper
{
    /// <summary>
    /// Generic class for general DB exceptions
    /// </summary>
    public class DBHelperException : Exception
    {

    }
    /// <summary>
    /// Exception class used when DbFacade fails to start a new transaction
    /// </summary>
    public class FailedToStartTransaction : Exception
    {

    }
    /// <summary>
    /// Exception class used when DbFacade is already in a transaction and is asked to start a new transaction
    /// </summary>
    public class AlreadyInTransaction : Exception
    {

    }
}
