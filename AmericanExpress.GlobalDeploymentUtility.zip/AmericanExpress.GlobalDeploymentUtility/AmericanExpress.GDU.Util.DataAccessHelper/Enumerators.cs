﻿//-----------------------------------------------------------------------
// <copyright file="Enumerators.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This file contains enumerators required by Data Access Helper library</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Using - Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace AmericanExpress.GDU.Util.DataAccessHelper
{
    /// <summary>
    /// Data type enumrator used by Data Access Helper
    /// </summary>
    public enum ParamTypes
    {
        Integer,
        String,
        Float,
        DateTime,
        Decimal,
        Char,
        Varchar,
        Nvarchar
    }

    /// <summary>
    /// Parameter direction enumerator used by Data Access Helper
    /// </summary>
    public enum ParamDirection
    {
        input,
        output
    }
}
