﻿//-----------------------------------------------------------------------
// <copyright file="SearchRole.cs" company="">
//   
// </copyright>
// <summary>
// 
// NIIT Technolgies
// 10/14/2010
// 
//</summary>
namespace AmericanExpress.GDU
{
    #region using
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    using System.Configuration;
    #endregion

    /// <summary>
    /// This is main entry point for SearchRole module
    /// </summary>
    public partial class SearchRole : System.Web.UI.Page
    {
        #region variables

        /// <summary>
        /// Constant string
        /// </summary>
        public const string USER_NAME = "UserName";

        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        protected int currentPage, pageSize, startRecord;
        int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"].ToString());
        #endregion



        #region property
        /// <summary>
        /// GridViewSortDirection
        /// </summary>
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;
                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }
        #endregion

        #region methods

        /// <summary>
        /// This method load role data
        /// </summary>
        protected void BindRoleGridData()
        {
            this.gduModel = new GDUModel();
            string role;
            bool isDeactive = false;
            try
            {
                if (string.IsNullOrEmpty(txtRole.Text.ToString()))
                {
                    role = null;
                }
                else
                {
                    role = txtRole.Text.ToString().Trim();
                }
                isDeactive = chkDeactivated.Checked;
                Session[AdmConstants.IS_DEACTIVE] = isDeactive;
                DataTable dtSearchRole = gduModel.GetRoleDetails(0, null, role, isDeactive, "GD", CurrentPage, PageSize, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());
                DataView dvSearchRole = new DataView();
                if (dtSearchRole.Rows.Count > 0)
                {
                    //lblRecordCount.Text = "Total Records: " + dtSearchRole.Rows.Count.ToString();
                    //dvSearchRole = dtSearchRole.DefaultView;

                    //if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(""))
                    //{
                    //    dvSearchRole.Sort = this.ViewState["SortExp"].ToString()
                    //             + " " + this.ViewState["SortOrder"].ToString();
                    //}

                    //lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows.Count.ToString();
                    grdRole.DataSource = dtSearchRole;
                    grdRole.DataBind();
                    lblRecordCount.Text = "Total Records: " + dtSearchRole.Rows[0]["TotalRecord"].ToString();
                    if (int.Parse(dtSearchRole.Rows[0]["TotalRecord"].ToString()) % PageSize > 0)
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(dtSearchRole.Rows[0]["TotalRecord"].ToString()) / PageSize);
                    }
                    else
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(dtSearchRole.Rows[0]["TotalRecord"].ToString()) / PageSize) - 1;
                    }
                    //ShowTotalNumberOfRecords();
                    ShowPageNumbers();
                    ShowPagingLinks();
                    //PagingRow.Visible = true;
                    PagingRow.Style.Add("display", "block");                   
                    btnAddRole.Visible = true;
                    btnRoleView.Visible = true;
                }
                else
                {
                    //lblRecordCount.Text = "Total Records: 0";
                    lblRecordCount.Text = "Total Records: 0";
                    grdRole.DataSource = null;
                    grdRole.DataBind();
                    CurrentPage = 0;
                    ViewState["CurrentPage"] = null;
                    PagingRow.Style.Add("display", "none");
                    dtSearchRole = null;                   
                    btnRoleView.Visible = false;
                }
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.SearchRole_BindRoleGridData);
            }
        }

        #endregion

        #region Events
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {

                if (!IsPostBack)
                {
                    if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                        Response.Redirect("NotAuthorized.aspx", false);

                    this.gduModel = new GDUModel();
                    btnRoleView.Visible = false;
                }
                else
                {
                    searchBoxDiv.Style.Add("display", searchBoxDivStatus.Value);

                    if (searchBoxDivStatus.Value == "none")
                    {
                        searchBox.Src = "../images/plus.gif";
                        searchBoxHd.Attributes.Add("class", "closed");
                    }
                    else
                    {
                        searchBox.Src = "../images/minus.gif";
                        searchBoxHd.Attributes.Add("class", "");
                    }

                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchRole_Page_Load));
                //throw Common.HandleException(ex, Common.MethodName.SearchRole_Page_Load);
            }
        }

        /// <summary>
        /// This event will search role records
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                ViewState["SortExp"] = "CLIENT_NM";
                ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                CurrentPage = 0;
                this.BindRoleGridData();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchRole_Search_Click));
            }
        }
        /// <summary>
        /// This event will be used for view role records
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void btnRoleView_Click(object sender, EventArgs e)
        {
            string roleID;
            string clientCode;

            try
            {
                foreach (GridViewRow grdRoleRow in grdRole.Rows)
                {
                    RadioButton rbCheck = (RadioButton)grdRoleRow.FindControl("rdobutton");
                    Label lblID = (Label)grdRoleRow.FindControl("lblID");
                    Label lblclientCode = (Label)grdRoleRow.FindControl("lblclientCode");
                    if (rbCheck.Checked == true)
                    {
                        roleID = Convert.ToString(lblID.Text);
                        clientCode = Convert.ToString(lblclientCode.Text);
                        Response.Redirect("ManageRole.aspx?mode=View&RoleID=" + roleID + "&ClientCode=" + clientCode, false);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchRole_ViewRole));
                //throw Common.HandleException(ex, Common.MethodName.SearchRole_btnRoleView_Click);
            }
        }
        /// <summary>
        /// This event will be used for add role
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void btnAddRole_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageRole.aspx?mode=Add");
        }
        /// <summary>
        /// This is PageIndexChanging event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">GridViewPageEventArgs e</param>
        protected void grdRole_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdRole.PageIndex = e.NewPageIndex;
            this.BindRoleGridData();

        }
        /// <summary>
        /// This is RowDataBound event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">GridViewRowEventArgs e</param>
        protected void grdRole_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow | e.Row.RowType == DataControlRowType.Header)
                {
                    e.Row.Cells[4].Attributes.Add("class", "last");
                    e.Row.Cells[0].Attributes.Add("class", "first");
                }
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (this.ViewState["SortExp"] == null)
                        this.ViewState["SortExp"] = "";

                    int sortColumnIndex = GetSortColumnIndex(grdRole, this.ViewState["SortExp"].ToString());
                    if (ViewState["SortOrder"].ToString() == "ASC")
                        this.GridViewSortDirection = SortDirection.Ascending;
                    else
                        this.GridViewSortDirection = SortDirection.Descending;
                    AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
                }

            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchRole_grid_RowDataBound));
                //throw Common.HandleException(ex, Common.MethodName.SearchRole_grdRole_RowDataBound);
            }
        }
        /// <summary>
        /// This is Sorting event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">GridViewSortEventArgs e</param>
        protected void grdRole_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                CurrentPage = 0;
                ViewState["CurrentPage"] = null;
                if (this.GridViewSortDirection == SortDirection.Ascending)
                {
                    this.GridViewSortDirection = SortDirection.Descending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
                    //===========================
                    if (Convert.ToString(ViewState["SortExp"]) != e.SortExpression)
                    {
                        this.GridViewSortDirection = SortDirection.Ascending;
                        ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                    }
                    //===========================
                }
                else
                {
                    this.GridViewSortDirection = SortDirection.Ascending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                }
                ViewState["SortExp"] = e.SortExpression;
                this.BindRoleGridData();
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.SearchRole_grdRole_Sorting);
            }
        }

        /// <summary>
        /// This is used to retrieve sorted column index no.
        /// </summary>
        /// <param name="gridObject">This is the grid view object.</param>
        /// <param name="sortExpression">This is the sort expression.</param>
        /// <returns>int</returns>
        public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        {
            string sortExpressionString = null;
            foreach (DataControlField field in gridObject.Columns)
            {
                if (sortExpression != string.Empty)
                {
                    sortExpressionString = sortExpression.ToString();
                }

                if (field.SortExpression == sortExpressionString)
                {
                    return gridObject.Columns.IndexOf(field);
                }
            }

            return -1;
        }

        /// <summary>
        /// This will set the Up/Down image for sorted column.
        /// </summary>
        /// <param name="columnIndex">This is the column index.</param>
        /// <param name="headerRow">This is the grid view header row.</param>
        /// <param name="strgrdSortDirection">This is the sort direction.</param>
        public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        {
            if (columnIndex == -1)
            {
                return;
            }

            if (strgrdSortDirection == SortDirection.Ascending)
            {
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
            }
            else
            {
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
            }
        }

        public int CurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object current = this.ViewState["CurrentPage"];
                if (current == null)
                    return 0; // default page index of 0 
                else
                    return (int)current;
            }
            set
            {
                this.ViewState["CurrentPage"] = value;
            }
        }
        protected void LinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage = 0;
            BindRoleGridData();
        }
        protected void LinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            CurrentPage -= 1;
            BindRoleGridData();
        }
        protected void LinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage += 1;
            BindRoleGridData();
        }
        protected void LinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            CurrentPage = int.Parse(ViewState["TotalPages"].ToString());
            BindRoleGridData();
        }
        //To show total page numbers 
        //private void ShowTotalNumberOfRecords()
        //{
        //    int i, j;
        //    if (CurrentPage == 0)
        //        i = 1;
        //    else
        //        i = (CurrentPage * PageSize) + 1;
        //    LabelPageFirstRecord.Text = i.ToString();
        //    if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
        //        LabelPageLastRecord.Text = LabelTotalRecords.Text;
        //    else
        //    {
        //        j = ((CurrentPage + 1) * PageSize);
        //        LabelPageLastRecord.Text = j.ToString();
        //    }
        //}
        //To show current page number 
        private void ShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (CurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (CurrentPage > (int.Parse(ViewState["TotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["TotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["TotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = CurrentPage - 1;
                endPageNumber = CurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (CurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["TotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            CurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindRoleGridData();
        }
        private void ShowPagingLinks()
        {
            if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
            {
                LinkButtonNext.Enabled = false;
                LinkButtonLast.Enabled = false;
            }
            else
            {
                LinkButtonNext.Enabled = true;
                LinkButtonLast.Enabled = true;
            }
            if (CurrentPage == 0)
            {
                LinkButtonPrevious.Enabled = false;
                LinkButtonFirst.Enabled = false;
            }
            else
            {
                LinkButtonPrevious.Enabled = true;
                LinkButtonFirst.Enabled = true;
            }
        }
        #endregion
    }

}