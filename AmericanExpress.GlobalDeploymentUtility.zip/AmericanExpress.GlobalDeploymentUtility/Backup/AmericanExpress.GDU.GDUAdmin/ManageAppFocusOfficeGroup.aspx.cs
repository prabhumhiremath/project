﻿//-----------------------------------------------------------------------
// <copyright file="ManageUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Manages user creation/addition/deactivation</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

namespace AmericanExpress.GDU.GDUAdmin
{
    #region Page level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU;
    using AmericanExpress.GDU.Model;
    using System.Collections.Generic;
    using System.Security.Principal;
    using AmericanExpress.GDU.Utilities.Diagnostics;

    #endregion
    public partial class ManageAppFocusOfficeGroup : System.Web.UI.Page
    {
        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        string GroupName = null;
        int GroupCode = 0;
        string UserId = string.Empty;
        string ReturnResult = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                this.gduModel = new GDUModel();
                txtGroupName.Enabled = false;
                txtGroupName.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                if (!Page.IsPostBack)
                {
                    if (Request.QueryString[AdmConstants.MODE].ToString().ToUpper().Equals("ADD"))
                    {
                        this.ShowHideButton(AdmConstants.CRUD_MODE.ADD);
                        ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ADD.ToString();
                        txtGroupName.Enabled = true;

                    }
                    else
                    {
                        this.ShowHideButton(AdmConstants.CRUD_MODE.UPDATE);
                        ViewState["ID"] = Request.QueryString["GROUPID"].ToString();
                        this.PopulateControls(Convert.ToInt16(ViewState["ID"]));
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_AppfFocusOfficeGroup_Page_Load));
                //throw ex;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            // this.ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ADD.ToString();
            if (Session[AdmConstants.IS_DEACTIVE] != null)
            {
                if (Session[AdmConstants.IS_DEACTIVE].Equals(true))
                {
                    if (btnSave.Text == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                    {
                        this.ViewState[AdmConstants.MODE] = btnSave.Text;
                    }
                }
            }

            if (!string.IsNullOrEmpty(txtGroupName.Text.Trim()))
            {
                GroupName = txtGroupName.Text.Trim();
            }
            GroupCode = Convert.ToInt16(ViewState["ID"]);
            UserId = GetUserName();
            ReturnResult = ManageAppFGroup(GroupName, GroupCode, UserId, Convert.ToString(this.ViewState[AdmConstants.MODE]));
            if (!string.IsNullOrEmpty(ReturnResult))
            {
                lblMsgPanel.Text = ReturnResult;
                txtGroupName.Enabled = true;
                this.ShowHideButton(AdmConstants.CRUD_MODE.ADD);
            }
            else
            {
                Response.Redirect("SearchAppFocusOfficeGroup.aspx",false);
            }

        }
        protected void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (btnModify.Text.ToUpper() == "MODIFY")
                {
                    txtGroupName.Enabled = true;
                    btnDelete.Visible = false;
                    btnModify.Text = AdmConstants.CRUD_MODE.UPDATE.ToString();
                    ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.UPDATE.ToString();
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtGroupName.Text.Trim()))
                    {
                        GroupName = txtGroupName.Text.Trim();
                    }
                    GroupCode = Convert.ToInt16(ViewState["ID"]);
                    UserId = GetUserName();
                    ReturnResult = ManageAppFGroup(GroupName, GroupCode, UserId, Convert.ToString(this.ViewState[AdmConstants.MODE]));
                    if (!string.IsNullOrEmpty(ReturnResult))
                    {
                        lblMsgPanel.Text = ReturnResult;
                        txtGroupName.Enabled = true;
                        this.ShowHideButton(AdmConstants.CRUD_MODE.UPDATE);
                    }
                    else
                    {
                        Response.Redirect("SearchAppFocusOfficeGroup.aspx");
                    }
                }
            }

            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GDU_AppfFocusOfficeGroup_Save_Click));
                string errmsg = ex.Message;
                lblMsgPanel.Text = errmsg;
            }
        }
        #region "Methods"
        private string ManageAppFGroup(string GroupName, int ID, string UserID, string ActionMode)
        {
            string status = string.Empty;
            status = this.gduModel.ManageAppFOfficeGroup(GroupName, ID, UserID, ActionMode);
            return status;
        }
        private void PopulateControls(int OfficeCode)
        {
            try
            {
                DataTable GroupDetail = this.GetAppOfficeGroupDetails(OfficeCode);
                if (GroupDetail != null)
                {

                    txtGroupName.Text = GroupDetail.Rows[0]["GROUP_NM"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private DataTable GetAppOfficeGroupDetails(int ID)
        {
            DataTable OfficeDetail = this.gduModel.GetAppFocusOfficeGroupDetails(ID, 0, 5000, "GROUP_NM", "ASC");
            if (OfficeDetail.Rows.Count > 0)
            {
                return OfficeDetail;
            }
            else
            {
                return null;
            }
        }

        private void ShowHideButton(AdmConstants.CRUD_MODE mode)
        {

            if (mode == AdmConstants.CRUD_MODE.ADD)
            {
                btnSave.Visible = true;
                btnModify.Visible = false;
                btnDelete.Visible = false;
            }
            else
            {
                bool IsDeactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                if (IsDeactive)
                {
                    btnSave.Text = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                    ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                    btnDelete.Visible = false;
                    btnModify.Visible = false;
                }
                else
                {
                    btnSave.Visible = false;

                }
                //btnSave.Visible = false;
                //btnModify.Visible = true;
            }
        }

        private string GetUserName()
        {
            string UserName = string.Empty;
            try
            {
                UserName = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return UserName;
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.DEACTIVATE.ToString();
            this.btnSave_Click(sender, e);
        }

        #endregion


    }
}
