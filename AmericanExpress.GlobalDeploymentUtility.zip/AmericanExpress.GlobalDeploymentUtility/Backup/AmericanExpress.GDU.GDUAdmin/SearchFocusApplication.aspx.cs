﻿//-----------------------------------------------------------------------
// <copyright file="SearchUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Renders Search user UI   </Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

namespace AmericanExpress.GDU.GDUAdmin
{
    #region Page Level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    #endregion

    /// <summary>
    /// Search User class
    /// </summary>
    public partial class SearchFocusApplication : System.Web.UI.Page
    {

        #region variables
        /// <summary>
        /// Constant string
        /// </summary>
        public const string APP_NAME = "APP_ID";

        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        protected int currentPage, pageSize, startRecord;
        int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"].ToString());

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {
                txtAppName.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                if (!IsPostBack)
                {

                    //if (global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);
                    btnAppView.Visible = false;
                }
                else
                {
                    searchBoxDiv.Style.Add("display", searchBoxDivStatus.Value);
                    if (searchBoxDivStatus.Value == "none")
                    {
                        searchBox.Src = "../images/plus.gif";
                        searchBoxHd.Attributes.Add("class", "closed");
                    }
                    else
                    {
                        searchBox.Src = "../images/minus.gif";
                        searchBoxHd.Attributes.Add("class", string.Empty);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchAPPF_Application_Page_Load));

            }
        }
        public void Page_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError().GetBaseException();
            String requestPath = Request.Url.ToString();
        }
        protected void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                ////===========================
                ViewState["SortExp"] = APP_NAME;
                ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                ////===========================
                CurrentPage = 0;
                this.BindGridData();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchAPPF_Application_Search_Click));
            }
        }

        protected void btnAppView_Click(object sender, EventArgs e)
        {
            string AppID = string.Empty;
            try
            {
                foreach (GridViewRow grdFocusAppRow in grdFocusApp.Rows)
                {
                    RadioButton radioCheck = (RadioButton)grdFocusAppRow.FindControl("rdobutton");
                    if (radioCheck.Checked)
                    {
                        AppID = grdFocusApp.DataKeys[grdFocusAppRow.RowIndex].Value.ToString();
                        break;
                    }
                }

                Response.Redirect("ManageFocusApplication.aspx?MODE=VIEW&APPID=" + AppID, false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void grdFocusApp_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdFocusApp.PageIndex = e.NewPageIndex;
            this.BindGridData();
        }


        protected void grdFocusApp_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                CurrentPage = 0;
                ViewState["CurrentPage"] = null;
                if (this.GridViewSortDirection == SortDirection.Ascending)
                {
                    this.GridViewSortDirection = SortDirection.Descending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
                }
                else
                {
                    this.GridViewSortDirection = SortDirection.Ascending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                }

                ViewState["SortExp"] = e.SortExpression;
                this.BindGridData();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region methods
        protected void BindGridData()
        {
            this.gduModel = new GDUModel();
            string AppName = string.Empty;

            try
            {
                AppName = string.IsNullOrEmpty(txtAppName.Text.Trim()) ? null : txtAppName.Text.Trim();
                DataTable searchAppFocus = this.gduModel.SearchFocusApplication(txtAppName.Text, CurrentPage, PageSize, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());
                DataView search = new DataView();
                if (searchAppFocus.Rows.Count > 0)
                {
                    //lblRecordCount.Text = "Total Records: " + searchAppFocus.Rows.Count.ToString();
                    //search = searchAppFocus.DefaultView;
                    //if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(string.Empty))
                    //{
                    //    search.Sort = this.ViewState["SortExp"].ToString()
                    //             + " " + this.ViewState["SortOrder"].ToString();
                    //}

                    grdFocusApp.DataSource = searchAppFocus;
                    grdFocusApp.DataBind();
                    lblRecordCount.Text = "Total Records: " + searchAppFocus.Rows[0]["TotalRecord"].ToString();
                    if (int.Parse(searchAppFocus.Rows[0]["TotalRecord"].ToString()) % PageSize > 0)
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(searchAppFocus.Rows[0]["TotalRecord"].ToString()) / PageSize);
                    }
                    else
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(searchAppFocus.Rows[0]["TotalRecord"].ToString()) / PageSize) - 1;
                    }
                    //ShowTotalNumberOfRecords();
                    ShowPageNumbers();
                    ShowPagingLinks();
                    //PagingRow.Visible = true;
                    PagingRow.Style.Add("display", "block");
                    btnAppView.Visible = true;
                }
                else
                {
                    lblRecordCount.Text = "Total Records: 0";
                    grdFocusApp.DataSource = null;
                    grdFocusApp.DataBind();
                    CurrentPage = 0;
                    ViewState["CurrentPage"] = null;
                    PagingRow.Style.Add("display", "none");

                    btnAppView.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                {
                    ViewState["sortDirection"] = SortDirection.Ascending;
                }

                return (SortDirection)ViewState["sortDirection"];
            }

            set { ViewState["sortDirection"] = value; }
        }
        /// <summary>
        /// This is used to retrieve sorted column index no.
        /// </summary>
        /// <param name="gridObject">This is the grid view object.</param>
        /// <param name="sortExpression">This is the sort expression.</param>
        /// <returns>int</returns>
        public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        {
            string sortExpressionString = null;
            foreach (DataControlField field in gridObject.Columns)
            {
                if (sortExpression != string.Empty)
                {
                    sortExpressionString = sortExpression.ToString();
                }

                if (field.SortExpression == sortExpressionString)
                {
                    return gridObject.Columns.IndexOf(field);
                }
            }

            return -1;
        }
        public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        {
            if (columnIndex == -1)
            {
                return;
            }

            if (strgrdSortDirection == SortDirection.Ascending)
            {
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
            }
            else
            {
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
            }
        }
        #endregion


        protected void grdFocusApp_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataRowView drv = null;
            drv = (DataRowView)e.Row.DataItem;
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow | e.Row.RowType == DataControlRowType.Header)
                {
                    e.Row.Cells[2].Attributes.Add("class", "last");
                    e.Row.Cells[0].Attributes.Add("class", "first");
                }

                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (this.ViewState["SortExp"] == null)
                    {
                        this.ViewState["SortExp"] = string.Empty;
                    }

                    int sortColumnIndex = GetSortColumnIndex(grdFocusApp, this.ViewState["SortExp"].ToString());
                    AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int CurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object current = this.ViewState["CurrentPage"];
                if (current == null)
                    return 0; // default page index of 0 
                else
                    return (int)current;
            }
            set
            {
                this.ViewState["CurrentPage"] = value;
            }
        }
        protected void LinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage = 0;
            BindGridData();
        }
        protected void LinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            CurrentPage -= 1;
            BindGridData();
        }
        protected void LinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage += 1;
            BindGridData();
        }
        protected void LinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            CurrentPage = int.Parse(ViewState["TotalPages"].ToString());
            BindGridData();
        }
        //To show total page numbers 
        //private void ShowTotalNumberOfRecords()
        //{
        //    int i, j;
        //    if (CurrentPage == 0)
        //        i = 1;
        //    else
        //        i = (CurrentPage * PageSize) + 1;
        //    LabelPageFirstRecord.Text = i.ToString();
        //    if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
        //        LabelPageLastRecord.Text = LabelTotalRecords.Text;
        //    else
        //    {
        //        j = ((CurrentPage + 1) * PageSize);
        //        LabelPageLastRecord.Text = j.ToString();
        //    }
        //}
        //To show current page number 
        private void ShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (CurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (CurrentPage > (int.Parse(ViewState["TotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["TotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["TotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = CurrentPage - 1;
                endPageNumber = CurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (CurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["TotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            CurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindGridData();
        }
        private void ShowPagingLinks()
        {
            if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
            {
                LinkButtonNext.Enabled = false;
                LinkButtonLast.Enabled = false;
            }
            else
            {
                LinkButtonNext.Enabled = true;
                LinkButtonLast.Enabled = true;
            }
            if (CurrentPage == 0)
            {
                LinkButtonPrevious.Enabled = false;
                LinkButtonFirst.Enabled = false;
            }
            else
            {
                LinkButtonPrevious.Enabled = true;
                LinkButtonFirst.Enabled = true;
            }
        }

    }
}
