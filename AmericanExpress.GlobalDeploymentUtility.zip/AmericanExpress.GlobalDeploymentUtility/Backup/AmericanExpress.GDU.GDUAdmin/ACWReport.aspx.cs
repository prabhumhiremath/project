﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using AmericanExpress.GDU;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class ACWReport : System.Web.UI.Page
    {
        GDUModel _gduModal;
        DataTable _dtDataTable;
        DataTable _dtDataTableDetails;

        const string LABEL = "UserName";
        public string strUserName = string.Empty;
        public string strVersion = string.Empty;
        protected string HdnUserIds = string.Empty;
        Boolean Flag = true;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _gduModal = new GDUModel();
                _dtDataTable = new DataTable();
                _dtDataTableDetails = new DataTable();

                if (!IsPostBack)
                {
                    PopulateOfficeGroups();
                    BindFocusReportOfficeID();

                }
            }
            catch (Exception ex)
            {
            }
        }
        /// <summary>
        /// populate virtual country
        /// </summary>
        private void PopulateOfficeGroups()
        {
            _gduModal = new GDUModel();
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict = _gduModal.PopulateAppFGroup(string.Empty, 0, "Virtual");
            ddlAPPFOfficeGroup.DataSource = dict;
            ddlAPPFOfficeGroup.DataTextField = "Value";
            ddlAPPFOfficeGroup.DataValueField = "Key";
            this.ddlAPPFOfficeGroup.DataBind();
            this.ddlAPPFOfficeGroup.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "0"));
        }

        protected void ddlAPPFOfficeGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

            BindFocusReportOfficeID();
            ClearControls();

            if (ddlAPPFOfficeGroup.SelectedIndex == 0)
            {
                ddlOfficeID.SelectedIndex = 0;
                txtUser.ReadOnly = false;
            }
            else
            {

                ddlOfficeID.SelectedIndex = 0;
                txtUser.ReadOnly = true;
            }


        }
        private void ClearControls()
        {
            txtUser.Text = "";

        }
        private void DownloadFile(string fname, bool forceDownload)
        {
            string path = MapPath(fname);
            string name = Path.GetFileName(path);
            string ext = Path.GetExtension(path);
            string type = "";
            // set known types based on file extension  
            if (ext != null)
            {
                switch (ext.ToLower())
                {
                    case ".htm":
                    case ".html":
                        type = "text/HTML";
                        break;

                    case ".txt":
                        type = "text/plain";
                        break;

                    case ".doc":
                    case ".rtf":
                        type = "Application/msword";
                        break;
                }
            }
            if (forceDownload)
            {
                Response.AppendHeader("content-disposition",
                    "attachment; filename=" + name);
            }
            if (type != "")
                Response.ContentType = type;
            Response.WriteFile(path);
            //Response.End();
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                BindCSV();
                if (Flag == true)
                {
                    //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('In condition true!');", true);
                    if (null != _dtDataTable && _dtDataTable.Rows.Count > 0)
                    {
                        CreateCSV(@"AppToDownload\ACW.csv", _dtDataTable);
                        string filePath = Server.MapPath(@"AppToDownload\ACW.csv");
                        System.IO.FileInfo fileInfo = new System.IO.FileInfo(filePath);
                        Response.ContentType = "application/vnd.ms-excel";
                        Response.AddHeader("Content-Disposition", "attachment;filename=ACW.csv");
                        Response.AddHeader("Content-Length", fileInfo.Length.ToString());
                        Response.WriteFile(filePath);
                        //Response.End();
                        HttpContext.Current.ApplicationInstance.CompleteRequest();
                    }

                    //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('After Create CSV!');", true);
                    //CreateCSV(@"C:\Program Files\ACW.csv", _dtDataTable);
                    //System.Diagnostics.Process.Start(@"C:\Program Files\ADP.csv");
                    
                    //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('End of In condition true!');", true);
                }
                else
                {
                    this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('There is no data for selected criteria!');", true);
                }
                //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW1", "alert('After Else');", true);

            }
            catch (Exception ex)
            {
                //string message = ex.Message;
                //lblerrorMsg.Text = message;
                //lblerrorMsg.Visible = true;
                //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW2", "alert('In final catch');", true);
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Search_Click));

            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ddlApplication.SelectedIndex = 0;
            ddlAPPFOfficeGroup.SelectedIndex = 0;
            BindFocusReportOfficeID();
            txtUser.Text = "";
            hdnUser.Value = "";
            ddlOfficeID.SelectedIndex = 0;
            txtDateFrom.Text = string.Empty;
            txtDateTo.Text = string.Empty;
        }

        private void CreateCSV(string strFilePath, DataTable dt)
        {
            //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('Inside CreateCSV!');", true);
            // Create the CSV file to which data will be exported.
            StreamWriter sw = new StreamWriter(Server.MapPath(strFilePath), false);
            // First we will write the headers.
            try
            {
            int iColCount = dt.Columns.Count;
            if (iColCount>0)
            {
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(dt.Columns[i]);
                if (i < iColCount - 1)
                {
                    sw.Write(",");
                }
            }

            sw.Write(sw.NewLine);
            // Now write all the rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        sw.Write(dr[i].ToString());
                    }
                    if (i < iColCount - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
            }
            }
            catch (Exception ex)
            {
                //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW67", "alert('CSV didnt work!');", true);
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Search_Click));

            }
            

        }
        private void BindCSV()
        {
            string fromDate = string.Empty;
            string toDate = string.Empty;
            string App_Name = string.Empty;
            string Office_Id = string.Empty;

            int Office_GroupId;

            if (hdnUser.Value == "" || hdnUser.Value == null)
                strUserName = null;
            else
                strUserName = hdnUser.Value.Split('-')[0].ToString();

            if (ddlApplication.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                App_Name = null;
            else
                App_Name = string.Empty;//"Travel Suite"; //ddlApplication.SelectedValue.ToString();

            //if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
            //    Office_Id = null;
            //else
            //    Office_Id = ddlOfficeID.SelectedValue.ToString();

            if (hiddenOfficeId.Value == "1")
            {
                Office_GroupId = 0;
                if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    Office_Id = null;
                else
                    Office_Id = ddlOfficeID.SelectedValue.ToString();
            }
            else
            {
                Office_Id = null;
                Office_GroupId = Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue.ToString());
            }

            if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                fromDate = txtDateFrom.Text.Trim();
            }

            if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
            {
                toDate = txtDateTo.Text.Trim();
            }
            else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                toDate = System.DateTime.Now.ToShortDateString();
            }
            //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW3", "alert('Before try!');", true);
            try
            {
                //_dtDataTable = _gduModal.GetTravelSuiteAppFocusReportTable(strUserName, App_Name, fromDate, toDate, Office_Id, Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue.ToString()));
                _dtDataTable = _gduModal.GetACWReportDetails(App_Name, fromDate, toDate, Office_Id, strUserName, Office_GroupId);
                //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW4", "alert('After request process!');", true);
                if ( _dtDataTable == null || _dtDataTable.Rows.Count == 0)
                {
                    //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW8", "alert('False Alert!');", true);
                    Flag = false;
                    
                }
                else
                {
                    //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW9", "alert('True Alert!');", true);
                    Flag = true;
                    
                }

            }
            catch (Exception ex)
            {
                //this.ClientScript.RegisterStartupScript(this.GetType(), "ACW5", "alert('In Catch BindCSV!');", true);
                Flag = false;
                Label lbl = (Label)Master.FindControl("lblMsgPanel");
                string errmsg = ex.Message;
                lbl.Text = errmsg;
                throw ex;
            }


        }
        private void ClearControls(Control control)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                ClearControls(control.Controls[i]);
            }
            if (!(control is TableCell))
            {
                if (control.GetType().GetProperty("SelectedItem") != null)
                {
                    LiteralControl literal = new LiteralControl();
                    control.Parent.Controls.Add(literal);
                    try
                    {
                        literal.Text = (string)control.GetType().GetProperty("SelectedItem").GetValue(control, null);
                    }
                    catch
                    {
                    }
                    control.Parent.Controls.Remove(control);
                }
                else
                    if (control.GetType().GetProperty("Text") != null)
                    {
                        LiteralControl literal = new LiteralControl();
                        control.Parent.Controls.Add(literal);
                        literal.Text = (string)control.GetType().GetProperty("Text").GetValue(control, null);
                        control.Parent.Controls.Remove(control);
                    }
            }
            return;
        }

        public override void VerifyRenderingInServerForm(Control control) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="allowPaging"></param>
        //private void BindGrid(bool allowPaging)
        //{
        //    string fromDate = string.Empty;
        //    string toDate = string.Empty;
        //    string App_Name = string.Empty;
        //    string Office_Id = string.Empty;

        //    if (hdnUser.Value == "" || hdnUser.Value == null)
        //        strUserName = null;
        //    else
        //        strUserName = hdnUser.Value.Split('-')[0].ToString();

        //    if (ddlApplication.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
        //        App_Name = null;
        //    else
        //        App_Name = "Travel Suite"; //ddlApplication.SelectedValue.ToString();

        //    if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
        //        Office_Id = null;
        //    else
        //        Office_Id = ddlOfficeID.SelectedValue.ToString();

        //    if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
        //    {
        //        fromDate = txtDateFrom.Text.Trim();
        //    }

        //    if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
        //    {
        //        toDate = txtDateTo.Text.Trim();
        //    }
        //    else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
        //    {
        //        toDate = System.DateTime.Now.ToShortDateString();
        //    }

        //    try
        //    {
        //        _dtDataTable = _gduModal.GetTravelSuiteAppFocusReportTable(strUserName, App_Name, fromDate, toDate, Office_Id, Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue.ToString()));

        //        if (_dtDataTable.Rows.Count > 0)
        //        {
        //           // lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows.Count.ToString();
        //            //btnExport.Visible = true;
        //          //  btnExport.Style.Add("display", "block");
        //        }
        //        else
        //        {
        //           // lblRecordCount.Text = "Total Records: 0";
        //            //btnExport.Visible = false;
        //           // btnExport.Style.Add("display", "none");
        //        }
        //        return;
        //        //DataRow[] dtRow = _dtDataTable.Select("Version <> ''");
        //        //BindingGridControl(allowPaging);
        //    }
        //    catch (Exception ex)
        //    {
        //        Label lbl = (Label)Master.FindControl("lblMsgPanel");
        //        string errmsg = ex.Message;
        //        lbl.Text = errmsg;
        //    }

        //    //Show the visibility   
        //   // this.pnlReport.Visible = true;
        //   // this.pnlButtonRow.Visible = true;


        //}

        /// <summary>
        /// binding repeater control.
        /// </summary>
        //private void BindingGridControl(bool allowPaging)
        //{
        //   // grdAppFocusReport.EmptyDataText = "There is no record.";
        //    DataView dvSearch = new DataView();
        //    dvSearch = _dtDataTable.DefaultView;

        //    if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(""))
        //    {
        //        dvSearch.Sort = this.ViewState["SortExp"].ToString()
        //                 + " " + this.ViewState["SortOrder"].ToString();
        //    }

        //   // grdAppFocusReport.AllowPaging = allowPaging;
        //    if (allowPaging)
        //    {
        //       // grdAppFocusReport.PageSize = 20;
        //    }

        //    //grdAppFocusReport.DataSource = dvSearch;
        //    //grdAppFocusReport.DataBind();
        //}

        //protected void grdAppFocusReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    //grdAppFocusReport.PageIndex = e.NewPageIndex;
        //    //BindGrid(true);

        //}

        //protected void grdAppFocusReport_Sorting(object sender, GridViewSortEventArgs e)
        //{
        //    try
        //    {
        //        if (this.GridViewSortDirection == SortDirection.Ascending)
        //        {
        //            this.GridViewSortDirection = SortDirection.Descending;
        //            ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
        //        }
        //        else
        //        {
        //            this.GridViewSortDirection = SortDirection.Ascending;
        //            ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
        //        }
        //      //  grdAppFocusReport.PageIndex = 0;
        //        ViewState["SortExp"] = e.SortExpression;
        //        //BindGrid(true);
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        //protected void grdAppFocusReport_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    DataRowView drv = null;
        //    drv = (DataRowView)e.Row.DataItem;
        //    try
        //    {
        //        //if (e.Row.RowType == DataControlRowType.DataRow | e.Row.RowType == DataControlRowType.Header)
        //        //{
        //        //    e.Row.Cells[2].Attributes.Add("class", "last");
        //        //    e.Row.Cells[0].Attributes.Add("class", "first");
        //        //    //e.Row.Cells[5].Style.Add("word-break", "break-all");
        //        //    //e.Row.Cells[5].Width = 100;
        //        //    //e.Row.Cells[6].Style.Add("word-break", "break-all");
        //        //    //e.Row.Cells[6].Width = 100;
        //        //}
        //        if (e.Row.RowType == DataControlRowType.Header)
        //        {
        //            if (this.ViewState["SortExp"] == null)
        //                this.ViewState["SortExp"] = "";

        //           // int sortColumnIndex = GetSortColumnIndex(grdAppFocusReport, this.ViewState["SortExp"].ToString());
        //           // AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_grid_RowDataBound));

        //    }
        //}

        /// <summary>
        /// GridViewSortDirection
        /// </summary>
        //public SortDirection GridViewSortDirection
        //{
        //    get
        //    {
        //        if (ViewState["sortDirection"] == null)
        //            ViewState["sortDirection"] = SortDirection.Ascending;
        //        return (SortDirection)ViewState["sortDirection"];
        //    }
        //    set { ViewState["sortDirection"] = value; }
        //}

        /// <summary>
        /// This is used to retrieve sorted column index no.
        /// </summary>
        /// <param name="gridObject">This is the grid view object.</param>
        /// <param name="sortExpression">This is the sort expression.</param>
        /// <returns>int</returns>
        //public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        //{
        //    string sortExpressionString = null;
        //    foreach (DataControlField field in gridObject.Columns)
        //    {
        //        if (sortExpression != "")
        //            sortExpressionString = sortExpression.ToString();

        //        if (field.SortExpression == sortExpressionString)
        //        {
        //            return gridObject.Columns.IndexOf(field);
        //        }
        //    }
        //    return -1;
        //}

        /// <summary>
        /// This will set the Up/Down image for sorted column.
        /// </summary>
        /// <param name="columnIndex">This is the column index.</param>
        /// <param name="headerRow">This is the grid view header row.</param>
        /// <param name="strgrdSortDirection">This is the sort direction.</param>
        //public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        //{
        //    if (columnIndex == -1) return;
        //    if (strgrdSortDirection == SortDirection.Ascending)
        //        headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
        //    else
        //        headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
        //}


        //protected void lnkAppFocusReport_Click(object sender, EventArgs e)
        //{
        //    // Fetch the Record ID            
        //    LinkButton btndetails = sender as LinkButton;
        //    GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
        //    //grdAppFocusReportDetails.PageIndex = 0;
        //    ViewState["ADSID"] = null;
        //    ViewState["UsageDate"] = null;
        // //   ViewState["GroupSeqNo"] = grdAppFocusReport.DataKeys[gvrow.RowIndex].Value.ToString();
        //   // _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(grdAppFocusReport.DataKeys[gvrow.RowIndex].Value.ToString(), "TRAVELSUITE");
        //    if (_dtDataTableDetails.Rows.Count > 0)
        //    {
        //       // lblRecDetailCount.Text = "Total Records : " + _dtDataTableDetails.Rows.Count.ToString();
        //       // grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
        //       // grdAppFocusReportDetails.DataBind();
        //    }
        //    else
        //    {
        //       // grdAppFocusReportDetails.DataSource = null;
        //       // grdAppFocusReportDetails.DataBind();
        //    }

        //    //mpeFocusReportDetail.Show();
        //}

        //protected void lnkUserFocusReport_Click(object sender, EventArgs e)
        //{
        //    LinkButton btndetails = sender as LinkButton;
        //    GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
        //   // grdAppFocusReportDetails.PageIndex = 0;
        //    ViewState["GroupSeqNo"] = null;
        //    ViewState["ADSID"] = btndetails.CommandArgument.ToString();
        //    ViewState["UsageDate"] = gvrow.Cells[6].Text.ToString();

        //    _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(btndetails.CommandArgument.ToString(), gvrow.Cells[6].Text.ToString(), "TRAVELSUITE");

        //    if (_dtDataTableDetails.Rows.Count > 0)
        //    {
        //      //  lblRecDetailCount.Text = "Total Records : " + _dtDataTableDetails.Rows.Count.ToString();
        //       // grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
        //       // grdAppFocusReportDetails.DataBind();
        //    }
        //    else
        //    {
        //        //grdAppFocusReportDetails.DataSource = null;
        //        //grdAppFocusReportDetails.DataBind();
        //    }

        //   // mpeFocusReportDetail.Show();
        //}

        private void BindFocusReportApplicationName()
        {
            try
            {
                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = _gduModal.PopulateFocusReportApplicationName();
                this.ddlApplication.DataSource = objDictonary;
                ddlApplication.DataValueField = AdmConstants.KEY;
                ddlApplication.DataTextField = AdmConstants.VALUE;
                ddlApplication.DataBind();
                ddlApplication.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));


            }
            catch (Exception ex)
            {
            }
        }

        private void BindFocusReportOfficeID()
        {
            try
            {

                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                //objDictonary = _gduModal.PopulateFocusReportOfficeID(Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue));
                objDictonary = _gduModal.PopulateFocusReportOfficeID(Convert.ToInt32("0"));
                this.ddlOfficeID.DataSource = objDictonary;
                ddlOfficeID.DataValueField = AdmConstants.KEY;
                ddlOfficeID.DataTextField = AdmConstants.VALUE;
                ddlOfficeID.DataBind();
                ddlOfficeID.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));

                //_gduModal = new GDUModel();
                //Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                //objDictonary = _gduModal.PopulateFocusReportOfficeID();
                //this.ddlOfficeID.DataSource = objDictonary;
                //ddlOfficeID.DataValueField = AdmConstants.KEY;
                //ddlOfficeID.DataTextField = AdmConstants.VALUE;
                //ddlOfficeID.DataBind();
                //ddlOfficeID.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));
            }
            catch (Exception ex)
            {
            }
        }

        //protected void grdAppFocusReportDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //   // grdAppFocusReportDetails.PageIndex = e.NewPageIndex;

        //    if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
        //        _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE");
        //    else
        //        _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE");

        //    //_dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString());
        //    if (_dtDataTableDetails.Rows.Count > 0)
        //    {
        //       // grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
        //        //grdAppFocusReportDetails.DataBind();
        //    }
        //    else
        //    {
        //       // grdAppFocusReportDetails.DataSource = null;
        //        //grdAppFocusReportDetails.DataBind();
        //    }
        //   // mpeFocusReportDetail.Show();
        //}

        //protected void btnExportReportDetail_Click(object sender, EventArgs e)
        //{
        //    //try
        //    //{
        //    //    Response.ContentType = "application/vnd.ms-excel";
        //    //    Response.AddHeader("Content-Disposition", "attachment;filename=ApplicationFocusDetailedReport.xls");
        //    //    Response.BufferOutput = true;
        //    //    Response.ContentEncoding = System.Text.Encoding.UTF8;
        //    //    Response.Charset = AdmConstants.CHARSET;
        //    //    EnableViewState = false;

        //    //    StringWriter strWriter = new StringWriter();
        //    //    Html32TextWriter htmlWriter = new Html32TextWriter(strWriter);

        //    //    BindAppFocusDetailedReport(false);

        //    //    grdAppFocusReportDetails.RenderControl(htmlWriter);
        //    //    Response.Write(strWriter.ToString());
        //    //    Response.Flush();
        //    //    Response.End();

        //    //    BindAppFocusDetailedReport(true);
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Export_Click));
        //    //}
        //    try
        //    {
        //        Response.Clear();
        //        Response.ContentType = "application/vnd.ms-excel";
        //        Response.AddHeader("Content-Disposition", "attachment;filename=ApplicationUsageReport.xls");
        //        Response.BufferOutput = true;
        //        //Response.Buffer = true;
        //        Response.ContentEncoding = System.Text.Encoding.UTF8;
        //        Response.Charset = "";
        //        EnableViewState = false;
        //        StringWriter strWriter = new StringWriter();
        //        Html32TextWriter htmlWriter = new Html32TextWriter(strWriter);

        //        BindAppFocusDetailedReport(false);
        //       // this.ClearControls(grdAppFocusReportDetails);

        //       // grdAppFocusReportDetails.RenderControl(htmlWriter);
        //        Response.Write(strWriter.ToString());
        //        Response.Flush();
        //        Response.End();

        //        BindAppFocusDetailedReport(true);
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Export_Click));
        //        throw ex;
        //    }
        //}

        //protected void BindAppFocusDetailedReport(bool Paging)
        //{
        //    try
        //    {
        //        if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
        //            _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE");
        //        else
        //            _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE");

        //        //_dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString());
        //        //grdAppFocusReportDetails.AllowPaging = Paging;
        //        if (_dtDataTableDetails.Rows.Count > 0)
        //        {
        //          //  grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
        //          //  grdAppFocusReportDetails.DataBind();
        //        }
        //        else
        //        {
        //          //  grdAppFocusReportDetails.DataSource = null;
        //           // grdAppFocusReportDetails.DataBind();
        //        }
        //       // mpeFocusReportDetail.Show();
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        protected void ddlOfficeID_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateOfficeGroups();
            ddlAPPFOfficeGroup.SelectedIndex = 0;

        }
    }
}

