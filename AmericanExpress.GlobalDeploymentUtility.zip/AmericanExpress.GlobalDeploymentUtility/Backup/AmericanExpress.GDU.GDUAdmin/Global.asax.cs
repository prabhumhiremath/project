﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using AmericanExpress.GDU.Model;
using System.Configuration;
using System.Data;

namespace AmericanExpress.GDU
{

    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {
            GDUModel _gduModel = new GDUModel();
            string userName = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name;
            string userMail = string.Empty;
            string userType = Constants.ADMINUSERTYPE;
            string userGroup = "IBM";
            try
            {
                _gduModel.AddSPUser(userName, userMail, userType, userGroup);
            }
            catch (Exception ex)
            {

            }

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }

        public static bool IsPageAuthorized(string fileName)
        {


            string userId = string.Empty;
            bool isAuthorized = false;
            string System_CD = "GD";

            try
            {

                GDUModel gduModel = new GDUModel();

                userId = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);
                DataTable dtUserMenu = gduModel.GetUserMenu(userId, "CheckMenu", System_CD);
                if (dtUserMenu.Select("FunctionPageUrlTxt like '%" + fileName + "%'").Length > 0)
                    isAuthorized = true;
            }
            catch (Exception ex)
            {

            }

            return isAuthorized;

        }


    }
}