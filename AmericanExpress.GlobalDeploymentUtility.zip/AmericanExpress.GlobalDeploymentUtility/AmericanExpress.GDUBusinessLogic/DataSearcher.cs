﻿//-----------------------------------------------------------------------
// <copyright file="DataSearcher.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class is used for retrieving records on database server.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/04/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.BusinessLogic
{
    #region Namespace
    using System;
    using System.Configuration;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using AmericanExpress.GDU.BusinessInterface;
    using AmericanExpress.GDU.BusinessEntities;
    using AmericanExpress.GDU.Util.DBSchemaHelper;
    using AmericanExpress.GDU.Utilities.ExceptionMgmt;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    #endregion

    /// <summary>
    /// GWiz Business class
    /// </summary>
    public partial class GWizBusiness : IGDUBusinessProvider
    {
        /// <summary>
        /// <Description>This method is to search Link Data.</Description>
        /// </summary>
        /// <param name="input">Search link input</param>
        /// <returns>return search result</returns>
        //public SearchLinkResult[] SearchLinkData(SearchLinkInput input)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    string SharePointFolder = ConfigurationSettings.AppSettings[Constants.CONSTSPFLODER].ToString();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = null;
        //    DataSet ds = new DataSet();
        //    SearchLinkResult[] objSearchLinkResult = null;
        //    ////call admin procedure
        //    try
        //    {
        //        if (input.IsAdmin)
        //        {
        //            if (input.Mode == Constants.CONSTGLOBAL)
        //            {
        //                sp = proc[Constants.CONSTSPGLOBALCATNAME];
        //                sp.Parameters["@inGlobalID"].Value = input.GlobalCode;
        //            }
        //            else if (input.Mode == Constants.CONSTLOCATION)
        //            {
        //                sp = proc[Constants.CONSTSPLOCATIONNAME];
        //                sp.Parameters["@inAccCode"].Value = input.AccountCode;
        //                sp.Parameters["@inCountry"].Value = input.FromCountryCode;
        //                sp.Parameters["@inCity"].Value = input.FromCityCode;
        //                ////sp.Parameters["@inAggRule"].Value = input.AggregationRule;
        //            }
        //            else if (input.Mode == Constants.CONSTCARRIERNAME)
        //            {
        //                sp = proc[Constants.CONSTSPSEARCHCARRIERNAME];
        //                sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //            }
        //            else if (input.Mode == Constants.CONSTOTHERINFO)
        //            {
        //                sp = proc[Constants.CONSTSPOTHERINFONAME];
        //            }
        //        }
        //        ////call client procedure
        //        else
        //        {
        //            if (input.AccountCode.ToString().Contains("ClientSpecific"))
        //            {
        //                DBStoredProcedure sp1 = proc["usp_SearchAccounts"];
        //                DataSet ds1 = new DataSet();
        //                try
        //                {
        //                    sp1.Parameters["@inAccountCode"].Value = null;
        //                    sp1.Parameters["@inAccountName"].Value = null;
        //                    sp1.Parameters["@inActive"].Value = true;
        //                    sp1.Parameters["@inClientID"].Value = Convert.ToInt32(input.AccountCode.Split('-')[1].ToString());
        //                    sp1.Parameters["@inAccountType"].Value = null;
        //                    ds1 = proc.GetDataset(sp1);
        //                    //==================
        //                    sp = proc["usp_SearchResults_ClientSpecific"];
        //                    sp.Parameters["@inAccCode"].Value = ds1.Tables[0].Rows[0]["Account_CD"].ToString();
        //                    sp.Parameters["@inFromCountry"].Value = (input.FromCountryCode == "0" ? string.Empty : input.FromCountryCode);
        //                    sp.Parameters["@inToCountry"].Value = (input.ToCountryCode == "0" ? string.Empty : input.ToCountryCode);
        //                    sp.Parameters["@inFromCity"].Value = (input.FromCityCode == "0" ? string.Empty : input.FromCityCode);
        //                    sp.Parameters["@inToCity"].Value = (input.ToCityCode == "0" ? string.Empty : input.ToCityCode);
        //                    sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //                    sp.Parameters["@inLanguageCD"].Value = input.LanguageCode;
        //                    sp.Parameters["@inLanguageRest"].Value = input.LanguageRest;
        //                    sp.Parameters["@indate"].Value = input.InputDate;
        //                    //==================
        //                }
        //                catch (Exception ex)
        //                {
        //                }
        //            }
        //            else
        //            {
        //                sp = proc[Constants.CONSTSPSEARCHNAME];
        //                sp.Parameters["@inAccCode"].Value = (input.AccountCode == "0" ? string.Empty : input.AccountCode);
        //                sp.Parameters["@inFromCountry"].Value = (input.FromCountryCode == "0" ? string.Empty : input.FromCountryCode);
        //                sp.Parameters["@inToCountry"].Value = (input.ToCountryCode == "0" ? string.Empty : input.ToCountryCode);
        //                sp.Parameters["@inFromCity"].Value = (input.FromCityCode == "0" ? string.Empty : input.FromCityCode);
        //                sp.Parameters["@inToCity"].Value = (input.ToCityCode == "0" ? string.Empty : input.ToCityCode);
        //                sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //                sp.Parameters["@inLanguageCD"].Value = input.LanguageCode;
        //                sp.Parameters["@inLanguageRest"].Value = input.LanguageRest;
        //                sp.Parameters["@indate"].Value = input.InputDate;
        //                ////sp.Parameters["@inAggRule"].Value = input.AggregationRule;
        //            }
        //        }

        //        DataSet dsGetLinkID = new DataSet();
        //        SearchLink[] objSearchLink = null;
        //        SearchLinkDetails[] objSearchLinkDetails = null;
        //        SearchLinkCategoryDetails[] objSearchLinkCategoryDetails = null;
        //        ds = proc.GetDataset(sp);

        //        if (input.Mode == string.Empty)
        //        {
        //            for (int k = 0; k < ds.Tables.Count - 1; k++)
        //            {
        //                for (int i = 0; i < ds.Tables[k].Rows.Count; i++)
        //                {
        //                    if (!string.IsNullOrEmpty(ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString()) && ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString() != "ENG")
        //                    {
        //                        if (ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString() != input.LanguageCode)
        //                        {
        //                            ds.Tables[k].Rows[i].Delete();
        //                            ds.Tables[k].Rows[i].AcceptChanges();
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        objSearchLinkResult = new SearchLinkResult[ds.Tables.Count];
        //        List<int> lstLink = new List<int>();
        //        List<int> lstLinkDetail = new List<int>();

        //        for (int searchLinkResult = 0; searchLinkResult < ds.Tables.Count; searchLinkResult++)
        //        {
        //            objSearchLinkResult[searchLinkResult] = new SearchLinkResult();
        //            objSearchLink = new SearchLink[this.CountSearchLink(ds.Tables[searchLinkResult])];
        //            int link = 0;
        //            foreach (DataRow linkDataRow in ds.Tables[searchLinkResult].Rows)
        //            {
        //                int iLink_ID = Convert.ToInt32(linkDataRow["LINK_ID"]);
        //                if (!lstLink.Contains(iLink_ID))
        //                {
        //                    objSearchLink[link] = new SearchLink();
        //                    DataRow[] linkArray = ds.Tables[searchLinkResult].Select("LINK_ID=" + iLink_ID, "Dtl_Label_NM ASC");

        //                    if (linkArray.Length > 0)
        //                    {
        //                        objSearchLink[link].AccountCode = Convert.ToString(linkArray[0]["ACCOUNT_CD"]);
        //                        objSearchLink[link].CityCode = Convert.ToString(linkArray[0]["City_CD"]);
        //                        objSearchLink[link].CountryCode = Convert.ToString(linkArray[0]["Country_CD"]);
        //                        objSearchLink[link].AccountName = Convert.ToString(linkArray[0]["Account_NM"]);
        //                        objSearchLink[link].CountryName = Convert.ToString(linkArray[0]["Country_NM"]);
        //                        objSearchLink[link].CityName = Convert.ToString(linkArray[0]["City_NM"]);
        //                        if (linkArray[0]["LinkType_CD"].ToString() != Constants.CONSTGENERAL)
        //                        {
        //                            objSearchLink[link].IsGlobalAcc = Convert.ToBoolean(linkArray[0]["IsGlobalAcc"]);
        //                            objSearchLink[link].IsVirtualAcc = Convert.ToBoolean(linkArray[0]["IsVirtualAcc"]);
        //                            objSearchLink[link].IsGlobalCountry = Convert.ToBoolean(linkArray[0]["IsGlobalCountry"]);
        //                            objSearchLink[link].IsVirtualCountry = Convert.ToBoolean(linkArray[0]["IsVirtualCountry"]);
        //                            objSearchLink[link].IsGlobalCity = Convert.ToBoolean(linkArray[0]["IsGlobalCity"]);
        //                            objSearchLink[link].IsVirtualCity = Convert.ToBoolean(linkArray[0]["IsVirtualCity"]);

        //                            // Add 4 columns to Creted and Modified Details
        //                            objSearchLink[link].CreatedUserID = Convert.ToString(linkArray[0]["CREATED_USER_ID"]);
        //                            objSearchLink[link].CreatedUserDate = Convert.ToDateTime(linkArray[0]["CREATED_DT"]);
        //                            objSearchLink[link].ModifiedUserID = Convert.ToString(linkArray[0]["MODIFIED_USER_ID"]);
        //                            objSearchLink[link].ModifiedUserDate = Convert.ToDateTime(linkArray[0]["MODIFIED_DT"]);

        //                        }

        //                        objSearchLink[link].LabelName = string.Empty;
        //                        objSearchLink[link].LinkID = Convert.ToInt32(linkArray[0]["LINK_ID"]);
        //                        objSearchLink[link].IsBrowsable = false;
        //                        objSearchLink[link].GlobalID = Convert.ToInt32(linkArray[0]["Global_ID"] == DBNull.Value ? 0 : linkArray[0]["Global_ID"]);
        //                        objSearchLink[link].GlobalText = string.Empty;
        //                        objSearchLink[link].LabelID = 0;
        //                        objSearchLink[link].CarrierCode = (linkArray[0]["Carrier_CD"] == DBNull.Value ? string.Empty : linkArray[0]["Carrier_CD"]).ToString();
        //                        objSearchLink[link].Rating = 0;
        //                        objSearchLinkDetails = new SearchLinkDetails[this.CountSearchLinkDetail(linkArray)];
        //                        int linkDtl = 0;
        //                        foreach (DataRow drLink in linkArray)
        //                        {
        //                            int iLinkDetail_ID = Convert.ToInt32(drLink["LINK_DTL_ID"]);
        //                            if (!lstLinkDetail.Contains(iLinkDetail_ID))
        //                            {
        //                                objSearchLinkDetails[linkDtl] = new SearchLinkDetails();
        //                                DataRow[] drLinkDetailArray = ds.Tables[searchLinkResult].Select("LINK_ID=" + iLink_ID + " AND LINK_DTL_ID=" + iLinkDetail_ID);

        //                                if (drLinkDetailArray.Length > 0)
        //                                {
        //                                    objSearchLinkDetails[linkDtl].LinkDetailID = Convert.ToInt32(drLinkDetailArray[0]["LINK_DTL_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkTypeCode = Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]);
        //                                    objSearchLinkDetails[linkDtl].LabelName = Convert.ToString(drLinkDetailArray[0]["Dtl_Label_NM"]);

        //                                    if (!string.IsNullOrEmpty(drLinkDetailArray[0]["LINK"].ToString()))
        //                                    {
        //                                        if (drLinkDetailArray[0]["LINK"].ToString().StartsWith(SharePointFolder))
        //                                        {
        //                                            drLinkDetailArray[0]["LINK"] = SharePointURL + drLinkDetailArray[0]["LINK"].ToString();
        //                                        }
        //                                    }

        //                                    ////objSearchLinkDetails[linkDtl].Link = drLinkDetailArray[0]["LINK"] != null ? drLinkDetailArray[0]["LINK"].ToString() : "";////linkArray[0]["LINK"].ToString(); 
        //                                    if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].Link = (drLinkDetailArray[0]["LINK"] != null ? drLinkDetailArray[0]["LINK"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                                    }
        //                                    else
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].Link = drLinkDetailArray[0]["LINK"] != null ? drLinkDetailArray[0]["LINK"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                                    }

        //                                    objSearchLinkDetails[linkDtl].LanguageCode = Convert.ToString(drLinkDetailArray[0]["Dtl_Language_CD"]);
        //                                    objSearchLinkDetails[linkDtl].DownloadFlag = Convert.ToBoolean(drLinkDetailArray[0]["Dtl_Download_Flag"]);
        //                                    objSearchLinkDetails[linkDtl].HoverText = Convert.ToString(drLinkDetailArray[0]["Dtl_Hover_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].GeneralText = Convert.ToString(drLinkDetailArray[0]["General_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].IsAlertRangeVisible = Convert.ToBoolean(drLinkDetailArray[0]["VISIBLE_TO_CLIENT"]);
        //                                    objSearchLinkDetails[linkDtl].Keyword_Txt = Convert.ToString(drLinkDetailArray[0]["KeyWord_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].IsBrowsable = false;
        //                                    objSearchLinkDetails[linkDtl].LabelID = Convert.ToInt32(drLinkDetailArray[0]["Dtl_Label_ID"] != DBNull.Value ? drLinkDetailArray[0]["Dtl_Label_ID"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["Dtl_Label_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkID = Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"] != DBNull.Value ? drLinkDetailArray[0]["LINK_ID"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"]); //Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkType = Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"] != DBNull.Value ? drLinkDetailArray[0]["Dtl_Link_Type"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"]);// Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"]); 
        //                                    objSearchLinkDetails[linkDtl].Rating = 0;
        //                                    objSearchLinkDetails[linkDtl].ValidFromDate = Convert.ToString(drLinkDetailArray[0]["ValidFrom_DT"] != DBNull.Value ? drLinkDetailArray[0]["ValidFrom_DT"] : string.Empty);
        //                                    objSearchLinkDetails[linkDtl].ValidToDate = Convert.ToString(drLinkDetailArray[0]["ValidTo_DT"] != DBNull.Value ? drLinkDetailArray[0]["ValidTo_DT"] : string.Empty);
        //                                    //Add For UserId and Date
        //                                    //-----------------------
        //                                    if (Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]) != Constants.CONSTGENERAL)
        //                                    {

        //                                        objSearchLinkDetails[linkDtl].CreatedUserID = Convert.ToString(drLinkDetailArray[0]["CREATED_USER_ID"]);
        //                                        objSearchLinkDetails[linkDtl].CreatedUserDate = Convert.ToDateTime(drLinkDetailArray[0]["CREATED_DT"]);
        //                                        objSearchLinkDetails[linkDtl].ModifiedUserID = Convert.ToString(drLinkDetailArray[0]["MODIFIED_USER_ID"]);
        //                                        objSearchLinkDetails[linkDtl].ModifiedUserDate = Convert.ToDateTime(drLinkDetailArray[0]["MODIFIED_DT"]);

        //                                    }
        //                                    //-----------------------

        //                                    if (Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]) == Constants.CONSTGENERAL)
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].DisplayValidFromMonth = int.Parse(drLinkDetailArray[0]["DisplayFrom_Month"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidToMonth = int.Parse(drLinkDetailArray[0]["DisplayTo_Month"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidFromDay = int.Parse(drLinkDetailArray[0]["DisplayFrom_Day"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidToDay = int.Parse(drLinkDetailArray[0]["DisplayTo_Day"].ToString());
        //                                    }

        //                                    if (Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]) == "CATEGORY")
        //                                    {
        //                                        objSearchLinkCategoryDetails = new SearchLinkCategoryDetails[this.CountSearchLinkCatDetail(drLinkDetailArray)];
        //                                        int iLinkDtlCat = 0;
        //                                        if (objSearchLinkCategoryDetails.Length > 0)
        //                                        {
        //                                            foreach (DataRow drLinkCatDtl in drLinkDetailArray)
        //                                            {
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat] = new SearchLinkCategoryDetails();

        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkCategoryDetailID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["LINK_CAT_DTL_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LanguageCode = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Language_CD"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].DownloadFlag = Convert.ToBoolean(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Download_Flag"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].HoverText = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Hover_Txt"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].Keyword_Txt = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_KeyWord_Txt"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].IsBrowsable = false;
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LabelID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["Cat_dtl_label_id"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LabelName = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Label_NM"]);


        //                                                //To Add User And Date
        //                                                //--------------------

        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].CreatedUserID = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["CREATED_USER_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].CreatedUserDate = Convert.ToDateTime(drLinkDetailArray[iLinkDtlCat]["CREATED_DT"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].ModifiedUserID = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["MODIFIED_USER_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].ModifiedUserDate = Convert.ToDateTime(drLinkDetailArray[iLinkDtlCat]["MODIFIED_DT"]);

        //                                                //--------------------
        //                                                if (!string.IsNullOrEmpty(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString()))
        //                                                {
        //                                                    if (drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString().StartsWith(SharePointFolder))
        //                                                    {
        //                                                        drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] = SharePointURL + drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString();
        //                                                    }
        //                                                }

        //                                                if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                                                {
        //                                                    objSearchLinkCategoryDetails[iLinkDtlCat].Link = (drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] != null ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                                                }
        //                                                else
        //                                                {
        //                                                    objSearchLinkCategoryDetails[iLinkDtlCat].Link = drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] != null ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                                                }

        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkDetailID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["LINK_DTL_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkType = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link_Type"] != DBNull.Value ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link_Type"] : 0);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].Rating = 0;
        //                                                iLinkDtlCat++;
        //                                            }

        //                                            objSearchLinkDetails[linkDtl].LinkCategoryDetails = objSearchLinkCategoryDetails;
        //                                        }
        //                                    }
        //                                }

        //                                if (!lstLinkDetail.Contains(iLinkDetail_ID))
        //                                {
        //                                    lstLinkDetail.Add(iLinkDetail_ID);
        //                                }

        //                                linkDtl++;
        //                            }
        //                        }

        //                        objSearchLink[link].LinkDetails = objSearchLinkDetails;
        //                    }

        //                    if (!lstLink.Contains(iLink_ID))
        //                    {
        //                        lstLink.Add(iLink_ID);
        //                    }

        //                    link++;
        //                }
        //            }

        //            objSearchLinkResult[searchLinkResult].SearchLnkResult = objSearchLink;
        //            lstLink = new List<int>();
        //            lstLinkDetail = new List<int>();
        //        }

        //        ////std.ResponseCodeStatus = StdResponseCode.Success;
        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        ////try
        //        ////{ 
        //        ////     string message = ExceptionManager.GetErrorMessage(8050);
        //        ////     throw new GenericException(message, 8050);
        //        ////}
        //        ////catch (Exception Ex)
        //        ////{
        //        ////    ExceptionManager.HandleException(Ex, 9000);
        //        ////}

        //        ////GWizException GWizEx = new GWizException();
        //        if (objSearchLinkResult == null)
        //        {
        //            objSearchLinkResult = new SearchLinkResult[3];
        //            objSearchLinkResult[0] = new SearchLinkResult();
        //        }

        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResult[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //        ////objSearchLinkResult = new SearchLinkResult[3];
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objSearchLinkResult;
        //}

        public ManageApplicationDetails[] SearchApplication(ManageApplicationInput input)
        {
            ManageApplicationDetails[] objApplicationDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHAPPLICATION];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@ApplicationNM"].Value = input.ApplicationNM;
                sp.Parameters["@inActive"].Value = !input.IsDeactive;
                sp.Parameters["@ApplicationAbbr"].Value = input.ApplicationAbbr;
                if (input.AppId == null)
                    input.AppId = "0";
                sp.Parameters["@AppId"].Value = input.AppId;

                sp.Parameters["@PageIndex"].Value = input.PageIndex;
                sp.Parameters["@PageSize"].Value = input.PageSize;
                sp.Parameters["@SortColumn"].Value = input.SortColumn;
                sp.Parameters["@SortOrder"].Value = input.SortOrder;


                ds = proc.GetDataset(sp);
                objApplicationDetails = new ManageApplicationDetails[ds.Tables[0].Rows.Count];

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objApplicationDetails[i] = new ManageApplicationDetails();
                    objApplicationDetails[i].ApplicationNM = Convert.ToString(ds.Tables[0].Rows[i]["App_Name"]);
                    objApplicationDetails[i].ApplicationAbbr = Convert.ToString(ds.Tables[0].Rows[i]["App_Abbr_Name"]);
                    objApplicationDetails[i].ApplicationDeployPath = Convert.ToString(ds.Tables[0].Rows[i]["App_Deploy_Path"]);
                    objApplicationDetails[i].AppExeName = Convert.ToString(ds.Tables[0].Rows[i]["App_Exe_Name"]);
                    objApplicationDetails[i].AppType = Convert.ToString(ds.Tables[0].Rows[i]["App_Type"]);
                    objApplicationDetails[i].AppId = Convert.ToInt32(ds.Tables[0].Rows[i]["App_Id"]);
                    objApplicationDetails[i].EntryPoint = Convert.ToString(ds.Tables[0].Rows[i]["EntryPoint"]);
                    objApplicationDetails[i].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objApplicationDetails;
        }

        public AppUserDetails[] SearchAppUsers(AppUserInput input)
        {
            AppUserDetails[] objAppUserDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHAPPUSER];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@UserId"].Value = input.UserId;
                sp.Parameters["@App_ID"].Value = input.App_ID;
                sp.Parameters["@inActive"].Value = !input.IsDeactive;
                sp.Parameters["@InFlag"].Value = input.InFlag;

                sp.Parameters["@PageIndex"].Value = input.PageIndex;
                sp.Parameters["@PageSize"].Value = input.PageSize;
                sp.Parameters["@SortColumn"].Value = input.SortColumn;
                sp.Parameters["@SortOrder"].Value = input.SortOrder;

                ds = proc.GetDataset(sp);
                objAppUserDetails = new AppUserDetails[ds.Tables[0].Rows.Count];

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppUserDetails[i] = new AppUserDetails();
                    objAppUserDetails[i].UserId = Convert.ToString(ds.Tables[0].Rows[i]["ADS_ID"]);
                    objAppUserDetails[i].AppName = Convert.ToString(ds.Tables[0].Rows[i]["App_Name"]);
                    objAppUserDetails[i].Role_CD = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                    objAppUserDetails[i].UserName = Convert.ToString(ds.Tables[0].Rows[i]["USER_NM"]);
                    objAppUserDetails[i].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppUserDetails;
        }


        /// <summary>
        /// <Description>This method is to search Other Info Data.</Description>
        /// </summary>
        /// <param name="input">Search other info input</param>
        /// <returns>return search result</returns>
        //public SearchInfoResult[] SearchOtherInfo(SearchOtherInfoInput input)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    string SharePointFolder = ConfigurationSettings.AppSettings[Constants.CONSTSPFLODER].ToString();
        //    DBStoredProcedure sp = new DBStoredProcedure();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    if (input.Mode == "0")
        //    {
        //        sp = proc[Constants.CONSTSPOTHERINFONAME];
        //        sp.Parameters["@inOtherInfoCode"].Value = input.OtherInfoCode;
        //        sp.Parameters["@inLanguageCD"].Value = input.LanguageCD;
        //        sp.Parameters["@inDate"].Value = input.InputDate;
        //    }
        //    else
        //    {
        //        sp = proc[Constants.CONSTCATEGORYSPADMIN];
        //        sp.Parameters["@inOtherInfoCode"].Value = input.OtherInfoCode;
        //    }

        //    DataSet ds = new DataSet();
        //    SearchInfoResult[] objSearchInfoResult = null;
        //    SearchOtherInfo[] objOtherInfo = null;
        //    SearchOtherInfoDetails[] objOtherInfoDetails = null;
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objSearchInfoResult = new SearchInfoResult[ds.Tables.Count];
        //        objOtherInfo = new SearchOtherInfo[ds.Tables[0].Rows.Count];
        //        List<int> lstOtherInfo = new List<int>();
        //        List<int> lstOtherInfoDetail = new List<int>();
        //        for (int iSearchInfo = 0; iSearchInfo < ds.Tables.Count; iSearchInfo++)
        //        {
        //            int iOtherInfo = 0;
        //            objSearchInfoResult[iSearchInfo] = new SearchInfoResult();
        //            objOtherInfo = new SearchOtherInfo[this.CountSearchOtherInfo(ds.Tables[iSearchInfo])];
        //            foreach (DataRow OtherInfoRow in ds.Tables[iSearchInfo].Rows)
        //            {
        //                int iOtherInfo_ID = Convert.ToInt32(OtherInfoRow["OtherInfo_ID"]);
        //                if (!lstOtherInfo.Contains(iOtherInfo_ID))
        //                {
        //                    objOtherInfo[iOtherInfo] = new SearchOtherInfo();
        //                    DataRow[] drOtherInfoArray = ds.Tables[iSearchInfo].Select("OtherInfo_ID=" + iOtherInfo_ID);

        //                    if (drOtherInfoArray.Length > 0)
        //                    {
        //                        objOtherInfo[iOtherInfo].DownloadFlag = Convert.ToBoolean(drOtherInfoArray[0]["OtherInfoFlag"].ToString());
        //                        objOtherInfo[iOtherInfo].GeneralText = Convert.ToString(drOtherInfoArray[0]["OtherInfo_GenText"].ToString());
        //                        objOtherInfo[iOtherInfo].IsAlertRangeVisible = Convert.ToBoolean(drOtherInfoArray[0]["VISIBLE_TO_CLIENT"]);
        //                        objOtherInfo[iOtherInfo].HoverText = Convert.ToString(drOtherInfoArray[0]["OtherInfo_Hover_Text"].ToString());
        //                        objOtherInfo[iOtherInfo].Keyword_Txt = Convert.ToString(drOtherInfoArray[0]["KeyWord_Txt"].ToString());
        //                        objOtherInfo[iOtherInfo].IsBrowsable = false;
        //                        ////objOtherInfo[iOtherInfo].LabelID = Convert.ToInt32(drOtherInfoArray[0]["OtherInfo_Label_Id"].ToString());
        //                        ////objOtherInfo[iOtherInfo].LabelID = 0;
        //                        objOtherInfo[iOtherInfo].LabelID = objOtherInfo[iOtherInfo] == null ? 0 : Convert.ToInt32(drOtherInfoArray[0]["OtherInfo_Label_Id"].ToString());
        //                        objOtherInfo[iOtherInfo].LabelName = Convert.ToString(drOtherInfoArray[0]["OtherInfoLabelName"].ToString());
        //                        objOtherInfo[iOtherInfo].LanguageCode = Convert.ToString(drOtherInfoArray[0]["OtherInfo_Lang_CD"].ToString());

        //                        if (!string.IsNullOrEmpty(drOtherInfoArray[0]["OtherInfo_Link"].ToString()))
        //                        {
        //                            if (drOtherInfoArray[0]["OtherInfo_Link"].ToString().StartsWith(SharePointFolder))
        //                            {
        //                                drOtherInfoArray[0]["OtherInfo_Link"] = SharePointURL + drOtherInfoArray[0]["OtherInfo_Link"].ToString();
        //                            }
        //                        }

        //                        if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                        {
        //                            objOtherInfo[iOtherInfo].Link = (drOtherInfoArray[0]["OtherInfo_Link"] != null ? drOtherInfoArray[0]["OtherInfo_Link"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                        }
        //                        else
        //                        {
        //                            objOtherInfo[iOtherInfo].Link = drOtherInfoArray[0]["OtherInfo_Link"] != null ? drOtherInfoArray[0]["OtherInfo_Link"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                        }

        //                        ////objOtherInfo[iOtherInfo].Link = Convert.ToString(drOtherInfoArray[0]["OtherInfo_Link"].ToString());
        //                        objOtherInfo[iOtherInfo].LinkType = Convert.ToInt32(drOtherInfoArray[0]["OtherInfo_LinkType"].ToString());
        //                        objOtherInfo[iOtherInfo].LinkTypeCode = Convert.ToString(drOtherInfoArray[0]["OtherInfoLinkType_CD"].ToString());
        //                        objOtherInfo[iOtherInfo].OtherInfoID = Convert.ToInt32(drOtherInfoArray[0]["OtherInfo_ID"].ToString());
        //                        objOtherInfo[iOtherInfo].OtherInfoLabelID = Convert.ToInt32(drOtherInfoArray[0]["OtherInfoLabel_ID"].ToString());
        //                        objOtherInfo[iOtherInfo].Rating = 0;
        //                        objOtherInfo[iOtherInfo].ValidFromDate = Convert.ToString(drOtherInfoArray[0]["ValidFrom_DT"] != DBNull.Value ? drOtherInfoArray[0]["ValidFrom_DT"] : string.Empty);
        //                        objOtherInfo[iOtherInfo].ValidToDate = Convert.ToString(drOtherInfoArray[0]["ValidTo_DT"] != DBNull.Value ? drOtherInfoArray[0]["ValidTo_DT"] : string.Empty);
        //                        if (drOtherInfoArray[0]["OtherInfoLinkType_CD"].ToString() == Constants.CONSTGENERAL)
        //                        {
        //                            objOtherInfo[iOtherInfo].DisplayValidFromMonth = int.Parse(drOtherInfoArray[0]["DisplayFrom_Month"].ToString());
        //                            objOtherInfo[iOtherInfo].DisplayValidToMonth = int.Parse(drOtherInfoArray[0]["DisplayTo_Month"].ToString());
        //                            objOtherInfo[iOtherInfo].DisplayValidFromDay = int.Parse(drOtherInfoArray[0]["DisplayFrom_Day"].ToString());
        //                            objOtherInfo[iOtherInfo].DisplayValidToDay = int.Parse(drOtherInfoArray[0]["DisplayTo_Day"].ToString());
        //                        }

        //                        //Make User Id and Date
        //                        if (drOtherInfoArray[0]["OtherInfoLinkType_CD"].ToString() != Constants.CONSTGENERAL)
        //                        {
        //                            objOtherInfo[iOtherInfo].CreatedUserID = Convert.ToString(drOtherInfoArray[0]["CREATED_USER_ID"].ToString());
        //                            objOtherInfo[iOtherInfo].CreatedUserDate = Convert.ToDateTime(drOtherInfoArray[0]["CREATED_DT"].ToString());
        //                            objOtherInfo[iOtherInfo].ModifiedUserID = Convert.ToString(drOtherInfoArray[0]["MODIFIED_USER_ID"]);
        //                            objOtherInfo[iOtherInfo].ModifiedUserDate = Convert.ToDateTime(drOtherInfoArray[0]["MODIFIED_DT"].ToString());
        //                        }

        //                        if (drOtherInfoArray[0]["OtherInfoLinkType_CD"].ToString() == Constants.CONSTCATEGORY)
        //                        {
        //                            objOtherInfoDetails = new SearchOtherInfoDetails[this.CountSearchOtherInfoDetail(drOtherInfoArray)];
        //                            int iOtherInfoDtl = 0;
        //                            if (this.CountSearchOtherInfoDetail(drOtherInfoArray) > 0)
        //                            {
        //                                foreach (DataRow drOtherInfo in drOtherInfoArray)
        //                                {
        //                                    int iOtherInfoDetail_ID = Convert.ToInt32(drOtherInfo["OtherInfo_DTL_ID"] != DBNull.Value ? drOtherInfo["OtherInfo_DTL_ID"] : 0);
        //                                    if (!lstOtherInfoDetail.Contains(iOtherInfoDetail_ID))
        //                                    {
        //                                        objOtherInfoDetails[iOtherInfoDtl] = new SearchOtherInfoDetails();
        //                                        DataRow[] drOtherInfoDetailArray = ds.Tables[iSearchInfo].Select("OtherInfo_ID=" + iOtherInfo_ID + " AND OtherInfo_DTL_ID=" + iOtherInfoDetail_ID);
        //                                        if (drOtherInfoDetailArray.Length > 0)
        //                                        {
        //                                            objOtherInfoDetails[iOtherInfoDtl].DownloadFlag = Convert.ToBoolean(drOtherInfoDetailArray[0]["OtherInfoDtl_Flag"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].GeneralText = Convert.ToString(drOtherInfoDetailArray[0]["OtherInfoDet_GenText"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].IsAlertRangeVisible = Convert.ToBoolean(drOtherInfoDetailArray[0]["VISIBLE_TO_CLIENT"]);
        //                                            objOtherInfoDetails[iOtherInfoDtl].HoverText = Convert.ToString(drOtherInfoDetailArray[0]["OtherInfoDtl_Hover_Text"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].Keyword_Txt = Convert.ToString(drOtherInfoDetailArray[0]["Dtl_KeyWord_Txt"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].IsBrowsable = false;
        //                                            objOtherInfoDetails[iOtherInfoDtl].LabelID = Convert.ToInt32(drOtherInfoDetailArray[0]["OtherInfoDtl_Label_Id"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].LabelName = Convert.ToString(drOtherInfoDetailArray[0]["OtherInfodtlLabelName"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].LanguageCode = Convert.ToString(drOtherInfoDetailArray[0]["OtherInfoDtl_Lang_CD"].ToString());
        //                                            if (!string.IsNullOrEmpty(drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString()))
        //                                            {
        //                                                if (drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString().StartsWith(SharePointFolder))
        //                                                {
        //                                                    drOtherInfoDetailArray[0]["OtherInfoDtl_Link"] = SharePointURL + drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString();
        //                                                }
        //                                            }

        //                                            if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                                            {
        //                                                objOtherInfoDetails[iOtherInfoDtl].Link = (drOtherInfoDetailArray[0]["OtherInfoDtl_Link"] != null ? drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                                            }
        //                                            else
        //                                            {
        //                                                objOtherInfoDetails[iOtherInfoDtl].Link = drOtherInfoDetailArray[0]["OtherInfoDtl_Link"] != null ? drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                                            }

        //                                            objOtherInfoDetails[iOtherInfoDtl].Link = Convert.ToString(drOtherInfoDetailArray[0]["OtherInfoDtl_Link"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].LinkType = Convert.ToInt32(drOtherInfoDetailArray[0]["OtherInfoDtl_LinkType"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].OtherInfoDetailID = Convert.ToInt32(drOtherInfoDetailArray[0]["OtherInfo_Dtl_ID"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].OtherInfoID = Convert.ToInt32(drOtherInfoDetailArray[0]["OtherInfo_ID"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].Rating = 0;

        //                                            //Make Change
        //                                            objOtherInfoDetails[iOtherInfoDtl].CreatedUserID = Convert.ToString(drOtherInfoDetailArray[0]["CREATED_USER_ID"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].CreatedUserDate = Convert.ToDateTime(drOtherInfoDetailArray[0]["CREATED_DT"].ToString());
        //                                            objOtherInfoDetails[iOtherInfoDtl].ModifiedUserID = Convert.ToString(drOtherInfoDetailArray[0]["MODIFIED_USER_ID"]);
        //                                            objOtherInfoDetails[iOtherInfoDtl].ModifiedUserDate = Convert.ToDateTime(drOtherInfoDetailArray[0]["MODIFIED_DT"].ToString());

        //                                        }

        //                                        if (!lstOtherInfoDetail.Contains(iOtherInfoDetail_ID))
        //                                        {
        //                                            lstOtherInfoDetail.Add(iOtherInfoDetail_ID);
        //                                        }

        //                                        iOtherInfoDtl++;
        //                                    }
        //                                }
        //                            }

        //                            objOtherInfo[iOtherInfo].OtherInfoDetails = objOtherInfoDetails;
        //                        }
        //                    }

        //                    if (!lstOtherInfo.Contains(iOtherInfo_ID))
        //                    {
        //                        lstOtherInfo.Add(iOtherInfo_ID);
        //                    }

        //                    iOtherInfo++;
        //                }
        //            }

        //            objSearchInfoResult[iSearchInfo].SearchOthResult = objOtherInfo;
        //            lstOtherInfo = new List<int>();
        //            lstOtherInfoDetail = new List<int>();
        //        }

        //        objSearchInfoResult[0].STDResponse = new StandardResponse();
        //        objSearchInfoResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objSearchInfoResult == null)
        //        {
        //            objSearchInfoResult = new SearchInfoResult[2];
        //            objSearchInfoResult[0] = new SearchInfoResult();
        //        }

        //        objSearchInfoResult[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchInfoResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchInfoResult[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //        ////ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objSearchInfoResult;
        //}

        /// <summary>
        /// <Description>This method is to search Account Data.</Description>
        /// </summary>
        /// <param name="Request">Account Input</param>
        /// <returns>return account details</returns>
        //public AccountDetails SearchAccount(AccountInput Request)
        //{
        //    return new AccountDetails();
        //}

        /// <summary>
        /// <Description>This method is to search City Data.</Description>
        /// </summary>
        /// <param name="Request">City Input</param>
        /// <returns>return City Details</returns>
        //public CityDetails SearchCity(CityInput Request)
        //{
        //    return new CityDetails();
        //}

        /// <summary>
        /// <Description>This method is to search Country Data.</Description>
        /// </summary>
        /// <param name="Request">Country Input</param>
        /// <returns>return Country Details</returns>
        //public CountryDetails SearchCountry(CountryInput Request)
        //{
        //    return new CountryDetails();
        //}

        /// <summary>
        /// <Description>This method is to get Link ID.</Description>
        /// </summary>
        /// <param name="input">Transaction ID Input</param>
        /// <returns>return Transaction Details</returns>
        //public TransactionIdDetails GetTransactionId(TransactionIdInput input)
        //{
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPLINKID];
        //    DataSet ds = new DataSet();
        //    TransactionIdDetails objTransactionIdDetails = null;
        //    try
        //    {
        //        sp.Parameters["@inAccCode"].Value = input.AccountCode;
        //        sp.Parameters["@inCountry"].Value = input.CountryCode;
        //        sp.Parameters["@inCity"].Value = input.CityCode;
        //        sp.Parameters["@inGlobalCategory"].Value = input.GlobalCatCode;
        //        sp.Parameters["@inCarrier"].Value = input.CarrierCode;
        //        sp.Parameters["@inOtherInfo"].Value = input.OtherInfoCode;
        //        sp.Parameters["@clientID"].Value = input.clientID;
        //        objTransactionIdDetails = new TransactionIdDetails();
        //        ds = proc.GetDataset(sp);

        //        if (ds != null && ds.Tables.Count > 0)
        //        {
        //            if (ds.Tables[0].Rows.Count > 0)
        //            {
        //                objTransactionIdDetails.TransactionId = ds.Tables[0].Rows[0]["TransactionId"].ToString();
        //                objTransactionIdDetails.TransactionType = ds.Tables[0].Rows[0]["TransactionType"].ToString();
        //            }
        //        }

        //        objTransactionIdDetails.STDResponse = new StandardResponse();
        //        objTransactionIdDetails.STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objTransactionIdDetails.STDResponse = new StandardResponse();
        //        objTransactionIdDetails.STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objTransactionIdDetails.STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9002);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objTransactionIdDetails;
        //}

        #region Carrier

        /// <summary>
        /// <Description>This method is to search Carrier Data.</Description>
        /// </summary>
        /// <param name="input">Carrier Input</param>
        /// <returns>return Carrier Details</returns>
        //public CarrierDetails[] SearchCarrier(CarrierInput input)
        //{
        //    CarrierDetails[] objCarrierDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHCARR];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //        sp.Parameters["@inCarrierName"].Value = input.CarrierName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        ds = proc.GetDataset(sp);
        //        objCarrierDetails = new CarrierDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objCarrierDetails[i] = new CarrierDetails();
        //            objCarrierDetails[i].CarrierCode = Convert.ToString(ds.Tables[0].Rows[i]["Carrier_CD"]);
        //            objCarrierDetails[i].CarrierName = Convert.ToString(ds.Tables[0].Rows[i]["Carrier_NM"]);
        //            objCarrierDetails[i].ModifiedDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["Modified_DT"]);
        //            objCarrierDetails[i].GlobalCD = ds.Tables[0].Rows[i]["GlobalCarrierCD"].ToString();
        //        }

        //        if (objCarrierDetails == null || objCarrierDetails.Length == 0)
        //        {
        //            objCarrierDetails = new CarrierDetails[1];
        //            objCarrierDetails[0] = new CarrierDetails();
        //        }

        //        objCarrierDetails[0].STDResponse = new StandardResponse();
        //        objCarrierDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objCarrierDetails == null)
        //        {
        //            objCarrierDetails = new CarrierDetails[1];
        //            objCarrierDetails[0] = new CarrierDetails();
        //        }

        //        objCarrierDetails[0].STDResponse = new StandardResponse();
        //        objCarrierDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objCarrierDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCarrierDetails;
        //}
        #endregion

        #region Account
        /// <summary>
        /// This method is to search Account Data
        /// </summary>
        /// <param name="input">Manage Account Input</param>
        /// <returns>return Account Details</returns>
        //public ManageAccountDetails[] SearchAccounts(ManageAccountInput input)
        //{
        //    ManageAccountDetails[] objAccDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_SearchAccounts"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inAccountCode"].Value = input.AccountCode;
        //        sp.Parameters["@inAccountName"].Value = input.AccountName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        sp.Parameters["@inClientID"].Value = input.ClientID;
        //        sp.Parameters["@inAccountType"].Value = input.AccountType;
        //        ds = proc.GetDataset(sp);
        //        objAccDetails = new ManageAccountDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objAccDetails[i] = new ManageAccountDetails();
        //            objAccDetails[i].AccountCode = Convert.ToString(ds.Tables[0].Rows[i]["Account_CD"]);
        //            objAccDetails[i].AccountName = Convert.ToString(ds.Tables[0].Rows[i]["Account_NM"]);
        //            objAccDetails[i].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsGlobal"]);
        //            objAccDetails[i].IsVirtual = Convert.ToString(ds.Tables[0].Rows[i]["IsVirtual"]);
        //            objAccDetails[i].ClientID = Convert.ToInt32(ds.Tables[0].Rows[i]["Client_ID"]);
        //            objAccDetails[i].IsDeactive = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive"]);
        //            objAccDetails[i].VirtualCD = ds.Tables[0].Rows[i]["VirtualCode"].ToString();
        //            objAccDetails[i].GlobalCD = ds.Tables[0].Rows[i]["GloblalCode"].ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objAccDetails;
        //}
        #endregion

        //#region City
        ///// <summary>
        ///// This method is to search city data
        ///// </summary>
        ///// <param name="input">Manage City Input</param>
        ///// <returns>return City details</returns>
        //public ManageCityDetails[] SearchCities(ManageCityInput input)
        //{
        //    ManageCityDetails[] objCitydetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_SearchCities"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inCityCode"].Value = input.CityCode;
        //        sp.Parameters["@inCityName"].Value = input.CityName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        sp.Parameters["@inCountryCode"].Value = input.CountryCode;
        //        sp.Parameters["@inCityType"].Value = input.CityType;
        //        ds = proc.GetDataset(sp);
        //        objCitydetails = new ManageCityDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objCitydetails[i] = new ManageCityDetails();
        //            objCitydetails[i].CityCode = Convert.ToString(ds.Tables[0].Rows[i]["City_CD"]);
        //            objCitydetails[i].CityName = Convert.ToString(ds.Tables[0].Rows[i]["City_NM"]);
        //            objCitydetails[i].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsGlobal"]);
        //            objCitydetails[i].IsVirtual = Convert.ToString(ds.Tables[0].Rows[i]["IsVirtual"]);
        //            objCitydetails[i].CountryCode = Convert.ToString(ds.Tables[0].Rows[i]["Country_CD"]);
        //            objCitydetails[i].IsDeactive = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive"]);
        //            objCitydetails[i].VirtualCD = ds.Tables[0].Rows[i]["VirtualCode"].ToString();
        //            objCitydetails[i].GlobalCD = ds.Tables[0].Rows[i]["GloblalCode"].ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCitydetails;
        //}
        //#endregion

        //#region Country
        ///// <summary>
        ///// This method is to search country data
        ///// </summary>
        ///// <param name="input">Manage Country Input</param>
        ///// <returns>return Country Details</returns>
        //public ManageCountryDetails[] SearchCountry(ManageCountryInput input)
        //{
        //    ManageCountryDetails[] objCountryDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_SearchCountry"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inCountryCode"].Value = input.CountryCode;
        //        sp.Parameters["@inCountryName"].Value = input.CountryName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        sp.Parameters["@inCountryType"].Value = input.CountryType;
        //        ds = proc.GetDataset(sp);
        //        objCountryDetails = new ManageCountryDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objCountryDetails[i] = new ManageCountryDetails();
        //            objCountryDetails[i].CountryCode = Convert.ToString(ds.Tables[0].Rows[i]["COUNTRY_CD"]);
        //            objCountryDetails[i].CountryName = Convert.ToString(ds.Tables[0].Rows[i]["COUNTRY_NM"]);
        //            objCountryDetails[i].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[i]["IS_GLOBAL"]);
        //            objCountryDetails[i].IsVirtual = Convert.ToString(ds.Tables[0].Rows[i]["Is_Virtual"]);
        //            objCountryDetails[i].IsDeactive = Convert.ToBoolean(ds.Tables[0].Rows[i]["ACTIVE_ID"]);
        //            objCountryDetails[i].CreatedUserID = Convert.ToString(ds.Tables[0].Rows[i]["CREATED_USER_ID"]);
        //            objCountryDetails[i].ModifiedUserID = Convert.ToString(ds.Tables[0].Rows[i]["MODIFIED_USER_ID"]);
        //            objCountryDetails[i].GlobalCD = Convert.ToString(ds.Tables[0].Rows[i]["GlobalCountryCD"]);
        //            objCountryDetails[i].VirtualCD = Convert.ToString(ds.Tables[0].Rows[i]["VirtualCountryCD"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCountryDetails;
        //}
        //#endregion

        /// <summary>
        /// This method is to get mapping details 
        /// </summary>
        /// <param name="input">mapping input</param>
        /// <returns>return mapping details</returns>
        //public MappingDetails[] GetMappingDetails(MappingInput input)
        //{
        //    MappingDetails[] objMappDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_MappingDetails"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inInputType"].Value = input.Input_Type;
        //        sp.Parameters["@inInputCD"].Value = input.Input_CD;
        //        sp.Parameters["@inMappingInputCD"].Value = input.Mapping_Input_Type;
        //        ds = proc.GetDataset(sp);
        //        objMappDetails = new MappingDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objMappDetails[i] = new MappingDetails();
        //            objMappDetails[i].Mapping_CD = Convert.ToString(ds.Tables[0].Rows[i]["Mapping_CD"]);
        //            objMappDetails[i].Real_CD = Convert.ToString(ds.Tables[0].Rows[i]["Real_CD"]);
        //            objMappDetails[i].Virtual_CD = Convert.ToString(ds.Tables[0].Rows[i]["Virtual_CD"]);
        //            objMappDetails[i].Real_NM = Convert.ToString(ds.Tables[0].Rows[i]["Real_NM"]);
        //            objMappDetails[i].Mode = Convert.ToString(ds.Tables[0].Rows[i]["Mode"]);
        //            objMappDetails[i].InTransaction = Convert.ToString(ds.Tables[0].Rows[i]["InTransaction"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objMappDetails;
        //}

        #region User

        /// <summary>
        /// <Description>This method is to search User Data.</Description>
        /// </summary>
        /// <param name="input">User Input</param>
        /// <returns>return User Details</returns>
        public UserDetails[] SearchUsers(UserInput input)
        {
            UserDetails[] objUserDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DataSet ds = new DataSet();
            try
            {
                if (input.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSEARCHUSER_GDU];

                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@inUserName"].Value = input.UserName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@inClientID"].Value = input.ClientId;
                    sp.Parameters["@RequestedBy"].Value = input.RequestedBy;
                    sp.Parameters["@IsGrouping"].Value = input.IsGrouping;

                    sp.Parameters["@PageIndex"].Value = input.CurrentPage;
                    sp.Parameters["@PageSize"].Value = input.PageSize;
                    sp.Parameters["@SortColumn"].Value = input.SortExpression;
                    sp.Parameters["@SortOrder"].Value = input.SortOrder;

                    ds = proc.GetDataset(sp);
                    objUserDetails = new UserDetails[ds.Tables[0].Rows.Count];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objUserDetails[i] = new UserDetails();
                        objUserDetails[i].UserId = Convert.ToString(ds.Tables[0].Rows[i]["ADS_ID"]);
                        objUserDetails[i].UserName = Convert.ToString(ds.Tables[0].Rows[i]["USER_NM"]);
                        objUserDetails[i].Language = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_NM"]);
                        objUserDetails[i].LanguageCode = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_CD"]);
                        objUserDetails[i].EmailAddress = Convert.ToString(ds.Tables[0].Rows[i]["EMAIL_ADD_TXT"]);
                        objUserDetails[i].ModifiedUserDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objUserDetails[i].UserRole = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objUserDetails[i].UserRoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objUserDetails[i].DefaultClientID = (ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"] != DBNull.Value) ? Convert.ToInt32(ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"]) : 0;
                        objUserDetails[i].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);

                    }
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSEARCHUSER];

                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@inUserName"].Value = input.UserName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@inClientID"].Value = input.ClientId;

                    ds = proc.GetDataset(sp);
                    objUserDetails = new UserDetails[ds.Tables[0].Rows.Count];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objUserDetails[i] = new UserDetails();
                        objUserDetails[i].UserId = Convert.ToString(ds.Tables[0].Rows[i]["ADS_ID"]);
                        objUserDetails[i].UserName = Convert.ToString(ds.Tables[0].Rows[i]["USER_NM"]);
                        objUserDetails[i].Language = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_NM"]);
                        objUserDetails[i].LanguageCode = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_CD"]);
                        objUserDetails[i].EmailAddress = Convert.ToString(ds.Tables[0].Rows[i]["EMAIL_ADD_TXT"]);
                        objUserDetails[i].ModifiedUserDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objUserDetails[i].UserRole = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objUserDetails[i].UserRoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objUserDetails[i].DefaultClientID = (ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"] != DBNull.Value) ? Convert.ToInt32(ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"]) : 0;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objUserDetails;
        }

        public UserDetails[] PopulateSearchUsers(UserInput input)
        {
            UserDetails[] objUserDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DataSet ds = new DataSet();
            try
            {
                if (input.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPULATEUSER_GDU];

                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@inUserName"].Value = input.UserName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@inClientID"].Value = input.ClientId;
                    sp.Parameters["@RequestedBy"].Value = input.RequestedBy;
                    sp.Parameters["@IsGrouping"].Value = input.IsGrouping;

                    ds = proc.GetDataset(sp);
                    objUserDetails = new UserDetails[ds.Tables[0].Rows.Count];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objUserDetails[i] = new UserDetails();
                        objUserDetails[i].UserId = Convert.ToString(ds.Tables[0].Rows[i]["ADS_ID"]);
                        objUserDetails[i].UserName = Convert.ToString(ds.Tables[0].Rows[i]["USER_NM"]);
                        objUserDetails[i].Language = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_NM"]);
                        objUserDetails[i].LanguageCode = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_CD"]);
                        objUserDetails[i].EmailAddress = Convert.ToString(ds.Tables[0].Rows[i]["EMAIL_ADD_TXT"]);
                        objUserDetails[i].ModifiedUserDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objUserDetails[i].UserRole = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objUserDetails[i].UserRoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objUserDetails[i].DefaultClientID = (ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"] != DBNull.Value) ? Convert.ToInt32(ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"]) : 0;
                    }
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPULATEUSER];

                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@inUserName"].Value = input.UserName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@inClientID"].Value = input.ClientId;
                    sp.Parameters["@RequestedBy"].Value = input.RequestedBy;
                    sp.Parameters["@IsGrouping"].Value = input.IsGrouping;

                    ds = proc.GetDataset(sp);
                    objUserDetails = new UserDetails[ds.Tables[0].Rows.Count];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objUserDetails[i] = new UserDetails();
                        objUserDetails[i].UserId = Convert.ToString(ds.Tables[0].Rows[i]["ADS_ID"]);
                        objUserDetails[i].UserName = Convert.ToString(ds.Tables[0].Rows[i]["USER_NM"]);
                        objUserDetails[i].Language = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_NM"]);
                        objUserDetails[i].LanguageCode = Convert.ToString(ds.Tables[0].Rows[i]["LANGUAGE_CD"]);
                        objUserDetails[i].EmailAddress = Convert.ToString(ds.Tables[0].Rows[i]["EMAIL_ADD_TXT"]);
                        objUserDetails[i].ModifiedUserDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objUserDetails[i].UserRole = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objUserDetails[i].UserRoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objUserDetails[i].DefaultClientID = (ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"] != DBNull.Value) ? Convert.ToInt32(ds.Tables[0].Rows[i]["DEFAULT_CLIENT_ID"]) : 0;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objUserDetails;
        }
        #endregion

        #region UserAuthentication
        /// <summary>
        /// This method is to get user authentication
        /// </summary>
        /// <param name="Request">user input</param>
        /// <returns>return user authentication details</returns>
        public UserAuthenticationDetails UserAuthentication(UserAuthenticationInput Request)
        {
            UserAuthenticationDetails userAuthenticationDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPAUTH];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@inUserId"].Value = Request.UserID;
                sp.Parameters["@inGroup"].Value = Request.Group;
                ds = proc.GetDataset(sp);
                userAuthenticationDetails = new UserAuthenticationDetails();
                if (ds != null && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        userAuthenticationDetails.IsAuthenticated = true;
                        userAuthenticationDetails.Description = string.Empty;
                    }
                    else
                    {
                        userAuthenticationDetails.IsAuthenticated = false;
                        userAuthenticationDetails.Description = string.Empty;
                    }
                }

                userAuthenticationDetails.STDResponse = new StandardResponse();
                userAuthenticationDetails.STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                userAuthenticationDetails.STDResponse = new StandardResponse();
                userAuthenticationDetails.STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                userAuthenticationDetails.STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9002);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return userAuthenticationDetails;
        }
        #endregion

        //#region search label
        ///// <summary>
        ///// this method is to search label
        ///// </summary>
        ///// <param name="Request">Search label input</param>
        ///// <returns>return search label details</returns>
        //public SearchLabelDetail[] SearchLabel(SearchLabelInput Request)
        //{
        //    SearchLabelDetail[] searchLabelDetail = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPLINKLABEL];
        //    DataSet ds = new DataSet();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    try
        //    {
        //        sp.Parameters["@TYPE"].Value = Request.Type;
        //        sp.Parameters["@ClientAbbr"].Value = Request.ClientCode;
        //        ds = proc.GetDataset(sp);

        //        if (ds != null && ds.Tables.Count > 0)
        //        {
        //            searchLabelDetail = new SearchLabelDetail[ds.Tables[0].Rows.Count];
        //            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //            {
        //                searchLabelDetail[i] = new SearchLabelDetail();
        //                if (ds.Tables[0].Rows[i]["link_type"].ToString() == "1")
        //                {
        //                    searchLabelDetail[i].Link_Txt = SharePointURL + ds.Tables[0].Rows[i]["LINK_TXT"].ToString();
        //                }
        //                else
        //                {
        //                    searchLabelDetail[i].Link_Txt = ds.Tables[0].Rows[i]["LINK_TXT"].ToString();
        //                }

        //                searchLabelDetail[i].Label_Id = int.Parse(ds.Tables[0].Rows[i]["LABEL_ID"].ToString());
        //                searchLabelDetail[i].Label_NM = ds.Tables[0].Rows[i]["LABEL_NM"].ToString();
        //                searchLabelDetail[i].Hover_Txt = ds.Tables[0].Rows[i]["Hover_Txt"].ToString();
        //                searchLabelDetail[i].Link_Type = Convert.ToByte(ds.Tables[0].Rows[i]["Link_Type"]);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return searchLabelDetail;
        //}
        //#endregion

        /// <summary>
        /// <Description>This method is to count Link Data.</Description>
        /// </summary>
        /// <param name="dt">data table</param>
        /// <returns>int</returns>
        private int CountSearchLink(DataTable dt)
        {
            int iLinkID = 0;
            List<int> lstCount = new List<int>();
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["LINK_ID"] != DBNull.Value)
                {
                    iLinkID = Convert.ToInt32(dr["LINK_ID"]);
                    if (!lstCount.Contains(iLinkID))
                    {
                        lstCount.Add(iLinkID);
                    }
                }
            }

            return lstCount.Count;
        }

        /// <summary>
        /// <Description>This method is to count Other info Data.</Description>
        /// </summary>
        /// <param name="dt">datatable</param>
        /// <returns>int</returns>
        private int CountSearchOtherInfo(DataTable dt)
        {
            int iLinkID = 0;
            List<int> lstCount = new List<int>();
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["OtherInfo_ID"] != DBNull.Value)
                {
                    iLinkID = Convert.ToInt32(dr["OtherInfo_ID"]);
                    if (!lstCount.Contains(iLinkID))
                    {
                        lstCount.Add(iLinkID);
                    }
                }
            }

            return lstCount.Count;
        }

        /// <summary>
        /// <Description>This method is to count other info detail Data.</Description>
        /// </summary>
        /// <param name="drArray">DataRow array</param>
        /// <returns>int</returns>
        private int CountSearchOtherInfoDetail(DataRow[] drArray)
        {
            int iLinkDetailID = 0;
            List<int> lstCount = new List<int>();
            foreach (DataRow dr in drArray)
            {
                if (dr["OtherInfo_DTL_ID"] != DBNull.Value)
                {
                    iLinkDetailID = Convert.ToInt32(dr["OtherInfo_DTL_ID"]);
                    if (!lstCount.Contains(iLinkDetailID))
                    {
                        lstCount.Add(iLinkDetailID);
                    }
                }
            }

            return lstCount.Count;
        }

        /// <summary>
        /// <Description>This method is to count Link detail Data.</Description>
        /// </summary>
        /// <param name="drArray">DataRow array</param>
        /// <returns>int</returns>
        private int CountSearchLinkDetail(DataRow[] drArray)
        {
            int iLinkDetailID = 0;
            List<int> lstCount = new List<int>();
            foreach (DataRow dr in drArray)
            {
                if (dr["LINK_DTL_ID"] != DBNull.Value)
                {
                    iLinkDetailID = Convert.ToInt32(dr["LINK_DTL_ID"]);
                    if (!lstCount.Contains(iLinkDetailID))
                    {
                        lstCount.Add(iLinkDetailID);
                    }
                }
            }

            return lstCount.Count;
        }

        /// <summary>
        /// <Description>This method is to count Link category detail Data.</Description>
        /// </summary>
        /// <param name="drArray">DataRow array</param>
        /// <returns>int</returns>
        private int CountSearchLinkCatDetail(DataRow[] drArray)
        {
            int iLinkCatDetailID = 0;
            List<int> lstCount = new List<int>();
            foreach (DataRow dr in drArray)
            {
                if (dr["LINK_CAT_DTL_ID"] != DBNull.Value)
                {
                    iLinkCatDetailID = Convert.ToInt32(dr["LINK_CAT_DTL_ID"]);
                    if (!lstCount.Contains(iLinkCatDetailID))
                    {
                        lstCount.Add(iLinkCatDetailID);
                    }
                }
            }

            return lstCount.Count;
        }

        #region Client
        /// <summary>
        /// This method is to search Account Data
        /// </summary>
        /// <param name="input">Manage Account Input</param>
        /// <returns>return Account Details</returns>
        //public ManageClientDetails[] SearchClients(ManageClientInput input)
        //{
        //    ManageClientDetails[] objClientDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHCLIENT];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@clientName"].Value = input.ClientName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        sp.Parameters["@inClientId"].Value = input.ClientId;
        //        ds = proc.GetDataset(sp);
        //        objClientDetails = new ManageClientDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objClientDetails[i] = new ManageClientDetails();
        //            objClientDetails[i].ClientId = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_ID"]);
        //            objClientDetails[i].ClientName = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_NM"]);
        //            objClientDetails[i].ClientAbbr = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_ABBREV_NM"]);
        //            objClientDetails[i].CREATED_DT = Convert.ToDateTime(ds.Tables[0].Rows[i]["CREATED_DT"]);
        //            objClientDetails[i].CREATED_USER_ID = Convert.ToString(ds.Tables[0].Rows[i]["CREATED_USER_ID"]);
        //            objClientDetails[i].GlobalCD = ds.Tables[0].Rows[i]["GloblalCode"].ToString();

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objClientDetails;
        //}
        #endregion

        #region Roles
        //public ManageRoleDetails[] SearchRoles(ManageRoleInput input)
        //{
        //    ManageRoleDetails[] objRoleDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHROLE];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inClientID"].Value = input.ClientId;
        //        sp.Parameters["@inRoleId"].Value = input.RoleId;
        //        sp.Parameters["@inRoleName"].Value = input.RoleName;
        //        sp.Parameters["@inActive"].Value = !input.IsDeactive;
        //        sp.Parameters["@SYSTEM_CD"].Value = input.System_CD;

        //        ds = proc.GetDataset(sp);
        //        objRoleDetails = new ManageRoleDetails[ds.Tables[0].Rows.Count];

        //        if (input.System_CD == "GD")
        //        {
        //            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //            {
        //                objRoleDetails[i] = new ManageRoleDetails();
        //                objRoleDetails[i].ClientId = Convert.ToInt32(ds.Tables[0].Rows[i]["CLIENT_ID"]);
        //                objRoleDetails[i].ClientName = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_NM"]);
        //                objRoleDetails[i].RoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
        //                objRoleDetails[i].RoleName = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
        //                objRoleDetails[i].ModifiedDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
        //                objRoleDetails[i].RoleTypeCD = Convert.ToString(ds.Tables[0].Rows[i]["ROLETYPE_CD"]);
        //                objRoleDetails[i].SYSTEM_NAME = Convert.ToString(ds.Tables[0].Rows[i]["SYSTEM_NM"]);
        //            }
        //        }
        //        else
        //        {
        //            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //            {
        //                objRoleDetails[i] = new ManageRoleDetails();
        //                objRoleDetails[i].ClientId = Convert.ToInt32(ds.Tables[0].Rows[i]["CLIENT_ID"]);
        //                objRoleDetails[i].ClientName = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_NM"]);
        //                objRoleDetails[i].RoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
        //                objRoleDetails[i].RoleName = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
        //                objRoleDetails[i].ModifiedDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
        //                objRoleDetails[i].RoleTypeCD = Convert.ToString(ds.Tables[0].Rows[i]["ROLETYPE_CD"]);
        //                objRoleDetails[i].SYSTEM_NAME = string.Empty;
        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objRoleDetails;
        //}
        public ManageRoleDetails[] SearchRoles(ManageRoleInput input)
        {
            ManageRoleDetails[] objRoleDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);

            DataSet ds = new DataSet();
            try
            {
                if (input.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHROLE_GDU];
                    sp.Parameters["@inClientID"].Value = input.ClientId;
                    sp.Parameters["@inRoleId"].Value = input.RoleId;
                    sp.Parameters["@inRoleName"].Value = input.RoleName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@SYSTEM_CD"].Value = input.System_CD;

                    sp.Parameters["@PageIndex"].Value = input.CurrentPage;
                    sp.Parameters["@PageSize"].Value = input.PageSize;
                    sp.Parameters["@SortColumn"].Value = input.SortExpression;
                    sp.Parameters["@SortOrder"].Value = input.SortOrder;

                    ds = proc.GetDataset(sp);
                    objRoleDetails = new ManageRoleDetails[ds.Tables[0].Rows.Count];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objRoleDetails[i] = new ManageRoleDetails();
                        objRoleDetails[i].ClientId = Convert.ToInt32(ds.Tables[0].Rows[i]["CLIENT_ID"]);
                        objRoleDetails[i].ClientName = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_NM"]);
                        objRoleDetails[i].RoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objRoleDetails[i].RoleName = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objRoleDetails[i].ModifiedDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objRoleDetails[i].RoleTypeCD = Convert.ToString(ds.Tables[0].Rows[i]["ROLETYPE_CD"]);
                        objRoleDetails[i].SYSTEM_NAME = Convert.ToString(ds.Tables[0].Rows[i]["SYSTEM_NM"]);
                        objRoleDetails[i].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                    }
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHROLE];
                    sp.Parameters["@inClientID"].Value = input.ClientId;
                    sp.Parameters["@inRoleId"].Value = input.RoleId;
                    sp.Parameters["@inRoleName"].Value = input.RoleName;
                    sp.Parameters["@inActive"].Value = !input.IsDeactive;
                    sp.Parameters["@SYSTEM_CD"].Value = input.System_CD;

                    ds = proc.GetDataset(sp);
                    objRoleDetails = new ManageRoleDetails[ds.Tables[0].Rows.Count];
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        objRoleDetails[i] = new ManageRoleDetails();
                        objRoleDetails[i].ClientId = Convert.ToInt32(ds.Tables[0].Rows[i]["CLIENT_ID"]);
                        objRoleDetails[i].ClientName = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_NM"]);
                        objRoleDetails[i].RoleCode = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_CD"]);
                        objRoleDetails[i].RoleName = Convert.ToString(ds.Tables[0].Rows[i]["ROLE_NM"]);
                        objRoleDetails[i].ModifiedDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["MODIFIED_DT"]);
                        objRoleDetails[i].RoleTypeCD = Convert.ToString(ds.Tables[0].Rows[i]["ROLETYPE_CD"]);
                        objRoleDetails[i].SYSTEM_NAME = string.Empty;
                    }

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objRoleDetails;
        }

        public ManageRoleDetails[] SearchClientRoles(ManageRoleInput input)
        {
            ManageRoleDetails[] objRoleDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHCLIENTROLE];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@Client_ID"].Value = input.ClientId;
                sp.Parameters["@Role_CD"].Value = input.RoleTypeCD;

                ds = proc.GetDataset(sp);
                objRoleDetails = new ManageRoleDetails[ds.Tables[0].Rows.Count];

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objRoleDetails[i] = new ManageRoleDetails();
                    objRoleDetails[i].RoleTypeCD = Convert.ToString(ds.Tables[0].Rows[i]["ROLETYPE_CD"]);
                    objRoleDetails[i].ClientAbbr = Convert.ToString(ds.Tables[0].Rows[i]["CLIENT_ABBREV_NM"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objRoleDetails;
        }
        #endregion
        //public ClientDetailbyAcc[] PopulateClientbyAcc(ClientAccInput input)
        //{
        //    ClientDetailbyAcc[] objClientAccDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSCLIENTDETAILBYACC];
        //    DataSet ds = new DataSet();
        //    try
        //    {

        //        sp.Parameters["@AccountCD"].Value = input.AccountCD.ToString();
        //        //sp.Parameters["@AccountCD"].Value = "ALU";
        //        //if (input.Active == null)
        //        //{
        //        //    sp.Parameters["@Active"].Value = 1;
        //        //}


        //        ds = proc.GetDataset(sp);
        //        objClientAccDetails = new ClientDetailbyAcc[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objClientAccDetails[iCount] = new ClientDetailbyAcc();
        //            objClientAccDetails[iCount].AccountCD = Convert.ToString(ds.Tables[0].Rows[iCount]["ACCOUNT_CD"]);
        //            objClientAccDetails[iCount].ClientID = Convert.ToString(ds.Tables[0].Rows[iCount]["CLIENT_ID"]);
        //            objClientAccDetails[iCount].ClientName = Convert.ToString(ds.Tables[0].Rows[iCount]["CLIENT_NM"]);
        //            objClientAccDetails[iCount].ClientAbbreviation = Convert.ToString(ds.Tables[0].Rows[iCount]["CLIENT_ABBREV_NM"].ToString());

        //        }
        //        if (objClientAccDetails == null || objClientAccDetails.Length == 0)
        //        {
        //            objClientAccDetails = new ClientDetailbyAcc[1];
        //            objClientAccDetails[0] = new ClientDetailbyAcc();
        //        }
        //        objClientAccDetails[0].STDResponse = new StandardResponse();
        //        objClientAccDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objClientAccDetails == null)
        //        {
        //            objClientAccDetails = new ClientDetailbyAcc[1];
        //            objClientAccDetails[0] = new ClientDetailbyAcc();
        //        }
        //        objClientAccDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objClientAccDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objClientAccDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objClientAccDetails;
        //}


        public UserMenuDetails[] SearchUserMenu(UserInput input)
        {
            UserMenuDetails[] objUserMenuDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DataSet ds = new DataSet();
            try
            {

                if (input.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTUSERMENU_GDU];
                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@Mode"].Value = input.Mode;
                    sp.Parameters["@System_CD"].Value = input.System_CD;
                    ds = proc.GetDataset(sp);
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTUSERMENU];
                    sp.Parameters["@inUserId"].Value = input.UserId;
                    sp.Parameters["@Mode"].Value = input.Mode;
                    sp.Parameters["@System_CD"].Value = input.System_CD;
                    ds = proc.GetDataset(sp);
                }


                objUserMenuDetails = new UserMenuDetails[ds.Tables[0].Rows.Count];

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objUserMenuDetails[i] = new UserMenuDetails();
                    objUserMenuDetails[i].FunctionId = Convert.ToInt32(ds.Tables[0].Rows[i]["FUNCTION_ID"]);
                    objUserMenuDetails[i].FunctionName = Convert.ToString(ds.Tables[0].Rows[i]["FUNCTION_NM"]);
                    objUserMenuDetails[i].FunctionPageUrlTxt = Convert.ToString(ds.Tables[0].Rows[i]["FUNCTION_PAGE_URL_TXT"]);
                    objUserMenuDetails[i].FunctionParentId = Convert.ToInt32(ds.Tables[0].Rows[i]["FUNCTION_PARENT_ID"]);
                    objUserMenuDetails[i].DispOrderNo = (ds.Tables[0].Rows[i]["DISP_ORDER_NO"] != DBNull.Value) ? Convert.ToInt32(ds.Tables[0].Rows[i]["DISP_ORDER_NO"]) : 0;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objUserMenuDetails;
        }

        public DurationTimeDetails[] SearchDurationTime(DurationTimeInput input)
        {
            DurationTimeDetails[] objAppUserDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPSEARCHTIMEDURATION];
            DataSet ds = new DataSet();
            try
            {
                ds = proc.GetDataset(sp);
                objAppUserDetails = new DurationTimeDetails[ds.Tables[0].Rows.Count];
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppUserDetails[i] = new DurationTimeDetails();
                    objAppUserDetails[i].TimeDuration = Convert.ToInt16(ds.Tables[0].Rows[i]["TIME_DURATION"]);
                    objAppUserDetails[i].TimeFormat = Convert.ToChar(ds.Tables[0].Rows[i]["TIME_FORMAT"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objAppUserDetails;
        }

        public FocusAppDetails[] SearchFocusApp(FocusAppInput input)
        {
            FocusAppDetails[] objAppfApplication = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHFOCUSAPP];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@AppDESC"].Value = input.App_DESC;
                sp.Parameters["@PageIndex"].Value = input.CurrentPage;
                sp.Parameters["@PageSize"].Value = input.PageSize;
                sp.Parameters["@SortColumn"].Value = input.SortExpression;
                sp.Parameters["@SortOrder"].Value = input.SortOrder;
                ds = proc.GetDataset(sp);
                objAppfApplication = new FocusAppDetails[ds.Tables[0].Rows.Count];
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppfApplication[i] = new FocusAppDetails();
                    objAppfApplication[i].ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"]);
                    objAppfApplication[i].App_Id = Convert.ToString(ds.Tables[0].Rows[i]["APP_ID"]);
                    objAppfApplication[i].App_DESC = Convert.ToString(ds.Tables[0].Rows[i]["APP_DS"]);
                    objAppfApplication[i].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecord"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppfApplication;
        }
        public FocusAppDetails[] PopulateSearchFocusApp(FocusAppInput input)
        {
            FocusAppDetails[] objAppfApplication = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHFOCUSAPP_ID];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@ID"].Value = input.ID;
                ds = proc.GetDataset(sp);
                objAppfApplication = new FocusAppDetails[ds.Tables[0].Rows.Count];
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppfApplication[i] = new FocusAppDetails();
                    objAppfApplication[i].App_Id = Convert.ToString(ds.Tables[0].Rows[i]["APP_ID"]);
                    objAppfApplication[i].App_DESC = Convert.ToString(ds.Tables[0].Rows[i]["APP_DS"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppfApplication;
        }

        //public AppFocusOfficeDetails[] SearchAppFocusOffice(AppFocusOfficeInput input)
        //{
        //    AppFocusOfficeDetails[] objAppFocusOfficeDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSEARCHFOCUSOFFICEAPP];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@OfficeDesc"].Value = input.Office_Desc;
        //        sp.Parameters["@ID"].Value = input.ID;
        //        ds = proc.GetDataset(sp);
        //        objAppFocusOfficeDetails = new AppFocusOfficeDetails[ds.Tables[0].Rows.Count];
        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objAppFocusOfficeDetails[i] = new AppFocusOfficeDetails();
        //            objAppFocusOfficeDetails[i].ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"]);
        //            objAppFocusOfficeDetails[i].Office_ID = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_ID"]);
        //            objAppFocusOfficeDetails[i].Office_Desc = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_DS"]);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objAppFocusOfficeDetails;
        //}

        public AppFocusOfficeDetails[] SearchAppFocusOffice(AppFocusOfficeInput input)
        {
            AppFocusOfficeDetails[] objAppFocusOfficeDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHFOCUSOFFICEAPP];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@OfficeDesc"].Value = input.Office_Desc;
                sp.Parameters["@ID"].Value = input.ID;
                sp.Parameters["@inActive"].Value = !input.IsActive;
                sp.Parameters["@FLAG"].Value = input.STATUS;

                sp.Parameters["@PageIndex"].Value = input.CurrentPage;
                sp.Parameters["@PageSize"].Value = input.PageSize;
                sp.Parameters["@SortColumn"].Value = input.SortExpression;
                sp.Parameters["@SortOrder"].Value = input.SortOrder;

                ds = proc.GetDataset(sp);
                objAppFocusOfficeDetails = new AppFocusOfficeDetails[ds.Tables[0].Rows.Count];
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppFocusOfficeDetails[i] = new AppFocusOfficeDetails();
                    objAppFocusOfficeDetails[i].ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"]);
                    objAppFocusOfficeDetails[i].Office_ID = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_ID"]);
                    objAppFocusOfficeDetails[i].Office_Desc = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_DS"]);
                    objAppFocusOfficeDetails[i].IsReport = ds.Tables[0].Rows[i]["ISREPORT"].ToString();
                    objAppFocusOfficeDetails[i].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"].ToString());
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppFocusOfficeDetails;
        }

        public FocusGroupDetails[] SearchAPPFGroup(FocusGroupInput input)
        {
            FocusGroupDetails[] objAppfGroup = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHAPPFOCUSGROUP];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@ID"].Value = input.ID;
                sp.Parameters["@Group_NM"].Value = input.Group_NM;
                sp.Parameters["@inActive"].Value = !input.IsActive;

                sp.Parameters["@PageIndex"].Value = input.CurrentPage;
                sp.Parameters["@PageSize"].Value = input.PageSize;
                sp.Parameters["@SortColumn"].Value = input.SortExpression;
                sp.Parameters["@SortOrder"].Value = input.SortOrder;

                ds = proc.GetDataset(sp);
                objAppfGroup = new FocusGroupDetails[ds.Tables[0].Rows.Count];
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objAppfGroup[i] = new FocusGroupDetails();
                    objAppfGroup[i].ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"]);
                    objAppfGroup[i].Group_NM = Convert.ToString(ds.Tables[0].Rows[i]["GROUP_NM"]);
                    objAppfGroup[i].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"].ToString());

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppfGroup;
        }

        public AppFocusOfficeDetails[] GetMappingOfficeGroupDetails(FocusGroupMappingInput input)
        {
            AppFocusOfficeDetails[] objMappDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTAPPFOFFICEGROUPMAPP];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@inAPPFOfficeGroupID"].Value = input.GROUP_ID;
                ds = proc.GetDataset(sp);
                objMappDetails = new AppFocusOfficeDetails[ds.Tables[0].Rows.Count];

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    objMappDetails[i] = new AppFocusOfficeDetails();
                    objMappDetails[i].Office_ID = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_ID"]);
                    objMappDetails[i].Office_Desc = Convert.ToString(ds.Tables[0].Rows[i]["OFFICE_DS"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objMappDetails;
        }

        public VersionDetails[] PopulatePreVersions(AppUserInput AppInput)
        {
            VersionDetails[] objVersionDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DataSet ds = new DataSet();
            try
            {
                if (AppInput.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPPREVERSION];
                    sp.Parameters["@AppId"].Value = AppInput.App_ID;
                    sp.Parameters["@App_Version"].Value = AppInput.App_Version;
                    sp.Parameters["@App_Type"].Value = AppInput.APP_TYPE;
                    ds = proc.GetDataset(sp);
                    objVersionDetails = new VersionDetails[ds.Tables[0].Rows.Count];
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPVERSION];
                    ds = proc.GetDataset(sp);
                    objVersionDetails = new VersionDetails[ds.Tables[0].Rows.Count];
                }
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objVersionDetails[iCount] = new VersionDetails();
                    objVersionDetails[iCount].VersionId = Convert.ToString(ds.Tables[0].Rows[iCount]["RELEASE_ID"]);
                    objVersionDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["RELEASE_VERSION"]);
                    objVersionDetails[iCount].IsRollback = Convert.ToChar(ds.Tables[0].Rows[iCount]["ISROLLBACK"]);
                    objVersionDetails[iCount].AppExeName = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Exe_Name"]);
                    objVersionDetails[iCount].EntryPoint = Convert.ToString(ds.Tables[0].Rows[iCount]["EntryPoint"]);

                }

            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objVersionDetails;
        }

        public OfficeGroupMappingReportDetail[] PopulateOfficeGroupMappingReport(OfficeGroupMappingReportInput Request)
        {
            OfficeGroupMappingReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPOFFICEGROUPMAPPINGREPORT];   //proc["usp_GetAppUploadedReport"];  
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@group_ID"].Value = Request.GroupID;
                sp.Parameters["@PageIndex"].Value = Request.PageIndex;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortColumn;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;
                ds = proc.GetDataset(sp);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                objDetails = new OfficeGroupMappingReportDetail[ds.Tables[0].Rows.Count];
                //}
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objDetails[iCount] = new OfficeGroupMappingReportDetail();
                    if (Convert.ToString(ds.Tables[0].Rows[iCount]["GROUP_NM"]) != null)
                    {
                        objDetails[iCount].GroupNM = Convert.ToString(ds.Tables[0].Rows[iCount]["GROUP_NM"]);
                        objDetails[iCount].OfficeID = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_DS"]);
                        objDetails[iCount].ADSID = Convert.ToString(ds.Tables[0].Rows[iCount]["ADS_ID"]);
                        objDetails[iCount].USER_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["USER_NM"]);
                        objDetails[iCount].COMPUTER_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["COMPUTER_NM"]);
                        objDetails[iCount].IP_ADDR_TXT = Convert.ToString(ds.Tables[0].Rows[iCount]["IP_ADDR_TXT"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                    }
                }

                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new OfficeGroupMappingReportDetail[1];
                    objDetails[0] = new OfficeGroupMappingReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new OfficeGroupMappingReportDetail[1];
                    objDetails[0] = new OfficeGroupMappingReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }

        public StandardResponse CheckPilotAppUser(PilotAppUploadInput input)
        {
            std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSEARCHPILOTAPPUSER];
            DataSet ds = new DataSet();
            string status= string.Empty;
            try
            {
                sp.Parameters["@APP_NAME"].Value = input.APP_NAME;
                sp.Parameters["@APP_VERSION"].Value = input.AppVersion;
                sp.Parameters["@ADS_ID"].Value = input.AdsId;
                sp.Parameters["@MACHINENAME"].Value = input.MachineName;
                sp.Parameters["@OFFICEID"].Value = input.OfficeId;
                sp.Parameters["@IPAddress"].Value = input.IPAddress;
                //Market Release
                sp.Parameters["@APPCODEBASE"].Value = input.AppCodeBase;
                ds = proc.GetDataset(sp);
                status = sp.Parameters["@outStatus"].Value.ToString();
                if (status != "0")
                {                   
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                    std.ResponseMessage = status;
                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
            }
            return std;
        }

        //For Global Aert
        //public SearchLinkResult[] SearchLinkDataGlobalAlert(ClientGlobalAlertInput request)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();

        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = null;
        //    DataSet ds = new DataSet();
        //    SearchLinkResult[] objSearchLinkResult = null;
        //    ////call admin procedure
        //    try
        //    {
        //        sp = proc[Constants.CONSTSPGLOBALALERT];
        //        sp.Parameters["@ClientID"].Value = request.ClientId;
        //        DataSet dsGetLinkID = new DataSet();
        //        SearchLink[] objSearchLink = null;
        //        SearchLinkDetails[] objSearchLinkDetails = null;
        //        SearchLinkCategoryDetails[] objSearchLinkCategoryDetails = null;
        //        ds = proc.GetDataset(sp);
        //        //if (input.Mode == string.Empty)
        //        //{
        //        //    for (int k = 0; k < ds.Tables.Count - 1; k++)
        //        //    {
        //        //        for (int i = 0; i < ds.Tables[k].Rows.Count; i++)
        //        //        {
        //        //            if (!string.IsNullOrEmpty(ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString()) && ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString() != "ENG")
        //        //            {
        //        //                if (ds.Tables[k].Rows[i]["Cat_Dtl_Language_CD"].ToString() != input.LanguageCode)
        //        //                {
        //        //                    ds.Tables[k].Rows[i].Delete();
        //        //                    ds.Tables[k].Rows[i].AcceptChanges();
        //        //                }
        //        //            }
        //        //        }
        //        //    }
        //        //}

        //        objSearchLinkResult = new SearchLinkResult[ds.Tables.Count];
        //        List<int> lstLink = new List<int>();
        //        List<int> lstLinkDetail = new List<int>();

        //        for (int searchLinkResult = 0; searchLinkResult < ds.Tables.Count; searchLinkResult++)
        //        {
        //            objSearchLinkResult[searchLinkResult] = new SearchLinkResult();
        //            objSearchLink = new SearchLink[this.CountSearchLink(ds.Tables[searchLinkResult])];
        //            int link = 0;
        //            foreach (DataRow linkDataRow in ds.Tables[searchLinkResult].Rows)
        //            {
        //                int iLink_ID = Convert.ToInt32(linkDataRow["LINK_ID"]);
        //                if (!lstLink.Contains(iLink_ID))
        //                {
        //                    objSearchLink[link] = new SearchLink();
        //                    DataRow[] linkArray = ds.Tables[searchLinkResult].Select("LINK_ID=" + iLink_ID, "Dtl_Label_NM ASC");

        //                    if (linkArray.Length > 0)
        //                    {
        //                        objSearchLink[link].AccountCode = Convert.ToString(linkArray[0]["ACCOUNT_CD"]);
        //                        objSearchLink[link].CityCode = Convert.ToString(linkArray[0]["City_CD"]);
        //                        objSearchLink[link].CountryCode = Convert.ToString(linkArray[0]["Country_CD"]);
        //                        objSearchLink[link].AccountName = Convert.ToString(linkArray[0]["Account_NM"]);
        //                        objSearchLink[link].CountryName = Convert.ToString(linkArray[0]["Country_NM"]);
        //                        objSearchLink[link].CityName = Convert.ToString(linkArray[0]["City_NM"]);
        //                        if (linkArray[0]["LinkType_CD"].ToString() != Constants.CONSTGENERAL)
        //                        {
        //                            objSearchLink[link].IsGlobalAcc = Convert.ToBoolean(linkArray[0]["IsGlobalAcc"]);
        //                            objSearchLink[link].IsVirtualAcc = Convert.ToBoolean(linkArray[0]["IsVirtualAcc"]);
        //                            objSearchLink[link].IsGlobalCountry = Convert.ToBoolean(linkArray[0]["IsGlobalCountry"]);
        //                            objSearchLink[link].IsVirtualCountry = Convert.ToBoolean(linkArray[0]["IsVirtualCountry"]);
        //                            objSearchLink[link].IsGlobalCity = Convert.ToBoolean(linkArray[0]["IsGlobalCity"]);
        //                            objSearchLink[link].IsVirtualCity = Convert.ToBoolean(linkArray[0]["IsVirtualCity"]);
        //                        }

        //                        objSearchLink[link].LabelName = string.Empty;
        //                        objSearchLink[link].LinkID = Convert.ToInt32(linkArray[0]["LINK_ID"]);
        //                        objSearchLink[link].IsBrowsable = false;
        //                        objSearchLink[link].GlobalID = Convert.ToInt32(linkArray[0]["Global_ID"] == DBNull.Value ? 0 : linkArray[0]["Global_ID"]);
        //                        objSearchLink[link].GlobalText = string.Empty;
        //                        objSearchLink[link].LabelID = 0;
        //                        objSearchLink[link].CarrierCode = (linkArray[0]["Carrier_CD"] == DBNull.Value ? string.Empty : linkArray[0]["Carrier_CD"]).ToString();
        //                        objSearchLink[link].Rating = 0;
        //                        objSearchLinkDetails = new SearchLinkDetails[this.CountSearchLinkDetail(linkArray)];
        //                        int linkDtl = 0;
        //                        foreach (DataRow drLink in linkArray)
        //                        {
        //                            int iLinkDetail_ID = Convert.ToInt32(drLink["LINK_DTL_ID"]);
        //                            if (!lstLinkDetail.Contains(iLinkDetail_ID))
        //                            {
        //                                objSearchLinkDetails[linkDtl] = new SearchLinkDetails();
        //                                DataRow[] drLinkDetailArray = ds.Tables[searchLinkResult].Select("LINK_ID=" + iLink_ID + " AND LINK_DTL_ID=" + iLinkDetail_ID);

        //                                if (drLinkDetailArray.Length > 0)
        //                                {
        //                                    objSearchLinkDetails[linkDtl].LinkDetailID = Convert.ToInt32(drLinkDetailArray[0]["LINK_DTL_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkTypeCode = Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]);
        //                                    objSearchLinkDetails[linkDtl].LabelName = Convert.ToString(drLinkDetailArray[0]["Dtl_Label_NM"]);

        //                                    if (!string.IsNullOrEmpty(drLinkDetailArray[0]["LINK"].ToString()))
        //                                    {
        //                                        //if (drLinkDetailArray[0]["LINK"].ToString().StartsWith(SharePointFolder))
        //                                        //{
        //                                        //    drLinkDetailArray[0]["LINK"] = SharePointURL + drLinkDetailArray[0]["LINK"].ToString();
        //                                        //}
        //                                    }
        //                                    if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].Link = (drLinkDetailArray[0]["LINK"] != null ? drLinkDetailArray[0]["LINK"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                                    }
        //                                    else
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].Link = drLinkDetailArray[0]["LINK"] != null ? drLinkDetailArray[0]["LINK"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                                    }

        //                                    objSearchLinkDetails[linkDtl].LanguageCode = Convert.ToString(drLinkDetailArray[0]["Dtl_Language_CD"]);
        //                                    objSearchLinkDetails[linkDtl].DownloadFlag = Convert.ToBoolean(drLinkDetailArray[0]["Dtl_Download_Flag"]);
        //                                    objSearchLinkDetails[linkDtl].HoverText = Convert.ToString(drLinkDetailArray[0]["Dtl_Hover_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].GeneralText = Convert.ToString(drLinkDetailArray[0]["General_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].IsAlertRangeVisible = Convert.ToBoolean(drLinkDetailArray[0]["VISIBLE_TO_CLIENT"]);
        //                                    objSearchLinkDetails[linkDtl].Keyword_Txt = Convert.ToString(drLinkDetailArray[0]["KeyWord_Txt"]);
        //                                    objSearchLinkDetails[linkDtl].IsBrowsable = false;
        //                                    objSearchLinkDetails[linkDtl].LabelID = Convert.ToInt32(drLinkDetailArray[0]["Dtl_Label_ID"] != DBNull.Value ? drLinkDetailArray[0]["Dtl_Label_ID"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["Dtl_Label_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkID = Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"] != DBNull.Value ? drLinkDetailArray[0]["LINK_ID"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"]); //Convert.ToInt32(drLinkDetailArray[0]["LINK_ID"]);
        //                                    objSearchLinkDetails[linkDtl].LinkType = Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"] != DBNull.Value ? drLinkDetailArray[0]["Dtl_Link_Type"] : 0); ////Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"]);// Convert.ToInt32(drLinkDetailArray[0]["Dtl_Link_Type"]); 
        //                                    objSearchLinkDetails[linkDtl].Rating = 0;
        //                                    objSearchLinkDetails[linkDtl].ValidFromDate = Convert.ToString(drLinkDetailArray[0]["ValidFrom_DT"] != DBNull.Value ? drLinkDetailArray[0]["ValidFrom_DT"] : string.Empty);
        //                                    objSearchLinkDetails[linkDtl].ValidToDate = Convert.ToString(drLinkDetailArray[0]["ValidTo_DT"] != DBNull.Value ? drLinkDetailArray[0]["ValidTo_DT"] : string.Empty);

        //                                    if (Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]) == Constants.CONSTGENERAL)
        //                                    {
        //                                        objSearchLinkDetails[linkDtl].DisplayValidFromMonth = int.Parse(drLinkDetailArray[0]["DisplayFrom_Month"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidToMonth = int.Parse(drLinkDetailArray[0]["DisplayTo_Month"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidFromDay = int.Parse(drLinkDetailArray[0]["DisplayFrom_Day"].ToString());
        //                                        objSearchLinkDetails[linkDtl].DisplayValidToDay = int.Parse(drLinkDetailArray[0]["DisplayTo_Day"].ToString());
        //                                    }

        //                                    if (Convert.ToString(drLinkDetailArray[0]["LinkType_CD"]) == "CATEGORY")
        //                                    {
        //                                        objSearchLinkCategoryDetails = new SearchLinkCategoryDetails[this.CountSearchLinkCatDetail(drLinkDetailArray)];
        //                                        int iLinkDtlCat = 0;
        //                                        if (objSearchLinkCategoryDetails.Length > 0)
        //                                        {
        //                                            foreach (DataRow drLinkCatDtl in drLinkDetailArray)
        //                                            {
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat] = new SearchLinkCategoryDetails();

        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkCategoryDetailID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["LINK_CAT_DTL_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LanguageCode = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Language_CD"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].DownloadFlag = Convert.ToBoolean(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Download_Flag"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].HoverText = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Hover_Txt"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].Keyword_Txt = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_KeyWord_Txt"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].IsBrowsable = false;
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LabelID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["Cat_dtl_label_id"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LabelName = Convert.ToString(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Label_NM"]);

        //                                                if (!string.IsNullOrEmpty(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString()))
        //                                                {
        //                                                    //if (drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString().StartsWith(SharePointFolder))
        //                                                    //{
        //                                                    //    drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] = SharePointURL + drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString();
        //                                                    //}
        //                                                }

        //                                                if (!string.IsNullOrEmpty(CompName) && !(string.IsNullOrEmpty(CompIP)))
        //                                                {
        //                                                    objSearchLinkCategoryDetails[iLinkDtlCat].Link = (drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] != null ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString() : string.Empty).Replace(CompName, CompIP);////linkArray[0]["LINK"].ToString(); 
        //                                                }
        //                                                else
        //                                                {
        //                                                    objSearchLinkCategoryDetails[iLinkDtlCat].Link = drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"] != null ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link"].ToString() : string.Empty;////linkArray[0]["LINK"].ToString(); 
        //                                                }

        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkDetailID = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["LINK_DTL_ID"]);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].LinkType = Convert.ToInt32(drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link_Type"] != DBNull.Value ? drLinkDetailArray[iLinkDtlCat]["Cat_Dtl_Link_Type"] : 0);
        //                                                objSearchLinkCategoryDetails[iLinkDtlCat].Rating = 0;
        //                                                iLinkDtlCat++;
        //                                            }

        //                                            objSearchLinkDetails[linkDtl].LinkCategoryDetails = objSearchLinkCategoryDetails;
        //                                        }
        //                                    }
        //                                }

        //                                if (!lstLinkDetail.Contains(iLinkDetail_ID))
        //                                {
        //                                    lstLinkDetail.Add(iLinkDetail_ID);
        //                                }

        //                                linkDtl++;
        //                            }
        //                        }

        //                        objSearchLink[link].LinkDetails = objSearchLinkDetails;
        //                    }

        //                    if (!lstLink.Contains(iLink_ID))
        //                    {
        //                        lstLink.Add(iLink_ID);
        //                    }

        //                    link++;
        //                }
        //            }

        //            objSearchLinkResult[searchLinkResult].SearchLnkResult = objSearchLink;
        //            lstLink = new List<int>();
        //            lstLinkDetail = new List<int>();
        //        }
        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objSearchLinkResult == null)
        //        {
        //            objSearchLinkResult = new SearchLinkResult[3];
        //            objSearchLinkResult[0] = new SearchLinkResult();
        //        }

        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResult[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objSearchLinkResult;
        //}

        //public SearchLinkResult[] SearchLinkDataClientAlert(SearchLinkInput input)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    string SharePointFolder = ConfigurationSettings.AppSettings[Constants.CONSTSPFLODER].ToString();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = null;
        //    DataSet ds = new DataSet();
        //    SearchLinkResult[] objSearchLinkResult = null;
        //    ////call admin procedure
        //    try
        //    {
        //        if (input.IsAdmin)
        //        {
        //            if (input.Mode == Constants.CONSTGLOBAL)
        //            {
        //                sp = proc[Constants.CONSTSPGLOBALCATNAME];
        //                sp.Parameters["@inGlobalID"].Value = input.GlobalCode;
        //            }
        //            else if (input.Mode == Constants.CONSTLOCATION)
        //            {
        //                sp = proc[Constants.CONSTSPLOCATIONNAME];
        //                sp.Parameters["@inAccCode"].Value = input.AccountCode;
        //                sp.Parameters["@inCountry"].Value = input.FromCountryCode;
        //                sp.Parameters["@inCity"].Value = input.FromCityCode;
        //                ////sp.Parameters["@inAggRule"].Value = input.AggregationRule;
        //            }
        //            else if (input.Mode == Constants.CONSTCARRIERNAME)
        //            {
        //                sp = proc[Constants.CONSTSPSEARCHCARRIERNAME];
        //                sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //            }
        //            else if (input.Mode == Constants.CONSTOTHERINFO)
        //            {
        //                sp = proc[Constants.CONSTSPOTHERINFONAME];
        //            }
        //        }
        //        ////call client procedure
        //        else
        //        {
        //            sp = proc[Constants.CONSTSPSEARCHNAME];
        //            sp.Parameters["@inAccCode"].Value = (input.AccountCode == "0" ? string.Empty : input.AccountCode);
        //            sp.Parameters["@inFromCountry"].Value = (input.FromCountryCode == "0" ? string.Empty : input.FromCountryCode);
        //            sp.Parameters["@inToCountry"].Value = (input.ToCountryCode == "0" ? string.Empty : input.ToCountryCode);
        //            sp.Parameters["@inFromCity"].Value = (input.FromCityCode == "0" ? string.Empty : input.FromCityCode);
        //            sp.Parameters["@inToCity"].Value = (input.ToCityCode == "0" ? string.Empty : input.ToCityCode);
        //            sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //            sp.Parameters["@inLanguageCD"].Value = input.LanguageCode;
        //            sp.Parameters["@inLanguageRest"].Value = input.LanguageRest;
        //            sp.Parameters["@indate"].Value = input.InputDate;                   
        //        }
        //        DataSet dsGetLinkID = new DataSet();
        //        SearchLink[] objSearchLink = null;
        //        SearchLinkDetails[] objSearchLinkDetails = null;
        //        SearchLinkCategoryDetails[] objSearchLinkCategoryDetails = null;
        //        ds = proc.GetDataset(sp);
        //        objSearchLinkResult = new SearchLinkResult[ds.Tables.Count];
        //        List<int> lstLink = new List<int>();
        //        List<int> lstLinkDetail = new List<int>();
        //        objSearchLink[0].AccountCode = "a";
        //        objSearchLinkResult[0].SearchLnkResult = objSearchLink;
        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {               
        //        if (objSearchLinkResult == null)
        //        {
        //            objSearchLinkResult = new SearchLinkResult[3];
        //            objSearchLinkResult[0] = new SearchLinkResult();
        //        }

        //        objSearchLinkResult[0].STDResponse = new StandardResponse();
        //        objSearchLinkResult[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResult[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //        ////objSearchLinkResult = new SearchLinkResult[3];
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objSearchLinkResult;
        //}

        //public SearchClientTotalAlert SearchClientTotalAlert(SearchLinkInput input)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    string SharePointFolder = ConfigurationSettings.AppSettings[Constants.CONSTSPFLODER].ToString();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = null;
        //    DataSet ds = new DataSet();
        //    SearchClientTotalAlert objSearchesult = null;
        //    objSearchesult = new SearchClientTotalAlert();
        //    ////call admin procedure
        //    try
        //    {
        //        if (input.IsAdmin)
        //        {
        //            if (input.Mode == Constants.CONSTGLOBAL)
        //            {
        //                sp = proc[Constants.CONSTSPGLOBALCATNAME];
        //                sp.Parameters["@inGlobalID"].Value = input.GlobalCode;
        //            }
        //            else if (input.Mode == Constants.CONSTLOCATION)
        //            {
        //                sp = proc[Constants.CONSTSPLOCATIONNAME];
        //                sp.Parameters["@inAccCode"].Value = input.AccountCode;
        //                sp.Parameters["@inCountry"].Value = input.FromCountryCode;
        //                sp.Parameters["@inCity"].Value = input.FromCityCode;
        //                ////sp.Parameters["@inAggRule"].Value = input.AggregationRule;
        //            }
        //            else if (input.Mode == Constants.CONSTCARRIERNAME)
        //            {
        //                sp = proc[Constants.CONSTSPSEARCHCARRIERNAME];
        //                sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //            }
        //            else if (input.Mode == Constants.CONSTOTHERINFO)
        //            {
        //                sp = proc[Constants.CONSTSPOTHERINFONAME];
        //            }
        //        }
        //        ////call client procedure
        //        else
        //        {
        //            sp = proc[Constants.CONSTSPTOTALALERT];
        //            sp.Parameters["@inAccCode"].Value = (input.AccountCode == "0" ? string.Empty : input.AccountCode);
        //            sp.Parameters["@inFromCountry"].Value = (input.FromCountryCode == "0" ? string.Empty : input.FromCountryCode);
        //            sp.Parameters["@inToCountry"].Value = (input.ToCountryCode == "0" ? string.Empty : input.ToCountryCode);
        //            sp.Parameters["@inFromCity"].Value = (input.FromCityCode == "0" ? string.Empty : input.FromCityCode);
        //            sp.Parameters["@inToCity"].Value = (input.ToCityCode == "0" ? string.Empty : input.ToCityCode);
        //            sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //            sp.Parameters["@inLanguageCD"].Value = input.LanguageCode;
        //            sp.Parameters["@inLanguageRest"].Value = input.LanguageRest;
        //            sp.Parameters["@indate"].Value = input.InputDate;
        //        }
        //        //DataSet dsGetLinkID = new DataSet();
        //        //SearchClientTotalAlert objSearchAlert = null;
        //        // SearchLinkDetails[] objSearchLinkDetails = null;
        //        //SearchLinkCategoryDetails[] objSearchLinkCategoryDetails = null;
        //        ds = proc.GetDataset(sp);
        //        //objSearchesult = new SearchClientTotalAlert();
        //        //List<int> lstLink = new List<int>();
        //        //List<int> lstLinkDetail = new List<int>();
        //        objSearchesult.TotalAlert = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
        //        objSearchesult.AlertDate = Convert.ToString(ds.Tables[0].Rows[0][1]);
        //        objSearchesult.STDResponse = new StandardResponse();
        //        objSearchesult.STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objSearchesult == null)
        //        {
        //            objSearchesult = new SearchClientTotalAlert();
        //            //objSearchAlert = new  SearchLinkResult();
        //        }

        //        objSearchesult.STDResponse = new StandardResponse();
        //        objSearchesult.STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchesult.STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);
        //        ////objSearchLinkResult = new SearchLinkResult[3];
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objSearchesult;
        //}

        //public SearchInfoTotalAlert SearchOtherInfoTotalAlert(SearchOtherInfoInput input)
        //{
        //    string CompName = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPNAME].ToString();
        //    string CompIP = ConfigurationSettings.AppSettings[Constants.CONSTSPCOMPIP].ToString();
        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();
        //    string SharePointFolder = ConfigurationSettings.AppSettings[Constants.CONSTSPFLODER].ToString();
        //    DBStoredProcedure sp = new DBStoredProcedure();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    if (input.Mode == "0")
        //    {
        //        sp = proc[Constants.CONSTSPOTHERINFOTOTALALERT];
        //        sp.Parameters["@inOtherInfoCode"].Value = input.OtherInfoCode;
        //        sp.Parameters["@inLanguageCD"].Value = input.LanguageCD;
        //        sp.Parameters["@inDate"].Value = input.InputDate;
        //    }
        //    else
        //    {
        //        sp = proc[Constants.CONSTCATEGORYSPADMIN];
        //        sp.Parameters["@inOtherInfoCode"].Value = input.OtherInfoCode;
        //    }

        //    DataSet ds = new DataSet();
        //    SearchInfoTotalAlert objSearchInfoResult = null;

        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objSearchInfoResult = new SearchInfoTotalAlert();
        //        objSearchInfoResult.TotalAlert = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
        //        objSearchInfoResult.AlertDate = Convert.ToString(ds.Tables[0].Rows[0][1].ToString());

        //        objSearchInfoResult.STDResponse = new StandardResponse();
        //        objSearchInfoResult.STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objSearchInfoResult == null)
        //        {
        //            objSearchInfoResult = new SearchInfoTotalAlert();
        //            objSearchInfoResult = new SearchInfoTotalAlert();
        //        }

        //        objSearchInfoResult.STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchInfoResult.STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchInfoResult.STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9000);

        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objSearchInfoResult;
        //}

        //public AuditTrialDetails[] GetAuditTrial(AuditTrialInput input)
        //{
        //    AuditTrialDetails[] objAuditTrialDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTGETAUDITTRIAL];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@LABEL_ID"].Value = input.LabelId;
        //        sp.Parameters["@MODE"].Value = input.Mode;
        //        ds = proc.GetDataset(sp);
        //        objAuditTrialDetails = new AuditTrialDetails[ds.Tables[0].Rows.Count];

        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            objAuditTrialDetails[i] = new AuditTrialDetails();
        //            objAuditTrialDetails[i].Created_User_ID = Convert.ToString(ds.Tables[0].Rows[i]["CREATED_USER"]);
        //            objAuditTrialDetails[i].Created_DT = Convert.ToString(ds.Tables[0].Rows[i]["CREATED_DT"]);
        //            objAuditTrialDetails[i].Modified_User_ID = Convert.ToString(ds.Tables[0].Rows[i]["MODIFIED_USER"]);
        //            objAuditTrialDetails[i].Modified_DT = Convert.ToString(ds.Tables[0].Rows[i]["MODIFIED_DT"]);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objAuditTrialDetails;
        //}

        public GetAppLatestVersionInfo GetAppLatestVersion(GetAppLatestVersionInput getAppLatestVersion)
        {
            GetAppLatestVersionInfo response = new GetAppLatestVersionInfo();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.GETAPPLATESTVERSION];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@App_ID"].Value = int.Parse(getAppLatestVersion.App_ID);
                sp.Parameters["@App_Type"].Value = getAppLatestVersion.App_Type;
                ds = proc.GetDataset(sp);

                if (null != ds && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    response.App_ID = ds.Tables[0].Rows[0]["App_ID"].ToString();
                    response.App_Name = ds.Tables[0].Rows[0]["App_Name"].ToString();
                    response.App_Type = ds.Tables[0].Rows[0]["App_Type"].ToString();
                    response.App_Version = ds.Tables[0].Rows[0]["App_Version"].ToString();
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);////Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return response;
        }
    }
}