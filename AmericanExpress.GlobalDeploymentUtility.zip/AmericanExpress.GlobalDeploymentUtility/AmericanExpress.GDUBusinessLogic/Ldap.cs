﻿//-----------------------------------------------------------------------
// <copyright file="LDAP.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class is used for Authorisation.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/02/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessLogic
{
    class Ldap
    {
        /// <summary>
        /// <Description>This method is to authorise any user.</Description>
        /// </summary>
        /// <param name="LdapPath"></param>
        /// <param name="GroupName"></param>
        /// <param name="UserName"></param>
        /// <returns></returns>
        public List<string> AuthoriseUser(string LdapPath,string GroupName, string UserName)
        { 
        return new List<string>();
        }

    }
}
