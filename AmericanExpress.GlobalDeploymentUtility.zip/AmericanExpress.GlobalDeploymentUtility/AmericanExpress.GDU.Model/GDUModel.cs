﻿namespace AmericanExpress.GDU.Model
{

    #region Namespace
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Security.Principal;
    using System.ServiceModel;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web;
    using System.Xml;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model.GDUService;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    using AmericanExpress.GDU.Utilities.ExceptionMgmt;
    using System.Data.SqlClient;
    using System.Configuration;

    #endregion


    public partial class GDUModel
    {

        GDUServiceClient _gWiz;
        string OtherInfoWord = string.Empty;
        ClientRelease _clientRelease;
        ClientReleaseQuery _clientReleaseQuery;
        ClientReleaseDtlQuery[] _clientReleaseDtlQuery;
        const string EVENT_SOURCE_NAME = "GWiz";
        const string LOG_NAME = "Application";
        StringBuilder _searchResult;

        public DataTable GetAppUserDetails(string userId, int App_ID, bool isDeactive, string Inflag, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtAppUser = new DataTable();
            AppUserDetails[] AppuserDetails;
            DataRow drAppUserInfo;
            try
            {
                this._gWiz = new GDUServiceClient();

                dtAppUser.Columns.Add("UserID", Type.GetType("System.String"));
                dtAppUser.Columns.Add("AppName", Type.GetType("System.String"));
                dtAppUser.Columns.Add("Role_CD", Type.GetType("System.String"));
                dtAppUser.Columns.Add("UserName", Type.GetType("System.String"));
                dtAppUser.Columns.Add("TotalRecord", Type.GetType("System.String"));
                AppUserQuery AppuserQuery = new AppUserQuery();
                AppuserQuery.UserId = userId;
                AppuserQuery.App_ID = App_ID;
                AppuserQuery.IsDeactive = isDeactive;
                AppuserQuery.InFlag = Inflag;

                AppuserQuery.PageIndex = currentPage;
                AppuserQuery.PageSize = pageSize;
                AppuserQuery.SortColumn = sortExpression;
                AppuserQuery.SortOrder = sortOrder;

                AppuserDetails = this._gWiz.SearchAppUsers(AppuserQuery);

                for (int iCount = 0; iCount < AppuserDetails.Length; iCount++)
                {
                    drAppUserInfo = dtAppUser.NewRow();
                    drAppUserInfo["UserID"] = AppuserDetails[iCount].UserId;
                    drAppUserInfo["AppName"] = AppuserDetails[iCount].AppName;
                    drAppUserInfo["Role_CD"] = AppuserDetails[iCount].Role_CD;
                    drAppUserInfo["UserName"] = AppuserDetails[iCount].UserName;
                    drAppUserInfo["TotalRecord"] = AppuserDetails[iCount].TotalRecords;
                    dtAppUser.Rows.Add(drAppUserInfo);
                }

                return dtAppUser;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        //public Dictionary<string, string> PopulateClientInfo(string clientName, int maxRecords)
        //{
        //    ClientDetails[] objClientDetails;
        //    StandardResponse std = new StandardResponse();
        //    DataTable dtClientInfo = new DataTable();
        //    DataRow[] drClientRows;
        //    DataRow drClient;
        //    Dictionary<string, string> objDictionary = new Dictionary<string, string>();
        //    try
        //    {
        //        this._gWiz = new GDUServiceClient();
        //        std = this._gWiz.PopulateClientInfo(out objClientDetails);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    if (std.ResponseCodeStatus == StdResponseCode.Success)
        //    {
        //        dtClientInfo.Columns.Add(new DataColumn("ClientID", System.Type.GetType("System.String")));
        //        dtClientInfo.Columns.Add(new DataColumn("ClientName", System.Type.GetType("System.String")));
        //        dtClientInfo.Columns.Add(new DataColumn("Client_abbrev_nm", System.Type.GetType("System.String")));
        //        int iCount = objClientDetails.Count();
        //        for (int iCounter = 0; iCounter < iCount; iCounter++)
        //        {
        //            drClient = dtClientInfo.NewRow();
        //            drClient["ClientID"] = objClientDetails[iCounter].ClientID.ToString();
        //            drClient["ClientName"] = objClientDetails[iCounter].ClientName.ToString();
        //            drClient["Client_abbrev_nm"] = objClientDetails[iCounter].ClientAbbreviation.ToString();
        //            dtClientInfo.Rows.Add(drClient);
        //        }

        //        drClientRows = dtClientInfo.Select("ClientName Like '" + clientName + "%'");
        //        for (int counter = 0; counter < drClientRows.Count(); counter++)
        //        {
        //            objDictionary.Add(drClientRows[counter]["ClientID"].ToString() + "-" + drClientRows[counter]["Client_abbrev_nm"].ToString(), drClientRows[counter]["ClientName"].ToString());
        //        }
        //    }
        //    else
        //    {
        //        throw new GenericException(std.ResponseMessage, 0);
        //    }

        //    return objDictionary;
        //}

        public Dictionary<string, string> PopulateUserInfo(string userName, int maxRecords, string systemCD)
        {
            this._gWiz = new GDUServiceClient();
            Dictionary<string, string> dictUsers = new Dictionary<string, string>();
            UserQuery userQuery = new UserQuery();
            userQuery.UserName = userName;
            userQuery.System_CD = systemCD;
            UserDetails[] details = this._gWiz.PopulateSearchUsers(userQuery);
            if (details != null)
            {
                int iCount = details.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    if (!dictUsers.ContainsKey(details[iCounter].UserId))
                    {
                        dictUsers.Add(details[iCounter].UserId.ToString() + "-" + details[iCounter].UserId.ToString(), details[iCounter].UserName.ToString());
                    }
                }
            }
            return dictUsers;
        }

        public Dictionary<string, string> PopulateApplicationInfo()
        {
            ApplicationDetails[] objAppDetails;
            StandardResponse std = new StandardResponse();
            DataTable dtApplicationInfo = new DataTable();
            DataRow[] drApplicationRows;
            DataRow drApplication;
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                std = this._gWiz.PopulateAppInfo(out objAppDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                dtApplicationInfo.Columns.Add(new DataColumn("AppID", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppDeployPath", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppAbbrName", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppExeName", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppAbbr", System.Type.GetType("System.String")));
                //dtApplicationInfo.Columns.Add(new DataColumn("EntryPoint", System.Type.GetType("System.String")));
                //dtApplicationInfo.Columns.Add(new DataColumn("App_Type", System.Type.GetType("System.String")));
                int iCount = objAppDetails.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    drApplication = dtApplicationInfo.NewRow();
                    drApplication["AppID"] = objAppDetails[iCounter].AppID.ToString();
                    drApplication["AppDeployPath"] = objAppDetails[iCounter].AppDeployPath.ToString();
                    drApplication["AppAbbrName"] = objAppDetails[iCounter].AppAbbrName.ToString();
                    drApplication["AppAbbr"] = objAppDetails[iCounter].AppAbbr.ToString();
                    //drApplication["EntryPoint"] = objAppDetails[iCounter].EntryPoint.ToString();
                    //drApplication["App_Type"] = objAppDetails[iCounter].App_Type.ToString();
                    dtApplicationInfo.Rows.Add(drApplication);
                }


                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    objDictionary.Add(objAppDetails[iCounter].AppID.ToString() + "~" + objAppDetails[iCounter].AppDeployPath.ToString(), objAppDetails[iCounter].AppAbbrName.ToString());
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }

        /// <summary>
        /// populate users
        /// </summary>
        /// <returns>dictionary </returns>
        public Dictionary<string, string> PopulateUsers(string ClientID, string RequestedBy, string IsGrouping, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            this._gWiz = new GDUServiceClient();
            Dictionary<string, string> dictUsers = new Dictionary<string, string>();
            UserQuery userQuery = new UserQuery();
            userQuery.ClientId = Convert.ToInt32(ClientID);
            userQuery.IsGrouping = IsGrouping;
            userQuery.RequestedBy = RequestedBy;
            userQuery.System_CD = System_CD;

            userQuery.CurrentPage = currentPage;
            userQuery.PageSize = pageSize;
            userQuery.SortExpression = sortExpression;
            userQuery.SortOrder = sortOrder;

            UserDetails[] details = this._gWiz.SearchUsers(userQuery);
            if (details != null)
            {
                int iCount = details.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    if (!dictUsers.ContainsKey(details[iCounter].UserId))
                    {
                        dictUsers.Add(details[iCounter].UserId, details[iCounter].UserName);
                    }
                }
            }
            return dictUsers;
        }

        /// <summary>
        /// To Get Client Deployment DataTable
        /// </summary>
        /// <param name="UserId">user id</param>
        /// <param name="Version">version</param>
        /// <param name="Flag">flag</param>
        /// <returns>client deployment table</returns>
        public DataTable GetClientDeploymentDataTable(string UserId, string Version, int Flag, string clientId, int App_ID, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drClientDeploymentDetail;
            StandardResponse std;
            ClientDeploymentInfo[] clientDeploymentDetails;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("App_Name", Type.GetType("System.String"));
            dtReport.Columns.Add("User_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("IP", Type.GetType("System.String"));
            dtReport.Columns.Add("Nac_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("Exe_VersionNo", Type.GetType("System.String"));
            dtReport.Columns.Add("Exe_TimeStamp_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("RecordTimeStamp_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("Application_Path", Type.GetType("System.String"));
            dtReport.Columns.Add("Latest_VersionNo", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_Name", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            ClientDeploymentReportQuery cdReportQuery = new ClientDeploymentReportQuery();
            cdReportQuery.UserId = UserId;
            cdReportQuery.Version = Version;
            cdReportQuery.NonMaxFlag = Flag;
            cdReportQuery.clientId = clientId;
            cdReportQuery.App_ID = App_ID.ToString();
            cdReportQuery.System_CD = System_CD;

            cdReportQuery.CurrentPage = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortExpression = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateGWizClientDeploymentReport(cdReportQuery, out clientDeploymentDetails);

            for (int iCollCount = 0; iCollCount < clientDeploymentDetails.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drClientDeploymentDetail = dtReport.NewRow();
                drClientDeploymentDetail["App_Name"] = clientDeploymentDetails[iCollCount].App_Name;
                drClientDeploymentDetail["User_Id"] = clientDeploymentDetails[iCollCount].UserId;
                drClientDeploymentDetail["IP"] = clientDeploymentDetails[iCollCount].IPAddress;
                drClientDeploymentDetail["Nac_Id"] = clientDeploymentDetails[iCollCount].NACId;
                drClientDeploymentDetail["Exe_VersionNo"] = clientDeploymentDetails[iCollCount].ExeVersionNo;
                drClientDeploymentDetail["Exe_TimeStamp_DT"] = clientDeploymentDetails[iCollCount].ExeTimeStamp;
                drClientDeploymentDetail["RecordTimeStamp_DT"] = clientDeploymentDetails[iCollCount].TimeStamp;
                drClientDeploymentDetail["Application_Path"] = clientDeploymentDetails[iCollCount].ApplicationPath;
                drClientDeploymentDetail["Latest_VersionNo"] = clientDeploymentDetails[iCollCount].LatestVersionNo;
                drClientDeploymentDetail["Computer_Name"] = clientDeploymentDetails[iCollCount].ComputerName;
                drClientDeploymentDetail["TotalRecord"] = clientDeploymentDetails[iCollCount].ToatlRecords;
                dtReport.Rows.Add(drClientDeploymentDetail);
            }

            return dtReport;
        }

        /// <summary>
        /// populate version
        /// </summary>
        /// <returns>versions</returns>
        public Dictionary<string, string> PopulateVersion(int AppId, string System_CD)
        {
            this._gWiz = new GDUServiceClient();
            ApplicationDetails AppDetails = new ApplicationDetails();
            AppUserQuery appDetails = new AppUserQuery();
            appDetails.App_ID = AppId;
            appDetails.System_CD = System_CD;
            Dictionary<string, string> dictVersion = new Dictionary<string, string>();
            VersionDetail[] details = this._gWiz.SearchVersion(appDetails);
            if (details != null)
            {
                dictVersion = details.ToDictionary(p => p.ReleaseId + "-" + p.App_ID, p => p.ReleaseVersion);
            }

            return dictVersion;
        }

        /// <summary>
        /// add sp user
        /// </summary>
        /// <param name="UserName">user name </param>
        /// <param name="userGroup">user group</param>
        /// <param name="userEmail">user email</param>
        /// <param name="userType">user type</param>
        public void AddSPUser(string UserName, string userEmail, string userType, string userGroup)
        {
            try
            {
                //this._gWizSP = new SP.GDUServiceClient();
                //SP.SharePointUserRequest request = new AmericanExpress.GWiz.Model.SharePointService.SharePointUserRequest();
                //SP.SharePointUserResponse response = new SP.SharePointUserResponse();
                //request.UserName = UserName;
                //if (userType == Constants.CONSTCLIENT)
                //{
                //    request.UserType = Constants.USERROLECLIENT;
                //}
                //else
                //{
                //    request.UserType = Constants.USERROLEADMIN;
                //}

                //request.UserEmail = userEmail;
                //request.UserGroup = userGroup;
                //response = this._gWizSP.AddSPUser(request);

                //if (userEmail == string.Empty)
                //    userEmail = response.Email;

                //if (response.ErrorCode == Constants.CONSTSUCCESS && request.UserType == Constants.USERROLECLIENT)
                //{
                //    ManageUsers(Constants.CONSTADD, (UserName.Substring(UserName.LastIndexOf(@"\"))).Replace(@"\", string.Empty), response.UserName, userEmail, Constants.CONSTLANGUAGE, userType, DateTime.Now, string.Empty, 0, userGroup,string.Empty);
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ManageApplication(string actionmode, string applicationType, string abbriviation, string ExeName, string applicationDeploymentPath, string applicationName, string appId, string entrypoint)
        {
            StandardResponse stdResponse = new StandardResponse();
            this._gWiz = new GDUServiceClient();
            try
            {
                ManageApplicationQuery applicationDetails = new ManageApplicationQuery();
                applicationDetails.AppId = appId;
                applicationDetails.ApplicationNM = applicationName;
                applicationDetails.ApplicationDeployPath = applicationDeploymentPath;
                applicationDetails.ApplicationExeName = ExeName;
                applicationDetails.AppType = applicationType;
                applicationDetails.AppMode = actionmode;
                applicationDetails.ApplicationAbbr = abbriviation;
                applicationDetails.EntryPoint = entrypoint;
                stdResponse = this._gWiz.ManageApplication(applicationDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (stdResponse.ResponseCodeStatus == StdResponseCode.Failed)
            {
                throw new GenericException(stdResponse.ResponseMessage, 0);
            }
        }

        public DataTable GetApplicationDetails(string ApplicationNM, string AppId, string ApplicationAbbr, bool isDeactive, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtApplication = new DataTable();
            ManageApplicationDetails[] applicationDetails;
            DataRow drApplicationInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtApplication.Columns.Add("ApplicationNM", Type.GetType("System.String"));
                dtApplication.Columns.Add("ApplicationAbbr", Type.GetType("System.String"));
                dtApplication.Columns.Add("ApplicationDeployPath", Type.GetType("System.String"));
                dtApplication.Columns.Add("ApplicationType", Type.GetType("System.String"));
                dtApplication.Columns.Add("ApplicationExeName", Type.GetType("System.String"));
                dtApplication.Columns.Add("AppId", Type.GetType("System.String"));
                dtApplication.Columns.Add("EntryPoint", Type.GetType("System.String"));
                dtApplication.Columns.Add("TotalRecord", Type.GetType("System.String"));

                ManageApplicationQuery applicationQuery = new ManageApplicationQuery();
                applicationQuery.ApplicationNM = ApplicationNM;
                applicationQuery.IsDeactive = isDeactive;
                applicationQuery.ApplicationAbbr = ApplicationAbbr;
                applicationQuery.AppId = AppId;

                applicationQuery.PageIndex = currentPage;
                applicationQuery.PageSize = pageSize;
                applicationQuery.SortColumn = sortExpression;
                applicationQuery.SortOrder = sortOrder;

                applicationDetails = this._gWiz.SearchApplication(applicationQuery);

                for (int iCount = 0; iCount < applicationDetails.Length; iCount++)
                {
                    drApplicationInfo = dtApplication.NewRow();
                    drApplicationInfo["ApplicationNM"] = applicationDetails[iCount].ApplicationNM;
                    drApplicationInfo["ApplicationAbbr"] = applicationDetails[iCount].ApplicationAbbr;
                    drApplicationInfo["ApplicationDeployPath"] = applicationDetails[iCount].ApplicationDeployPath;
                    drApplicationInfo["ApplicationExeName"] = applicationDetails[iCount].ApplicationExeName;
                    drApplicationInfo["ApplicationType"] = applicationDetails[iCount].ApplicationType;
                    drApplicationInfo["AppId"] = applicationDetails[iCount].AppId;
                    drApplicationInfo["EntryPoint"] = applicationDetails[iCount].EntryPoint;
                    drApplicationInfo["TotalRecord"] = applicationDetails[iCount].TotalRecords;
                    dtApplication.Rows.Add(drApplicationInfo);
                }

                return dtApplication;
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        /// <summary>
        /// Manages the users.
        /// </summary>
        /// <param name="actionmode">action mode</param>
        /// <param name="userId">user id</param>
        /// <param name="userName">user name</param>
        /// <param name="userEmail">user email</param>
        /// <param name="userLanguage">user language</param>
        /// <param name="userRole">user role</param>
        /// <param name="modifiedon">date and time of modification</param>
        public void ManageUsers(string actionmode, string userId, string userName, string userEmail, string userLanguage, string userRole, DateTime modifiedon, string authorizedRoleIds, int App_ID, string defaultClientAbbr, string CurrentRole, string System_CD)
        {
            StandardResponse stdResponse;
            this._gWiz = new GDUServiceClient();
            UserQuery userDetails = new UserQuery();
            userDetails.UserId = userId;
            userDetails.UserName = userName;
            userDetails.LanguageCode = userLanguage;
            userDetails.AuthorizedRoleIds = authorizedRoleIds;
            userDetails.App_ID = App_ID;
            userDetails.System_CD = System_CD;

            if (userRole == Constants.CONSTCLIENT)
            {
                userDetails.UserRoleCode = Constants.USERROLECLIENT;
            }
            else if (userRole == Constants.ADMINUSERTYPE)
            {
                userDetails.UserRoleCode = Constants.USERROLEADMIN;
            }
            else
            {
                userDetails.UserRoleCode = userRole;
            }

            userDetails.EmailAddress = userEmail;
            userDetails.ModifiedUserDate = modifiedon;
            if (userRole == Constants.CONSTCLIENT)
            {
                userDetails.ModifiedUserID = userId;
            }
            else
            {
                userDetails.ModifiedUserID = GetUserNameAdmin();
            }

            userDetails.Mode = actionmode;
            try
            {
                stdResponse = this._gWiz.ManageUsers(userDetails);
                if (userRole != Constants.CONSTCLIENT)
                {
                    if (userRole != Constants.ADMINUSERTYPE)
                    {
                        if (actionmode == Constants.CONSTADD || actionmode == Constants.CONSTACTIVATE)
                        {
                            if (authorizedRoleIds == string.Empty)
                            {
                                // AddSPManageUser(userId, userEmail, "AD", "All");
                                // AddSPManageUser(userId, userEmail, "DC", "All");
                                //AddSPManageUser(userId, userEmail, userRole, defaultClientAbbr);
                            }
                            else
                            {
                                // AddRemoveSPUser("Add", authorizedRoleIds, userId, userEmail);
                            }

                        }
                        else if (actionmode == Constants.CONSTDEACTIVATE)
                        {
                            if (CurrentRole == string.Empty)
                            {
                                // RemoveSPUser(userId, userEmail, "AD", "All");
                                //  RemoveSPUser(userId, userEmail, "DC", "All");
                            }
                            else
                            {
                                // AddRemoveSPUser("Remove", CurrentRole, userId, userEmail);
                                //string[] allRoleIdClientId = authorizedRoleIds.Remove(authorizedRoleIds.Length - 1, 1).Split(',');
                                //for (int index = 0; index < allRoleIdClientId.Length; index++)
                                //{
                                //    ManageRoleDetails[] roleDetails;
                                //    ManageRoleQuery roleQuery = new ManageRoleQuery();
                                //    try
                                //    {
                                //        roleQuery.ClientId = Convert.ToInt32(allRoleIdClientId[index].Split('-')[1]);
                                //        roleQuery.RoleTypeCD = allRoleIdClientId[index].Split('-')[0].ToString();

                                //        roleDetails = this._gWiz.SearchClientRoles(roleQuery);

                                //        for (int iCount = 0; iCount < roleDetails.Length; iCount++)
                                //        {
                                //            RemoveSPUser(userId, userEmail, roleDetails[iCount].RoleTypeCD, roleDetails[iCount].ClientAbbr);
                                //        }
                                //    }
                                //    catch (Exception ex)
                                //    {
                                //    }
                                //}
                            }
                            //RemoveSPUser(userId, userEmail, userRole);
                        }
                        else if (actionmode == Constants.CONSTUPDATE)
                        {
                            //if (CurrentRole != string.Empty)
                            //    AddRemoveSPUser("Remove", CurrentRole, userId, userEmail);
                            //if (authorizedRoleIds != string.Empty)
                            //    AddRemoveSPUser("Add", authorizedRoleIds, userId, userEmail);

                            //RemoveSPUser(userId, userEmail, userRole, "All");
                            //AddSPManageUser(userId, userEmail, userRole, defaultClientAbbr);

                        }
                    }
                }
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {

                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }
        }

        /// <summary>
        /// Fetches username for admin
        /// </summary>
        /// <returns></returns>
        private string GetUserNameAdmin()
        {
            string UserName = string.Empty;
            try
            {
                UserName = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return UserName;
        }

        public void ManageAppUsers(string actionmode, string userId, string userRole, DateTime modifiedon, string authorizedRoleIds, string CurrentRole)
        {
            StandardResponse stdResponse;
            this._gWiz = new GDUServiceClient();
            AppUserQuery AppuserDetails = new AppUserQuery();
            AppuserDetails.UserId = userId;
            AppuserDetails.Mode = actionmode;
            AppuserDetails.Role_CD = userRole;
            AppuserDetails.ModifiedUserDate = modifiedon;
            AppuserDetails.AuthorizedRoleIds = authorizedRoleIds;

            try
            {
                stdResponse = this._gWiz.ManageAppUsers(AppuserDetails);
                if (userRole != Constants.CONSTCLIENT)
                {
                    if (userRole != Constants.ADMINUSERTYPE)
                    {
                        if (actionmode == Constants.CONSTADD || actionmode == Constants.CONSTACTIVATE)
                        {
                            if (authorizedRoleIds == string.Empty)
                            {
                                //AddSPManageUser(userId, userEmail, "AD", "All");
                                //AddSPManageUser(userId, userEmail, "DC", "All");
                                //AddSPManageUser(userId, userEmail, userRole, defaultClientAbbr);
                            }
                            else
                            {
                                //AddRemoveSPUser("Add", authorizedRoleIds, userId, userEmail);
                            }

                        }
                        else if (actionmode == Constants.CONSTDEACTIVATE)
                        {
                            if (CurrentRole == string.Empty)
                            {
                                //RemoveSPUser(userId, userEmail, "AD", "All");
                                //RemoveSPUser(userId, userEmail, "DC", "All");
                            }
                            else
                            {
                                //AddRemoveSPUser("Remove", CurrentRole, userId, userEmail);

                            }
                        }
                        else if (actionmode == Constants.CONSTUPDATE)
                        {
                            //if (CurrentRole != string.Empty)
                            //    //AddRemoveSPUser("Remove", CurrentRole, userId, userEmail);
                            //if (authorizedRoleIds != string.Empty)
                            //AddRemoveSPUser("Add", authorizedRoleIds, userId, userEmail);


                        }
                    }
                }
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {

                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }
        }

        public void ManageRole(string roleCd, string roleName, int clientId, DateTime modifiedDt, string flag, string authorizedFunctionIds, string roleTypeCD, string System_CD)//ref string outRoleCd, ref int outClientId)
        {
            StandardResponse stdResponse = new StandardResponse();
            this._gWiz = new GDUServiceClient();
            try
            {
                ManageRoleQuery roleDetails = new ManageRoleQuery();
                roleDetails.RoleCode = roleCd;
                roleDetails.RoleName = roleName;
                roleDetails.ClientId = clientId;
                //roleDetails.FunctionId = Convert.ToInt32(functionId);
                roleDetails.CreatedBy = GetUserNameAdmin();
                roleDetails.ModifiedDt = modifiedDt;
                roleDetails.Flag = flag;
                roleDetails.AuthorizedFunctionIds = authorizedFunctionIds;
                roleDetails.RoleTypeCD = roleTypeCD;
                roleDetails.System_CD = System_CD;
                stdResponse = this._gWiz.ManageRole(roleDetails);
                //return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (stdResponse.ResponseCodeStatus == StdResponseCode.Failed)
            {
                throw new GenericException(stdResponse.ResponseMessage, 0);
            }
        }


        /// <summary>
        /// Populates the role.
        /// </summary>
        /// <returns>return dictionary</returns>
        public Dictionary<string, string> PopulateRole()
        {
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                UserRoleDetails[] roleDetails;
                roleDetails = this._gWiz.PopulateUserRole();
                int iCount = roleDetails.Count();
                for (int i = 0; i < iCount; i++)
                {
                    objDictionary.Add(roleDetails[i].RoleCode + "-" + roleDetails[i].ClientID, roleDetails[i].RoleName);
                }
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }

            return objDictionary;
        }

        public Dictionary<string, string> PopulateRoleMaster()
        {
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                RoleMasterDetails[] roleMasterDetails;
                roleMasterDetails = this._gWiz.PopulateRoleMaster();
                int iCount = roleMasterDetails.Count();
                for (int i = 0; i < iCount; i++)
                {
                    objDictionary.Add(roleMasterDetails[i].RoleCD, roleMasterDetails[i].RoleName);
                }
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }

            return objDictionary;
        }

        public DataTable GetRoleDetails(int Client_ID, string roleCode, string roleName, bool isDeactive, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtRole = new DataTable();
            ManageRoleDetails[] roleDetails;
            DataRow drroleInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtRole.Columns.Add("CLIENT_ID", Type.GetType("System.String"));
                dtRole.Columns.Add("CLIENT_NAME", Type.GetType("System.String"));
                dtRole.Columns.Add("ROLE_NAME", Type.GetType("System.String"));
                dtRole.Columns.Add("ROLE_CD", Type.GetType("System.String"));
                dtRole.Columns.Add("MODIFIED_DT", Type.GetType("System.DateTime"));
                dtRole.Columns.Add("ROLETYPE_CD", Type.GetType("System.String"));
                dtRole.Columns.Add("SYSTEM_NAME", Type.GetType("System.String"));
                dtRole.Columns.Add("TotalRecord", Type.GetType("System.String"));
                ManageRoleQuery roleQuery = new ManageRoleQuery();
                roleQuery.ClientId = Client_ID;
                roleQuery.RoleCode = roleCode;
                roleQuery.RoleName = roleName;
                roleQuery.IsDeactive = isDeactive;
                roleQuery.System_CD = System_CD;

                roleQuery.CurrentPage = currentPage;
                roleQuery.PageSize = pageSize;
                roleQuery.SortExpression = sortExpression;
                roleQuery.SortOrder = sortOrder;

                roleDetails = this._gWiz.SearchRoles(roleQuery);
                for (int iCount = 0; iCount < roleDetails.Length; iCount++)
                {
                    drroleInfo = dtRole.NewRow();
                    drroleInfo["CLIENT_ID"] = roleDetails[iCount].ClientId;
                    drroleInfo["CLIENT_NAME"] = roleDetails[iCount].ClientName;
                    drroleInfo["ROLE_NAME"] = roleDetails[iCount].RoleName;
                    drroleInfo["ROLE_CD"] = roleDetails[iCount].RoleCode;
                    drroleInfo["MODIFIED_DT"] = roleDetails[iCount].ModifiedDate;
                    drroleInfo["ROLETYPE_CD"] = roleDetails[iCount].RoleTypeCD;
                    drroleInfo["SYSTEM_NAME"] = roleDetails[iCount].SYSTEM_NAME;
                    drroleInfo["TotalRecord"] = roleDetails[iCount].TotalRecord;
                    dtRole.Rows.Add(drroleInfo);
                }

                return dtRole;
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        public DataTable GetFunctionDetails(string funcType, string roleId, int clientID, string SYSTEM_CD)
        {
            DataTable dtFunctions = new DataTable();
            ManageFunctionDetails[] funcDetails;
            StandardResponse std = new StandardResponse();
            DataRow drFuncInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtFunctions.Columns.Add("FUNCTION_ID", Type.GetType("System.Int32"));
                dtFunctions.Columns.Add("FUNCTION_NM", Type.GetType("System.String"));
                ManageFunctionQuery funcQuery = new ManageFunctionQuery();
                funcQuery.ClientId = clientID;
                funcQuery.RoleCode = roleId;
                funcQuery.FunctionType = funcType;
                funcQuery.System_CD = SYSTEM_CD;
                funcDetails = this._gWiz.PopulateFunctions(funcQuery);
                for (int iCount = 0; iCount < funcDetails.Length; iCount++)
                {
                    drFuncInfo = dtFunctions.NewRow();
                    drFuncInfo["FUNCTION_ID"] = funcDetails[iCount].FuntionId;
                    drFuncInfo["FUNCTION_NM"] = funcDetails[iCount].FunctionName;
                    dtFunctions.Rows.Add(drFuncInfo);
                }
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            return dtFunctions;
        }

        /// <summary>
        /// Gets the user details
        /// </summary>
        /// <param name="userName">user name</param>
        /// <param name="userId">user id</param>
        /// <returns>return user details</returns>
        public DataTable GetUserDetails(string userName, string userId, bool isDeactive, string RequestedBy, string IsGrouping, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtUser = new DataTable();
            UserDetails[] userDetails;
            DataRow drUserInfo;
            try
            {
                this._gWiz = new GDUServiceClient();

                dtUser.Columns.Add("UserID", Type.GetType("System.String"));
                dtUser.Columns.Add("UserName", Type.GetType("System.String"));
                dtUser.Columns.Add("EmailAddress", Type.GetType("System.String"));
                dtUser.Columns.Add("Language", Type.GetType("System.String"));
                dtUser.Columns.Add("Role", Type.GetType("System.String"));
                dtUser.Columns.Add("LanguageCode", Type.GetType("System.String"));
                dtUser.Columns.Add("RoleCode", Type.GetType("System.String"));
                dtUser.Columns.Add("ModifiedDT", Type.GetType("System.DateTime"));
                dtUser.Columns.Add("DefaultClientID", Type.GetType("System.Int32"));
                dtUser.Columns.Add("App_ID", Type.GetType("System.Int32"));
                dtUser.Columns.Add("TotalRecord", Type.GetType("System.String"));
                UserQuery userQuery = new UserQuery();
                userQuery.UserId = userId;
                userQuery.UserName = userName;
                userQuery.IsDeactive = isDeactive;
                userQuery.RequestedBy = RequestedBy;
                userQuery.IsGrouping = IsGrouping;
                userQuery.System_CD = System_CD;

                userQuery.CurrentPage = currentPage;
                userQuery.PageSize = pageSize;
                userQuery.SortExpression = sortExpression;
                userQuery.SortOrder = sortOrder;

                userDetails = this._gWiz.SearchUsers(userQuery);

                for (int iCount = 0; iCount < userDetails.Length; iCount++)
                {
                    drUserInfo = dtUser.NewRow();
                    drUserInfo["UserID"] = userDetails[iCount].UserId;
                    drUserInfo["UserName"] = userDetails[iCount].UserName;
                    drUserInfo["EmailAddress"] = userDetails[iCount].EmailAddress;
                    drUserInfo["LanguageCode"] = userDetails[iCount].LanguageCode;
                    drUserInfo["Language"] = userDetails[iCount].Language;
                    drUserInfo["Role"] = userDetails[iCount].UserRole;
                    drUserInfo["RoleCode"] = userDetails[iCount].UserRoleCode;
                    drUserInfo["ModifiedDT"] = userDetails[iCount].ModifiedUserDate;
                    drUserInfo["DefaultClientID"] = userDetails[iCount].DefaultClientID;
                    drUserInfo["App_ID"] = userDetails[iCount].App_ID;
                    drUserInfo["TotalRecord"] = userDetails[iCount].TotalRecord;
                    dtUser.Rows.Add(drUserInfo);
                }

                return dtUser;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        /// <summary>
        /// Populates the language
        /// </summary>
        /// <returns>return dictionary</returns>
        public Dictionary<string, string> PopulateLanguage()
        {
            LanguageDetails[] languageDetails;
            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                std = this._gWiz.PopulateLanguage(out languageDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                int iCount = languageDetails.Count();

                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    objDictionary.Add(languageDetails[iCounter].LanguageCode, languageDetails[iCounter].LanguageName);
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }

        public DataTable PopulateRoleDetails(string roleType, string userId, string SYSTEM_CD)
        {
            DataTable dtRoles = new DataTable();
            RoleDetails[] roleDetails;
            StandardResponse std = new StandardResponse();
            DataRow drRoleInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtRoles.Columns.Add("ROLE_CLIENT_ID", Type.GetType("System.String"));
                dtRoles.Columns.Add("ROLE_NM", Type.GetType("System.String"));
                RoleQuery roleQuery = new RoleQuery();
                roleQuery.RoleType = roleType;
                roleQuery.UserId = userId;
                roleQuery.System_CD = SYSTEM_CD;
                roleDetails = this._gWiz.PopulateRole(roleQuery);
                for (int iCount = 0; iCount < roleDetails.Length; iCount++)
                {
                    drRoleInfo = dtRoles.NewRow();
                    drRoleInfo["ROLE_CLIENT_ID"] = roleDetails[iCount].RoleClientId;
                    drRoleInfo["ROLE_NM"] = roleDetails[iCount].RoleName;
                    dtRoles.Rows.Add(drRoleInfo);
                }
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            return dtRoles;
        }

        public Dictionary<string, string> PopulateAppAbbrInfo()
        {
            ApplicationDetails[] objAppDetails;
            StandardResponse std = new StandardResponse();
            DataTable dtApplicationInfo = new DataTable();
            DataRow[] drApplicationRows;
            DataRow drApplication;
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                std = this._gWiz.PopulateAppInfo(out objAppDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                dtApplicationInfo.Columns.Add(new DataColumn("AppID", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppDeployPath", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppAbbrName", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppExeName", System.Type.GetType("System.String")));
                dtApplicationInfo.Columns.Add(new DataColumn("AppAbbr", System.Type.GetType("System.String")));
                int iCount = objAppDetails.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    drApplication = dtApplicationInfo.NewRow();
                    drApplication["AppID"] = objAppDetails[iCounter].AppID.ToString();
                    drApplication["AppDeployPath"] = objAppDetails[iCounter].AppDeployPath.ToString();
                    drApplication["AppAbbrName"] = objAppDetails[iCounter].AppAbbrName.ToString();
                    drApplication["AppAbbr"] = objAppDetails[iCounter].AppAbbr.ToString();
                    dtApplicationInfo.Rows.Add(drApplication);
                }


                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    objDictionary.Add(objAppDetails[iCounter].AppAbbr.ToString(), objAppDetails[iCounter].AppAbbrName.ToString());
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }

        public DataTable GetAppUploadedDataTable(string UserId, string fromdate, string todate, string rollback, int App_ID, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppUploadedDetail;
            StandardResponse std;
            AppUploadedInfo[] AppUploadedDetail;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("App_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("USER_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("Version", Type.GetType("System.String"));
            dtReport.Columns.Add("IP", Type.GetType("System.String"));
            dtReport.Columns.Add("Mac_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("Upload_Dt", Type.GetType("System.String"));
            dtReport.Columns.Add("[RollBack]", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));

            AppUploadedReportQuery cdReportQuery = new AppUploadedReportQuery();
            cdReportQuery.UserId = UserId;
            cdReportQuery.From_DT = fromdate;
            cdReportQuery.To_Date = todate;
            cdReportQuery.RollBack = rollback;
            cdReportQuery.App_ID = App_ID;

            cdReportQuery.CurrentPage = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortExpression = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateGWizAppUploadedReport(cdReportQuery, out AppUploadedDetail);

            for (int iCollCount = 0; iCollCount < AppUploadedDetail.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drAppUploadedDetail = dtReport.NewRow();
                drAppUploadedDetail["App_NM"] = AppUploadedDetail[iCollCount].App_Name;
                drAppUploadedDetail["USER_NM"] = AppUploadedDetail[iCollCount].User_Name;
                drAppUploadedDetail["Version"] = AppUploadedDetail[iCollCount].Version;
                drAppUploadedDetail["IP"] = AppUploadedDetail[iCollCount].IP;
                drAppUploadedDetail["Mac_NM"] = AppUploadedDetail[iCollCount].Computer_NM;
                drAppUploadedDetail["Upload_Dt"] = AppUploadedDetail[iCollCount].Upload_Dt;
                drAppUploadedDetail["[RollBack]"] = AppUploadedDetail[iCollCount].RollBack;
                drAppUploadedDetail["TotalRecord"] = AppUploadedDetail[iCollCount].TotalRecords;
                dtReport.Rows.Add(drAppUploadedDetail);
            }

            return dtReport;
        }

        public void SaveReleaseInfo(DataTable releaseInfo, string releaseVer, string releaseDate, int App_ID, string IsRollBack, string IP, string System_CD, string APP_TYPE, string clientMachineName)
        {
            int DetailCount = 0;
            int LoopCounter = 0;
            int CurrentRecordCount = 0;
            int ReleaseID = 0;
            int Count1 = 100;
            int indexCount = 0;
            bool Flag = false;
            string UserName = this.GetUserNameAdmin();
            DetailCount = releaseInfo.Rows.Count;
            StandardResponse std;
            this._gWiz = new GDUServiceClient();

            if (DetailCount >= 100)
            {
                LoopCounter = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(DetailCount) / 100));
                for (int j = 0; j < LoopCounter; j++)
                {
                    this._clientRelease = new ClientRelease();
                    this._clientReleaseQuery = new ClientReleaseQuery();

                    if ((DetailCount - CurrentRecordCount) <= 100)
                    {
                        this._clientReleaseDtlQuery = new ClientReleaseDtlQuery[DetailCount - CurrentRecordCount];
                    }
                    else
                    {
                        this._clientReleaseDtlQuery = new ClientReleaseDtlQuery[100];
                    }
                    this._clientReleaseQuery.CREATED_USER_ID = UserName;
                    this._clientReleaseQuery.MODIFIED_USER_ID = UserName;
                    this._clientReleaseQuery.RELEASE_DT = releaseDate;
                    this._clientReleaseQuery.RELEASE_VERSION = releaseVer;
                    this._clientReleaseQuery.App_ID = App_ID;
                    this._clientReleaseQuery.RELEASE_ID = ReleaseID;
                    this._clientReleaseQuery.IsConnected = Flag;
                    this._clientReleaseQuery.IsRollBack = IsRollBack;
                    this._clientReleaseQuery.IP = IP;
                    this._clientReleaseQuery.System_CD = System_CD;
                    this._clientReleaseQuery.APP_TYPE = APP_TYPE;
                    this._clientReleaseQuery.Computer_NM = clientMachineName;

                    this._clientRelease.ClientReleaseVer = this._clientReleaseQuery;

                    indexCount = 0;
                    for (int iCount = CurrentRecordCount; iCount < Count1; iCount++)
                    {
                        if (!string.IsNullOrEmpty(releaseInfo.Rows[iCount]["FileName"].ToString()))
                        {
                            this._clientReleaseDtlQuery[indexCount] = new ClientReleaseDtlQuery();
                            this._clientReleaseDtlQuery[indexCount].CREATED_USER_ID = UserName;
                            this._clientReleaseDtlQuery[indexCount].FILE_NM = releaseInfo.Rows[iCount]["FileName"].ToString();
                            this._clientReleaseDtlQuery[indexCount].FILE_VERSION = releaseInfo.Rows[iCount]["FileVersion"].ToString();
                            this._clientReleaseDtlQuery[indexCount].FILE_PATH = releaseInfo.Rows[iCount]["FilePath"].ToString();
                            this._clientReleaseDtlQuery[indexCount].MODIFIED_USER_ID = UserName;
                            CurrentRecordCount++;
                            indexCount++;
                        }
                    }
                    this._clientRelease.ClientReleaseDtl = this._clientReleaseDtlQuery;
                    std = this._gWiz.ClientReleaseResponse(this._clientRelease);
                    if (std.ResponseCodeStatus.ToString().ToUpper() == "SUCCESS")
                    {
                        ReleaseID = int.Parse(std.ResponseMessage);
                        Flag = true;
                        if ((DetailCount - CurrentRecordCount) <= 100)
                            Count1 = Count1 + (DetailCount - CurrentRecordCount);
                        else
                            Count1 = Count1 + 100;
                    }
                }
            }
            else
            {
                this._gWiz = new GDUServiceClient();
                this._clientRelease = new ClientRelease();
                this._clientReleaseQuery = new ClientReleaseQuery();
                this._clientReleaseDtlQuery = new ClientReleaseDtlQuery[releaseInfo.Rows.Count];
                this._clientReleaseQuery.CREATED_USER_ID = UserName;
                this._clientReleaseQuery.MODIFIED_USER_ID = UserName;
                this._clientReleaseQuery.RELEASE_DT = releaseDate;
                this._clientReleaseQuery.RELEASE_VERSION = releaseVer;
                this._clientReleaseQuery.App_ID = App_ID;
                this._clientReleaseQuery.IsConnected = false;
                this._clientReleaseQuery.IsRollBack = IsRollBack;
                this._clientReleaseQuery.IP = IP;
                this._clientReleaseQuery.System_CD = System_CD;
                this._clientReleaseQuery.APP_TYPE = APP_TYPE;
                this._clientReleaseQuery.Computer_NM = clientMachineName;
                //System.Net.Dns.GetHostName();  
                this._clientRelease.ClientReleaseVer = this._clientReleaseQuery;
                for (int iCount = 0; iCount < releaseInfo.Rows.Count; iCount++)
                {
                    this._clientReleaseDtlQuery[iCount] = new ClientReleaseDtlQuery();
                    this._clientReleaseDtlQuery[iCount].CREATED_USER_ID = UserName;
                    this._clientReleaseDtlQuery[iCount].FILE_NM = releaseInfo.Rows[iCount]["FileName"].ToString();
                    this._clientReleaseDtlQuery[iCount].FILE_VERSION = releaseInfo.Rows[iCount]["FileVersion"].ToString();
                    this._clientReleaseDtlQuery[iCount].FILE_PATH = releaseInfo.Rows[iCount]["FilePath"].ToString();
                    this._clientReleaseDtlQuery[iCount].MODIFIED_USER_ID = UserName;
                }
                this._clientRelease.ClientReleaseDtl = this._clientReleaseDtlQuery;
                std = this._gWiz.ClientReleaseResponse(this._clientRelease);
            }
        }

        /// <summary>
        /// to get client usage datatable
        /// </summary>
        /// <param name="UserId">UserId</param>
        /// <param name="Version">Version</param>
        /// <param name="fromDate">fromDate</param>
        /// <param name="toDate">toDate</param>
        /// <returns>client usage datatable</returns>
        public DataTable GetClientUsageDataTable(string UserId, string Version, string fromDate, string toDate, string ClientID, int App_ID, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drClientUsageDetail;
            StandardResponse std;
            ClientUsageInfo[] clientUsageDetails;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("App_Abbr_Name", Type.GetType("System.String"));
            dtReport.Columns.Add("Nac_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("IP", Type.GetType("System.String"));
            dtReport.Columns.Add("Start_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("End_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("Version", Type.GetType("System.String"));
            dtReport.Columns.Add("Total_Usage", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            ClientUsageReportQuery cdReportQuery = new ClientUsageReportQuery();
            cdReportQuery.UserId = UserId;
            cdReportQuery.Version = Version;
            cdReportQuery.Start_DT = fromDate;
            cdReportQuery.End_DT = toDate;
            cdReportQuery.Client_ID = ClientID;
            cdReportQuery.App_ID = App_ID;
            cdReportQuery.System_CD = System_CD;
            cdReportQuery.PageIndex = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortColumn = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateGWizClientUsageReport(cdReportQuery, out clientUsageDetails);

            for (int iCollCount = 0; iCollCount < clientUsageDetails.Length; iCollCount++)
            {
                drClientUsageDetail = dtReport.NewRow();
                drClientUsageDetail["App_Abbr_Name"] = clientUsageDetails[iCollCount].App_Name;
                drClientUsageDetail["Version"] = clientUsageDetails[iCollCount].Version;
                drClientUsageDetail["IP"] = clientUsageDetails[iCollCount].IP;
                drClientUsageDetail["Nac_Id"] = clientUsageDetails[iCollCount].NACId;
                if (!string.IsNullOrEmpty(clientUsageDetails[iCollCount].Start_DT))
                {
                    drClientUsageDetail["Start_DT"] = Convert.ToDateTime(clientUsageDetails[iCollCount].Start_DT);
                }
                if (!string.IsNullOrEmpty(clientUsageDetails[iCollCount].End_DT))
                {
                    drClientUsageDetail["End_DT"] = Convert.ToDateTime(clientUsageDetails[iCollCount].End_DT);
                }
                drClientUsageDetail["Total_Usage"] = clientUsageDetails[iCollCount].TotalUsage;
                if (!string.IsNullOrEmpty(clientUsageDetails[iCollCount].ComputerName))
                {
                    drClientUsageDetail["Computer_NM"] = clientUsageDetails[iCollCount].ComputerName.ToString();
                }
                drClientUsageDetail["TotalRecord"] = clientUsageDetails[iCollCount].TotalRecord;
                dtReport.Rows.Add(drClientUsageDetail);
            }
            return dtReport;
        }

        public DataTable GetUserMenu(string userId, string Mode, string System_CD)
        {
            DataTable dtUserMenu = new DataTable();
            UserMenuDetails[] userMenuDetails;
            DataRow drUserMenuInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtUserMenu.Columns.Add("FunctionId", Type.GetType("System.Int32"));
                dtUserMenu.Columns.Add("FunctionName", Type.GetType("System.String"));
                dtUserMenu.Columns.Add("FunctionPageUrlTxt", Type.GetType("System.String"));
                dtUserMenu.Columns.Add("FunctionParentId", Type.GetType("System.Int32"));
                dtUserMenu.Columns.Add("DispOrderNo", Type.GetType("System.Int32"));
                UserQuery userQuery = new UserQuery();
                userQuery.UserId = userId;
                userQuery.Mode = Mode;
                userQuery.System_CD = System_CD;
                userMenuDetails = this._gWiz.SearchUserMenu(userQuery);
                for (int iCount = 0; iCount < userMenuDetails.Length; iCount++)
                {
                    drUserMenuInfo = dtUserMenu.NewRow();
                    drUserMenuInfo["FunctionId"] = userMenuDetails[iCount].FunctionId;
                    drUserMenuInfo["FunctionName"] = userMenuDetails[iCount].FunctionName;
                    drUserMenuInfo["FunctionPageUrlTxt"] = userMenuDetails[iCount].FunctionPageUrlTxt;
                    drUserMenuInfo["FunctionParentId"] = userMenuDetails[iCount].FunctionParentId;
                    drUserMenuInfo["DispOrderNo"] = userMenuDetails[iCount].DispOrderNo;
                    dtUserMenu.Rows.Add(drUserMenuInfo);
                }
                return dtUserMenu;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        /// <summary>
        /// Manages Entry Time.
        /// </summary>
        /// <param name="Time">Time</param>

        public string ManageEntryTime(int Time, string UserId, char TimeFormat)
        {
            StandardResponse stdResponse;
            string returnResult = string.Empty;
            this._gWiz = new GDUServiceClient();
            DurationTime Duration = new DurationTime();
            Duration.TimeDuration = Time;
            Duration.UserId = UserId;
            Duration.TimeFormat = TimeFormat;
            try
            {
                stdResponse = this._gWiz.ManageTimeDuration(Duration);

            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {

                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }

            if (stdResponse.ResponseCodeStatus == StdResponseCode.Success)
            {
                returnResult = StdResponseCode.Success.ToString();
            }
            else
            {
                returnResult = StdResponseCode.Failed.ToString();
            }
            return returnResult;
        }

        public DataTable GetAppFocusReportTable(string UserName, string AppName, string fromDate, string toDate, string OfficeID, int OfficeGroupId, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppFocusRepDetail;
            StandardResponse std;

            AppFocusReportDetails[] appFocusReportDetails;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("SequenceNo", Type.GetType("System.String"));
            dtReport.Columns.Add("AppName", Type.GetType("System.String"));
            dtReport.Columns.Add("UserName", Type.GetType("System.String"));
            dtReport.Columns.Add("OfficeId", Type.GetType("System.String"));
            dtReport.Columns.Add("UsageDate", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("IpAddress", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalUsage", Type.GetType("System.String"));
            dtReport.Columns.Add("ToDate", Type.GetType("System.String"));
            dtReport.Columns.Add("ADS_ID", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            AppFocusReportQuery appFocusReportQuery = new AppFocusReportQuery();
            appFocusReportQuery.AppName = AppName;
            appFocusReportQuery.UserName = UserName;
            appFocusReportQuery.FromDate = fromDate;
            appFocusReportQuery.ToDate = toDate;
            appFocusReportQuery.OfficeId = OfficeID;
            appFocusReportQuery.OfficeGroupId = OfficeGroupId;

            appFocusReportQuery.CurrentPage = currentPage;
            appFocusReportQuery.PageSize = pageSize;
            appFocusReportQuery.SortExpression = sortExpression;
            appFocusReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateAppFocusReport(appFocusReportQuery, out appFocusReportDetails);

            for (int iCollCount = 0; iCollCount < appFocusReportDetails.Length; iCollCount++)
            {
                drAppFocusRepDetail = dtReport.NewRow();
                drAppFocusRepDetail["SequenceNo"] = appFocusReportDetails[iCollCount].GroupSeqNo;
                drAppFocusRepDetail["AppName"] = appFocusReportDetails[iCollCount].AppName;
                drAppFocusRepDetail["UserName"] = appFocusReportDetails[iCollCount].UserName;
                drAppFocusRepDetail["OfficeId"] = appFocusReportDetails[iCollCount].OfficeId;
                drAppFocusRepDetail["Computer_NM"] = appFocusReportDetails[iCollCount].ComputerName;
                drAppFocusRepDetail["IpAddress"] = appFocusReportDetails[iCollCount].IpAddress;
                drAppFocusRepDetail["UsageDate"] = appFocusReportDetails[iCollCount].UsageDate.ToString();
                drAppFocusRepDetail["TotalUsage"] = appFocusReportDetails[iCollCount].TotalUsage;
                drAppFocusRepDetail["ToDate"] = appFocusReportDetails[iCollCount].ApplEndDate;
                drAppFocusRepDetail["ADS_ID"] = appFocusReportDetails[iCollCount].ADSId;
                drAppFocusRepDetail["TotalRecord"] = appFocusReportDetails[0].TotalRecords;

                dtReport.Rows.Add(drAppFocusRepDetail);
            }
            return dtReport;
        }

        public DataTable GetAppFocusReportTableDetails(string sequenceNo, string ReqBy, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppFocusRepDetail;
            StandardResponse std;

            AppFocusReportDetails[] appFocusReportDetails;
            this._gWiz = new GDUServiceClient();

            dtReport.Columns.Add("ApplicationName", Type.GetType("System.String"));
            dtReport.Columns.Add("ProcessName", Type.GetType("System.String"));
            dtReport.Columns.Add("APP_FOCUS_STARTDATE", Type.GetType("System.String"));
            dtReport.Columns.Add("APP_FOCUS_ENDDATE", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalUsage", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));

            AppFocusReportQuery appFocusReportQuery = new AppFocusReportQuery();
            appFocusReportQuery.GroupSeqNo = sequenceNo;
            appFocusReportQuery.AppName = ReqBy;

            appFocusReportQuery.CurrentPage = currentPage;
            appFocusReportQuery.PageSize = pageSize;
            appFocusReportQuery.SortExpression = sortExpression;
            appFocusReportQuery.SortOrder = sortOrder;


            std = this._gWiz.PopulateAppFocusReportDetail(appFocusReportQuery, out appFocusReportDetails);

            for (int iCollCount = 0; iCollCount < appFocusReportDetails.Length; iCollCount++)
            {
                drAppFocusRepDetail = dtReport.NewRow();
                drAppFocusRepDetail["ApplicationName"] = appFocusReportDetails[iCollCount].AppName;
                drAppFocusRepDetail["ProcessName"] = appFocusReportDetails[iCollCount].ProcessName;
                drAppFocusRepDetail["APP_FOCUS_STARTDATE"] = appFocusReportDetails[iCollCount].FromDate;
                drAppFocusRepDetail["APP_FOCUS_ENDDATE"] = appFocusReportDetails[iCollCount].ToDate;
                drAppFocusRepDetail["TotalUsage"] = appFocusReportDetails[iCollCount].TotalUsage;
                drAppFocusRepDetail["TotalRecord"] = appFocusReportDetails[0].TotalRecords;
                dtReport.Rows.Add(drAppFocusRepDetail);
            }
            return dtReport;
        }

        public DataTable GetAppUserFocusReportTableDetails(string ADS_ID, string Usagedate, string ReqBy, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppFocusRepDetail;
            StandardResponse std;
            AppFocusReportDetails[] appFocusReportDetails;
            this._gWiz = new GDUServiceClient();

            dtReport.Columns.Add("ApplicationName", Type.GetType("System.String"));
            dtReport.Columns.Add("ProcessName", Type.GetType("System.String"));
            dtReport.Columns.Add("APP_FOCUS_STARTDATE", Type.GetType("System.String"));
            dtReport.Columns.Add("APP_FOCUS_ENDDATE", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalUsage", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));

            AppFocusReportQuery appFocusReportQuery = new AppFocusReportQuery();
            appFocusReportQuery.ADSId = ADS_ID;
            appFocusReportQuery.FromDate = Usagedate;
            appFocusReportQuery.AppName = ReqBy;

            appFocusReportQuery.CurrentPage = currentPage;
            appFocusReportQuery.PageSize = pageSize;
            appFocusReportQuery.SortExpression = sortExpression;
            appFocusReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateAppUserFocusReportDetail(appFocusReportQuery, out appFocusReportDetails);

            for (int iCollCount = 0; iCollCount < appFocusReportDetails.Length; iCollCount++)
            {
                drAppFocusRepDetail = dtReport.NewRow();
                drAppFocusRepDetail["ApplicationName"] = appFocusReportDetails[iCollCount].AppName;
                drAppFocusRepDetail["ProcessName"] = appFocusReportDetails[iCollCount].ProcessName;
                drAppFocusRepDetail["APP_FOCUS_STARTDATE"] = appFocusReportDetails[iCollCount].FromDate;
                drAppFocusRepDetail["APP_FOCUS_ENDDATE"] = appFocusReportDetails[iCollCount].ToDate;
                drAppFocusRepDetail["TotalUsage"] = appFocusReportDetails[iCollCount].TotalUsage;
                drAppFocusRepDetail["TotalRecord"] = appFocusReportDetails[0].TotalRecords;
                dtReport.Rows.Add(drAppFocusRepDetail);
            }
            return dtReport;
        }

        public Dictionary<string, string> PopulateFocusReportApplicationName()
        {
            RptFocusAppDetails[] FocusReportDetails;
            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                std = this._gWiz.PopulateFocusReportApplicationName(out FocusReportDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                int iCount = FocusReportDetails.Count();

                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    objDictionary.Add(FocusReportDetails[iCounter].AppID, FocusReportDetails[iCounter].App_DESC);
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }


        //public Dictionary<string, string> PopulateFocusReportOfficeID()
        //{
        //    RptFocusOfficeIdDetails[] FocusReportDetails;
        //    StandardResponse std = new StandardResponse();
        //    Dictionary<string, string> objDictionary = new Dictionary<string, string>();
        //    try
        //    {
        //        this._gWiz = new GDUServiceClient();
        //        std = this._gWiz.PopulateFocusReportOfficeID(out FocusReportDetails);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    if (std.ResponseCodeStatus == StdResponseCode.Success)
        //    {
        //        int iCount = FocusReportDetails.Count();

        //        for (int iCounter = 0; iCounter < iCount; iCounter++)
        //        {
        //            objDictionary.Add(FocusReportDetails[iCounter].OfficeId, FocusReportDetails[iCounter].Office_DESC);
        //        }
        //    }
        //    else
        //    {
        //        throw new GenericException(std.ResponseMessage, 0);
        //    }

        //    return objDictionary;
        //}
        public Dictionary<string, string> PopulateFocusReportOfficeID(int GroupID)
        {
            RptFocusOfficeIdDetails[] FocusReportDetails;
            FocusGroupRequest request = new FocusGroupRequest();
            request.PopulateRequest = new FocusGroupQuery();
            request.ServiceInput = new StandardInput();

            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                request.PopulateRequest.ID = GroupID;
                this._gWiz = new GDUServiceClient();
                std = this._gWiz.PopulateFocusReportOfficeID(request.ServiceInput, request.PopulateRequest, out FocusReportDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                int iCount = FocusReportDetails.Count();

                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    objDictionary.Add(FocusReportDetails[iCounter].OfficeId, FocusReportDetails[iCounter].Office_DESC);
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }

        public int GetTimeDuration(out  Char TimeFormat)
        {

            TimeDurationDetails[] getTimeDetails;
            DurationTime durationTime = new DurationTime();
            StandardResponse std = new StandardResponse();


            int TimeValue = 0;
            try
            {
                this._gWiz = new GDUServiceClient();
                getTimeDetails = _gWiz.SearchTimeDuration(durationTime);
                TimeValue = Convert.ToInt32(getTimeDetails[0].TimeDuration.ToString());
                TimeFormat = Convert.ToChar(getTimeDetails[0].TimeFormat);


            }
            catch (Exception ex)
            {
                throw ex;
            }

            return TimeValue;
        }

        public DataTable SearchFocusApplication(string AppDESC, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtAppDetails = new DataTable();
            FocusAppDetails[] focusAppDetails;
            DataRow drfocusAppInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtAppDetails.Columns.Add("AppID", Type.GetType("System.String"));
                dtAppDetails.Columns.Add("AppDESC", Type.GetType("System.String"));
                dtAppDetails.Columns.Add("ID", Type.GetType("System.Int32"));
                dtAppDetails.Columns.Add("TotalRecord", Type.GetType("System.String"));
                FocusAppQuery AppNameQuery = new FocusAppQuery();
                AppNameQuery.APP_DS = AppDESC;

                AppNameQuery.CurrentPage = currentPage;
                AppNameQuery.PageSize = pageSize;
                AppNameQuery.SortExpression = sortExpression;
                AppNameQuery.SortOrder = sortOrder;
                focusAppDetails = this._gWiz.SearchFocusApplication(AppNameQuery);
                for (int iCount = 0; iCount < focusAppDetails.Length; iCount++)
                {
                    drfocusAppInfo = dtAppDetails.NewRow();
                    drfocusAppInfo["AppID"] = focusAppDetails[iCount].App_Id;
                    drfocusAppInfo["AppDESC"] = focusAppDetails[iCount].APP_DS;
                    drfocusAppInfo["ID"] = focusAppDetails[iCount].ID;
                    drfocusAppInfo["TotalRecord"] = focusAppDetails[iCount].TotalRecords;
                    dtAppDetails.Rows.Add(drfocusAppInfo);
                }
                return dtAppDetails;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        public void ManageFocusApplication(string ApplicationDESC, int ID)
        {
            StandardResponse stdResponse;
            this._gWiz = new GDUServiceClient();
            FocusAppQuery appDetails = new FocusAppQuery();
            appDetails.APP_DS = ApplicationDESC;
            appDetails.ID = ID;

            try
            {
                stdResponse = this._gWiz.ManageFocusApplication(appDetails);

            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {

                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }
        }
        public DataTable GetFocusAppDetails(int ID)
        {
            DataTable dtFocusApp = new DataTable();
            FocusAppDetails[] AppDetails;
            DataRow drAppInfo;
            try
            {
                this._gWiz = new GDUServiceClient();

                dtFocusApp.Columns.Add("AppID", Type.GetType("System.String"));
                dtFocusApp.Columns.Add("AppDESC", Type.GetType("System.String"));

                FocusAppQuery appQuery = new FocusAppQuery();
                appQuery.ID = ID;


                AppDetails = this._gWiz.PopulateSearchFocusApplication(appQuery);

                for (int iCount = 0; iCount < AppDetails.Length; iCount++)
                {
                    drAppInfo = dtFocusApp.NewRow();
                    drAppInfo["AppID"] = AppDetails[iCount].App_Id;
                    drAppInfo["AppDESC"] = AppDetails[iCount].APP_DS;

                    dtFocusApp.Rows.Add(drAppInfo);
                }

                return dtFocusApp;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }

        //public DataTable GetAppFocusOfficeDetails(string AppOfficeDesc)
        //{
        //    DataTable dtOfficeDetails = new DataTable();
        //    AppFocusOfficeDetails[] officeDetails;
        //    DataRow drOfficeInfo;
        //    try
        //    {
        //        this._gWiz = new GDUServiceClient();
        //        dtOfficeDetails.Columns.Add("ID", Type.GetType("System.Int32"));
        //        dtOfficeDetails.Columns.Add("OFFICE_ID", Type.GetType("System.String"));
        //        dtOfficeDetails.Columns.Add("OFFICE_DESC", Type.GetType("System.String"));
        //        AppFocusOfficeQuery AppNameQuery = new AppFocusOfficeQuery();
        //        AppNameQuery.OfficeDesc = AppOfficeDesc;
        //        officeDetails = this._gWiz.SearchAppFocusOffice(AppNameQuery);

        //        for (int iCount = 0; iCount < officeDetails.Length; iCount++)
        //        {
        //            drOfficeInfo = dtOfficeDetails.NewRow();
        //            drOfficeInfo["ID"] = officeDetails[iCount].ID;
        //            drOfficeInfo["OFFICE_ID"] = officeDetails[iCount].Office_ID;
        //            drOfficeInfo["OFFICE_DESC"] = officeDetails[iCount].Office_Desc;
        //            dtOfficeDetails.Rows.Add(drOfficeInfo);
        //        }

        //        return dtOfficeDetails;
        //    }
        //    catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
        //    {
        //        ////in the faultmsg object , Detail object contains our customized error message information.
        //        //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
        //        string errmsg = faultMsg.Detail.MyCustomErrMsg;
        //        throw new Exception(errmsg);
        //    }
        //    catch (Exception Ex)
        //    {
        //        GDUException GDUEx = new GDUException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
        //    }
        //}

        public DataTable GetAppFocusOfficeDetails(string AppOfficeDesc, int ID, bool isDeactive, string Status, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtOfficeDetails = new DataTable();
            AppFocusOfficeDetails[] officeDetails;
            DataRow drOfficeInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtOfficeDetails.Columns.Add("ID", Type.GetType("System.Int32"));
                dtOfficeDetails.Columns.Add("OFFICE_ID", Type.GetType("System.String"));
                dtOfficeDetails.Columns.Add("OFFICE_DESC", Type.GetType("System.String"));
                dtOfficeDetails.Columns.Add("ISREPORT", Type.GetType("System.String"));
                dtOfficeDetails.Columns.Add("TotalRecord", Type.GetType("System.String"));
                AppFocusOfficeQuery AppNameQuery = new AppFocusOfficeQuery();
                AppNameQuery.Id = ID;
                AppNameQuery.OfficeDesc = AppOfficeDesc;
                AppNameQuery.ISACTIVE = isDeactive;
                AppNameQuery.STATUS = Status;

                AppNameQuery.CurrentPage = currentPage;
                AppNameQuery.PageSize = pageSize;
                AppNameQuery.SortExpression = sortExpression;
                AppNameQuery.SortOrder = sortOrder;

                officeDetails = this._gWiz.SearchAppFocusOffice(AppNameQuery);

                for (int iCount = 0; iCount < officeDetails.Length; iCount++)
                {
                    drOfficeInfo = dtOfficeDetails.NewRow();
                    drOfficeInfo["ID"] = officeDetails[iCount].ID;
                    drOfficeInfo["OFFICE_ID"] = officeDetails[iCount].Office_ID;
                    drOfficeInfo["OFFICE_DESC"] = officeDetails[iCount].Office_Desc;
                    drOfficeInfo["ISREPORT"] = officeDetails[iCount].ISREPORT;
                    drOfficeInfo["TotalRecord"] = officeDetails[iCount].TotalRecords;
                    dtOfficeDetails.Rows.Add(drOfficeInfo);
                }

                return dtOfficeDetails;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }
        public DataTable GetAppFocusOfficeDetails(int ID, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtFocusApp = new DataTable();
            AppFocusOfficeDetails[] AppDetails;
            DataRow drAppInfo;
            try
            {
                this._gWiz = new GDUServiceClient();

                dtFocusApp.Columns.Add("OFFICE_ID", Type.GetType("System.String"));
                dtFocusApp.Columns.Add("OFFICE_DESC", Type.GetType("System.String"));
                dtFocusApp.Columns.Add("ISREPORT", Type.GetType("System.String"));

                AppFocusOfficeQuery appQuery = new AppFocusOfficeQuery();
                appQuery.Id = ID;

                appQuery.CurrentPage = currentPage;
                appQuery.PageSize = pageSize;
                appQuery.SortExpression = sortExpression;
                appQuery.SortOrder = sortOrder;

                AppDetails = this._gWiz.SearchAppFocusOffice(appQuery);

                for (int iCount = 0; iCount < AppDetails.Length; iCount++)
                {
                    drAppInfo = dtFocusApp.NewRow();
                    drAppInfo["OFFICE_ID"] = AppDetails[iCount].Office_ID;
                    drAppInfo["OFFICE_DESC"] = AppDetails[iCount].Office_Desc;
                    drAppInfo["ISREPORT"] = AppDetails[iCount].ISREPORT;

                    dtFocusApp.Rows.Add(drAppInfo);
                }

                return dtFocusApp;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }
        //public void ManageAppFocusOffice(string OfficeDESC, int ID)
        //{
        //    StandardResponse stdResponse;
        //    this._gWiz = new GDUServiceClient();
        //    AppFocusOfficeQuery OfficeDetails = new AppFocusOfficeQuery();
        //    OfficeDetails.OfficeDesc = OfficeDESC;
        //    OfficeDetails.Id = ID;

        //    try
        //    {
        //        stdResponse = this._gWiz.ManageAppFocusOffice(OfficeDetails);

        //    }
        //    catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
        //    {

        //        ////in the faultmsg object , Detail object contains our customized error message information.
        //        //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
        //        string errmsg = faultMsg.Detail.MyCustomErrMsg;
        //        throw new Exception(errmsg);
        //    }
        //    catch (Exception Ex)
        //    {
        //        GDUException GDUEx = new GDUException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
        //    }
        //    finally
        //    {
        //    }
        //}
        public string ManageAppFocusOffice(string OfficeDESC, int ID, string UserID, string ActionMode, string IsReport)
        {
            StandardResponse stdResponse;
            this._gWiz = new GDUServiceClient();
            string returnresult = string.Empty;
            AppFocusOfficeQuery OfficeDetails = new AppFocusOfficeQuery();
            OfficeDetails.OfficeDesc = OfficeDESC;
            OfficeDetails.Id = ID;
            OfficeDetails.USER_ID = UserID;
            OfficeDetails.MODE = ActionMode;
            OfficeDetails.ISREPORT = IsReport;
            try
            {
                stdResponse = this._gWiz.ManageAppFocusOffice(OfficeDetails);

            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {

                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            if (stdResponse.ResponseCodeStatus == StdResponseCode.Failed)
            {

                returnresult = stdResponse.ResponseMessage;


            }
            return returnresult;
        }

        //Office Group 
        public DataTable SearchFocusGroupApplication(string GroupName, bool isDeactive, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtFocusGroupDetails = new DataTable();
            FocusGroupDetails[] focusGroupDetails;
            DataRow drfocusGroupInfo;
            try
            {
                this._gWiz = new GDUServiceClient();
                dtFocusGroupDetails.Columns.Add("ID", Type.GetType("System.Int32"));
                dtFocusGroupDetails.Columns.Add("GroupName", Type.GetType("System.String"));
                dtFocusGroupDetails.Columns.Add("TotalRecord", Type.GetType("System.String"));
                FocusGroupQuery GroupNameQuery = new FocusGroupQuery();
                GroupNameQuery.GROUP_NM = GroupName;
                GroupNameQuery.ISACTIVE = isDeactive;

                GroupNameQuery.CurrentPage = currentPage;
                GroupNameQuery.PageSize = pageSize;
                GroupNameQuery.SortExpression = sortExpression;
                GroupNameQuery.SortOrder = sortOrder;

                focusGroupDetails = this._gWiz.SearchAPPFocusGroup(GroupNameQuery);

                for (int iCount = 0; iCount < focusGroupDetails.Length; iCount++)
                {
                    drfocusGroupInfo = dtFocusGroupDetails.NewRow();
                    drfocusGroupInfo["ID"] = focusGroupDetails[iCount].ID;
                    drfocusGroupInfo["GroupName"] = focusGroupDetails[iCount].GROUP_NM;
                    drfocusGroupInfo["TotalRecord"] = focusGroupDetails[iCount].TotalRecord;
                    dtFocusGroupDetails.Rows.Add(drfocusGroupInfo);
                }
                return dtFocusGroupDetails;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }
        public DataTable GetAppFocusOfficeGroupDetails(int ID, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtAppFGroup = new DataTable();
            FocusGroupDetails[] AppFGroupDetails;
            DataRow drAppFGroupInfo;
            try
            {
                this._gWiz = new GDUServiceClient();

                dtAppFGroup.Columns.Add("GROUP_ID", Type.GetType("System.Int32"));
                dtAppFGroup.Columns.Add("GROUP_NM", Type.GetType("System.String"));
                FocusGroupQuery grpQuery = new FocusGroupQuery();
                grpQuery.ID = ID;
                grpQuery.CurrentPage = currentPage;
                grpQuery.PageSize = pageSize;
                grpQuery.SortExpression = sortExpression;
                grpQuery.SortOrder = sortOrder;

                AppFGroupDetails = this._gWiz.SearchAPPFocusGroup(grpQuery);
                for (int iCount = 0; iCount < AppFGroupDetails.Length; iCount++)
                {
                    drAppFGroupInfo = dtAppFGroup.NewRow();
                    drAppFGroupInfo["GROUP_ID"] = AppFGroupDetails[iCount].ID;
                    drAppFGroupInfo["GROUP_NM"] = AppFGroupDetails[iCount].GROUP_NM;

                    dtAppFGroup.Rows.Add(drAppFGroupInfo);
                }

                return dtAppFGroup;
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
        }
        public string ManageAppFOfficeGroup(string GroupName, int ID, string UserID, string ActionMode)
        {
            StandardResponse stdResponse;
            string returnresult = string.Empty;
            this._gWiz = new GDUServiceClient();
            FocusGroupQuery GroupDetails = new FocusGroupQuery();
            GroupDetails.ID = ID;
            GroupDetails.GROUP_NM = GroupName;
            GroupDetails.USER_ID = UserID;
            GroupDetails.MODE = ActionMode;
            try
            {
                stdResponse = this._gWiz.ManageAppFocusGroup(GroupDetails);
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            if (stdResponse.ResponseCodeStatus == StdResponseCode.Failed)
            {

                returnresult = stdResponse.ResponseMessage;


            }
            return returnresult;
        }

        /// <summary>
        /// Populates the Office Groups.
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> PopulateAppFGroup(string GroupName, int GroupID, params string[] isVirtual)
        {
            PopulateFocusGroupDetails[] CounDetails;
            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                FocusGroupRequest request = new FocusGroupRequest();
                request.PopulateRequest = new FocusGroupQuery();
                request.ServiceInput = new StandardInput();
                if (isVirtual[0] == "Virtual")
                {
                    request.ServiceInput.EnumType = InputType.Virtual;
                }
                else
                {
                    request.ServiceInput.EnumType = InputType.Real;
                    request.PopulateRequest.ID = GroupID;
                }
                std = this._gWiz.LoadOfficeGroup(request.ServiceInput, request.PopulateRequest, out CounDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (std.ResponseCodeStatus == StdResponseCode.Success)
            {
                int iCount = CounDetails.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    if (CounDetails[iCounter].GROUP_NM != GroupName)
                    {
                        objDictionary.Add(CounDetails[iCounter].ID.ToString(), CounDetails[iCounter].GROUP_NM);
                    }
                }
            }
            else
            {
                throw new GenericException(std.ResponseMessage, 0);
            }

            return objDictionary;
        }

        public DataTable GetMappingDetails(int Input_Mapping_CD, string Input_CD)
        {
            DataTable dtMapping = new DataTable();
            DataRow drMappInfo;
            this._gWiz = new GDUServiceClient();
            StandardResponse response = new StandardResponse();
            try
            {
                OfficeGroupMappingQuery request = new OfficeGroupMappingQuery();
                request.GroupID = Input_Mapping_CD;
                AppFocusOfficeDetails[] mappiDetails = null;
                response = this._gWiz.GetMappingOfficeGroupDetails(request, out mappiDetails);
                dtMapping.Columns.Add("OFFICE_ID", Type.GetType("System.String"));
                dtMapping.Columns.Add("OFFICE_DS", Type.GetType("System.String"));

                for (int iCount = 0; iCount < mappiDetails.Length; iCount++)
                {
                    drMappInfo = dtMapping.NewRow();
                    drMappInfo["OFFICE_ID"] = mappiDetails[iCount].Office_ID;
                    drMappInfo["OFFICE_DS"] = mappiDetails[iCount].Office_Desc;
                    dtMapping.Rows.Add(drMappInfo);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dtMapping;
        }
        public void MappedOfficeGroup(DataTable dtMapping, string UserID, int GrpID)
        {
            string Office_ID = string.Empty;
            FocusGroupMappingRequest MappingRequest = new FocusGroupMappingRequest();
            StandardResponse std = new StandardResponse();
            try
            {
                OfficeGroupMappingQuery request = new OfficeGroupMappingQuery();
                request.GroupID = GrpID;
                request.CreatedUserID = UserID;
                this._gWiz = new GDUServiceClient();
                if (dtMapping.Rows.Count > 0)
                {
                    for (int iCount = 0; iCount < dtMapping.Rows.Count; iCount++)
                    {
                        Office_ID += dtMapping.Rows[iCount]["OfficeID"].ToString() + ',';

                    }
                }
                if (Office_ID.IndexOf(',') > 0)
                {
                    Office_ID.Remove(Office_ID.LastIndexOf(','));
                }

                request.OfficeID = Office_ID;
                std = this._gWiz.MappedOfficeGroupdtls(request);

            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }
        }

        public Dictionary<string, string> GetAppPrevVersion(int AppId, string AppVersion, string systemCD, string ReqType)
        {
            this._gWiz = new GDUServiceClient();
            Dictionary<string, string> dictAppVersion = new Dictionary<string, string>();
            AppUserQuery appQuery = new AppUserQuery();
            appQuery.App_ID = AppId;
            appQuery.System_CD = systemCD;
            appQuery.App_Version = AppVersion;
            appQuery.App_Type = ReqType;
            VersionDetail[] details = this._gWiz.SearchPreVersions(appQuery);
            if (details != null)
            {
                int iCount = details.Count();
                for (int iCounter = 0; iCounter < iCount; iCounter++)
                {
                    if (!dictAppVersion.ContainsKey(details[iCounter].ReleaseVersion))
                    {
                        dictAppVersion.Add(details[iCounter].ReleaseVersion.ToString(), details[iCounter].AppExeName.ToString() + "~" + details[iCounter].EntryPoint.ToString() + "~" + details[iCounter].IsRollback.ToString());
                    }
                }
            }
            return dictAppVersion;
        }

        public void ManageAppPrevVersion(int App_ID, string version, string System_CD, out string Status, string APP_TYPE)
        {
            this._clientRelease = new ClientRelease();
            this._clientReleaseQuery = new ClientReleaseQuery();
            this._clientReleaseDtlQuery = new ClientReleaseDtlQuery[0];
            StandardResponse std = new StandardResponse();
            this._gWiz = new GDUServiceClient();
            try
            {
                _clientReleaseQuery.App_ID = App_ID;
                _clientReleaseQuery.RELEASE_VERSION = version;
                _clientReleaseQuery.System_CD = System_CD;
                _clientReleaseQuery.APP_TYPE = APP_TYPE;
                this._clientRelease.ClientReleaseVer = this._clientReleaseQuery;
                this._clientRelease.ClientReleaseDtl = this._clientReleaseDtlQuery;
                std = this._gWiz.UpdateAppPreVersion(this._clientRelease);
            }
            catch (Exception Ex)
            {
            }
            Status = std.ResponseCodeStatus.ToString();
        }

        public DataTable GetOfiiceGroupMappingReportDataTable(int Group_ID, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drOfiiceGroupMappingReportDetail;
            StandardResponse std;
            OfficeGroupMappingReportInfo[] OfiiceGroupMappingReportDetail;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("GROUP_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("OFFICE_DS", Type.GetType("System.String"));
            dtReport.Columns.Add("ADS_ID", Type.GetType("System.String"));
            dtReport.Columns.Add("USER_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("COMPUTER_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("IP_ADDR_TXT", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));

            OfficeGroupMappingReportQuery cdReportQuery = new OfficeGroupMappingReportQuery();
            cdReportQuery.GroupID = Group_ID.ToString();
            cdReportQuery.PageIndex = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortColumn = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateOfficeGroupMappingReport(cdReportQuery, out OfiiceGroupMappingReportDetail);

            for (int iCollCount = 0; iCollCount < OfiiceGroupMappingReportDetail.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drOfiiceGroupMappingReportDetail = dtReport.NewRow();
                drOfiiceGroupMappingReportDetail["GROUP_NM"] = OfiiceGroupMappingReportDetail[iCollCount].GroupNM;
                drOfiiceGroupMappingReportDetail["OFFICE_DS"] = OfiiceGroupMappingReportDetail[iCollCount].OfficeID;
                drOfiiceGroupMappingReportDetail["ADS_ID"] = OfiiceGroupMappingReportDetail[iCollCount].ADSID;

                drOfiiceGroupMappingReportDetail["USER_NM"] = OfiiceGroupMappingReportDetail[iCollCount].USER_NM;
                drOfiiceGroupMappingReportDetail["COMPUTER_NM"] = OfiiceGroupMappingReportDetail[iCollCount].COMPUTER_NM;
                drOfiiceGroupMappingReportDetail["IP_ADDR_TXT"] = OfiiceGroupMappingReportDetail[iCollCount].IP_ADDR_TXT;
                drOfiiceGroupMappingReportDetail["TotalRecord"] = OfiiceGroupMappingReportDetail[iCollCount].TotalRecords;
                dtReport.Rows.Add(drOfiiceGroupMappingReportDetail);
            }

            return dtReport;
        }

        public DataTable GetPilotAppTable(string UserId, string fromdate, string todate, string rollback, int App_ID, string APP_TYPE, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppUploadedDetail;
            StandardResponse std;
            AppUploadedInfo[] AppUploadedDetail;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("App_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("USER_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("Version", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("IP", Type.GetType("System.String"));
            dtReport.Columns.Add("Upload_Dt", Type.GetType("System.String"));
            dtReport.Columns.Add("App_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("APP_TYPE", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));

            AppUploadedReportQuery cdReportQuery = new AppUploadedReportQuery();
            cdReportQuery.UserId = UserId;
            cdReportQuery.From_DT = fromdate;
            cdReportQuery.To_Date = todate;
            cdReportQuery.RollBack = rollback;
            cdReportQuery.App_ID = App_ID;
            cdReportQuery.APP_TYPE = APP_TYPE;

            cdReportQuery.CurrentPage = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortExpression = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulatePilotAppUploadReport(cdReportQuery, out AppUploadedDetail);

            for (int iCollCount = 0; iCollCount < AppUploadedDetail.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drAppUploadedDetail = dtReport.NewRow();
                drAppUploadedDetail["App_NM"] = AppUploadedDetail[iCollCount].App_Name;
                drAppUploadedDetail["USER_NM"] = AppUploadedDetail[iCollCount].User_Name;
                drAppUploadedDetail["Version"] = AppUploadedDetail[iCollCount].Version;
                drAppUploadedDetail["IP"] = AppUploadedDetail[iCollCount].IP;
                drAppUploadedDetail["Upload_Dt"] = AppUploadedDetail[iCollCount].Upload_Dt;
                drAppUploadedDetail["Computer_NM"] = AppUploadedDetail[iCollCount].Computer_NM;
                drAppUploadedDetail["App_ID"] = AppUploadedDetail[iCollCount].App_ID;
                drAppUploadedDetail["APP_TYPE"] = AppUploadedDetail[iCollCount].APP_TYPE;
                drAppUploadedDetail["TotalRecord"] = AppUploadedDetail[iCollCount].TotalRecords;
                dtReport.Rows.Add(drAppUploadedDetail);
            }
            return dtReport;
        }

        #region ImportXl
        public void SaveXlData(DataTable FileToRead, int AppId, string AppVersion, string UploadType, int GroupId)
        {
            try
            {

                string UserName = this.GetUserNameAdmin();
                ManagePilotAppExcelSheetQuery pilotAppExcelSheetInput = new ManagePilotAppExcelSheetQuery();
                StandardResponse std = new StandardResponse();
                this._gWiz = new GDUServiceClient();
                if (UploadType == "Excel")
                {
                    DataTable dt = new DataTable();
                    dt.TableName = "TEMPPILOT";
                    FileToRead.TableName = "TEMPPILOT";
                    dt = FileToRead.Copy();
                    pilotAppExcelSheetInput.DtExcelData = dt;
                    pilotAppExcelSheetInput.GroupID = 0;
                }
                else if (UploadType == "Group")
                {
                    pilotAppExcelSheetInput.GroupID = GroupId;
                    //pilotAppExcelSheetInput.XmlData = null;

                }
                pilotAppExcelSheetInput.AppId = AppId;
                pilotAppExcelSheetInput.AppVersion = AppVersion;
                pilotAppExcelSheetInput.CreatedUserId = UserName;
                pilotAppExcelSheetInput.UploadType = UploadType;
                std = _gWiz.ImportPilotAppData(pilotAppExcelSheetInput);
            }
            catch (Exception ex)
            {
            }
            finally
            {
            }
        }

        public DataTable GetPilotUserDetailTable(int App_Id, string Version, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppUploadedDetail;
            StandardResponse std;
            PilotAppRepDetails[] AppUploadedDetail;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("User_Name", Type.GetType("System.String"));
            dtReport.Columns.Add("UserId", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("IPAddress", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            PilotAppRepQuery cdReportQuery = new PilotAppRepQuery();
            cdReportQuery.App_Id = App_Id;
            cdReportQuery.Version = Version;

            cdReportQuery.CurrentPage = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortExpression = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulatePilotUserDetails(cdReportQuery, out AppUploadedDetail);

            for (int iCollCount = 0; iCollCount < AppUploadedDetail.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drAppUploadedDetail = dtReport.NewRow();
                drAppUploadedDetail["UserId"] = AppUploadedDetail[iCollCount].UserId;
                drAppUploadedDetail["User_Name"] = AppUploadedDetail[iCollCount].UserName;
                drAppUploadedDetail["Computer_NM"] = AppUploadedDetail[iCollCount].MachineName;
                drAppUploadedDetail["IPAddress"] = AppUploadedDetail[iCollCount].IPAddress;
                drAppUploadedDetail["TotalRecord"] = AppUploadedDetail[iCollCount].TotalRecords;
                dtReport.Rows.Add(drAppUploadedDetail);
            }

            return dtReport;
        }

        //public string ReturnSearchResultXMLAdmin(Dictionary<string, string> xmlValues)
        //{


        //    string[] keys = xmlValues.Keys.ToArray();
        //    string[] values = xmlValues.Values.ToArray();

        //    string result = string.Empty;
        //    string imagePath = "Images\\";
        //    string imageName = string.Empty;
        //    string url = string.Empty;
        //    string browsable = string.Empty;
        //    string aggTooltip = string.Empty;
        //    string imgShowHide = string.Empty;
        //    string childCount = string.Empty;
        //    string GroupDesc = string.Empty;
        //    string Account = string.Empty;
        //    string AccountCountry = string.Empty;
        //    string AccountCountryCity = string.Empty;
        //    string Country = string.Empty;
        //    string CountryCity = string.Empty;
        //    _searchResult = new StringBuilder();
        //    try
        //    {
        //        if (keys.Length > 0)
        //        {

        //            _searchResult.Append("<" + Constants.ROOT_NODE_NAME + " " + Constants.ROOT_NODE_DESCRIPTION + "='Root'" + " " + Constants.IS_GLOBAL + "=''>");
        //            _searchResult.Append("<" + Constants.NODE_ORIGINATION + " " + Constants.NODE_DESCRIPTION + "='Office/Ads-ID Mapping'>");
        //            _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENTS + ">");
        //            for (int kCounter = 0; kCounter < keys.Length; kCounter++)
        //            {

        //                if (keys[kCounter].Length != 0)
        //                {


        //                    string[] TEMP = keys[kCounter].Split('|');
        //                    if (!string.IsNullOrEmpty(values[kCounter].Substring(values[kCounter].IndexOf('-'))))
        //                    {
        //                        result = values[kCounter].Substring(values[kCounter].IndexOf('-'));
        //                    }

        //                    //For OFFICE ID TG
        //                    _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENT + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.LINKID + "='" + Constants.CONSTZERO + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.VIEW_IMAGE + "='' " + Constants.LINKDETAILID + "='" + Constants.CONSTZERO + "' " + Constants.IMAGES + "='' " + Constants.NODE_DESCRIPTION + "='" + TEMP[0].ToString() + "' " + Constants.URL + "='" + string.Empty + "' " + Constants.DOWNLOAD + "='" + string.Empty + "' " + Constants.LINK_TYPE + "='" + string.Empty +
        //              "' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.MAXIMAGES + "='' " + Constants.MINIMAGES + "='' " + Constants.DISABLE_IMAGE + "='" + Constants.DISABLE_TRUE + "' " + Constants.MODE + "='' " + Constants.LINKTYPE_CODE + "='" + string.Empty + "' " + Constants.LABEL_ID + "='" + string.Empty + "' " + Constants.HOVER_TEXT + "='" + string.Empty + "'>");


        //                    //for ADS ID TAG

        //                    this._searchResult.Append("<" + Constants.NODE_TL + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.IMAGES + "='' "
        //               + Constants.LINKID + "='0' " + Constants.LINKDETAILID + "='' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.DOWNLOAD + "='' "
        //               + Constants.LINKDETAILCATEGORYID + "='' " + Constants.URL + "='" + url + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.LINKTYPE_CODE + "='" + kCounter.ToString() + "' " + Constants.VIEW_IMAGE + "='' "
        //               + Constants.LINK_TYPE + "='' " + Constants.LINK + "='' " + Constants.NODE_DESCRIPTION + "='' " + Constants.PARENTLABELID + "='' " + Constants.TRANSID + "='' " + Constants.AGGREATIONTOOLTIP + "='' " + Constants.KEYWORD + "='' "
        //               + Constants.LABEL_ID + "='' " + Constants.HOVER_TEXT + "=''>" + TEMP[1].ToString() + result + "</" + Constants.NODE_TL + ">");

        //                    for (int JCounter = kCounter + 1; JCounter <= keys.Length - 1; JCounter++)
        //                    {

        //                        string[] temp1 = keys[JCounter].Split('|');
        //                        if (!string.IsNullOrEmpty(values[kCounter].Substring(values[kCounter].IndexOf('-'))))
        //                        {
        //                            result = values[JCounter].Substring(values[JCounter].IndexOf('-'));
        //                        }

        //                        if (TEMP[0].ToLower() == temp1[0].ToLower())
        //                        {

        //                            this._searchResult.Append("<" + Constants.NODE_TL + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.IMAGES + "='' "
        //                  + Constants.LINKID + "='0' " + Constants.LINKDETAILID + "='' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.DOWNLOAD + "='' "
        //                  + Constants.LINKDETAILCATEGORYID + "='' " + Constants.URL + "='" + url + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.LINKTYPE_CODE + "='" + JCounter.ToString() + "' " + Constants.VIEW_IMAGE + "='' "
        //                  + Constants.LINK_TYPE + "='' " + Constants.LINK + "='' " + Constants.NODE_DESCRIPTION + "='' " + Constants.PARENTLABELID + "='' " + Constants.TRANSID + "='' " + Constants.AGGREATIONTOOLTIP + "='' " + Constants.KEYWORD + "='' "
        //                  + Constants.LABEL_ID + "='' " + Constants.HOVER_TEXT + "=''>" + temp1[1].ToString() + result + "</" + Constants.NODE_TL + ">");
        //                            keys[JCounter] = keys[JCounter].Remove(0);

        //                            keys[kCounter].Remove(0);

        //                        }

        //                    }
        //                    _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENT + ">");

        //                }

        //            }
        //            _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENTS + ">");
        //            _searchResult.Append("</" + Constants.NODE_ORIGINATION + ">");
        //        }
        //        else
        //        {
        //            _searchResult.Append("<" + Constants.ROOT_NODE_NAME + " " + Constants.ROOT_NODE_DESCRIPTION + "='Root'" + " " + Constants.IS_GLOBAL + "=''>");
        //            _searchResult.Append("<" + Constants.NODE_ORIGINATION + " " + Constants.NODE_DESCRIPTION + "='Office/Ads-ID Mapping'>");
        //            _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENTS + ">");
        //            _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENT + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.LINKID + "='" + Constants.CONSTZERO + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.VIEW_IMAGE + "='' " + Constants.LINKDETAILID + "='" + Constants.CONSTZERO + "' " + Constants.IMAGES + "='' " + Constants.NODE_DESCRIPTION + "='" + "No Record Found" + "' " + Constants.URL + "='" + string.Empty + "' " + Constants.DOWNLOAD + "='" + string.Empty + "' " + Constants.LINK_TYPE + "='" + string.Empty +
        //             "' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.MAXIMAGES + "='' " + Constants.MINIMAGES + "='' " + Constants.DISABLE_IMAGE + "='" + Constants.DISABLE_TRUE + "' " + Constants.MODE + "='' " + Constants.LINKTYPE_CODE + "='" + string.Empty + "' " + Constants.LABEL_ID + "='" + string.Empty + "' " + Constants.HOVER_TEXT + "='" + string.Empty + "'>");
        //            _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENT + ">");
        //            _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENTS + ">");
        //            _searchResult.Append("</" + Constants.NODE_ORIGINATION + ">");
        //        }


        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    _searchResult.Append("</" + Constants.ROOT_NODE_NAME + ">");
        //    return _searchResult.ToString();
        //}
        public string ReturnSearchResultXMLAdmin(Dictionary<string, string> xmlValues)
        {


            string[] keys = xmlValues.Keys.ToArray();
            string[] values = xmlValues.Values.ToArray();

            string result = string.Empty;
            string imagePath = "Images\\";
            string imageName = string.Empty;
            string url = string.Empty;
            string browsable = string.Empty;
            string aggTooltip = string.Empty;
            string imgShowHide = string.Empty;
            string childCount = string.Empty;
            string GroupDesc = string.Empty;
            string Account = string.Empty;
            string AccountCountry = string.Empty;
            string AccountCountryCity = string.Empty;
            string Country = string.Empty;
            string CountryCity = string.Empty;
            _searchResult = new StringBuilder();
            try
            {
                if (keys.Length > 0)
                {

                    _searchResult.Append("<" + Constants.ROOT_NODE_NAME + " " + Constants.ROOT_NODE_DESCRIPTION + "='Root'" + " " + Constants.IS_GLOBAL + "=''>");
                    _searchResult.Append("<" + Constants.NODE_ORIGINATION + " " + Constants.NODE_DESCRIPTION + "='Office/Ads-ID Mapping'>");
                    _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENTS + ">");
                    for (int kCounter = 0; kCounter < keys.Length; kCounter++)
                    {

                        if (keys[kCounter].Length != 0)
                        {
                            int len = ((values[kCounter].LastIndexOf(']') - values[kCounter].LastIndexOf('[') + 1));
                            string officeid = values[kCounter].Substring(values[kCounter].LastIndexOf('[') + 1, len - 2);
                            string[] TEMP = keys[kCounter].Split('|');
                            if (!string.IsNullOrEmpty(values[kCounter].Substring(values[kCounter].IndexOf('-'))))
                            {
                                result = values[kCounter].Substring(values[kCounter].IndexOf('-'));
                            }
                            //For OFFICE ID TG
                            _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENT + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.LINKID + "='" + Constants.CONSTZERO + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.VIEW_IMAGE + "='' " + Constants.LINKDETAILID + "='" + Constants.CONSTZERO + "' " + Constants.IMAGES + "='' " + Constants.NODE_DESCRIPTION + "='" + officeid + "' " + Constants.URL + "='" + string.Empty + "' " + Constants.DOWNLOAD + "='" + TEMP[0].ToString() + "' " + Constants.LINK_TYPE + "='" + string.Empty +
                      "' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.MAXIMAGES + "='' " + Constants.MINIMAGES + "='' " + Constants.DISABLE_IMAGE + "='" + Constants.DISABLE_TRUE + "' " + Constants.MODE + "='' " + Constants.LINKTYPE_CODE + "='" + string.Empty + "' " + Constants.LABEL_ID + "='" + string.Empty + "' " + Constants.HOVER_TEXT + "='" + string.Empty + "'>");

                            //for ADS ID TAG

                            this._searchResult.Append("<" + Constants.NODE_TL + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.IMAGES + "='' "
                       + Constants.LINKID + "='0' " + Constants.LINKDETAILID + "='' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.DOWNLOAD + "='' "
                       + Constants.LINKDETAILCATEGORYID + "='' " + Constants.URL + "='" + url + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.LINKTYPE_CODE + "='" + kCounter.ToString() + "' " + Constants.VIEW_IMAGE + "='' "
                       + Constants.LINK_TYPE + "='' " + Constants.LINK + "='' " + Constants.NODE_DESCRIPTION + "='' " + Constants.PARENTLABELID + "='' " + Constants.TRANSID + "='' " + Constants.AGGREATIONTOOLTIP + "='' " + Constants.KEYWORD + "='' "
                       + Constants.LABEL_ID + "='' " + Constants.HOVER_TEXT + "=''>" + TEMP[1].ToString() + result.Substring(0, result.LastIndexOf('[') - 1) + "</" + Constants.NODE_TL + ">");

                            for (int JCounter = kCounter + 1; JCounter <= keys.Length - 1; JCounter++)
                            {

                                string[] temp1 = keys[JCounter].Split('|');
                                if (!string.IsNullOrEmpty(values[kCounter].Substring(values[kCounter].IndexOf('-'))))
                                {
                                    result = values[JCounter].Substring(values[JCounter].IndexOf('-'));
                                }

                                if (TEMP[0].ToLower() == temp1[0].ToLower())
                                {

                                    this._searchResult.Append("<" + Constants.NODE_TL + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.IMAGES + "='' "
                          + Constants.LINKID + "='0' " + Constants.LINKDETAILID + "='' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.DOWNLOAD + "='' "
                          + Constants.LINKDETAILCATEGORYID + "='' " + Constants.URL + "='" + url + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.LINKTYPE_CODE + "='" + JCounter.ToString() + "' " + Constants.VIEW_IMAGE + "='' "
                          + Constants.LINK_TYPE + "='' " + Constants.LINK + "='' " + Constants.NODE_DESCRIPTION + "='' " + Constants.PARENTLABELID + "='' " + Constants.TRANSID + "='' " + Constants.AGGREATIONTOOLTIP + "='' " + Constants.KEYWORD + "='' "
                          + Constants.LABEL_ID + "='' " + Constants.HOVER_TEXT + "=''>" + temp1[1].ToString() + result.Substring(0, result.LastIndexOf('[') - 1) + "</" + Constants.NODE_TL + ">");
                                    keys[JCounter] = keys[JCounter].Remove(0);

                                    keys[kCounter].Remove(0);

                                }

                            }
                            _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENT + ">");

                        }

                    }
                    _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENTS + ">");
                    _searchResult.Append("</" + Constants.NODE_ORIGINATION + ">");
                }
                else
                {
                    _searchResult.Append("<" + Constants.ROOT_NODE_NAME + " " + Constants.ROOT_NODE_DESCRIPTION + "='Root'" + " " + Constants.IS_GLOBAL + "=''>");
                    _searchResult.Append("<" + Constants.NODE_ORIGINATION + " " + Constants.NODE_DESCRIPTION + "='Office/Ads-ID Mapping'>");
                    _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENTS + ">");
                    _searchResult.Append("<" + Constants.NODE_ORIGINSEGMENT + " " + Constants.IS_BROWSEABLE + "='" + string.Empty + "' " + Constants.LINKID + "='" + Constants.CONSTZERO + "' " + Constants.ADD_IMAGE + "='' " + Constants.EDIT_IMAGE + "='' " + Constants.DELETE_IMAGE + "='' " + Constants.VIEW_IMAGE + "='' " + Constants.LINKDETAILID + "='" + Constants.CONSTZERO + "' " + Constants.IMAGES + "='' " + Constants.NODE_DESCRIPTION + "='" + "No Record Found" + "' " + Constants.URL + "='" + string.Empty + "' " + Constants.DOWNLOAD + "='" + string.Empty + "' " + Constants.LINK_TYPE + "='" + string.Empty +
                     "' " + Constants.LANGUAGECODE + "='" + keys.Length + "' " + Constants.MAXIMAGES + "='' " + Constants.MINIMAGES + "='' " + Constants.DISABLE_IMAGE + "='" + Constants.DISABLE_TRUE + "' " + Constants.MODE + "='' " + Constants.LINKTYPE_CODE + "='" + string.Empty + "' " + Constants.LABEL_ID + "='" + string.Empty + "' " + Constants.HOVER_TEXT + "='" + string.Empty + "'>");
                    _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENT + ">");
                    _searchResult.Append("</" + Constants.NODE_ORIGINSEGMENTS + ">");
                    _searchResult.Append("</" + Constants.NODE_ORIGINATION + ">");
                }


            }
            catch (Exception ex)
            {

            }
            _searchResult.Append("</" + Constants.ROOT_NODE_NAME + ">");
            return _searchResult.ToString();
        }


        public void ManageAppFGroupADSID(string AdsIDs, string userid, int GroupID, int InType)
        {
            PopulateAppfOfficeAdsID[] CounDetails;
            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                AppFOfficeAdsIDRequest request = new AppFOfficeAdsIDRequest();
                request.PopulateRequest = new AppfOfficeAdsQuery();
                request.ServiceInput = new StandardInput();
                request.PopulateRequest.ADS_ID = AdsIDs;
                request.PopulateRequest.CreatedUserID = userid;
                request.PopulateRequest.GROUP_ID = GroupID;
                request.PopulateRequest.Type = InType;

                std = this._gWiz.ManageAppFOfficeADSID(request.ServiceInput, request.PopulateRequest, out CounDetails);
            }
            catch (FaultException<CustomFaultMsg> faultMsg) ////This is used to handle the customized SOAP faults raised by WCFService.
            {
                ////in the faultmsg object , Detail object contains our customized error message information.
                //// property "MyCustomErrMsg" is the one we created in our customized fualt message description. in ISecrive.cs file.
                string errmsg = faultMsg.Detail.MyCustomErrMsg;
                throw new Exception(errmsg);
            }
            catch (Exception Ex)
            {
                GDUException GDUEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                throw new Exception(ExceptionManager.HandleException(GDUEx, 4000));
            }
            finally
            {
            }
        }
        public DataTable PopulateAppFGroupADSID(string AdsIDs, int GroupID, int InType, out Dictionary<string, string> xslt)
        {
            //Newly Added
            DataTable dtMapping = new DataTable();
            DataRow drMappInfo;
            //End Newly Added
            PopulateAppfOfficeAdsID[] CounDetails;
            StandardResponse std = new StandardResponse();
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            try
            {
                this._gWiz = new GDUServiceClient();
                AppFOfficeAdsIDRequest request = new AppFOfficeAdsIDRequest();
                request.PopulateRequest = new AppfOfficeAdsQuery();
                request.ServiceInput = new StandardInput();

                request.PopulateRequest.ADS_ID = AdsIDs;
                request.PopulateRequest.GROUP_ID = GroupID;
                request.PopulateRequest.Type = InType;

                std = this._gWiz.PopulateAppFOfficeADSID(request.ServiceInput, request.PopulateRequest, out CounDetails);

                if (std.ResponseCodeStatus == StdResponseCode.Success)
                {
                    int iCount = CounDetails.Count();
                    dtMapping.Columns.Add("OFFICE_ID", Type.GetType("System.String"));
                    dtMapping.Columns.Add("ADS_ID", Type.GetType("System.String"));
                    dtMapping.Columns.Add("MACHINE_NM", Type.GetType("System.String"));
                    dtMapping.Columns.Add("USER_NM", Type.GetType("System.String"));
                    dtMapping.Columns.Add("OFFICE_DS", Type.GetType("System.String"));
                    for (int iCounter = 0; iCounter < iCount; iCounter++)
                    {
                        // Add into DataTAble
                        drMappInfo = dtMapping.NewRow();
                        drMappInfo["OFFICE_ID"] = CounDetails[iCounter].OFFICE_ID.ToString();
                        drMappInfo["ADS_ID"] = CounDetails[iCounter].ADS_ID.ToString();
                        drMappInfo["MACHINE_NM"] = CounDetails[iCounter].MACHINE_NM.ToString();
                        drMappInfo["USER_NM"] = CounDetails[iCounter].USER_NM.ToString();
                        drMappInfo["OFFICE_DS"] = CounDetails[iCounter].OFFICE_DS.ToString();
                        dtMapping.Rows.Add(drMappInfo);
                        objDictionary.Add(CounDetails[iCounter].OFFICE_ID.ToString() + "|" + CounDetails[iCounter].ADS_ID + "|" + CounDetails[iCounter].MACHINE_NM, CounDetails[iCounter].ADS_ID + "- [" + CounDetails[iCounter].MACHINE_NM.ToString() + "]- " + "[" + CounDetails[iCounter].USER_NM.ToString() + "]");

                    }

                    xslt = objDictionary;
                }
                else
                {
                    throw new GenericException(std.ResponseMessage, 0);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtMapping;
        }

        public DataTable GetTravelSuiteAppFocusReportTable(string UserName, string AppName, string fromDate, string toDate, string OfficeID, int OfficeGroupId, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drAppFocusRepDetail;
            StandardResponse std;

            TravelSuiteAppFocusReportDetails[] appFocusReportDetails;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("SequenceNo", Type.GetType("System.String"));
            dtReport.Columns.Add("AppName", Type.GetType("System.String"));
            dtReport.Columns.Add("UserName", Type.GetType("System.String"));
            dtReport.Columns.Add("OfficeId", Type.GetType("System.String"));
            dtReport.Columns.Add("UsageDate", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_NM", Type.GetType("System.String"));
            dtReport.Columns.Add("IpAddress", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalUsage", Type.GetType("System.String"));
            dtReport.Columns.Add("ToDate", Type.GetType("System.String"));
            dtReport.Columns.Add("ADS_ID", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            TravelSuiteAppFocusReportQuery appFocusReportQuery = new TravelSuiteAppFocusReportQuery();
            appFocusReportQuery.AppName = AppName;
            appFocusReportQuery.UserName = UserName;
            appFocusReportQuery.FromDate = fromDate;
            appFocusReportQuery.ToDate = toDate;
            appFocusReportQuery.OfficeId = OfficeID;
            appFocusReportQuery.OfficeGroupId = OfficeGroupId;

            appFocusReportQuery.CurrentPage = currentPage;
            appFocusReportQuery.PageSize = pageSize;
            appFocusReportQuery.SortExpression = sortExpression;
            appFocusReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulateTravelSuiteAppFocusReport(appFocusReportQuery, out appFocusReportDetails);

            for (int iCollCount = 0; iCollCount < appFocusReportDetails.Length; iCollCount++)
            {
                drAppFocusRepDetail = dtReport.NewRow();
                drAppFocusRepDetail["SequenceNo"] = appFocusReportDetails[iCollCount].GroupSeqNo;
                drAppFocusRepDetail["AppName"] = appFocusReportDetails[iCollCount].AppName;
                drAppFocusRepDetail["UserName"] = appFocusReportDetails[iCollCount].UserName;
                drAppFocusRepDetail["OfficeId"] = appFocusReportDetails[iCollCount].OfficeId;
                drAppFocusRepDetail["Computer_NM"] = appFocusReportDetails[iCollCount].ComputerName;
                drAppFocusRepDetail["IpAddress"] = appFocusReportDetails[iCollCount].IpAddress;
                drAppFocusRepDetail["UsageDate"] = appFocusReportDetails[iCollCount].UsageDate.ToString();
                drAppFocusRepDetail["TotalUsage"] = appFocusReportDetails[iCollCount].TotalUsage;
                drAppFocusRepDetail["ToDate"] = appFocusReportDetails[iCollCount].ApplEndDate;
                drAppFocusRepDetail["ADS_ID"] = appFocusReportDetails[iCollCount].ADSId;
                drAppFocusRepDetail["TotalRecord"] = appFocusReportDetails[0].TotalRecord;
                dtReport.Rows.Add(drAppFocusRepDetail);
            }
            return dtReport;
        }


        public DataTable GetClientPilotAppDeploymentReport(string UserId, string Version, int Flag, string clientId, int App_ID, string System_CD, int currentPage, int pageSize, string sortExpression, string sortOrder)
        {
            DataTable dtReport = new DataTable();
            DataRow drClientDeploymentDetail;
            StandardResponse std;
            PilotApplicationDeploymentReportInfo[] clientDeploymentDetails;
            this._gWiz = new GDUServiceClient();
            dtReport.Columns.Add("App_NAME", Type.GetType("System.String"));
            dtReport.Columns.Add("User_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("IP", Type.GetType("System.String"));
            dtReport.Columns.Add("Nac_Id", Type.GetType("System.String"));
            dtReport.Columns.Add("Exe_VersionNo", Type.GetType("System.String"));
            dtReport.Columns.Add("Exe_TimeStamp_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("RecordTimeStamp_DT", Type.GetType("System.DateTime"));
            dtReport.Columns.Add("Application_Path", Type.GetType("System.String"));
            dtReport.Columns.Add("Latest_VersionNo", Type.GetType("System.String"));
            dtReport.Columns.Add("Computer_Name", Type.GetType("System.String"));
            dtReport.Columns.Add("TotalRecord", Type.GetType("System.String"));
            PilotApplicationDeploymentReportQuery cdReportQuery = new PilotApplicationDeploymentReportQuery();
            cdReportQuery.UserId = UserId;
            cdReportQuery.Version = Version;
            cdReportQuery.NonMaxFlag = Flag;
            cdReportQuery.clientId = clientId;
            cdReportQuery.App_ID = App_ID.ToString();
            cdReportQuery.System_CD = System_CD;

            cdReportQuery.PageIndex = currentPage;
            cdReportQuery.PageSize = pageSize;
            cdReportQuery.SortColumn = sortExpression;
            cdReportQuery.SortOrder = sortOrder;

            std = this._gWiz.PopulatePilotApplicationDeploymentReport(cdReportQuery, out clientDeploymentDetails);

            for (int iCollCount = 0; iCollCount < clientDeploymentDetails.Length; iCollCount++)
            {
                ////creating row data in case of link category
                drClientDeploymentDetail = dtReport.NewRow();
                drClientDeploymentDetail["App_NAME"] = clientDeploymentDetails[iCollCount].App_Name;
                drClientDeploymentDetail["User_Id"] = clientDeploymentDetails[iCollCount].UserId;
                drClientDeploymentDetail["IP"] = clientDeploymentDetails[iCollCount].IPAddress;
                drClientDeploymentDetail["Nac_Id"] = clientDeploymentDetails[iCollCount].NACId;
                drClientDeploymentDetail["Exe_VersionNo"] = clientDeploymentDetails[iCollCount].ExeVersionNo;
                drClientDeploymentDetail["Exe_TimeStamp_DT"] = clientDeploymentDetails[iCollCount].ExeTimeStamp;
                drClientDeploymentDetail["RecordTimeStamp_DT"] = clientDeploymentDetails[iCollCount].TimeStamp;
                drClientDeploymentDetail["Application_Path"] = clientDeploymentDetails[iCollCount].ApplicationPath;
                drClientDeploymentDetail["Latest_VersionNo"] = clientDeploymentDetails[iCollCount].LatestVersionNo;
                drClientDeploymentDetail["Computer_Name"] = clientDeploymentDetails[iCollCount].ComputerName;
                drClientDeploymentDetail["TotalRecord"] = clientDeploymentDetails[iCollCount].TotalRecords;
                dtReport.Rows.Add(drClientDeploymentDetail);
            }

            return dtReport;
        }

        #endregion

        #region GetACWReportDetails
        public DataTable GetACWReportDetails(string appName, string fromDate, string toDate, string officeId, string userName, int groupId)
        {
            //DataTable dtACWReport = new DataTable();
            //DataRow drACWReport;
            //this._gWiz = new GDUServiceClient();
            //StandardResponse response = new StandardResponse();
            //try
            //{
            //    ACWCoralReportQuery request = new ACWCoralReportQuery();
            //    request.AppName = appName;
            //    request.FromDate = fromDate;
            //    request.ToDate = toDate;
            //    request.OfficeId = officeId;
            //    request.UserName = userName;
            //    request.GroupId = groupId;

            //    ACWCoralReportDetails[] ACWDetails = null;
            //    response = this._gWiz.PopulateACWReport(request, out ACWDetails);
            //    dtACWReport.Columns.Add("PHONEID", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("SERVER", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("STARTDATE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("ENDDATE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("TIMEZONE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("ACW_DURATION", Type.GetType("System.String"));

            //    for (int iCount = 0; iCount < ACWDetails.Length; iCount++)
            //    {
            //        drACWReport = dtACWReport.NewRow();
            //        drACWReport["PHONEID"] = ACWDetails[iCount].AdsId;
            //        drACWReport["SERVER"] = ACWDetails[iCount].Server;
            //        drACWReport["STARTDATE"] = ACWDetails[iCount].StartDt;
            //        drACWReport["ENDDATE"] = ACWDetails[iCount].EndDt;
            //        drACWReport["TIMEZONE"] = ACWDetails[iCount].TIMEZONE;
            //        drACWReport["ACW_DURATION"] = ACWDetails[iCount].ACWDuration;

            //        dtACWReport.Rows.Add(drACWReport);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            //return dtACWReport;

            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@AppName", SqlDbType.VarChar).Value = appName;
                cmd.Parameters.AddWithValue("@FromDate", SqlDbType.VarChar).Value = fromDate;
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = toDate;
                cmd.Parameters.AddWithValue("@OfficeId", SqlDbType.VarChar).Value = officeId;
                cmd.Parameters.AddWithValue("@UserName", SqlDbType.VarChar).Value = userName;
                cmd.Parameters.AddWithValue("@GroupID", SqlDbType.Int).Value = groupId;
                cmd.CommandText = "usp_GetACWCoralReport";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds.Tables[0];
        }
        #endregion

        public DataTable GetClientUsageDataTableEXPORT(string UserId, string Version, string fromDate, string toDate, string ClientID, int App_ID, string SortColumn, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserId == null)
                    UserId = "";

                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.AddWithValue("@Version", SqlDbType.VarChar).Value = Version;
                cmd.Parameters.AddWithValue("@From_date", SqlDbType.VarChar).Value = fromDate;
                cmd.Parameters.AddWithValue("@To_date", SqlDbType.VarChar).Value = toDate;
                cmd.Parameters.AddWithValue("@ClientID", SqlDbType.VarChar).Value = ClientID;
                cmd.Parameters.AddWithValue("@App_ID", SqlDbType.VarChar).Value = App_ID;

                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortColumn;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GETClientUsageReport_GDU_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {

            }

            return ds.Tables[0];
        }

        public DataTable GetClientDeploymentDataTableEXPORT(string UserId, string Version, int Flag, string clientId, int App_ID, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserId == null)
                    UserId = "";

                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.AddWithValue("@Version", SqlDbType.VarChar).Value = Version;
                cmd.Parameters.AddWithValue("@NonMaxFlag", SqlDbType.VarChar).Value = Flag;
                cmd.Parameters.AddWithValue("@ClientId", SqlDbType.VarChar).Value = clientId;
                cmd.Parameters.AddWithValue("@App_ID", SqlDbType.VarChar).Value = App_ID;

                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortExp;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GETClientDeploymentReport_GDU_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }

        public DataTable GetAppUploadedDataTableEXPORT(string UserId, string fromdate, string todate, string rollback, int App_ID, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserId == null)
                    UserId = "";
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.AddWithValue("@From_Dt", SqlDbType.VarChar).Value = fromdate;
                cmd.Parameters.AddWithValue("@To_Dt", SqlDbType.VarChar).Value = todate;
                cmd.Parameters.AddWithValue("@App_ID", SqlDbType.Int).Value = App_ID;
                cmd.Parameters.AddWithValue("@RollBack", SqlDbType.VarChar).Value = rollback;

                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortExp;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GetAppUploadedReport_GDU_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }

        public DataTable GetAppFocusReportTableEXPORT(string UserName, string AppName, string fromDate, string toDate, string OfficeID, int OfficeGroupId, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserName == null)
                    UserName = "";
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@AppName", SqlDbType.VarChar).Value = AppName;
                cmd.Parameters.AddWithValue("@FromDate", SqlDbType.VarChar).Value = fromDate;
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = toDate;
                cmd.Parameters.AddWithValue("@OfficeId", SqlDbType.Int).Value = OfficeID;
                cmd.Parameters.AddWithValue("@UserName", SqlDbType.VarChar).Value = UserName;
                cmd.Parameters.AddWithValue("@GroupID", SqlDbType.VarChar).Value = OfficeGroupId;

                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortExp;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GETAppFocusReport_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }

        public DataTable GetAppUserFocusReportTableDetailsEXPORT(string ADS_ID, string Usagedate, string ReqBy, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {

                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@ADS_ID", SqlDbType.VarChar).Value = ADS_ID;
                cmd.Parameters.AddWithValue("@ActiveDeactiveTime", SqlDbType.VarChar).Value = Usagedate;
                cmd.Parameters.AddWithValue("@REQBY", SqlDbType.VarChar).Value = ReqBy;
                cmd.CommandText = "usp_GETAppFocusReportDetailByUser_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }

        public DataTable GetAppFocusReportTableDetailsEXPORT(string sequenceNo, string ReqBy)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@SequenceNo", SqlDbType.VarChar).Value = sequenceNo;
                cmd.Parameters.AddWithValue("@REQBY", SqlDbType.VarChar).Value = ReqBy;
                cmd.CommandText = "usp_GETAppFocusReportDetail_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }

        public DataTable GetTravelSuiteAppFocusReportTableEXPORT(string UserName, string AppName, string fromDate, string toDate, string OfficeID, int OfficeGroupId, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserName == null)
                    UserName = "";
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@AppName", SqlDbType.VarChar).Value = AppName;
                cmd.Parameters.AddWithValue("@FromDate", SqlDbType.VarChar).Value = fromDate;
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = toDate;
                cmd.Parameters.AddWithValue("@OfficeId", SqlDbType.VarChar).Value = OfficeID;
                cmd.Parameters.AddWithValue("@UserName", SqlDbType.VarChar).Value = UserName;
                cmd.Parameters.AddWithValue("@GroupID", SqlDbType.VarChar).Value = OfficeGroupId;

                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortExp;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GetTravelSuiteAppFocusReport_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }


        public DataTable GetACWReportDetails(string fromDate, string toDate)
        {
            //DataTable dtACWReport = new DataTable();
            //DataRow drACWReport;
            //this._gWiz = new GDUServiceClient();
            //StandardResponse response = new StandardResponse();
            //try
            //{
            //    ACWCoralReportQuery request = new ACWCoralReportQuery();
            //    request.AppName = appName;
            //    request.FromDate = fromDate;
            //    request.ToDate = toDate;
            //    request.OfficeId = officeId;
            //    request.UserName = userName;
            //    request.GroupId = groupId;

            //    ACWCoralReportDetails[] ACWDetails = null;
            //    response = this._gWiz.PopulateACWReport(request, out ACWDetails);
            //    dtACWReport.Columns.Add("PHONEID", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("SERVER", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("STARTDATE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("ENDDATE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("TIMEZONE", Type.GetType("System.String"));
            //    dtACWReport.Columns.Add("ACW_DURATION", Type.GetType("System.String"));

            //    for (int iCount = 0; iCount < ACWDetails.Length; iCount++)
            //    {
            //        drACWReport = dtACWReport.NewRow();
            //        drACWReport["PHONEID"] = ACWDetails[iCount].AdsId;
            //        drACWReport["SERVER"] = ACWDetails[iCount].Server;
            //        drACWReport["STARTDATE"] = ACWDetails[iCount].StartDt;
            //        drACWReport["ENDDATE"] = ACWDetails[iCount].EndDt;
            //        drACWReport["TIMEZONE"] = ACWDetails[iCount].TIMEZONE;
            //        drACWReport["ACW_DURATION"] = ACWDetails[iCount].ACWDuration;

            //        dtACWReport.Rows.Add(drACWReport);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            //return dtACWReport;

            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                //cmd.Parameters.AddWithValue("@AppName", SqlDbType.VarChar).Value = appName;
                cmd.Parameters.AddWithValue("@FromDate", SqlDbType.VarChar).Value = fromDate;
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = toDate;
                //cmd.Parameters.AddWithValue("@OfficeId", SqlDbType.VarChar).Value = officeId;
                //cmd.Parameters.AddWithValue("@UserName", SqlDbType.VarChar).Value = userName;
                //cmd.Parameters.AddWithValue("@GroupID", SqlDbType.Int).Value = groupId;
                cmd.Parameters.AddWithValue("@Mode", SqlDbType.Int).Value = "E";
                cmd.CommandText = "usp_GETACWREPORT_FILE";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {

            }

            return ds.Tables[0];
        }


        public string GetAppVersionDB(int App_ID, string App_Type)
        {
            string App_Version = string.Empty;

            _gWiz = new GDUServiceClient();
            //GetAppLatestVersionRequest input = new GetAppLatestVersionRequest();
            //GetAppLatestVersionResponse response = new GetAppLatestVersionResponse();

            GetAppLatestVersionInput input = new GetAppLatestVersionInput();
            GetAppLatestVersionInfo response = new GetAppLatestVersionInfo();
            input.App_ID = Convert.ToString(App_ID);
            input.App_Type = App_Type;

            response = _gWiz.GetAppLatestVersion(input);

            App_Version = response.App_Version;

//            response = _gWiz.GetAppLatestVersion(

            return App_Version;
        }

        public DataTable GetClientPilotAppDeploymentReportEXPORT(string UserId, string Version, int Flag, string clientId, int App_ID, string SortExp, string SortOrder)
        {
            DataTable dtReport = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                if (UserId == null)
                    UserId = "";

                SqlConnection con;
                SqlCommand cmd = new SqlCommand();
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionInfo"].ToString());
                cmd.Parameters.AddWithValue("@UserID", SqlDbType.VarChar).Value = UserId;
                cmd.Parameters.AddWithValue("@Version", SqlDbType.VarChar).Value = Version;
                cmd.Parameters.AddWithValue("@NonMaxFlag", SqlDbType.VarChar).Value = Flag;
                cmd.Parameters.AddWithValue("@ClientId", SqlDbType.VarChar).Value = clientId;
                cmd.Parameters.AddWithValue("@App_ID", SqlDbType.VarChar).Value = App_ID;
                cmd.Parameters.AddWithValue("@SortColumn", SqlDbType.VarChar).Value = SortExp;
                cmd.Parameters.AddWithValue("@SortOrder", SqlDbType.VarChar).Value = SortOrder;

                cmd.CommandText = "usp_GetClientPilotAppDeploymentReport_GDU_EXPORT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.CommandTimeout = 3600;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                con.Close();
            }
            catch (Exception ex)
            {
            }
            return ds.Tables[0];
        }
    }
}
