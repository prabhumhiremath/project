﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Model
{
    public static class Constants
    {
        public const char SPLIT_CHAR = ';';
        public const string ROOT_NODE_NAME = "G-Wiz";
        public const string ROOT_NODE_DESCRIPTION = "RootDescription";
        public const string NODE_GENERAL_INFO = "GeneralInformation";
        public const string NODE_DESCRIPTION = "Description";
        public const string NODE_OI_DESCRIPTION = "Description";
        public const string NODE_TL = "TL";
        public const string NODE_ORIGINATION = "Origination";
        public const string NODE_ORIGINSEGMENTS = "OriginSegments";
        public const string NODE_ORIGINSEGMENT = "OriginSegment";
        public const string NODE_DESTINATION = "Destination";
        public const string NODE_DESTINATIONSEGMENTS = "DestinationSegments";
        public const string NODE_DESTINATIONSEGMENT = "DestinationSegment";
        public const string RESULT_CAPTION_ORIGIN = "Search result for origination";
        public const string URL = "Url";
        public const string RESULT_CAPTION_DEST = "Search result for destination";
        public const string NODE_GENERALSEGMENT = "GeneralSegment";
        public const string RESULT_CAPTION_OTHER = "Search result for other info";
        public const string IMAGES = "Images";
        public const string IS_BROWSEABLE = "IsBrowseable";
        public const string FEEDBACK_IMAGE = "FeedbackImage";
        public const string AGGREATIONTOOLTIP = "AggreationToolTip";
        public const string IsOriginTL = "OriginTL";
        public const string LINKID = "LinkID";
        public const string LINKDETAILID = "LinkDetailID";
        public const string LINKDETAILCATEGORYID = "LinkDetailCategoryID";

        public const string SHOWHIDE_IMAGE = "ImgShowHide";
        public const string ADD_IMAGE = "AddImage";
        public const string EDIT_IMAGE = "EditImage";
        public const string DELETE_IMAGE = "DeleteImage";
        public const string VIEW_IMAGE = "ViewImage";
        public const string LINK_TYPE = "LinkType";
        public const string LABEL_ID = "LabelId";
        public const string HOVER_TEXT = "HoverText";
        public const string DOWNLOAD = "DownLoad";
        public const string LINKTYPE_CODE = "LinkTypeCode";
        public const string LINK = "Link";
        public const string LANGUAGECODE = "LanguageCode";
        public const string ISFEEDBACK = "IsFeedbackEnabled";
        public const string PARENTLABELID = "ParentLabelID";
        public const string TRANSID = "TransID";
        public const string MODE = "Mode";
        public const string SEARCH_CRITERIA = "SearchCriteria";
        public const string CHILDCOUNT = "ChildCount";

        public const string GLOBALCODE = "GlobalCode";
        public const string CARRIERCODE = "CarrierCode";

        public const string MAXIMAGES = "MaxImage";
        public const string MINIMAGES = "MinImage";
        public const string FEEDBACKROOT = "FeedBackNode";
        public const string FEEDBACKCHILD = "Values";
        public const string FEEDBACKCODENODE = "FeedBackTypeCode";
        public const string FEEDBACKVALUENODE = "FeedBackTypeValue";

        public const string DISABLE_IMAGE = "DisableImage";
        public const string DISABLE_TRUE = "True";
        public const string DISABLE_FALSE = "False";
        public const string FeedbackImage_Name = "feedback.gif";
        public const string ADDCATEGORYIMAGENAME = "addcat.jpg";
        public const string ADDFILEURLIMAGENAME = "addfileurl.jpg";
        public const string addImageName = "add.gif";
        public const string editImageName = "edit.gif";
        public const string deleteImageName = "delete.gif";
        public const string GENERALINFO_EDITIMAGENAME = "editIcon.jpg";
        public const string GENERALINFO_DELETEIMAGENAME = "deleteIcon.jpg";
        public const string viewImage = "view.gif";
        public const string maxImageName = "plus.gif";
        public const string minImageName = "minus.gif";
        public const string CONSTCATEGORY_IMAGE = "c_cat.png";
        public const string CONSTGlOBALCATEGORY_IMAGE = "globalcat.png";
        public const string CONSTCARRIER_IMAGE = "carriercat.png";
        public const string CONSTCROSS_IMAGE = "C_cross.png";
        public const string CONSTCATEGORY = "CATEGORY";
        public const string CONSTPDF_IMAGE = "C_pdf.png";
        public const string CONSTEXCEL_IMAGE = "C_excel.png";
        public const string CONSTBMP_IMAGE = "C_bmp.png";
        public const string CONSTAVI_IMAGE = "C_avi.png";
        public const string CONSTJPG_IMAGE = "C_jpg.png";
        public const string CONSTWORD_IMAGE = "C_winword.png";
        public const string CONSTTEXT_IMAGE = "C_text.png";
        public const string CONSTPPT_IMAGE = "C_ppt.png";
        public const string CONSTEXPLORER_IMAGE = "C_explorer.png";
        public const string CONSTPDF_EXT = ".pdf";
        public const string CONSTEXCEL_EXT = ".xls";
        public const string CONSTBMP_EXT = ".bmp";
        public const string CONSTAVI_EXT = ".avi";
        public const string CONSTJPG_EXT = ".jpg";
        public const string CONSTJPEG_EXT = ".jpeg";
        public const string CONSTPNG_EXT = ".png";
        public const string CONSTGIF_EXT = ".gif";
        public const string CONSTDOC_EXT = ".doc";
        public const string CONSTTXT_EXT = ".txt";
        public const string CONSTPPT_EXT = ".ppt";
        //Phase 3 Req Change  
        public const string CONSTEXCELX_EXT = ".xlsx";
        public const string CONSTDOCX_EXT = ".docx";
        public const string CONSTPPTX_EXT = ".pptx";


        //End
        public const string CONSTGLOBAL = "GLOBAL";
        public const string CONSTCARRIER = "CARRIER";
        public const string CONSTLOCATION = "LOCATION";
        public const string CONSTORIGINATION = " Origination - ";
        public const string CONSTDESTINATION = "Destination - ";
        public const string CONSTGLOBALCATEGORY = "Global Category";
        public const string CONSTCARRIERS = "Air Carriers from Availability";
        public const string CONSTIMGDIR = "\\Images\\";
        public const char CONSTDOT = '.';
        public const string CONSTZERO = "0";
        public const string CONSTONE = "1";
        public const string CONSTSLASH = " / ";
        public const string CONSTADMIN = "Admin";
        public const string CONSTSELECT = "Please Select";
        public const string CONSTOTHERINFO = "Other Info";
        public const string CONSTPARAFILEPATH = "ParameterFilePath";
        public const string CONSTPARAFILENAME = "ParameterFileName";
        public const string CONSTCORDPATH = "ScreenCordinateFilePath";
        public const string CONSTCORDNAME = "ScreenCordinateFileName";
        public const string CONSTISFEEDBACK = "IsFeedback";
        public const string CONSTURLLINK = "URLLINK";
        public const string CONSTPOPUP = "POPUP";
        public const string CONSTDOWNPATH = "DownloadPath";
        public const string CONSTAGGREGATIONRULE = "AggrigationRule";
        public const string CONSTKEY = "key";
        public const string CONSTVALUE = "value";
        public const string CONSTGENERAL = "GENERAL";
        public const string CONSTVERSION = "AppVersion";

        public const string ACCOUNT = "Account";
        public const string ACCOUNTCOUNTRY = "AccountCountry";
        public const string ACCOUNTCOUNTRYCITY = "AccountCountryCity";
        public const string COUNTRY = "Country";
        public const string COUNTRYCITY = "CountryCity";

        public const string CONSTSPGROUP = "UserGroup";
        public const string CONSTCLIENT = "CLIENT";
        public const string CONSTLANGUAGE = "ENG";
        public const string ADMINUSERTYPE = "ADMIN";
        public const string USERROLECLIENT = "DC";
        public const string USERROLEADMIN = "AD";
        public const string CONSTSUCCESS = "Success";
        public const string CONSTADD = "ADD";
        public const string CONSTACTIVATE = "ACTIVATE";
        public const string CONSTDEACTIVATE = "DEACTIVATE";
        public const string CONSTUPDATE = "UPDATE";

        public const string NODE_ALERT = "AlertSections";
        public const string NODE_SECTION = "Sections";
        public const string VALIDFROMDATE = "ValidFromDate";
        public const string VALIDTODATE = "ValidToDate";
        public const string DISPLAYVALIDFROMMONTH = "DisplayValidFromMonth";
        public const string DISPLAYVALIDTOMONTH = "DisplayValidToMonth";
        public const string DISPLAYVALIDFROMDAY = "DisplayValidFromDay";
        public const string DISPLAYVALIDTODAY = "DisplayValidToDay";
        public const string TEXT_TO_DISPLAY = "TextToDisplay";
        public const string KEYWORD = "Keyword";
        public const string IS_GLOBAL = "IsGlobal";
        public const string VISIBLE_TO_CLIENT = "VisibleToClient";

    }
}
