﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ApplicationQuery
    {
        [DataMember]
        public string ApplicationNM
        {
            get;
            set;
        }

        [DataMember]
        public string ApplicationAbbr
        {
            get;
            set;
        }

        [DataMember]
        public string ApplicationDeployPath
        {
            get;
            set;
        }

        [DataMember]
        public string ApplicationExeName
        {
            get;
            set;
        }

        [DataMember]
        public string EntryPoint
        {
            get;
            set;
        }

        [DataMember]
        public string App_Type
        {
            get;
            set;
        }

    }
}
