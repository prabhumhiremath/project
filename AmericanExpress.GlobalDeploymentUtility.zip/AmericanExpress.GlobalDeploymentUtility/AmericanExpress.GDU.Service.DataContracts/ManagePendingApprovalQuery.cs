﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
   [DataContract]
    public class ManagePendingApprovalQuery
    {
       [DataMember]
       public int linkId
       {
           get;
           set;
       }

       [DataMember]
       public int linkDtlId
       {
           get;
           set;
       }

       [DataMember]
       public int linkCatDtlId
       {
           get;
           set;
       }

       [DataMember]
       public int labelId
       {
           get;
           set;
       }

       [DataMember]
       public bool isApprove
       {
           get;
           set;
       }

       [DataMember]
       public string mode
       {
           get;
           set;
       }

       [DataMember]
       public string uploadType
       {
           get;
           set;
       }
    }
}
