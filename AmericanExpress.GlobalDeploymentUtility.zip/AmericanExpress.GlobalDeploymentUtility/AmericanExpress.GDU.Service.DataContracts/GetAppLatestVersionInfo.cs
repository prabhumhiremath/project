﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class GetAppLatestVersionInfo
    {
        [DataMember]
        public string App_ID
        {
            get;
            set;
        }

        [DataMember]
        public string App_Name
        {
            get;
            set;
        }

        [DataMember]
        public string App_Version
        {
            get;
            set;
        }

        [DataMember]
        public string App_Type
        {
            get;
            set;
        }
    }
}
