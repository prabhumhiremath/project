﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ApplicationDetails
    {
        [DataMember]
        public int AppID
        {
            get;
            set;
        }
        [DataMember]
        public string AppDeployPath
        {
            get;
            set;
        }
        [DataMember]
        public string AppAbbrName
        {
            get;
            set;
        }
        [DataMember]
        public string AppExeName
        {
            get;
            set;
        }

        [DataMember]
        public string AppAbbr
        {
            get;
            set;
        }

        [DataMember]
        public string EntryPoint
        {
            get;
            set;
        }
        [DataMember]
        public string App_Type
        {
            get;
            set;
        }
    }
}
