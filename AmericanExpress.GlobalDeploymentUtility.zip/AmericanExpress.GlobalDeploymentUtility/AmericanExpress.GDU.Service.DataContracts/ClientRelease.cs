﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Service.DataContracts
{
   public class ClientRelease
    {
       /// <summary>
       /// 
       /// </summary>
       public ClientReleaseQuery ClientReleaseVer
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public ClientReleaseDtlQuery[] ClientReleaseDtl
       {
           get;
           set;
       }
    }
}
