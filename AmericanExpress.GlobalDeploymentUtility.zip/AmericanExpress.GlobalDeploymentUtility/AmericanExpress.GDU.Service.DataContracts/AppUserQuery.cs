﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppUserQuery
    {
        [DataMember]
        public string UserId
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public int App_ID
        {
            get;
            set;
        }

        [DataMember]
        public bool IsDeactive
        {
            get;
            set;
        }

        [DataMember]
        public string Mode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        [DataMember]
        public string Role_CD
        {
            get;
            set;
        }

        [DataMember]
        public String AuthorizedRoleIds
        {
            get;
            set;
        }

        [DataMember]
        public string EntryPoint
        {
            get;
            set;
        }

        [DataMember]
        public string InFlag
        {
            get;
            set;
        }

        [DataMember]
        public string App_Type
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }

        [DataMember]
        public string App_Version
        {
            get;
            set;
        }

        [DataMember]
        public int PageIndex
        {
            get;
            set;
        }

        [DataMember]
        public int PageSize
        {
            get;
            set;
        }

        [DataMember]
        public string SortColumn
        {
            get;
            set;
        }

        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
