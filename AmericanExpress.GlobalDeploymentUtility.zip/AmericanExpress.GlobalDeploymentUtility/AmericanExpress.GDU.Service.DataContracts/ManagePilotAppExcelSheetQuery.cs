﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ManagePilotAppExcelSheetQuery
    {
        [DataMember]
        public System.Data.DataTable DtExcelData
        {
            get;
            set;
        }

        [DataMember]
        public string XmlData
        {
            get;
            set;
        }

        [DataMember]
        public int AppId
        {
            get;
            set;
        }

        [DataMember]
        public string AppVersion
        {
            get;
            set;
        }

        [DataMember]
        public string CreatedUserId
        {
            get;
            set;
        }

        [DataMember]
        public string UploadType
        {
            get;
            set;
        }

        [DataMember]
        public int GroupID
        {
            get;
            set;
        }
    }
}
