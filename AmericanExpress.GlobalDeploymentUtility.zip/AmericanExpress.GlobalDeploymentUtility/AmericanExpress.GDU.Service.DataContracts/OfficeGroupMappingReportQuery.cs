﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class OfficeGroupMappingReportQuery
    {
        [DataMember]
        public string GroupID
        {
            get;
            set;
        }

        [DataMember]
        public int PageIndex
        {
            get;
            set;
        }

        [DataMember]
        public int PageSize
        {
            get;
            set;
        }

        [DataMember]
        public string SortColumn
        {
            get;
            set;
        }

        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }

    }
}
