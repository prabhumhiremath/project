﻿//-----------------------------------------------------------------------
// <copyright file="UserRoleDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserRoleDetails class which contains attributes for UserRoleDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class UserRoleDetails
    {

        [DataMember]
        public string RoleCode
        {
            get;
            set;
        }

        [DataMember]
        public string RoleName
        {
            get;
            set;
        }
        
        [DataMember]
        public string DomainName
        {
            get;
            set;
        }

        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string ComputerName
        {
            get;
            set;
        }
        [DataMember]
        public string ClientID
        {
            get;
            set;
        } 
    }
}
