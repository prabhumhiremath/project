﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class FocusGroupDetails
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public Int32 ID
        {
            get;
            set;
        }
        [DataMember]
        public string GROUP_NM
        {
            get;
            set;
        }
        [DataMember]
        public string USER_ID
        {
            get;
            set;
        }
        [DataMember]
        public string MODE
        {
            get;
            set;
        }
        [DataMember]
        public bool ISACTIVE
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecord
        {
            get;
            set;
        }
        


    }
    [DataContract]
    public class PopulateFocusGroupDetails
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string  ID
        {
            get;
            set;
        }
        [DataMember]
        public string GROUP_NM
        {
            get;
            set;
        }
      
        



    }
    [DataContract]
    public class PopulateAppfOfficeAdsID
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ADS_ID
        {
            get;
            set;
        }
        [DataMember]
        public string OFFICE_ID
        {
            get;
            set;
        }
        [DataMember]
        public string OFFICE_DS
        {
            get;
            set;
        }
        [DataMember]
        public string MACHINE_NM
        {
            get;
            set;
        }
        [DataMember]
        public string USER_NM
        {
            get;
            set;
        }





    }
}
