﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class FocusAppQuery
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string APP_DS
        {
            get;
            set;
        }
        [DataMember]
        public string AppId
        {
            get;
            set;
        }
        [DataMember]
        public int ID
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
