﻿//-----------------------------------------------------------------------
// <copyright file="UserDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a DurationTime class which contains attributes for ManageDurationTime</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
 [DataContract]
   public class DurationTime
    {
     [DataMember]
     public int TimeDuration
     {
         get;
         set;
     }
     [DataMember]
     public String UserId
     {
         get;
         set;
     }

     [DataMember]
     public Char TimeFormat
     {
         get;
         set;
     }


    }
}
