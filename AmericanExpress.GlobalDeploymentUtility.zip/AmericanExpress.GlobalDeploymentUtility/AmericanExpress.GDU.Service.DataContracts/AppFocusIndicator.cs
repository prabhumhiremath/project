﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppFocusIndicator
    {
        [DataMember]
        public string AppFIndicator
        {
            get;
            set;
        }

        [DataMember]
        public string IndicatorName
        {
            get;
            set;
        }

        
    }
}
