﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class PilotAppRepQuery
    {
        [DataMember]
        public int App_Id
        {
            get;
            set;
        }

        [DataMember]
        public string APP_NAME
        {
            get;
            set;
        }

        [DataMember]
        public string Version
        {
            get;
            set;
        }

        [DataMember]
        public string AdsId
        {
            get;
            set;
        }

        [DataMember]
        public string MachineName
        {
            get;
            set;
        }

        [DataMember]
        public string OfficeId
        {
            get;
            set;
        }

        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
        //Market Release
        [DataMember]
        public string AppCodeBase
        {
            get;
            set;
        }
    }
}
