﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AddOfficeQuery
    {
        [DataMember]
        public string OfficeId
        {
            get;
            set;
        }

      
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string ADSId
        {
            get;
            set;
        }

        
    }
}
