﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{    
    [DataContract]
    public class TravelSuiteAppFocusReportQuery
    {
        [DataMember]
        public string AppName
        {
            get;
            set;
        }

        [DataMember]
        public string ADSId
        {
            get;
            set;
        }

        [DataMember]
        public string FromDate
        {
            get;
            set;
        }

        [DataMember]
        public string ToDate
        {
            get;
            set;
        }

        [DataMember]
        public string OfficeId
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public int SequenceNo
        {
            get;
            set;
        }

        [DataMember]
        public string GroupSeqNo
        {
            get;
            set;
        }
        [DataMember]
        public int OfficeGroupId
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
