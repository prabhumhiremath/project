﻿//-----------------------------------------------------------------------
// <copyright file="TransactionQuery.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a TransactionQuery class which contains attributes for TransactionQuery</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/12/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
   public class TransactionQuery
    {
        
        /// <summary>
        /// 
        /// </summary>
         [DataMember]
        public string AccountCode
        {
            get;
            set;
        }
      
        /// <summary>
        /// 
        /// </summary>
         [DataMember]
        public string CountryCode
        {
            get;
            set;
        }
       
        /// <summary>
        /// 
        /// </summary>
         [DataMember]
        public string CityCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string OtherInfoCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        
        public string GlobalCatCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CarrierCode
        {
            get;
            set;
        }

        [DataMember]
        public string DomainName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ComputerName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public int clientID
        {
            get;
            set;
        }
    }
}
