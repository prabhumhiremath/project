﻿//-----------------------------------------------------------------------
// <copyright file="ReportQuery.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a ReportQuery class which contains attributes for ReportQuery</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/04/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ReportQuery
    {
        [DataMember]
        public string strAccount
        {
            get;
            set;
        }
        [DataMember]
        public string strCountry
        {
            get;
            set;
        }
        [DataMember]
        public string strCity
        {
            get;
            set;
        }

        [DataMember]
        public string strFlag
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        [DataMember]
        public String IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        [DataMember]
        public String ComputerName
        {
            get;
            set;
        }
        ///<summary>
        /// 
        /// </summary>
        [DataMember]
        public String strClientId
        {
            get;
            set;
        } 



    }
}
