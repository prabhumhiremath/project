﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class OfficeGroupMappingReportInfo
    {
        #region Public Properties

        
        [DataMember]
        public string GroupNM
        {
            get;
            set;
        }

        [DataMember]
        public string OfficeID
        {
            get;
            set;
        }


        [DataMember]
        public string ADSID
        {
            get;
            set;
        }

        [DataMember]
        public string USER_NM
        {
            get;
            set;
        }

        [DataMember]
        public string COMPUTER_NM
        {
            get;
            set;
        }

        [DataMember]
        public string IP_ADDR_TXT
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecords
        {
            get;
            set;
        }

       
        #endregion

    }
}
