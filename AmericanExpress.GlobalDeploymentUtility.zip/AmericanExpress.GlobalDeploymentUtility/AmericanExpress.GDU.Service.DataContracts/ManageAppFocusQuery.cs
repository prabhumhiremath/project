﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ManageAppFocusQuery
    {
        [DataMember]
        public string XmlData
        {
            get;
            set;
        }

        [DataMember]
        public string ComputerName
        {
            get;
            set;
        }

        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }

        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string ADSId
        {
            get;
            set;
        }

        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string currentEndDate
        {
            get;
            set;
        }

        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public int FILE_TYPE
        {
            get;
            set;
        }
    }
}
