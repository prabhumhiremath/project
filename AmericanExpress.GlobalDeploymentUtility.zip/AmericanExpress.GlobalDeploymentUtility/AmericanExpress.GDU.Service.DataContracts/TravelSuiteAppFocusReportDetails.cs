﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{   
    [DataContract]
    public class TravelSuiteAppFocusReportDetails
    {
        [DataMember]
        public int SequenceNo
        {
            get;
            set;
        }

        [DataMember]
        public string ADSId
        {
            get;
            set;
        }


        [DataMember]
        public string AppName
        {
            get;
            set;
        }

        [DataMember]
        public string ProcessName
        {
            get;
            set;
        }

        [DataMember]
        public DateTime FromDate
        {
            get;
            set;
        }

        [DataMember]
        public DateTime ToDate
        {
            get;
            set;
        }

        [DataMember]
        public string OfficeId
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public string ComputerName
        {
            get;
            set;
        }

        [DataMember]
        public string IpAddress
        {
            get;
            set;
        }
        [DataMember]
        public string UsageDate
        {
            get;
            set;
        }
        [DataMember]
        public string TotalUsage
        {
            get;
            set;
        }
        [DataMember]
        public string GroupSeqNo
        {
            get;
            set;
        }

        [DataMember]
        public string ApplEndDate
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecord
        {
            get;
            set;
        }
    }
}
