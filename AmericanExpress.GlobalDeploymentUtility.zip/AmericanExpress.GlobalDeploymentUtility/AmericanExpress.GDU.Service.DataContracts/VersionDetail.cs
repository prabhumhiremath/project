﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class VersionDetail
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ReleaseId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ReleaseVersion
        {
            get;
            set;
        }

        [DataMember]
        public int App_ID
        {
            get;
            set;
        }

        [DataMember]
        public char IsRollback
        {
            get;
            set;
        }

        [DataMember]
        public string AppExeName
        {
            get;
            set;
        }

        [DataMember]
        public string EntryPoint
        {
            get;
            set;
        }
    }
}
