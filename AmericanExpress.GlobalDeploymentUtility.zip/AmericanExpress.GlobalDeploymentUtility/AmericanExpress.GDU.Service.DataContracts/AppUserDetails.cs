﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppUserDetails
    {

        [DataMember]
        public string UserId
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public string AppName
        {
            get;
            set;
        }

        [DataMember]
        public string Role_CD
        {
            get;
            set;
        }

        [DataMember]
        public string Mode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        [DataMember]
        public string EntryPoint
        {
            get;
            set;
        }

        [DataMember]
        public string InFlag
        {
            get;
            set;
        }

        [DataMember]
        public string App_Type
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecords
        {
            get;
            set;
        }

    }
}
