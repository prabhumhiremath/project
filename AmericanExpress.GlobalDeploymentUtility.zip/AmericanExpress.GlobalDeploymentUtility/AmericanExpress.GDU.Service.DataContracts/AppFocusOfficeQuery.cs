﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppFocusOfficeQuery
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public Int32 Id
        {
            get;
            set;
        }
        [DataMember]
        public string Office_ID
        {
            get;
            set;
        }
        [DataMember]
        public string OfficeDesc
        {
            get;
            set;
        }

        [DataMember]
        public string USER_ID
        {
            get;
            set;
        }
        [DataMember]
        public string MODE
        {
            get;
            set;
        }
        [DataMember]
        public bool ISACTIVE
        {
            get;
            set;
        }
        [DataMember]
        public string ISREPORT
        {
            get;
            set;
        }

        [DataMember]
        public string STATUS
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
