﻿//-----------------------------------------------------------------------
// <copyright file="LanguageDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a LanguageDetails class which contains attributes for language</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class LanguageDetails
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string LanguageCode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string LanguageName
        {
            get;
            set;
        }
        [DataMember]
        public string DomainName
        {
            get;
            set;
        }

        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string ComputerName
        {
            get;
            set;
        } 
    }
}
