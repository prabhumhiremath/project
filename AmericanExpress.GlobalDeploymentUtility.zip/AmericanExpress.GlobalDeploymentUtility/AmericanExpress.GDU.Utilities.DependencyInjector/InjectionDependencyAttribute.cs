﻿//-----------------------------------------------------------------------
// <copyright file="InjectionDependencyAttribute.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class for defining attribute to mark dependency</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Namespace Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace AmericanExpress.GDU.Utilities.DependencyInjector
{
    /// <summary>
    /// Attribute to mark an injectable property 
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
   public  class InjectionDependencyAttribute:Attribute
   {
       #region Private class members
       private string _implementationLibrary = string.Empty;
       #endregion

       #region Public Methods
       /// <summary>
       /// constructor to be used internally by f/w
       /// </summary>
       /// <param name="implemantationLibrary"></param>
       public InjectionDependencyAttribute(string implemantationLibrary)
       {
           _implementationLibrary = implemantationLibrary;
       }
       #endregion

       #region Public properties
       /// <summary>
        /// Gets library name as defined in configuration file
        /// </summary>
       public string ImplementationLibrary
        {
            get { return _implementationLibrary; }

        }
    #endregion
   }
}
