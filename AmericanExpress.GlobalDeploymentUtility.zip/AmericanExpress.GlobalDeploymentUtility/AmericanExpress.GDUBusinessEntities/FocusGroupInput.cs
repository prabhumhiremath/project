﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class FocusGroupInput
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public StandardInput STDinput
        {
            get;
            set;
        }
       public int ID
       {
           get;
           set;
       }
        public string Group_NM
        {
            get;
            set;
        }
        public string User_ID
        {
            get;
            set;
        }
        public string Mode
        {
            get;
            set;
        }
        public bool IsActive
        {
            get;
            set;
        }
       
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }

}
