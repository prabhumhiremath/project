﻿//-----------------------------------------------------------------------
// <copyright file="VersionDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a VersionDetails class which contains attributes for VersionDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class VersionDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public string VersionId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string Version
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        public int NonMaxFlag
        {
            get;
            set;
        }

        public char IsRollback
        {
            get;
            set;
        }

        public string AppExeName
        {
            get;
            set;
        }
        public string EntryPoint
        {
            get;
            set;
        }
    }
}