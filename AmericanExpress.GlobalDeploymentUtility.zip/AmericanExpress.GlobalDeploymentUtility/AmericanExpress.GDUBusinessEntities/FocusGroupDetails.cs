﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class FocusGroupDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public int ID
        {
            get;
            set;
        }
        public string Group_NM
        {
            get;
            set;
        }
        public string User_ID
        {
            get;
            set;
        }
        public string Mode
        {
            get;
            set;
        }
        public bool IsActive
        {
            get;
            set;
        }

        public int TotalRecord
        {
            get;
            set;
        }
    }
    public class PopulateFocusGroupDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string ID
        {
            get;
            set;
        }
        public string Group_NM
        {
            get;
            set;
        }
      
    }
}
