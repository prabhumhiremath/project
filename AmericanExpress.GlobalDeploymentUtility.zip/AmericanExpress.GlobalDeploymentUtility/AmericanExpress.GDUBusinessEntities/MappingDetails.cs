﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
  public  class MappingDetails
    {
        public string Mapping_CD
        {
            get;
            set;
        }
        public string Virtual_CD
        {
            get;
            set;
        }
        public string Real_CD
        {
            get;
            set;
        }
        public string Real_NM
        {
            get;
            set;
        }

        public string Mode
        {
            get;
            set;
        }

        public string InTransaction
        {
            get;
            set;
        }
    }
}
