﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppUploadedReportDetail
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public string App_Name
        {
            get;
            set;
        }

        public string Version
        {
            get;
            set;
        }

        public string IP
        {
            get;
            set;
        }

        public string Upload_Dt
        {
            get;
            set;
        }

        public string RollBack
        {
            get;
            set;
        }

        public string User_ID
        {
            get;
            set;
        }

        public string From_Dt
        {
            get;
            set;
        }

        public string To_Date
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        public string User_Name
        {
            get;
            set;
        }

        public string Computer_NM
        {
            get;
            set;
        }

        public string APP_TYPE
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }
    }
}
