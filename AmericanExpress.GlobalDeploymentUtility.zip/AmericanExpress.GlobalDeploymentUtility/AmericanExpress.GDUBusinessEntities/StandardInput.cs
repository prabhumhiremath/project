﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    /// <summary>
    /// 
    /// </summary>
    public enum InputType
    {
        Real,
        Virtual,
        All,
        VirtualAssociation
    }

  public class StandardInput
    {
      public InputType EnumType
      {
          get;
          set;
      }
    }
}
