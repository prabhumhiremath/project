﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppUserInput
    {

        public string UserId
        {
            get;
            set;
        }

        public string UserName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string AppName
        {
            get;
            set;
        }

        public bool IsDeactive
        {
            get;
            set;
        }

        public string Role_CD
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        public string Mode
        {
            get;
            set;
        }

        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        public string AuthorizedRoleIds
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string InFlag
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }

        public string App_Version
        {
            get;
            set;
        }

        public string APP_TYPE
        {
            get;
            set;
        }
        
        public int PageIndex
        {
            get;
            set;
        }
       
        public int PageSize
        {
            get;
            set;
        }
       
        public string SortColumn
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
