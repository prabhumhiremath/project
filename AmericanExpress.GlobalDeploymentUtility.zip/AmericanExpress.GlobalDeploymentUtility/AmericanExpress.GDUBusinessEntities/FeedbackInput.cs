﻿//-----------------------------------------------------------------------
// <copyright file="FeedbackInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a FeedbackInput class which contains attributes for FeedbackInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/17/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace AmericanExpress.GDU.BusinessEntities
{
   public class FeedbackInput
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }       
    }
}
