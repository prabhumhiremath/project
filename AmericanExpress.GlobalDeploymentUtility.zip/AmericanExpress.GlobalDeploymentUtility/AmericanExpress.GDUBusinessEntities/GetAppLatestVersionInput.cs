﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class GetAppLatestVersionInput
    {
        public string App_ID
        {
            get;
            set;
        }

        
        public string App_Type
        {
            get;
            set;
        }
    }
}
