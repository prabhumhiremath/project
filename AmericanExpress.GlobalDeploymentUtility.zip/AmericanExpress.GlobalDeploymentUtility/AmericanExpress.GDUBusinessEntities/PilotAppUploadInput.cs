﻿//-----------------------------------------------------------------------
// <copyright file="PilotAppUploadInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>17/10/2011</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class PilotAppUploadInput
    {
        #region Public Properties
        /// <summary>
        /// 
        /// </summary>
        public StandardInput STDinput
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public int AppId
        {
            get;
            set;
        }

        public string APP_NAME
        {
            get;
            set;
        }

        public string AppVersion
        {
            get;
            set;
        }

        public string AdsId
        {
            get;
            set;
        }


        public string MachineName
        {
            get;
            set;
        }

        public string OfficeId
        {
            get;
            set;
        }


        public string IPAddress
        {
            get;
            set;
        }

       
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
        //Market Release
        public string AppCodeBase
        {
            get;
            set;
        }

        #endregion
    }
}
