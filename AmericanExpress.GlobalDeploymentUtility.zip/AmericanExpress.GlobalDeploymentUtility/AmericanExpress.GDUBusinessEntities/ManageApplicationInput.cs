﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ManageApplicationInput
    {
        public string ApplicationNM
        {
            get;
            set;
        }
        public string ApplicationAbbr
        {
            get;
            set;
        }

        public string ApplicationDeployPath
        {
            get;
            set;
        }


        public bool IsDeactive
        {
            get;
            set;
        }

        public string AppExeName
        {
            get;
            set;
        }

        public string AppType
        {
            get;
            set;
        }

        public string AppMode
        {
            get;
            set;
        }

        public string AppId
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string App_Type
        {
            get;
            set;
        }
        
        public int PageIndex
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortColumn
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
