﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ClientReleaseInput
    {
        /// <summary>
        /// 
        /// </summary>
        public Int64 RELEASE_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string RELEASE_VERSION
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string RELEASE_DT
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CREATED_USER_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CREATED_DT
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string MODIFIED_USER_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime MODIFIED_DT
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        public bool IsConnected
        {
            get;
            set;
        }


        public string IsRollBack
        {
            get;
            set;
        }

        public string IP
        {
            get;
            set;
        }

        public string APP_TYPE
        {
            get;
            set;
        }

        public string Computer_NM
        {
            get;
            set;
        }
    }
}
