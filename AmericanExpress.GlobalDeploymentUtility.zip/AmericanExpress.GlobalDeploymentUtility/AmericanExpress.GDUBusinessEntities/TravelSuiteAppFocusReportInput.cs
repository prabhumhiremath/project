﻿using System;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class TravelSuiteAppFocusReportInput
    {
        #region Public Properties
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>

        public string AppName
        {
            get;
            set;
        }

        public string ADS_ID
        {
            get;
            set;
        }

        public string FromDate
        {
            get;
            set;
        }

        public string ToDate
        {
            get;
            set;
        }


        public string OfficeId
        {
            get;
            set;
        }

        public string UserName
        {
            get;
            set;
        }
        public int SequenceNo
        {
            get;
            set;
        }
        public string GroupSeqNo
        {
            get;
            set;
        }

        public int OfficeGroupId
        {
            get;
            set;
        }
        
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
       
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }

        #endregion
    }
}
