﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace AmericanExpress.GDU.BusinessEntities
{
    public class TravelSuiteAppFocusReportDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public int SequenceNo
        {
            get;
            set;
        }

        public string ADS_ID
        {
            get;
            set;
        }

        public string AppName
        {
            get;
            set;
        }


        public DateTime FromDate
        {
            get;
            set;
        }


        public DateTime ToDate
        {
            get;
            set;
        }


        public string OfficeId
        {
            get;
            set;
        }


        public string UserName
        {
            get;
            set;
        }


        public string ComputerName
        {
            get;
            set;
        }


        public string IpAddress
        {
            get;
            set;
        }

        public string UsageDate
        {
            get;
            set;
        }

        public string TotalUsage
        {
            get;
            set;
        }

        public string ProcessName
        {
            get;
            set;
        }

        public string GroupSeqNo
        {
            get;
            set;
        }

        public string ApplEndDate
        {
            get;
            set;
        }

        public int TotalRecord
        {
            get;
            set;
        }
    }
}
