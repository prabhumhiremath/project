﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppFocusOfficeDetails
    {
        public Int32 ID
        {
            get;
            set;
        }
        public string Office_ID
        {
            get;
            set;
        }
        public string Office_Desc
        {
            get;
            set;
        }

        public bool IsActive
        {
            get;
            set;
        }
        public string IsReport
        {
            get;
            set;
        }

        public int TotalRecord
        {
            get;
            set;
        }

    }
    public class AppFOfficeAdsID
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string ADS_ID
        {
            get;
            set;
        }
        public string OFFICE_ID
        {
            get;
            set;
        }
        public string OFFICE_DS
        {
            get;
            set;
        }
        public string MACHINE_NM
        {
            get;
            set;
        }
        public string USER_NM
        {
            get;
            set;
        }
    }
}
