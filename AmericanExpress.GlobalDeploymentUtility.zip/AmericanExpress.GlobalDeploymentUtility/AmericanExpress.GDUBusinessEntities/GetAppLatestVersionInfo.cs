﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class GetAppLatestVersionInfo
    {
        public string App_ID
        {
            get;
            set;
        }
        
        public string App_Name
        {
            get;
            set;
        }
        
        public string App_Version
        {
            get;
            set;
        }
        
        public string App_Type
        {
            get;
            set;
        }
    }
}
