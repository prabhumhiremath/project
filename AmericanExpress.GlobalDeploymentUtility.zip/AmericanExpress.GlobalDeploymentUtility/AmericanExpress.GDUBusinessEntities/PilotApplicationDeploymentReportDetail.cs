﻿//-----------------------------------------------------------------------
// <copyright file="ClientDeployementInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class PilotApplicationDeploymentReportDetail
    {
        #region Public Properties
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or stes the UserId.
        /// </summary>
        public string UserId
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the IPAddress.
        /// </summary>
        public string IPAddress
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the NACId.
        /// </summary>
        public string NACId
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeVersion.
        /// </summary>
        public string ExeVersionNo
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeTimeStamp.
        /// </summary>
        public DateTime ExeTimeStamp
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the TimeStamp.
        /// </summary>
        public DateTime RecordTimeStamp
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the ApplicationPath.
        /// </summary>
        public string ApplicationPath
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the Latest Version.
        /// </summary>
        public string LatestVersionNo
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the Computer Name.
        /// </summary>
        public string ComputerName
        {
            get;
            set;
        }

        public string App_Name
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }

        #endregion
    }
}
