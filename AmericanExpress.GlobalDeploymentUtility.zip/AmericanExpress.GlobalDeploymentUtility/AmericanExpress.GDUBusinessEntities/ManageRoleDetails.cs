﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.BusinessEntities
{
    
    public class ManageRoleDetails
    {
             
       
        public Int32 ClientId
        {
            get;
            set;
        }

        
        public string RoleCode
        {
            get;
            set;
        }


        public string RoleName
        {
            get;
            set;
        }

       
        public string ClientName
        {
            get;
            set;

        }

        public DateTime ModifiedDate
        {
            get;
            set;
        }


        public string RoleTypeCD
        {
            get;
            set;

        }

        public string ClientAbbr
        {
            get;
            set;

        }

        public string SYSTEM_NAME
        {
            get;
            set;
        }

        public int TotalRecord
        {
            get;
            set;

        }
    }
}
