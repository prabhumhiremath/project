﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class OfficeGroupMappingReportInput
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public string GroupID
        {
            get;
            set;
        }
        
        public int PageIndex
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortColumn
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
