﻿//-----------------------------------------------------------------------
// <copyright file="UserDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserDetails class which contains attributes for UserDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class UserDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string UserName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsDeactive
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string Language
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string LanguageCode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string EmailAddress
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserRole
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserRoleCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string DomainName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string Mode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String ComputerName
        {
            get;
            set;
        }

        public Int32 DefaultClientID
        {
            get;
            set;
        }
        public Int32 App_ID
        {
            get;
            set;
        }

        public int TotalRecord
        {
            get;
            set;
        }


    }
}
