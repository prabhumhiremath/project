﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ApplicationDetailResponse
    {

        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public string ApplicationNM
        {
            get;
            set;
        }
        public string ApplicationAbbr
        {
            get;
            set;
        }

        public string ApplicationDeployPath
        {
            get;
            set;
        }

        public string AppExeName
        {
            get;
            set;
        }

        public string ApplicationType
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string App_Type
        {
            get;
            set;
        }

    }
}
