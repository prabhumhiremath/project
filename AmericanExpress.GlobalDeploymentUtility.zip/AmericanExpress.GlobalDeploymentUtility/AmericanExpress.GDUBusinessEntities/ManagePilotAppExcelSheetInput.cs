﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ManagePilotAppExcelSheetInput
    {
        public System.Data.DataTable DtExcelData
        {
            get;
            set;
        }
        public string XmlData
        {
            get;
            set;
        }
        public int AppId
        {
            get;
            set;
        }
        public string AppVersion
        {
            get;
            set;
        }
        public string CreatedUserId
        {
            get;
            set;
        }
        public string UploadType
        {
            get;
            set;
        }
        public int GroupID
        {
            get;
            set;
        }
    }
}
