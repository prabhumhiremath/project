﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ApplicationInput
    {
        public string ApplicationNM
        {
            get;
            set;
        }
        public string ApplicationAbbr
        {
            get;
            set;
        }

        public string App_ID
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string App_Type
        {
            get;
            set;
        }
    }
}
