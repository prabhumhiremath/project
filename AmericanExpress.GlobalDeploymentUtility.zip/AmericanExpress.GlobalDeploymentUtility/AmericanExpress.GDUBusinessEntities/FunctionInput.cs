﻿//-----------------------------------------------------------------------
// <copyright file="AccountInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountInput class which contains attributes for AccountInput.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;


namespace AmericanExpress.GDU.BusinessEntities
{

    /// <summary>
    /// 
    /// </summary>

    public class FunctionInput
    {
        #region Public Properties
        /// <summary>
        /// 
        /// </summary>

        public string FunctionType
        {
            get;
            set;
        }


        public Int32 ClientId
        {
            get;
            set;
        }


        public string RoleCode
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }

        #endregion
    }

}