﻿//-----------------------------------------------------------------------
// <copyright file="PilotAppUploadDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityDetails class which contains attributes for CityDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>17/10/2011</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

namespace AmericanExpress.GDU.BusinessEntities
{
   public class PilotAppUploadDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserName
        {
            get;
            set;
        }

        public string UserId
        {
            get;
            set;
        }

        public string MachineName
        {
            get;
            set;
        }
        public string IPAddress
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }
    }
}
