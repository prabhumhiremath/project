﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ManageApplicationDetails
    {
        public string ApplicationNM
        {
            get;
            set;
        }
        public string ApplicationAbbr
        {
            get;
            set;
        }

        public string ApplicationDeployPath
        {
            get;
            set;
        }

        public string AppExeName
        {
            get;
            set;
        }

        public string AppType
        {
            get;
            set;
        }

        public int AppId
        {
            get;
            set;

        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string App_Type
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }

    }
}
