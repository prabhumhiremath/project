﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class FocusAppDetails
    {

        public string App_Id
        {
            get;
            set;
        }

        public string App_DESC
        {
            get;
            set;
        }
        public int ID
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }


    }
}
