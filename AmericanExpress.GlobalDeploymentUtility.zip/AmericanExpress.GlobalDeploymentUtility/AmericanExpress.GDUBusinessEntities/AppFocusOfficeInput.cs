﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   
    public class AppFocusOfficeInput
    {
        public Int32 ID
        {
            get;
            set;
        }
        public string Office_ID
        {
            get;
            set;
        }
        public string Office_Desc
        {
            get;
            set;
        }

        public string User_ID
        {
            get;
            set;
        }
        public string Mode
        {
            get;
            set;
        }
        public bool IsActive
        {
            get;
            set;
        }
        public string IsReport
        {
            get;
            set;
        }

        public string STATUS
        {
            get;
            set;
        }
       
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
       
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
