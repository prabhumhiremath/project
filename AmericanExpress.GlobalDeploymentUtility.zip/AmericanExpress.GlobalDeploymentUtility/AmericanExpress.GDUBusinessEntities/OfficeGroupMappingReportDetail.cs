﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class OfficeGroupMappingReportDetail
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string GroupNM
        {
            get;
            set;
        }

        public string OfficeID
        {
            get;
            set;
        }

        public string ADSID
        {
            get;
            set;
        }

        public string USER_NM
        {
            get;
            set;
        }

        public string COMPUTER_NM
        {
            get;
            set;
        }

        public string IP_ADDR_TXT
        {
            get;
            set;
        }
        public int TotalRecords
        {
            get;
            set;
        }


    }
}
