﻿//-----------------------------------------------------------------------
// <copyright file="Constants.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class contains constant value for project</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>07/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;

namespace AmericanExpress.GWizAdmin.Utility
{
    public static class Constants
    {
        public static char SPLIT_CHAR = ';';
        public static string ROOT_NODE_NAME = "G-Wiz";
        public static string NODE_GENERAL_INFO = "GeneralInformation";
        public static string NODE_DESCRIPTION = "Description";
        public static string NODE_TL = "TL";
        public static string NODE_ORIGINATION = "Origination";
        public static string NODE_ORIGINSEGMENTS = "OriginSegments";
        public static string NODE_ORIGINSEGMENT = "OriginSegment";
        public static string NODE_DESTINATION = "Destination";
        public static string NODE_DESTINATIONSEGMENTS = "DestinationSegments";
        public static string NODE_DESTINATIONSEGMENT = "DestinationSegment";
        public static string RESULT_CAPTION_ORIGIN = "Search result for origination";
        public static string URL = "Url";
        public static string RESULT_CAPTION_DEST = "Search result for destination";
        public static string NODE_GENERALSEGMENT = "GeneralSegment";
        public static string RESULT_CAPTION_OTHER = "Search result for other info";
        public static string IMAGES = "Images";
        public static string IS_BROWSEABLE = "IsBrowseable";
        
    }
}
