﻿//-----------------------------------------------------------------------
// <copyright file="AjaxHandler.ashx" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This file handles the asynchronous calls.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.GDUAdmin
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Web.Services;
    using System.Web.Services.Protocols;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model;

    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class AjaxHandler : IHttpHandler
    {
        /// <summary>
        /// Entry point for the call.
        /// </summary>
        /// <param name="context">context</param>
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string stringData = string.Empty;

            switch (context.Request["w"])
            {
                case "User":
                    stringData = this.LoadUser(context.Request.QueryString["q"], context.Request.QueryString["max"]);
                    context.Response.Write(stringData);
                    break;

                case "UserList":
                    stringData = this.LoadUserList(context.Request.QueryString["q"], context.Request.QueryString["max"]);
                    context.Response.Write(stringData);
                    break;
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Fetch the user details.
        /// </summary>
        /// <param name="AccountName">user name</param>
        /// <param name="maxrecords">maximum records</param>
        /// <returns>stringBuilder</returns>
        protected string LoadUser(string clientName, string maxrecords)
        {
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            GDUModel gduModel = new GDUModel();
            objDictionary = gduModel.PopulateUserInfo(clientName, int.Parse(maxrecords), "GD");

            StringBuilder stringBuilder = new StringBuilder();
            foreach (KeyValuePair<string, string> kvp in objDictionary)
            {
                stringBuilder.AppendLine(kvp.Value.Trim() + "~" + kvp.Key);
            }
            return stringBuilder.ToString();
        }

        /// <summary>
        /// Fetch the user details on userlist.
        /// </summary>
        /// <param name="AccountName">user name</param>
        /// <param name="maxrecords">maximum records</param>
        /// <returns>stringBuilder</returns>
        protected string LoadUserList(string clientName, string maxrecords)
        {
            Dictionary<string, string> objDictionary = new Dictionary<string, string>();
            GDUModel gduModel = new GDUModel();
            objDictionary = gduModel.PopulateUserInfo(clientName, int.Parse(maxrecords), "GD");

            StringBuilder stringBuilder = new StringBuilder();

            foreach (KeyValuePair<string, string> kvp in objDictionary)
            {
                stringBuilder.AppendLine("<tr><td><input type='hidden' value='" + kvp.Key + "' />" + kvp.Value.Trim() + " </td><td> <input type='checkbox' id='chk'> </td></tr>");
            }
            return stringBuilder.ToString();
        }

    }
}
