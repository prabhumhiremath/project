﻿//-----------------------------------------------------------------------
// <copyright file="ManageUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Manages user creation/addition/deactivation</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU
{
    #region Page level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model;
    using System.Collections.Generic;
    using AmericanExpress.GDU.Utilities.Diagnostics;    

    #endregion

    /// <summary>
    /// Manage User Class
    /// </summary>
    public partial class ManageApplicationRole : System.Web.UI.Page
    {
        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        public string CurrentRole;
        public string CurrentRoles = null;
        public string AuthRole = null;
        public Dictionary<string, string> objDictonaryRole = new Dictionary<string, string>();
        #region "Events"
        /// <summary>
        /// Page Load event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            string UserName = string.Empty;
            string AppAbbrName = string.Empty;
            try
            {
                this.gduModel = new GDUModel();

                if (!Page.IsPostBack)
                {
                    //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);

                    //this.Populate_User(); 
                    this.PopulateDropdown();
                    //this.LoadClients();

                    btnDelete.Visible = false;
                    if (Request.QueryString[AdmConstants.MODE].ToString().ToUpper().Equals("ADD"))
                    {
                        ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ADD.ToString();
                        this.ShowHideButton(AdmConstants.CRUD_MODE.ADD);
                        //txtUserID.Enabled = true;
                        this.LoadApplication("Available", string.Empty, "ADD");
                    }
                    else
                    {
                        UserName = Request.QueryString["USERDTL"].ToString().Substring(0, Request.QueryString["USERDTL"].ToString().IndexOf("-"));
                        AppAbbrName = Request.QueryString["USERDTL"].ToString().Substring(Request.QueryString["USERDTL"].ToString().IndexOf("-"), (Request.QueryString["USERDTL"].ToString().Length - Request.QueryString["USERDTL"].ToString().IndexOf("-"))).Replace("-", "");
                        //UserName = UserName.Replace("_"," ");  

                        ViewState["USER_ID"] = UserName;
                        ViewState["AppName"] = AppAbbrName;

                        this.ShowHideButton(AdmConstants.CRUD_MODE.VIEW);
                        this.EnableDisableTextbox(false);
                        //txtUserID.Enabled = false;
                        this.PopulateControls(ViewState["USER_ID"].ToString());
                        this.LoadRolesOnEdit(Convert.ToString(ViewState["AppName"]), Convert.ToString(ViewState["USER_ID"]));
                        this.LoadApplication(Convert.ToString(ViewState["AppName"]), Convert.ToString(ViewState["USER_ID"]), null);

                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageUser_Page_Load));
                throw ex;
            }
        }

        /// <summary>
        /// Save button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Save_Click(object sender, EventArgs e)
        {
            try
            {
                string userName = null;
                string userCode = null;
                int App_ID = 0;
                string defaultClientAbbr = string.Empty;
                DateTime modifiedon = DateTime.MinValue;

                if (Session[AdmConstants.IS_DEACTIVE] != null)
                {
                    if (Session[AdmConstants.IS_DEACTIVE].Equals(true))
                    {
                        if (btnSave.Text == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                        {
                            this.ViewState[AdmConstants.MODE] = btnSave.Text;
                        }
                    }
                }

                //ViewState["USER_ID"] = ddlUser.SelectedItem.ToString();
                ViewState["USER_ID"] = hdnUser.Value.Split('-')[0].ToString();
                userCode = ViewState["USER_ID"].ToString();

                if (ViewState[AdmConstants.MODE] != null && (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.UPDATE.ToString() || (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.DEACTIVATE.ToString() || (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                {
                    userCode = ViewState["USER_ID"].ToString();
                    App_ID = Int32.Parse(ViewState["App_ID"].ToString());
                    modifiedon = Convert.ToDateTime(ViewState["MODIFIED_DT"]);
                }
                else
                {
                    modifiedon = DateTime.Now;
                }

                this.ManageAppUsers(ViewState[AdmConstants.MODE].ToString(), userCode, "DC", modifiedon, hdAuthorizedRolesIds.Value.ToString(), hdCurrentRoles.Value.ToString());
                Response.Redirect("SearchApplicationRole.aspx",false);
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageUser_Save_Click));
                string errmsg = ex.Message;
                lblMsgPanel.Text = errmsg;
            }
        }

        /// <summary>
        /// Delete button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Delete_Click(object sender, EventArgs e)
        {
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.DEACTIVATE.ToString();
            this.Save_Click(sender, e);
        }

        /// <summary>
        /// Modify button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Modify_Click(object sender, EventArgs e)
        {
            this.EnableDisableTextbox(false);
            this.ShowHideButton(AdmConstants.CRUD_MODE.UPDATE);
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.UPDATE.ToString();
        }

        #endregion

        #region "Methods"

        /// <summary>
        /// Enable/ disable textbox controls
        /// </summary>
        /// <param name="enableDisable">boolean parameter</param>
        private void EnableDisableTextbox(bool enableDisable)
        {


            ddlRoles.Enabled = enableDisable;
            txtUser.Enabled = enableDisable;
            //ddlUser.Enabled = enableDisable;
        }

        /// <summary>
        /// Show/hide button
        /// </summary>
        /// <param name="mode"> mode </param>
        private void ShowHideButton(AdmConstants.CRUD_MODE mode)
        {
            switch (mode)
            {
                case AdmConstants.CRUD_MODE.UPDATE:
                    {
                        btnSave.Visible = true;
                        btnSave.Text = AdmConstants.CRUD_MODE.UPDATE.ToString();
                        btnModify.Visible = false;
                        btnDelete.Visible = false;
                        btnAdd.Disabled = false;
                        btnAddAll.Disabled = false;
                        btnDel.Disabled = false;
                        btnDelAll.Disabled = false;
                        break;
                    }

                case AdmConstants.CRUD_MODE.ADD:
                    {
                        btnDelete.Visible = false;
                        btnModify.Visible = false;
                        break;
                    }

                case AdmConstants.CRUD_MODE.VIEW:
                    {
                        bool deactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                        if (deactive)
                        {
                            btnSave.Text = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                            btnDelete.Visible = false;
                            btnModify.Visible = false;
                            break;
                        }
                        else
                        {
                            btnSave.Visible = false;
                            btnAdd.Disabled = true;
                            btnAddAll.Disabled = true;
                            btnDel.Disabled = true;
                            btnDelAll.Disabled = true;
                            break;
                        }
                    }
            }
        }

        /// <summary>
        /// Add/edit/delete/activate 
        /// </summary>
        /// <param name="actionmode">action mode </param>
        /// <param name="userId">user ID</param>
        /// <param name="userName">user name</param>
        /// <param name="userEmail">user email</param>
        /// <param name="userLanguage">user language</param>
        /// <param name="userRole">user role</param>
        /// <param name="modifiedon">date and time of modification</param>
        /// <returns>return status</returns>
        private int ManageUsers(string actionmode, string userId, string userName, string userEmail, string userLanguage, string userRole, DateTime modifiedon, string authorizedRoleIds, int App_ID, string defaultClientAbbr, string CurrentRole, string System_CD)
        {
            int status = 0;
            //this.gwizModel.ManageUsers(actionmode, userId,  userName, userEmail,  userLanguage, userRole, modifiedon);
            this.gduModel.ManageUsers(actionmode, userId, userName, userEmail, userLanguage, userRole, modifiedon, authorizedRoleIds, App_ID, defaultClientAbbr, CurrentRole, System_CD);
            return status;

        }

        private int ManageAppUsers(string actionmode, string userId, string userRole, DateTime modifiedon, string authorizedRoleIds, string CurrentRole)
        {
            int status = 0;
            this.gduModel.ManageAppUsers(actionmode, userId, userRole, modifiedon, authorizedRoleIds, CurrentRole);
            return status;

        }

        /// <summary>
        /// Get country details on country id
        /// </summary>
        /// <param name="userId">user ID</param>
        /// <returns>return user details</returns>


        /// <summary>
        /// populate controls
        /// </summary>
        /// <param name="userCode">user code</param>
        private void PopulateControls(string userCode)
        {
            try
            {
                if (userCode != null)
                {
                    //foreach (ListItem item in ddlUser.Items)
                    //{
                    //    if (item.Value.Contains(userCode))
                    //    {
                    //        item.Selected = true;
                    //        break;
                    //    }
                    //}
                    txtUser.Text = Request.QueryString["USER"].ToString();
                    hdnUser.Value = Request.QueryString["USER"].ToString();
                    ViewState["MODIFIED_DT"] = DateTime.Now;
                    ddlRoles.SelectedIndex = 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// populate Dropdown
        /// </summary>
        private void PopulateDropdown()
        {
            this.gduModel = new GDUModel();
            //ddlLanguage.DataSource = this.gwizModel.PopulateLanguage();
            //ddlLanguage.DataTextField = AdmConstants.VALUE;
            //ddlLanguage.DataValueField = AdmConstants.KEY;
            //this.ddlLanguage.DataBind();
            //ddlLanguage.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
            //ddlRole.DataSource = this.gwizModel.PopulateRole();
            //ddlRole.DataTextField = AdmConstants.VALUE;
            //ddlRole.DataValueField = AdmConstants.KEY;
            //ddlRole.DataBind();
            //this.ddlRole.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
        }

        //private void Populate_User()
        //{
        //    Dictionary<string, string> objDictonary = new Dictionary<string, string>();
        //    objDictonary = gduModel.PopulateUsers(null, null, "N","GD");
        //    this.ddlUser.DataSource = objDictonary;
        //    ddlUser.DataValueField = AdmConstants.KEY;
        //    ddlUser.DataTextField = AdmConstants.VALUE;
        //    ddlUser.DataBind();
        //    ddlUser.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));
        //}

        /// <summary>
        /// cvlbAuthorizedRoles_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>

        protected void cvlbAuthorizedRoles_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = !string.IsNullOrEmpty(hdAuthorizedRolesIds.Value.ToString());
        }

        protected void LoadRolesOnEdit(string AppAbbrName, string userId)
        {
            try
            {
                int App_ID = 0;
                Dictionary<string, string> objDictonaryRole = new Dictionary<string, string>();
                objDictonaryRole = gduModel.PopulateApplicationInfo();
                foreach (KeyValuePair<string, string> keyPair in objDictonaryRole)
                {
                    if (keyPair.Value.ToString() == AppAbbrName)
                    {
                        App_ID = Int32.Parse(keyPair.Key.ToString().Substring(0, keyPair.Key.ToString().IndexOf("~"))); ;
                    }
                }

                ViewState["App_ID"] = App_ID;

                DataTable dtRoles = gduModel.GetAppUserDetails(userId, 0, false, "SearchAppUser", 0, 100, "App_Name", "ASC");
                lbAuthorizedApplications.DataTextField = dtRoles.Columns[1].ToString();
                lbAuthorizedApplications.DataValueField = dtRoles.Columns[0].ToString();
                lbAuthorizedApplications.DataSource = dtRoles;
                lbAuthorizedApplications.DataBind();
                if (lbAuthorizedApplications.Items[0].Value == string.Empty)
                    lbAuthorizedApplications.Items.Remove(lbAuthorizedApplications.Items[0]);
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageUser_LoadRolesOnEdit);
            }

        }

        protected void LoadApplication(string AppAbbrName, string userId, string Mode)
        {
            try
            {

                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = gduModel.PopulateApplicationInfo();
                DataTable dtAuthRoles = gduModel.GetAppUserDetails(userId, 0, false, "SearchAppUser", 0, 100, "App_Name", "ASC");
                DataView DV = new DataView(dtAuthRoles);
                DV.Sort = "AppName";
                DataTable dtRoles = new DataTable();
                dtRoles.Columns.Add("AppKey", Type.GetType("System.String"));
                dtRoles.Columns.Add("AppAbbrName", Type.GetType("System.String"));
                DataRow drApplicationInfo;
                foreach (KeyValuePair<string, string> keyPair in objDictonary)
                {
                    if (Mode != "ADD")
                    {
                        if (DV.Find(keyPair.Value) == -1)
                        {
                            drApplicationInfo = dtRoles.NewRow();
                            drApplicationInfo["AppKey"] = keyPair.Key;
                            drApplicationInfo["AppAbbrName"] = keyPair.Value;

                            dtRoles.Rows.Add(drApplicationInfo);
                        }
                    }
                    else
                    {
                        drApplicationInfo = dtRoles.NewRow();
                        drApplicationInfo["AppKey"] = keyPair.Key;
                        drApplicationInfo["AppAbbrName"] = keyPair.Value;

                        dtRoles.Rows.Add(drApplicationInfo);
                    }
                }

                if (dtRoles.Rows.Count == 0)
                {
                    drApplicationInfo = dtRoles.NewRow();
                    drApplicationInfo["AppKey"] = "";
                    drApplicationInfo["AppAbbrName"] = "";

                    dtRoles.Rows.Add(drApplicationInfo);
                }

                lbAvailableApplications.DataTextField = dtRoles.Columns[1].ToString();
                lbAvailableApplications.DataValueField = dtRoles.Columns[0].ToString();
                lbAvailableApplications.DataSource = dtRoles;
                lbAvailableApplications.DataBind();
                if (lbAvailableApplications.Items[0].Value == string.Empty)
                    lbAvailableApplications.Items.Remove(lbAvailableApplications.Items[0]);

            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageUser_LoadRoles);

            }

        }

        /// <summary>
        /// ShowHideButton
        /// </summary>
        /// <param name="mode">mode is add,update,view</param>
        private void ShowHideButton(string mode)
        {
            switch (mode)
            {
                case "Update":
                    btnSave.Visible = true;
                    btnSave.Text = "Update";
                    btnModify.Visible = false;
                    btnDelete.Visible = false;
                    btnAdd.Disabled = false;
                    btnAddAll.Disabled = false;
                    btnDel.Disabled = false;
                    btnDelAll.Disabled = false;
                    break;
                case "Add":
                    btnDelete.Visible = false;
                    btnModify.Visible = false;
                    break;
                case "View":
                    btnAdd.Disabled = true;
                    btnAddAll.Disabled = true;
                    btnDel.Disabled = true;
                    btnDelAll.Disabled = true;
                    btnSave.Visible = false;
                    break;
            }
        }

        protected void ddlRoles_SelectedIndexChanged(object sender, EventArgs e)
        {
            string UserID = string.Empty;
            //UserID = ddlUser.SelectedValue.ToString();
            if (hdnUser.Value != "")
                UserID = hdnUser.Value.Split('-')[0].ToString();
            else
                UserID = "SELECT ALL";
            this.LoadRolesOnEdit("", UserID);
            this.LoadApplication("", UserID, null);
            if (lbAuthorizedApplications.Items.Count > 0)
            {
                btnAdd.Disabled = true;
                btnAddAll.Disabled = true;
                btnDel.Disabled = true;
                btnDelAll.Disabled = true;
                btnSave.Visible = false;
            }


        }

        protected void ddlUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlRoles.SelectedIndex = 0;
            this.LoadApplication("Available", string.Empty, "ADD");
            lbAuthorizedApplications.Items.Clear();
            btnAdd.Disabled = false;
            btnAddAll.Disabled = false;
            btnDel.Disabled = false;
            btnDelAll.Disabled = false;
            btnSave.Visible = true;
        }

        //protected void LoadClients()
        //{
        //    try
        //    {


        //        Dictionary<string, string> objDictonary = new Dictionary<string, string>();
        //        objDictonary = gwizModel.PopulateClientInfo(null, 0);
        //        this.ddlClient.DataSource = objDictonary;
        //        ddlClient.DataValueField = AdmConstants.KEY;
        //        ddlClient.DataTextField = AdmConstants.VALUE;
        //        ddlClient.DataBind();
        //        //this.ddlClient.Items.Insert(0, new ListItem("All", "0-All"));
        //        ddlClient.Items.Insert(0, "Select Client");
        //    }
        //    catch (Exception ex)
        //    {
        //        //throw Common.HandleException(ex, Common.MethodName.ManageRole_LoadSystem);
        //    }
        //}


        #endregion
    }
}
