﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using AmericanExpress.GDU;
using System.Threading;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class TravelSuiteFocusReport : System.Web.UI.Page
    {
        GDUModel _gduModal;
        DataTable _dtDataTable;
        DataTable _dtDataTableDetails;

        const string LABEL = "UserName";
        public string strUserName = string.Empty;
        public string strVersion = string.Empty;
        protected string HdnUserIds = string.Empty;

        protected int currentPage, pageSize, startRecord;
        int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"].ToString());

        protected int detailcurrentPage, detailpageSize, detailstartRecord;
        int detailPageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultDetailPageSize"].ToString());

        protected void Page_Load(object sender, EventArgs e)
        {
            //ddlOfficeID.Attributes.Add("onchange", "ValidateOfficeGroup();");
            try
            {
                _gduModal = new GDUModel();
                _dtDataTable = new DataTable();
                _dtDataTableDetails = new DataTable();

                if (!IsPostBack)
                {
                    PopulateOfficeGroups();
                    // BindFocusReportApplicationName();
                    BindFocusReportOfficeID();
                    // btnExport.Visible = false;
                    hiddenOfficeId.Value = "0";
                    ViewState["detailSortExp"] = "APP_FOCUS_STARTDATE";
                    ViewState["detailSortOrder"] = "DESC";
                }


                //Colapsble
                //searchBoxDiv.Style.Add("display", searchBoxDivStatus.Value);
                //if (resultBoxHd.Visible == "none")
                //{
                //    searchBox.Src = "../images/plus.gif";
                //resultBoxHd.Attributes.Add("class", "closed");
                //}
                //else
                //{
                //    searchBox.Src = "../images/minus.gif";
                //    searchBoxHd.Attributes.Add("class", "");
                //}
                //EndColapsble

            }
            catch (Exception ex)
            {
            }
        }
        /// <summary>
        /// populate virtual country
        /// </summary>
        private void PopulateOfficeGroups()
        {
            _gduModal = new GDUModel();
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict = _gduModal.PopulateAppFGroup(string.Empty, 0, "Virtual");
            ddlAPPFOfficeGroup.DataSource = dict;
            ddlAPPFOfficeGroup.DataTextField = "Value";
            ddlAPPFOfficeGroup.DataValueField = "Key";
            this.ddlAPPFOfficeGroup.DataBind();
            this.ddlAPPFOfficeGroup.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "0"));
        }

        protected void ddlAPPFOfficeGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

            BindFocusReportOfficeID();
            ClearControls();

            if (ddlAPPFOfficeGroup.SelectedIndex == 0)
            {
                ddlOfficeID.SelectedIndex = 0;
                txtUser.ReadOnly = false;
            }
            else
            {

                ddlOfficeID.SelectedIndex = 0;
                txtUser.ReadOnly = true;
            }


        }
        private void ClearControls()
        {
            txtUser.Text = "";

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //===========================
                ViewState["SortExp"] = LABEL;
                ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                ////===========================
                CurrentPage = 0;
                BindGrid();

            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Search_Click));

            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {

            ddlApplication.SelectedIndex = 0;
            ddlAPPFOfficeGroup.SelectedIndex = 0;
            BindFocusReportOfficeID();
            txtUser.Text = "";
            hdnUser.Value = "";
            ddlOfficeID.SelectedIndex = 0;
            txtDateFrom.Text = string.Empty;
            txtDateTo.Text = string.Empty;

            grdAppFocusReport.DataSource = null;
            grdAppFocusReport.EmptyDataText = "";
            grdAppFocusReport.DataBind();
            // btnExport.Visible = false;
            btnExport.Style.Add("display", "none");
            lblRecordCount.Text = "";
            PagingRow.Style.Add("display", "none");
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt;
            try
            {
                dt = new DataTable();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                string App_Name = string.Empty;
                string Office_Id = string.Empty;
                int Office_GroupId;

                if (hdnUser.Value == "" || hdnUser.Value == null)
                    strUserName = null;
                else
                    strUserName = hdnUser.Value.Split('-')[0].ToString();

                if (ddlApplication.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    App_Name = null;
                else
                    App_Name = ddlApplication.SelectedValue.ToString();

                //if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                //    Office_Id = null;
                //else
                //    Office_Id = ddlOfficeID.SelectedValue.ToString();

                if (hiddenOfficeId.Value == "1")
                {
                    Office_GroupId = 0;
                    if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                        Office_Id = null;
                    else
                        Office_Id = ddlOfficeID.SelectedValue.ToString();
                }
                else
                {
                    Office_Id = "0";
                    Office_GroupId = Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue.ToString());
                }

                if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
                {
                    fromDate = txtDateFrom.Text.Trim();
                }

                if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
                {
                    toDate = txtDateTo.Text.Trim();
                }
                else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
                {
                    toDate = System.DateTime.Now.ToShortDateString();
                }
                dt = _gduModal.GetTravelSuiteAppFocusReportTableEXPORT(strUserName, App_Name, fromDate, toDate, Office_Id, Office_GroupId, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());

                Response.Clear();
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=TravelSuiteFocusReport.xls");
                Response.BufferOutput = true;
                Response.ContentEncoding = System.Text.Encoding.UTF8;
                Response.Charset = "";
                EnableViewState = false;
                StringWriter strWriter = new StringWriter();
                Html32TextWriter htmlWriter = new Html32TextWriter(strWriter);
                dt.Columns["APP_NM"].ColumnName = "AppName";
                dt.Columns["OFFICE_ID"].ColumnName = "OfficeId";
                dt.Columns["IP_ADDR_TXT"].ColumnName = "IpAddress";
                dt.Columns["ActiveDeactiveTime"].ColumnName = "UsageDate";
                dt.Columns["APP_ENDDATE"].ColumnName = "ToDate";
                dt.Columns["TOTAL_USAGE_TIME"].ColumnName = "TotalUsage";
                grdAppFocusReport.DataSource = dt.DefaultView;
                grdAppFocusReport.DataBind();
                this.ClearControls(grdAppFocusReport);
                grdAppFocusReport.RenderControl(htmlWriter);
                Response.Write(strWriter.ToString());
                Response.Flush();
                Response.End();
                //HttpContext.Current.ApplicationInstance.CompleteRequest();
                BindGrid();
            }
            catch (ThreadAbortException tex)
            {
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Export_Click));
            }
            finally
            {
                dt = null;
            }
        }

        private void ClearControls(Control control)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                ClearControls(control.Controls[i]);
            }
            if (!(control is TableCell))
            {
                if (control.GetType().GetProperty("SelectedItem") != null)
                {
                    LiteralControl literal = new LiteralControl();
                    control.Parent.Controls.Add(literal);
                    try
                    {
                        literal.Text = (string)control.GetType().GetProperty("SelectedItem").GetValue(control, null);
                    }
                    catch
                    {
                    }
                    control.Parent.Controls.Remove(control);
                }
                else
                    if (control.GetType().GetProperty("Text") != null)
                    {
                        LiteralControl literal = new LiteralControl();
                        control.Parent.Controls.Add(literal);
                        literal.Text = (string)control.GetType().GetProperty("Text").GetValue(control, null);
                        control.Parent.Controls.Remove(control);
                    }
            }
            return;
        }

        public override void VerifyRenderingInServerForm(Control control) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="allowPaging"></param>
        private void BindGrid()
        {
            string fromDate = string.Empty;
            string toDate = string.Empty;
            string App_Name = string.Empty;
            string Office_Id = string.Empty;
            int Office_GroupId;

            if (hdnUser.Value == "" || hdnUser.Value == null)
                strUserName = null;
            else
                strUserName = hdnUser.Value.Split('-')[0].ToString();

            if (ddlApplication.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                App_Name = null;
            else
                App_Name = ddlApplication.SelectedValue.ToString();

            //if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
            //    Office_Id = null;
            //else
            //    Office_Id = ddlOfficeID.SelectedValue.ToString();

            if (hiddenOfficeId.Value == "1")
            {
                Office_GroupId = 0;
                if (ddlOfficeID.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    Office_Id = null;
                else
                    Office_Id = ddlOfficeID.SelectedValue.ToString();
            }
            else
            {
                Office_Id = "0";
                Office_GroupId = Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue.ToString());
            }

            if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                fromDate = txtDateFrom.Text.Trim();
            }

            if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
            {
                toDate = txtDateTo.Text.Trim();
            }
            else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                toDate = System.DateTime.Now.ToShortDateString();
            }

            try
            {
                _dtDataTable = _gduModal.GetTravelSuiteAppFocusReportTable(strUserName, App_Name, fromDate, toDate, Office_Id, Office_GroupId, CurrentPage, PageSize, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());

                if (_dtDataTable.Rows.Count > 0)
                {
                    //lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows.Count.ToString();                   
                    //btnExport.Style.Add("display", "block");
                    grdAppFocusReport.DataSource = _dtDataTable;
                    grdAppFocusReport.DataBind();
                    lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows[0]["TotalRecord"].ToString();
                    if (int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) % PageSize > 0)
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) / PageSize);
                    }
                    else
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) / PageSize) - 1;
                    }
                    //ShowTotalNumberOfRecords();
                    ShowPageNumbers();
                    ShowPagingLinks();
                    //PagingRow.Visible = true;
                    PagingRow.Style.Add("display", "block");

                    // btnExport.Visible = true;
                    btnExport.Style.Add("display", "block");
                }
                else
                {
                    //lblRecordCount.Text = "Total Records: 0";                   
                    //btnExport.Style.Add("display", "none");
                    lblRecordCount.Text = "Total Records: 0";
                    grdAppFocusReport.DataSource = null;
                    grdAppFocusReport.DataBind();
                    CurrentPage = 0;
                    ViewState["CurrentPage"] = null;
                    //PagingRow.Visible = false;
                    PagingRow.Style.Add("display", "none");

                    //btnExport.Visible = false;
                    btnExport.Style.Add("display", "none");
                }

                //DataRow[] dtRow = _dtDataTable.Select("Version <> ''");
                // BindingGridControl(allowPaging);
            }
            catch (Exception ex)
            {
                Label lbl = (Label)Master.FindControl("lblMsgPanel");
                string errmsg = ex.Message;
                lbl.Text = errmsg;
            }

            //Show the visibility   
            this.pnlReport.Visible = true;
            this.pnlButtonRow.Visible = true;


        }

        /// <summary>
        /// binding repeater control.
        /// </summary>
        private void BindingGridControl(bool allowPaging)
        {
            grdAppFocusReport.EmptyDataText = "There is no record.";
            DataView dvSearch = new DataView();
            dvSearch = _dtDataTable.DefaultView;

            if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(""))
            {
                dvSearch.Sort = this.ViewState["SortExp"].ToString()
                         + " " + this.ViewState["SortOrder"].ToString();
            }

            grdAppFocusReport.AllowPaging = allowPaging;
            if (allowPaging)
            {
                grdAppFocusReport.PageSize = 20;
            }

            grdAppFocusReport.DataSource = dvSearch;
            grdAppFocusReport.DataBind();
        }

        protected void grdAppFocusReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAppFocusReport.PageIndex = e.NewPageIndex;
            BindGrid();

        }

        protected void grdAppFocusReport_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                CurrentPage = 0;
                ViewState["CurrentPage"] = null;
                if (this.GridViewSortDirection == SortDirection.Ascending)
                {
                    this.GridViewSortDirection = SortDirection.Descending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
                }
                else
                {
                    this.GridViewSortDirection = SortDirection.Ascending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                }
                grdAppFocusReport.PageIndex = 0;
                ViewState["SortExp"] = e.SortExpression;
                BindGrid();
            }
            catch (Exception ex)
            {

            }
        }

        protected void grdAppFocusReport_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataRowView drv = null;
            drv = (DataRowView)e.Row.DataItem;
            try
            {
                //if (e.Row.RowType == DataControlRowType.DataRow | e.Row.RowType == DataControlRowType.Header)
                //{
                //    e.Row.Cells[2].Attributes.Add("class", "last");
                //    e.Row.Cells[0].Attributes.Add("class", "first");
                //    //e.Row.Cells[5].Style.Add("word-break", "break-all");
                //    //e.Row.Cells[5].Width = 100;
                //    //e.Row.Cells[6].Style.Add("word-break", "break-all");
                //    //e.Row.Cells[6].Width = 100;
                //}
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (this.ViewState["SortExp"] == null)
                        this.ViewState["SortExp"] = "";

                    int sortColumnIndex = GetSortColumnIndex(grdAppFocusReport, this.ViewState["SortExp"].ToString());
                    AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_grid_RowDataBound));

            }
        }

        /// <summary>
        /// GridViewSortDirection
        /// </summary>
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;
                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }

        /// <summary>
        /// This is used to retrieve sorted column index no.
        /// </summary>
        /// <param name="gridObject">This is the grid view object.</param>
        /// <param name="sortExpression">This is the sort expression.</param>
        /// <returns>int</returns>
        public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        {
            string sortExpressionString = null;
            foreach (DataControlField field in gridObject.Columns)
            {
                if (sortExpression != "")
                    sortExpressionString = sortExpression.ToString();

                if (field.SortExpression == sortExpressionString)
                {
                    return gridObject.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        /// <summary>
        /// This will set the Up/Down image for sorted column.
        /// </summary>
        /// <param name="columnIndex">This is the column index.</param>
        /// <param name="headerRow">This is the grid view header row.</param>
        /// <param name="strgrdSortDirection">This is the sort direction.</param>
        public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        {
            if (columnIndex == -1) return;
            if (strgrdSortDirection == SortDirection.Ascending)
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
            else
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
        }


        protected void lnkAppFocusReport_Click(object sender, EventArgs e)
        {
            detailCurrentPage = 0;
            ViewState["detailCurrentPage"] = null;
            // Fetch the Record ID            
            LinkButton btndetails = sender as LinkButton;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            grdAppFocusReportDetails.PageIndex = 0;
            ViewState["ADSID"] = null;
            ViewState["UsageDate"] = null;
            ViewState["GroupSeqNo"] = grdAppFocusReport.DataKeys[gvrow.RowIndex].Value.ToString();
            _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(grdAppFocusReport.DataKeys[gvrow.RowIndex].Value.ToString(), "TRAVELSUITE", detailCurrentPage, detailPageSize, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());
            if (_dtDataTableDetails.Rows.Count > 0)
            {
                //lblRecDetailCount.Text = "Total Records : " + _dtDataTableDetails.Rows.Count.ToString();
                //grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
                //grdAppFocusReportDetails.DataBind();

                grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
                grdAppFocusReportDetails.DataBind();
                lblRecDetailCount.Text = "Total Records: " + _dtDataTableDetails.Rows[0]["TotalRecord"].ToString();
                if (int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) % detailPageSize > 0)
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize);
                }
                else
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize) - 1;
                }

                detailShowPageNumbers();
                detailShowPagingLinks();
                detailPagingRow.Style.Add("display", "block");
                btnExportReportDetail.Style.Add("display", "block");

            }
            else
            {
                //grdAppFocusReportDetails.DataSource = null;
                //grdAppFocusReportDetails.DataBind();

                detailCurrentPage = 0;
                ViewState["detailCurrentPage"] = null;
                grdAppFocusReportDetails.DataSource = null;
                grdAppFocusReportDetails.DataBind();
                detailPagingRow.Style.Add("display", "none");
                btnExportReportDetail.Style.Add("display", "none");
            }

            mpeFocusReportDetail.Show();
        }

        protected void lnkUserFocusReport_Click(object sender, EventArgs e)
        {
            LinkButton btndetails = sender as LinkButton;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            grdAppFocusReportDetails.PageIndex = 0;
            ViewState["GroupSeqNo"] = null;
            ViewState["ADSID"] = btndetails.CommandArgument.ToString();
            ViewState["UsageDate"] = gvrow.Cells[6].Text.ToString();

            _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(btndetails.CommandArgument.ToString(), gvrow.Cells[6].Text.ToString(), "TRAVELSUITE", detailCurrentPage, detailPageSize, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());

            if (_dtDataTableDetails.Rows.Count > 0)
            {
                //lblRecDetailCount.Text = "Total Records : " + _dtDataTableDetails.Rows.Count.ToString();
                //grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
                //grdAppFocusReportDetails.DataBind();

                grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
                grdAppFocusReportDetails.DataBind();
                lblRecDetailCount.Text = "Total Records: " + _dtDataTableDetails.Rows[0]["TotalRecord"].ToString();
                if (int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) % detailPageSize > 0)
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize);
                }
                else
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize) - 1;
                }

                detailShowPageNumbers();
                detailShowPagingLinks();
                detailPagingRow.Style.Add("display", "block");
                btnExportReportDetail.Style.Add("display", "block");

            }
            else
            {
                //grdAppFocusReportDetails.DataSource = null;
                //grdAppFocusReportDetails.DataBind();
                detailCurrentPage = 0;
                ViewState["detailCurrentPage"] = null;
                grdAppFocusReportDetails.DataSource = null;
                grdAppFocusReportDetails.DataBind();
                detailPagingRow.Style.Add("display", "none");
                btnExportReportDetail.Style.Add("display", "none");
            }

            mpeFocusReportDetail.Show();
        }

        private void BindFocusReportApplicationName()
        {
            try
            {
                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = _gduModal.PopulateFocusReportApplicationName();
                this.ddlApplication.DataSource = objDictonary;
                ddlApplication.DataValueField = AdmConstants.KEY;
                ddlApplication.DataTextField = AdmConstants.VALUE;
                ddlApplication.DataBind();
                ddlApplication.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));


            }
            catch (Exception ex)
            {
            }
        }

        private void BindFocusReportOfficeID()
        {
            try
            {

                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                //objDictonary = _gduModal.PopulateFocusReportOfficeID(Convert.ToInt32(ddlAPPFOfficeGroup.SelectedValue));
                objDictonary = _gduModal.PopulateFocusReportOfficeID(Convert.ToInt32("0"));
                this.ddlOfficeID.DataSource = objDictonary;
                ddlOfficeID.DataValueField = AdmConstants.KEY;
                ddlOfficeID.DataTextField = AdmConstants.VALUE;
                ddlOfficeID.DataBind();
                ddlOfficeID.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));

                //_gduModal = new GDUModel();
                //Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                //objDictonary = _gduModal.PopulateFocusReportOfficeID();
                //this.ddlOfficeID.DataSource = objDictonary;
                //ddlOfficeID.DataValueField = AdmConstants.KEY;
                //ddlOfficeID.DataTextField = AdmConstants.VALUE;
                //ddlOfficeID.DataBind();
                //ddlOfficeID.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));
            }
            catch (Exception ex)
            {
            }
        }

        protected void grdAppFocusReportDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            //grdAppFocusReportDetails.PageIndex = e.NewPageIndex;

            //if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
            //    _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE");
            //else
            //    _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE");

            //if (_dtDataTableDetails.Rows.Count > 0)
            //{
            //    grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
            //    grdAppFocusReportDetails.DataBind();
            //}
            //else
            //{
            //    grdAppFocusReportDetails.DataSource = null;
            //    grdAppFocusReportDetails.DataBind();
            //}
            //mpeFocusReportDetail.Show();
        }

        protected void btnExportReportDetail_Click(object sender, EventArgs e)
        {
            DataTable dt;
            try
            {
                dt = new DataTable();
                if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
                    dt = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE", 0, 5000, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());
                else
                    dt = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE", 0, 5000, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());

                if (dt.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", "attachment;filename=TravelSuiteAppFocusDetailedReport.xls");
                    Response.BufferOutput = true;
                    Response.ContentEncoding = System.Text.Encoding.UTF8;
                    Response.Charset = "";
                    EnableViewState = false;
                    StringWriter strWriter = new StringWriter();
                    Html32TextWriter htmlWriter = new Html32TextWriter(strWriter);
                    grdAppFocusReportDetails.DataSource = dt.DefaultView;
                    grdAppFocusReportDetails.DataBind();
                    this.ClearControls(grdAppFocusReportDetails);
                    grdAppFocusReportDetails.RenderControl(htmlWriter);
                    Response.Write(strWriter.ToString());
                    Response.Flush();
                    Response.End();
                    //HttpContext.Current.ApplicationInstance.CompleteRequest();
                    BindAppReportDetail();
                }
            }
            catch (ThreadAbortException tex)
            {
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Export_Click));
            }
            finally
            {
                dt = null;
            }
        }

        //protected void BindAppFocusDetailedReport(bool Paging)
        //{
        //    try
        //    {
        //        if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
        //            _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE");
        //        else
        //            _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE");

        //        //_dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString());
        //        grdAppFocusReportDetails.AllowPaging = Paging;
        //        if (_dtDataTableDetails.Rows.Count > 0)
        //        {
        //            grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
        //            grdAppFocusReportDetails.DataBind();
        //        }
        //        else
        //        {
        //            grdAppFocusReportDetails.DataSource = null;
        //            grdAppFocusReportDetails.DataBind();
        //        }
        //        mpeFocusReportDetail.Show();
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        protected void ddlOfficeID_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateOfficeGroups();
            ddlAPPFOfficeGroup.SelectedIndex = 0;
        }

        public int CurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object current = this.ViewState["CurrentPage"];
                if (current == null)
                    return 0; // default page index of 0 
                else
                    return (int)current;
            }
            set
            {
                this.ViewState["CurrentPage"] = value;
            }
        }
        protected void LinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage = 0;
            BindGrid();
        }
        protected void LinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            CurrentPage -= 1;
            BindGrid();
        }
        protected void LinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage += 1;
            BindGrid();
        }
        protected void LinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            CurrentPage = int.Parse(ViewState["TotalPages"].ToString());
            BindGrid();
        }
        //To show total page numbers 
        //private void ShowTotalNumberOfRecords()
        //{
        //    int i, j;
        //    if (CurrentPage == 0)
        //        i = 1;
        //    else
        //        i = (CurrentPage * PageSize) + 1;
        //    LabelPageFirstRecord.Text = i.ToString();
        //    if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
        //        LabelPageLastRecord.Text = LabelTotalRecords.Text;
        //    else
        //    {
        //        j = ((CurrentPage + 1) * PageSize);
        //        LabelPageLastRecord.Text = j.ToString();
        //    }
        //}
        //To show current page number 
        private void ShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (CurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (CurrentPage > (int.Parse(ViewState["TotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["TotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["TotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = CurrentPage - 1;
                endPageNumber = CurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (CurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["TotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            CurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindGrid();
        }
        private void ShowPagingLinks()
        {
            if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
            {
                LinkButtonNext.Enabled = false;
                LinkButtonLast.Enabled = false;
            }
            else
            {
                LinkButtonNext.Enabled = true;
                LinkButtonLast.Enabled = true;
            }
            if (CurrentPage == 0)
            {
                LinkButtonPrevious.Enabled = false;
                LinkButtonFirst.Enabled = false;
            }
            else
            {
                LinkButtonPrevious.Enabled = true;
                LinkButtonFirst.Enabled = true;
            }
        }

        //for detail report
        public int detailCurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object detailcurrent = this.ViewState["detailCurrentPage"];
                if (detailcurrent == null)
                    return 0; // default page index of 0 
                else
                    return (int)detailcurrent;
            }
            set
            {
                this.ViewState["detailCurrentPage"] = value;
            }
        }
        protected void detailLinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            detailCurrentPage = 0;
            BindAppReportDetail();
        }
        protected void detailLinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            detailCurrentPage -= 1;
            BindAppReportDetail();
        }
        protected void detailLinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            detailCurrentPage += 1;
            BindAppReportDetail();
        }
        protected void detailLinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            detailCurrentPage = int.Parse(ViewState["detailTotalPages"].ToString());
            BindAppReportDetail();
        }
        private void detailShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (detailCurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (detailCurrentPage > (int.Parse(ViewState["detailTotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["detailTotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["detailTotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = detailCurrentPage - 1;
                endPageNumber = detailCurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(detailtdPageNumbers.FindControl("detailLinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(detailtdPageNumbers.FindControl("detailLinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (detailCurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["detailTotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void detailLinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            detailCurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindAppReportDetail();
        }
        private void detailShowPagingLinks()
        {
            if (detailCurrentPage == int.Parse(ViewState["detailTotalPages"].ToString()))
            {
                detailLinkButtonNext.Enabled = false;
                detailLinkButtonLast.Enabled = false;
            }
            else
            {
                detailLinkButtonNext.Enabled = true;
                detailLinkButtonLast.Enabled = true;
            }
            if (detailCurrentPage == 0)
            {
                detailLinkButtonPrevious.Enabled = false;
                detailLinkButtonFirst.Enabled = false;
            }
            else
            {
                detailLinkButtonPrevious.Enabled = true;
                detailLinkButtonFirst.Enabled = true;
            }
        }

        private void BindAppReportDetail()
        {
            if (!string.IsNullOrEmpty(Convert.ToString(ViewState["ADSID"])) && !string.IsNullOrEmpty(Convert.ToString(ViewState["UsageDate"])))
                _dtDataTableDetails = _gduModal.GetAppUserFocusReportTableDetails(Convert.ToString(ViewState["ADSID"]), Convert.ToString(ViewState["UsageDate"]), "TRAVELSUITE", detailCurrentPage, detailPageSize, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());
            else
                _dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString(), "TRAVELSUITE", detailCurrentPage, detailPageSize, ViewState["detailSortExp"].ToString(), ViewState["detailSortOrder"].ToString());

            //_dtDataTableDetails = _gduModal.GetAppFocusReportTableDetails(ViewState["GroupSeqNo"].ToString());
            if (_dtDataTableDetails.Rows.Count > 0)
            {
                grdAppFocusReportDetails.DataSource = _dtDataTableDetails;
                grdAppFocusReportDetails.DataBind();

                lblRecDetailCount.Text = "Total Records: " + _dtDataTableDetails.Rows[0]["TotalRecord"].ToString();
                if (int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) % detailPageSize > 0)
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize);
                }
                else
                {
                    ViewState["detailTotalPages"] = Convert.ToInt32(int.Parse(_dtDataTableDetails.Rows[0]["TotalRecord"].ToString()) / detailPageSize) - 1;
                }

                detailShowPageNumbers();
                detailShowPagingLinks();
            }
            else
            {
                grdAppFocusReportDetails.DataSource = null;
                grdAppFocusReportDetails.DataBind();
            }
            mpeFocusReportDetail.Show();
        }
    }
}

