﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using AmericanExpress.GDU;
using System.Diagnostics;
using System.Text;
using System.Net;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class ApplicationToInstall : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GDUModel gduModel = new GDUModel();
            //string User_Id = string.Empty;
            //User_Id = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);

            //DataTable searchAppUser = gduModel.GetAppUserDetails(User_Id, 0, false, "SearchAppUser");
            //DataView DV = new DataView(searchAppUser);
            //DV.Sort = "AppName";

            //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
            //    Response.Redirect("NotAuthorized.aspx", false);

            if (!object.Equals(Session["AppToInstall"], null))
            {

                Dictionary<string, string> dictAppToUpload = new Dictionary<string, string>();
                dictAppToUpload = (Dictionary<string, string>)Session["AppToInstall"];


                if (!object.Equals(dictAppToUpload, null))
                {
                    foreach (KeyValuePair<string, string> pair in dictAppToUpload)
                    {
                        try
                        {
                            //if (DV.Find(pair.Value) != -1)
                            //{
                            HtmlAnchor htmlanchor = new HtmlAnchor();
                            htmlanchor.HRef = pair.Key + ".exe";
                            htmlanchor.Title = "Click to Install " + pair.Value;
                            htmlanchor.InnerText = "Click here to Install " + pair.Value;
                            pnlContainer.Controls.Add(htmlanchor);
                            pnlContainer.Controls.Add(new LiteralControl("<br>"));
                            pnlContainer.Controls.Add(new LiteralControl("<br>"));
                            //}
                            //else
                            //{
                            //    HtmlAnchor htmlanchor = new HtmlAnchor();
                            //    htmlanchor.Title = "Click to Install " + pair.Value + " (Not Authorised for this Application)";
                            //    htmlanchor.InnerText = "Click here to Install " + pair.Value + " (Not Authorised for this Application)";
                            //    htmlanchor.Attributes.Add("style", "color:red");
                            //    pnlContainer.Controls.Add(htmlanchor);
                            //    pnlContainer.Controls.Add(new LiteralControl("<br>"));
                            //    pnlContainer.Controls.Add(new LiteralControl("<br>"));
                            //}

                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
        }
    }
}
