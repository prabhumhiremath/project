﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AmericanExpress.GDU
{
    #region Page level Namespace
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    using System.Configuration;
    #endregion

    public partial class SearchClient : System.Web.UI.Page
    {
        public const string ACCOUNT_NAME = "App_Name";

        private GDUModel _gduModel;

        protected int currentPage, pageSize, startRecord;
        int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"].ToString());

        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {
                txtApplicationAbbr.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                txtApplicationNM.Attributes.Add("onkeypress", "javascript:return RestrictChar()");


                if (!IsPostBack)
                {
                    if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                       Response.Redirect("NotAuthorized.aspx", false);

                    this._gduModel = new GDUModel();
                    btnApplicationView.Visible = false;
                }
                else
                {
                    searchBoxDiv.Style.Add("display", searchBoxDivStatus.Value);

                    if (searchBoxDivStatus.Value == "none")
                    {
                        searchBox.Src = "../images/plus.gif";
                        searchBoxHd.Attributes.Add("class", "closed");
                    }
                    else
                    {
                        searchBox.Src = "../images/minus.gif";
                        searchBoxHd.Attributes.Add("class", string.Empty);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchClient_Page_Load));
                throw ex;
            }
        }



        protected void btnAddApplication_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageApplication.aspx?MODE=ADD");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                ////===========================
                ViewState["SortExp"] = ACCOUNT_NAME;
                ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                ////===========================
                //grdApplication.PageIndex = 0;
                CurrentPage = 0;
                this.BindGridData();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchClient_Search_Claick));
            }
        }

        protected void BindGridData()
        {

            this._gduModel = new GDUModel();
            string ApplicationNM = null;
            string ApplicationAbbr = null;
            string AppId = null;

            bool isDeactive;
            try
            {
                ApplicationNM = string.IsNullOrEmpty(txtApplicationNM.Text.Trim()) ? null : txtApplicationNM.Text.Trim();
                ApplicationAbbr = string.IsNullOrEmpty(txtApplicationAbbr.Text.Trim()) ? null : txtApplicationAbbr.Text.Trim();

                isDeactive = chkDeactivated.Checked;
                Session[AdmConstants.IS_DEACTIVE] = isDeactive;
                DataTable searchAcc = this._gduModel.GetApplicationDetails(ApplicationNM, AppId, ApplicationAbbr, isDeactive, CurrentPage, PageSize, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());
                DataView search = new DataView();
                if (searchAcc.Rows.Count > 0)
                {
                    //lblRecordCount.Text = "Total Records: " + searchAcc.Rows.Count.ToString();
                    //search = searchAcc.DefaultView;
                    //if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(string.Empty))
                    //{
                    //    search.Sort = this.ViewState["SortExp"].ToString()
                    //             + " " + this.ViewState["SortOrder"].ToString();
                    //}

                    //lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows.Count.ToString();
                    grdApplication.DataSource = searchAcc;
                    grdApplication.DataBind();
                    lblRecordCount.Text = "Total Records: " + searchAcc.Rows[0]["TotalRecord"].ToString();
                    if (int.Parse(searchAcc.Rows[0]["TotalRecord"].ToString()) % PageSize > 0)
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(searchAcc.Rows[0]["TotalRecord"].ToString()) / PageSize);
                    }
                    else
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(searchAcc.Rows[0]["TotalRecord"].ToString()) / PageSize) - 1;
                    }
                    //ShowTotalNumberOfRecords();
                    ShowPageNumbers();
                    ShowPagingLinks();
                    //PagingRow.Visible = true;
                    PagingRow.Style.Add("display", "block");
                    this.btnAddApplication.Visible = true;
                    this.btnApplicationView.Visible = true;
                }
                else
                {
                    //lblRecordCount.Text = "Total Records: 0";
                    lblRecordCount.Text = "Total Records: 0";
                    grdApplication.DataSource = null;
                    grdApplication.DataBind();
                    CurrentPage = 0;
                    ViewState["CurrentPage"] = null;
                    PagingRow.Style.Add("display", "none");
                    btnApplicationView.Visible = false;
                }

                //grdApplication.DataSource = search;
                //this.grdApplication.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnApplicationView_Click(object sender, EventArgs e)
        {
            string AppId = string.Empty;

            try
            {
                foreach (GridViewRow grdAccRow in grdApplication.Rows)
                {
                    RadioButton radioCheck = (RadioButton)grdAccRow.FindControl("rdobutton");
                    if (radioCheck.Checked)
                    {
                        AppId = grdApplication.DataKeys[grdAccRow.RowIndex].Value.ToString();

                        break;
                    }
                }

                Response.Redirect("ManageApplication.aspx?MODE=VIEW&AppId=" + AppId, false);
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_SearchClient_ViewClient));
                throw ex;
            }
        }

        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                {
                    ViewState["sortDirection"] = SortDirection.Ascending;
                }

                return (SortDirection)ViewState["sortDirection"];
            }

            set { ViewState["sortDirection"] = value; }
        }

        protected void grdApplication_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                CurrentPage = 0;
                ViewState["CurrentPage"] = null;

                if (this.GridViewSortDirection == SortDirection.Ascending)
                {
                    this.GridViewSortDirection = SortDirection.Descending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
                }
                else
                {
                    this.GridViewSortDirection = SortDirection.Ascending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                }

                ViewState["SortExp"] = e.SortExpression;
                this.BindGridData();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// client grid index changed event
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Application_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdApplication.PageIndex = e.NewPageIndex;
            this.BindGridData();
        }

        public int CurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object current = this.ViewState["CurrentPage"];
                if (current == null)
                    return 0; // default page index of 0 
                else
                    return (int)current;
            }
            set
            {
                this.ViewState["CurrentPage"] = value;
            }
        }
        protected void LinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage = 0;
            BindGridData();
        }
        protected void LinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            CurrentPage -= 1;
            BindGridData();
        }
        protected void LinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage += 1;
            BindGridData();
        }
        protected void LinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            CurrentPage = int.Parse(ViewState["TotalPages"].ToString());
            BindGridData();
        }
        //To show total page numbers 
        //private void ShowTotalNumberOfRecords()
        //{
        //    int i, j;
        //    if (CurrentPage == 0)
        //        i = 1;
        //    else
        //        i = (CurrentPage * PageSize) + 1;
        //    LabelPageFirstRecord.Text = i.ToString();
        //    if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
        //        LabelPageLastRecord.Text = LabelTotalRecords.Text;
        //    else
        //    {
        //        j = ((CurrentPage + 1) * PageSize);
        //        LabelPageLastRecord.Text = j.ToString();
        //    }
        //}
        //To show current page number 
        private void ShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (CurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (CurrentPage > (int.Parse(ViewState["TotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["TotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["TotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = CurrentPage - 1;
                endPageNumber = CurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (CurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["TotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            CurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindGridData();
        }
        private void ShowPagingLinks()
        {
            if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
            {
                LinkButtonNext.Enabled = false;
                LinkButtonLast.Enabled = false;
            }
            else
            {
                LinkButtonNext.Enabled = true;
                LinkButtonLast.Enabled = true;
            }
            if (CurrentPage == 0)
            {
                LinkButtonPrevious.Enabled = false;
                LinkButtonFirst.Enabled = false;
            }
            else
            {
                LinkButtonPrevious.Enabled = true;
                LinkButtonFirst.Enabled = true;
            }
        }

        protected void grdApplication_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataRowView drv = null;
            drv = (DataRowView)e.Row.DataItem;
            try
            {
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (this.ViewState["SortExp"] == null)
                        this.ViewState["SortExp"] = "";

                    int sortColumnIndex = GetSortColumnIndex(grdApplication, this.ViewState["SortExp"].ToString());
                    AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_grid_RowDataBound));
                throw ex;
            }
        }

        public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        {
            string sortExpressionString = null;
            foreach (DataControlField field in gridObject.Columns)
            {
                if (sortExpression != "")
                    sortExpressionString = sortExpression.ToString();

                if (field.SortExpression == sortExpressionString)
                {
                    return gridObject.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        {
            if (columnIndex == -1) return;
            if (strgrdSortDirection == SortDirection.Ascending)
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
            else
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
        }

    }
}
