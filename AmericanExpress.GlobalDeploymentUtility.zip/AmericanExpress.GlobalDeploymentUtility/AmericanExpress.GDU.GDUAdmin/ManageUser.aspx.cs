﻿//-----------------------------------------------------------------------
// <copyright file="ManageUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Manages user creation/addition/deactivation</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU
{
    #region Page level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model;
    using System.Collections.Generic;
    using AmericanExpress.GDU.Utilities.Diagnostics;

    #endregion

    /// <summary>
    /// Manage User Class
    /// </summary>
    public partial class ManageUser : System.Web.UI.Page
    {
        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        public string CurrentRole;

        #region "Events"
        /// <summary>
        /// Page Load event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {
                this.gduModel = new GDUModel();
                txtUserID.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                txtUserName.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                if (!Page.IsPostBack)
                {
                    //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);                    
                    ddlClient.Visible = false;
                    this.PopulateDropdown();
                    this.LoadClients();

                    if (Request.QueryString[AdmConstants.MODE].ToString().ToUpper().Equals("ADD"))
                    {
                        ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ADD.ToString();
                        this.ShowHideButton(AdmConstants.CRUD_MODE.ADD);
                        txtUserID.Enabled = true;
                        this.LoadRoles("Available", string.Empty, "GD");
                    }
                    else
                    {
                        ViewState["USER_ID"] = Request.QueryString["ADSID"].ToString();
                        this.ShowHideButton(AdmConstants.CRUD_MODE.VIEW);
                        this.EnableDisableTextbox(false);
                        txtUserID.Enabled = false;
                        this.PopulateControls(ViewState["USER_ID"].ToString());
                        this.LoadRoles("Available", Convert.ToString(ViewState["USER_ID"]), "GD");
                        this.LoadRolesOnEdit("Authorized", Convert.ToString(ViewState["USER_ID"]), "GD");
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageUser_Page_Load));
                throw ex;
            }
        }

        /// <summary>
        /// Save button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Save_Click(object sender, EventArgs e)
        {
            try
            {
                string userName = null;
                string userCode = null;
                string userLanguage = null;
                string userRole = null;
                string emailAddr = null;
                int defaultClientId = 0;
                string defaultClientAbbr = string.Empty;
                DateTime modifiedon = DateTime.MinValue;

                if (Session[AdmConstants.IS_DEACTIVE] != null)
                {
                    if (Session[AdmConstants.IS_DEACTIVE].Equals(true))
                    {
                        if (btnSave.Text == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                        {
                            this.ViewState[AdmConstants.MODE] = btnSave.Text;
                        }
                    }
                }

                if (!string.IsNullOrEmpty(txtUserName.Text.Trim()))
                {
                    userName = txtUserName.Text.Trim();
                }

                if (!string.IsNullOrEmpty(txtUserID.Text.Trim()))
                {
                    userCode = txtUserID.Text.Trim();
                }

                emailAddr = string.IsNullOrEmpty(txtEmailAdd.Text.Trim()) ? null : txtEmailAdd.Text.Trim();

                if (ddlRole.SelectedIndex > 0)
                {
                    userRole = ddlRole.SelectedItem.Value;
                }

                if (ddlLanguage.SelectedIndex > 0)
                {
                    userLanguage = ddlLanguage.SelectedItem.Value;
                }

                if (ViewState[AdmConstants.MODE] != null && (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.UPDATE.ToString() || (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.DEACTIVATE.ToString() || (ViewState[AdmConstants.MODE].ToString()) == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                {
                    userCode = ViewState["USER_ID"].ToString();
                    modifiedon = Convert.ToDateTime(ViewState["MODIFIED_DT"]);
                }
                else
                {
                    modifiedon = DateTime.Now;
                }

                this.ManageUsers(ViewState[AdmConstants.MODE].ToString(), userCode, userName, emailAddr, userLanguage, userRole, modifiedon, hdAuthorizedRolesIds.Value.ToString(), defaultClientId, defaultClientAbbr, hdCurrentRoles.Value.ToString(),"GD");
                Response.Redirect("SearchUser.aspx");
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageUser_Save_Click));
                string errmsg = ex.Message;
                lblMsgPanel.Text = errmsg;
            }
        }

        /// <summary>
        /// Delete button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Delete_Click(object sender, EventArgs e)
        {
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.DEACTIVATE.ToString();
            this.Save_Click(sender, e);
        }

        /// <summary>
        /// Modify button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Modify_Click(object sender, EventArgs e)
        {
            this.EnableDisableTextbox(true);
            this.ShowHideButton(AdmConstants.CRUD_MODE.UPDATE);
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.UPDATE.ToString();
        }

        #endregion

        #region "Methods"

        /// <summary>
        /// Enable/ disable textbox controls
        /// </summary>
        /// <param name="enableDisable">boolean parameter</param>
        private void EnableDisableTextbox(bool enableDisable)
        {
            txtUserName.Enabled = enableDisable;
            txtEmailAdd.Enabled = enableDisable;
            ddlLanguage.Enabled = enableDisable;
            ddlRole.Enabled = enableDisable;
            ddlClient.Enabled = enableDisable;
        }

        /// <summary>
        /// Show/hide button
        /// </summary>
        /// <param name="mode"> mode </param>
        private void ShowHideButton(AdmConstants.CRUD_MODE mode)
        {
            switch (mode)
            {
                case AdmConstants.CRUD_MODE.UPDATE:
                    {
                        btnSave.Visible = true;
                        btnSave.Text = AdmConstants.CRUD_MODE.UPDATE.ToString();
                        btnModify.Visible = false;
                        btnDelete.Visible = false;
                        btnAdd.Disabled = false;
                        btnAddAll.Disabled = false;
                        btnDel.Disabled = false;
                        btnDelAll.Disabled = false;
                        break;
                    }

                case AdmConstants.CRUD_MODE.ADD:
                    {
                        btnDelete.Visible = false;
                        btnModify.Visible = false;
                        break;
                    }

                case AdmConstants.CRUD_MODE.VIEW:
                    {
                        bool deactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                        if (deactive)
                        {
                            btnSave.Text = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                            btnDelete.Visible = false;
                            btnModify.Visible = false;
                            break;
                        }
                        else
                        {
                            btnSave.Visible = false;
                            btnAdd.Disabled = true;
                            btnAddAll.Disabled = true;
                            btnDel.Disabled = true;
                            btnDelAll.Disabled = true;
                            break;
                        }
                    }
            }
        }

        /// <summary>
        /// Add/edit/delete/activate 
        /// </summary>
        /// <param name="actionmode">action mode </param>
        /// <param name="userId">user ID</param>
        /// <param name="userName">user name</param>
        /// <param name="userEmail">user email</param>
        /// <param name="userLanguage">user language</param>
        /// <param name="userRole">user role</param>
        /// <param name="modifiedon">date and time of modification</param>
        /// <returns>return status</returns>
        private int ManageUsers(string actionmode, string userId, string userName, string userEmail, string userLanguage, string userRole, DateTime modifiedon, string authorizedRoleIds, int defaultClientId, string defaultClientAbbr, string CurrentRole, string System_CD)
        {
            int status = 0;
            //this.gwizModel.ManageUsers(actionmode, userId,  userName, userEmail,  userLanguage, userRole, modifiedon);
            this.gduModel.ManageUsers(actionmode, userId, userName, userEmail, userLanguage, userRole, modifiedon, authorizedRoleIds, defaultClientId, defaultClientAbbr, CurrentRole, System_CD);
            return status;

        }

        /// <summary>
        /// Get country details on country id
        /// </summary>
        /// <param name="userId">user ID</param>
        /// <returns>return user details</returns>
        private DataTable GetUser(string userId)
        {
            bool isDeactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
            DataTable userDetail = this.gduModel.GetUserDetails(null, userId, isDeactive, null, "N", "GD", 0, 5000, "User_NM", "ASC");
            if (userDetail.Rows.Count > 0)
            {
                return userDetail;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// populate controls
        /// </summary>
        /// <param name="userCode">user code</param>
        private void PopulateControls(string userCode)
        {
            try
            {
                DataTable userDetail = this.GetUser(userCode);
                if (userDetail != null)
                {
                    txtUserName.Text = userDetail.Rows[0]["UserName"].ToString();
                    txtUserID.Text = userDetail.Rows[0]["UserID"].ToString();
                    txtEmailAdd.Text = userDetail.Rows[0]["EmailAddress"].ToString();

                    if (userDetail.Rows[0]["LanguageCode"].ToString() != string.Empty)
                    {
                        ddlLanguage.Items.FindByValue(userDetail.Rows[0]["LanguageCode"].ToString()).Selected = true;
                    }

                    if (userDetail.Rows[0]["RoleCode"].ToString() != string.Empty)
                    {
                        //ddlRole.Items.FindByValue(userDetail.Rows[0]["RoleCode"].ToString()).Selected = true;
                        foreach (ListItem item in ddlRole.Items)
                        {
                            if (item.Value.Contains("-") && (item.Value.Split('-')[0] == userDetail.Rows[0]["RoleCode"].ToString()))
                            {
                                item.Selected = true;
                                break;
                            }
                        }
                    }
                    if (userDetail.Rows[0]["DefaultClientID"].ToString() != string.Empty)
                    {
                        foreach (ListItem item in ddlClient.Items)
                        {
                            if (item.Value.Contains("-") && (Convert.ToInt32(item.Value.Split('-')[0]) == Convert.ToInt32(userDetail.Rows[0]["DefaultClientID"])))
                                item.Selected = true;
                            //ddlClient.Items.FindByValue(sysCode).Selected = true;
                        }
                    }

                    ViewState["MODIFIED_DT"] = Convert.ToDateTime(userDetail.Rows[0]["ModifiedDT"]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// populate Dropdown
        /// </summary>
        private void PopulateDropdown()
        {
            this.gduModel = new GDUModel();
            ddlLanguage.DataSource = this.gduModel.PopulateLanguage();
            ddlLanguage.DataTextField = AdmConstants.VALUE;
            ddlLanguage.DataValueField = AdmConstants.KEY;
            this.ddlLanguage.DataBind();
            ddlLanguage.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
            ddlRole.DataSource = this.gduModel.PopulateRole();
            ddlRole.DataTextField = AdmConstants.VALUE;
            ddlRole.DataValueField = AdmConstants.KEY;
            ddlRole.DataBind();
            this.ddlRole.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
        }

        /// <summary>
        /// cvlbAuthorizedRoles_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>

        protected void cvlbAuthorizedRoles_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = !string.IsNullOrEmpty(hdAuthorizedRolesIds.Value.ToString());
        }

        protected void LoadRolesOnEdit(string roleType, string userId, string SYSTEM_CD)
        {
            try
            {
                DataTable dtRoles = gduModel.PopulateRoleDetails(roleType, userId, SYSTEM_CD);
                lbAuthorizedRoles.DataTextField = dtRoles.Columns[1].ToString();
                lbAuthorizedRoles.DataValueField = dtRoles.Columns[0].ToString();
                lbAuthorizedRoles.DataSource = dtRoles;
                lbAuthorizedRoles.DataBind();
                if (lbAuthorizedRoles.Items[0].Value == string.Empty)
                    lbAuthorizedRoles.Items.Remove(lbAuthorizedRoles.Items[0]);

            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageUser_LoadRolesOnEdit);
            }

        }
        /// <summary>
        /// LoadRoles
        /// </summary>
        /// <param name="ID"></param>
        protected void LoadRoles(string roleType, string userId, string SYSTEM_CD)
        {
            try
            {
                DataTable dtRoles = gduModel.PopulateRoleDetails(roleType, userId, SYSTEM_CD);
                lbAvailableRoles.DataTextField = dtRoles.Columns[1].ToString();
                lbAvailableRoles.DataValueField = dtRoles.Columns[0].ToString();
                lbAvailableRoles.DataSource = dtRoles;
                lbAvailableRoles.DataBind();
                if (lbAvailableRoles.Items[0].Value == string.Empty)
                    lbAvailableRoles.Items.Remove(lbAvailableRoles.Items[0]);


            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageUser_LoadRoles);

            }

        }

        /// <summary>
        /// ShowHideButton
        /// </summary>
        /// <param name="mode">mode is add,update,view</param>
        private void ShowHideButton(string mode)
        {
            switch (mode)
            {
                case "Update":
                    btnSave.Visible = true;
                    btnSave.Text = "Update";
                    btnModify.Visible = false;
                    btnDelete.Visible = false;
                    btnAdd.Disabled = false;
                    btnAddAll.Disabled = false;
                    btnDel.Disabled = false;
                    btnDelAll.Disabled = false;
                    break;
                case "Add":
                    btnDelete.Visible = false;
                    btnModify.Visible = false;
                    break;
                case "View":
                    btnAdd.Disabled = true;
                    btnAddAll.Disabled = true;
                    btnDel.Disabled = true;
                    btnDelAll.Disabled = true;
                    btnSave.Visible = false;
                    break;
            }
        }

        protected void LoadClients()
        {
            try
            {
                //Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                //objDictonary = gduModel.PopulateClientInfo(null, 0);
                //this.ddlClient.DataSource = objDictonary;
                //ddlClient.DataValueField = AdmConstants.KEY;
                //ddlClient.DataTextField = AdmConstants.VALUE;
                //ddlClient.DataBind();
                //this.ddlClient.Items.Insert(0, new ListItem("All", "0-All"));
                ddlClient.Items.Insert(0, "Select Client");
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_LoadSystem);
            }
        }
        #endregion
    }
}
