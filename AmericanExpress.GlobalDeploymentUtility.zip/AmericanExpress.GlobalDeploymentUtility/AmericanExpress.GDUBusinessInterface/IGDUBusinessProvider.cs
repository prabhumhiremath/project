﻿//-----------------------------------------------------------------------
// <copyright file="IGWizBusinessProvider.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class define the Interface for Business. </Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.BusinessEntities;

namespace AmericanExpress.GDU.BusinessInterface
{
    public interface IGDUBusinessProvider
    {
        #region Populate

        //AccountDetails[] PopulateAccount(AccountInput input);
        //CountryDetails[] LoadCountry(CountryInput input);
        //CountryDetails[] PopulateCountry();
        //CountryDetails[] PopulateCountry(CountryInput input);
        //CityDetails[] PopulateCity(CityInput Request);
        //CityDetails[] PopulateCity(CityInput Request,string jquery);

        //CategoryDetails[] PopulateCategory(SearchLinkInput input);
        //LinkTypeDetails[] PopulateLinkType();
        LanguageDetails[] PopulateLanguage();
        UserRoleDetails[] PopulateUserRole();
        //OtherInfoDetails[] PopulateOtherInfo();

        //FeedbackType[] PopulateFeedbackType();

        //AggregationRule[] PopulateAggregationRule();

        //ClientDetailbyAcc[] PopulateClientbyAcc(ClientAccInput input);
        FunctionDetails[] PopulateFunctions(FunctionInput input);

        #endregion

        #region Search Link

        //SearchLinkResult[] SearchLinkData(SearchLinkInput input);

        //SearchLinkResult[] SearchLinkDataClientAlert(SearchLinkInput input);
        //SearchClientTotalAlert SearchClientTotalAlert(SearchLinkInput input);

        #endregion

        #region Search Other Info

        //SearchInfoResult[] SearchOtherInfo(SearchOtherInfoInput input);

        //SearchInfoTotalAlert SearchOtherInfoTotalAlert(SearchOtherInfoInput input);

        #endregion

        #region Update Link

        //StandardResponse UpdateLinks(Link[] Request);

        #endregion

        #region Update GeneralInfo Link

        //StandardResponse UpdateGeneralInfoLinks(GeneralInfoLink[] Request);

        //StandardResponse UpdateGeneralInfoOtherInfo(GeneralInfoOtherInfoDetails Request);

        #endregion

        #region Delete

        //StandardResponse DeleteLink(DeleteLink Request);

        #endregion

        #region FeedBack

        //StandardResponse SaveFeedback(FeedbackInput Request);

        #endregion

        #region Update OtherInfo

        //StandardResponse UpdateOtherInfo(OtherInfo Request);

        //StandardResponse AddUpdateOtherInfoLink(OtherInfoInput Request);

        //StandardResponse DeleteOtherInfo(OtherInfoInput Request);

        //CategoryDetails[] PopulateOtherInfoCategory(OtherInfoInput Request);
        #endregion

        #region TransactionId
        //TransactionIdDetails GetTransactionId(TransactionIdInput Request);
        #endregion

        #region report
        ReportDetails[] PopulateGwizReport(ReportInput Request);
        //OtherInfoReportDetails[] PopulateGWizOtherInfoReport(OtherInfoReportInput Request);

        //ReportDetails[] PupulateGWizBrokenInfoReport();
        //OtherInfoReportDetails[] PupulateGWizOtherBrokenInfoReport();

        //FeedbackTypeDetails[] PopulateFeedbackTypeReport(FeedbackReportInput Request);

        ClientDeploymentReportDetail[] PopulateClientDeploymentReport(ClientDeploymentReportInput Request);

        ClientUsageReportDetail[] PopulateClientUsageReport(ClientUsageReportInput Request);
        #endregion

        #region AppUser

        AppUserDetails[] SearchAppUsers(AppUserInput Request);
        StandardResponse ManageAppUsers(AppUserInput Request);
        #endregion

        #region Globalcategory

        //StandardResponse AddUpdateGlobalCategory(GlobalCategoryInput Request);

        //StandardResponse DeleteGlobalcategory(GlobalCategoryInput Request);
        //CategoryDetails[] PopulateGlobalCategory();

        #endregion

        #region Carrier

        //CarrierDetails[] SearchCarrier(CarrierInput Request);
        //StandardResponse ManageCarriers(CarrierInput Request);

        #endregion

        #region Manage Country
        //ManageCountryDetails[] SearchCountry(ManageCountryInput Request);
        //StandardResponse ManageCountry(ManageCountryInput Request);

        #endregion

        #region Manage City
        //ManageCityDetails[] SearchCities(ManageCityInput Request);
        //StandardResponse ManageCities(ManageCityInput Request);

        #endregion

        #region User

        UserDetails[] SearchUsers(UserInput Request);
        UserDetails[] PopulateSearchUsers(UserInput Request);
        StandardResponse ManageUsers(UserInput Request);
        #endregion

        #region Version

        VersionDetails[] PopulateVersions(AppUserInput Request);

        #endregion

        #region Manage Account
        //ManageAccountDetails[] SearchAccounts(ManageAccountInput Request);
        //StandardResponse ManageAccounts(ManageAccountInput Request);

        #endregion

        #region Manage Client
        //ManageClientDetails[] SearchClients(ManageClientInput Request);
        //StandardResponse ManageClients(ManageClientInput Request);

        #endregion

        #region Roles
        ManageRoleDetails[] SearchRoles(ManageRoleInput Request);
        ManageRoleDetails[] SearchClientRoles(ManageRoleInput Request);
        StandardResponse ManageRole(ManageRoleInput Request);
        RoleDetails[] PopulateRoles(RoleInput input);
        #endregion

        #region AggregationRule
        //StandardResponse ManageAggregationRule(AggregationRule[] Request);
        #endregion

        #region UserAuthentication

        UserAuthenticationDetails UserAuthentication(UserAuthenticationInput Request);

        #endregion

        #region ClientDeploymentDetail
        StandardResponse AddClientDeploymentDetail(ClientDeployementInput Request);
        #endregion

        #region ClientUsageDetail
        StandardResponse AddClientUsageDetail(ClientUsageInput Request);
        #endregion

        #region Manage Application
        ManageApplicationDetails[] SearchApplication(ManageApplicationInput Request);
        StandardResponse ManageApplication(ManageApplicationInput Request);

        #endregion

        #region Manage AppFocus
        //ManageAppFocusDetails[] SearchAppFocus(ManageApplicationInput Request);
        StandardResponse ManageAppFocus(ManageAppFocusInput Request);

        #endregion

        //#region MappingCity
        //StandardResponse MapCity(CityMappingInput[] Request);
        //#endregion

        //SearchLabelDetail[] SearchLabel(SearchLabelInput Request);
        //StandardResponse MapAccount(AccountMappingInput[] Request);

        //ClientDetails[] PopulateClient();

        ApplicationDetails[] PopulateApplication();

        //ClientDetailReponse[] PopulateClientResponse(ClientInput input);

        //MappingDetails[] GetMappingDetails(MappingInput Request);

        //StandardResponse MapCountry(CountryMappingInput[] Request);

        StandardResponse SaveClientReleaseInfo(ClientRelease Request);

        UserMenuDetails[] SearchUserMenu(UserInput input);

        ApplicationDetailResponse[] PopulateApplicationResponse(ApplicationInput input);

        //ClientDetails[] PopulateUserClient(UserInput Request);

        AppUploadedReportDetail[] PopulateAppUploadedReport(AppUploadedReportInput Request);

        StandardResponse ManageUserProfile(UserInput Request);

        RoleMasterDetails[] PopulateRoleMaster();

        #region Manage Application Time Duration

        DurationTimeDetails[] SearchDurationTime(DurationTimeInput Request);
        StandardResponse ManageDurationTime(DurationTimeInput Request);
        RptFocusAppDetails[] PopulateFocusReportAppName();
        //RptFocusOfficeIdDetails[] PopulateFocusReportOfficeID();
        RptFocusOfficeIdDetails[] PopulateFocusReportOfficeID(FocusGroupInput Request);
        #endregion

        AppFocusReportDetails[] PopulateAppFocusReport(AppFocusReportInput Request);
        AppFocusReportDetails[] PopulateAppFocusReportDetail(AppFocusReportInput Request);
        AppFocusReportDetails[] PopulateAppUserFocusReportDetail(AppFocusReportInput Request);

        #region Manage Focus Application
        FocusAppDetails[] SearchFocusApp(FocusAppInput Request);
        FocusAppDetails[] PopulateSearchFocusApp(FocusAppInput Request);
        StandardResponse ManageFocusApplications(FocusAppInput Request);
        #endregion

        #region FocusOffice
        AppFocusOfficeDetails[] SearchAppFocusOffice(AppFocusOfficeInput Request);
        StandardResponse ManageAppFocusOffice(AppFocusOfficeInput Request);
        #endregion

        #region FocusGroup
        FocusGroupDetails[] SearchAPPFGroup(FocusGroupInput Request);
        StandardResponse ManageAppFocusGroup(FocusGroupInput Request);
        PopulateFocusGroupDetails[] PopulateOfficeGroup(FocusGroupInput input);
        AppFocusOfficeDetails[] GetMappingOfficeGroupDetails(FocusGroupMappingInput Request);
        StandardResponse MappedOfficeGroupdtls(FocusGroupMappingInput Request);
        #endregion

        #region PreviousVersions
        VersionDetails[] PopulatePreVersions(AppUserInput Request);
        StandardResponse UpdatePreVersionRelease(ClientRelease Request);
        #endregion

        #region OfficeGroupMappingReport
        OfficeGroupMappingReportDetail[] PopulateOfficeGroupMappingReport(OfficeGroupMappingReportInput Request);
        #endregion

        #region PilotApplicationUploadedReport
        AppUploadedReportDetail[] PopulatePilotAppReport(AppUploadedReportInput Request);
        PilotAppUploadDetails[] PopulatePilotUserDetails(PilotAppUploadInput Request);
        #endregion

        #region PilotApp_ImportExcelSheet
        StandardResponse ImportPilotAppData(ManagePilotAppExcelSheetInput Request);
        #endregion

        AppFOfficeAdsID[] PopulateAppfAdsID(AppFOfficeAdsMappingID Request);
        StandardResponse ManageAppfAdsID(AppFOfficeAdsMappingID Request);

        #region PopulateTravelSuiteAppFocusReport
        TravelSuiteAppFocusReportDetails[] PopulateTravelSuiteAppFocusReport(TravelSuiteAppFocusReportInput Request);
        #endregion

        #region PopulatePilotAppDeploymentreport
        PilotApplicationDeploymentReportDetail[] PopulatePilotApplicationDeploymentReport(PilotApplicationDeploymentReportInput Request);
        #endregion

        #region CheckPilotAppUser
        StandardResponse CheckPilotAppUser(PilotAppUploadInput Request);
        #endregion

        #region AddOffice
        StandardResponse AddOffice(AddOfficeInput Request);
        #endregion

        #region ACWReport
        ACWReportDetails[] PopulateACWReport(ACWReportInput input);
        #endregion

        #region AppFocusIndicator
        AppFocusIndicatorDetails[] PopulateAppFocusIndicator();
        #endregion

        #region GlobalAlert
        //SearchLinkDetails[] PopulateGlobalAlert();
        //SearchLinkResult[] SearchLinkDataGlobalAlert();
        //SearchLinkResult[] SearchLinkDataGlobalAlert(ClientGlobalAlertInput input);
        #endregion

        //PendingApprovalDetails[] PopulatePendingApproval(PendingApprovalInput input);
        TransitDataDetails[] PopulateTransitData(TransitDataInput input);

        //StandardResponse ManagePendingApproval(ManagePendingApprovalInput[] Request);

        //AuditTrialDetails[] GetAuditTrial(AuditTrialInput Request);

        GetAppLatestVersionInfo GetAppLatestVersion(GetAppLatestVersionInput getAppLatestVersion);
    }
}
