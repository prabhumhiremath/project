﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AmericanExpress.GWiz.ModelClient;
using System.Data;
using System.Xml;
using System.IO;
using System.Xml.Xsl;
using AmericanExpress.GWiz.Utility;
namespace AmericanExpress.GWiz.GWizClientWeb
{
    public partial class ContentSearch : System.Web.UI.Page
    {
        GWizModelClient _gm;
        DataTable dtSearch;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["IsGoogleSearch"] = "false";
                string key = Request.QueryString["Key"];
                txtSearch.Text = key;
                if (txtSearch.Text != string.Empty)
                { 
                ExecuteFunction();
                }
            }
        }
        protected void Page_Unload(object sender, EventArgs e)
        { 
        
        
        }
        private void RenderDiv(string xml)
        {

            try
            {
                XsltArgumentList args = new XsltArgumentList();
                args.AddExtensionObject("gwiz:XslUtils", new XslExtensionsUtil());

                XslCompiledTransform xsl = new XslCompiledTransform(true);
                XsltSettings xsltSettings = new XsltSettings(true, true);

                xsl.Load(@AppDomain.CurrentDomain.BaseDirectory + "xsl\\G-Wiz Search.xslt", xsltSettings, new XmlUrlResolver());

                XmlReader myXmlReader = new XmlTextReader(new StringReader(xml));

                System.IO.MemoryStream mStream = new MemoryStream();
 
                int pageNumber = Convert.ToInt32(Request.QueryString["pagenumber"]);
                args.AddParam("recordsPerPage", "", 10);
                args.AddParam("pageNumber", "", pageNumber);
                args.AddParam("recordCount", "", 77);		
                xsl.Transform(myXmlReader, args, mStream);
                mStream.Position = 0;
                StreamReader strStream = new StreamReader(mStream);
                string FormattedXml = strStream.ReadToEnd();
                TestRender.InnerHtml = FormattedXml.Replace("&#xA;", "\\n");
                //if (GeneralDescription != string.Empty)
                //{
                //    emGeneralSegment.InnerHtml = GeneralDescription;
                //}
                //else
                //{
                //    alertDiv.Style.Value = "visibility";
                //}
            }
            catch (Exception ex)
            {

            }

        }

        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ExecuteFunction();
            }
            catch (Exception ex)
            { 
            
            }
        }
          private void  ExecuteFunction()
          {
           _gm = new GWizModelClient();
           if (txtSearch.Text.ToString().Trim() != string.Empty)
           {
               List<string> totalResult = new List<string>();
               string contentXML = string.Empty;
               totalResult = _gm.GetSearchContentXML(txtSearch.Text.ToString().Trim(),string.Empty);
               contentXML = totalResult[0];
               lblCustomSearch.Text = "Custom Search: " + totalResult[1];
               lblSharePointSearch.Text = "Share Point Search: " + totalResult[2];
               RenderDiv(contentXML);
               Session["Keyword"] = txtSearch.Text.Trim();
           }
           else
           {
               RenderDiv("<GWiz></GWiz>");
               //Response.Write("<script>alert('Serach box should't be left blank')</scrit>");
           }
          }
        
    }
}
