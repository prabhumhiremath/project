﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

namespace AmericanExpress.GWiz.GWizClientWeb
{
    public partial class ExternalSearch : System.Web.UI.Page
    {
        
            
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                string key = Request.QueryString["Key"];
                if (!string.IsNullOrEmpty(key))
                {
                    Session["Key"] = key;
                }
                if (Session["Key"] != null)
                {
                    q.Text = Session["Key"].ToString();
                }
                if (Session["IsGoogleSearch"] != "true")
                {
                    
                    String query = Request.QueryString["q"];

                    if (!String.IsNullOrEmpty(query))
                    {

                        q.Text = SanitizeUserInput(HttpUtility.UrlDecode(query.Trim()));

                    }

                    if (q.Text != string.Empty)
                    {
                        ExecuteFunction();
                    }
                }

            }

        }
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            
        }
        /// <summary>

        /// Using the Google form field values, redirect to this page with those values in the URL's

        /// query string.  Google's JavaScript will pick up these parameters, perform the search, and

        /// display the results on your page.

        /// </summary>

        /// <param name="sender"></param>

        /// <param name="e"></param>

        protected void _btnSearch_Click(Object sender, EventArgs e)
        {

           

        }



        /// <summary>

        /// Strip tags from user input.

        /// </summary>

        /// <param name="text"></param>

        /// <returns></returns>

        private String SanitizeUserInput(String text)
        {

            if (String.IsNullOrEmpty(text))

                return String.Empty;



            String rxPattern = "<(?>\"[^\"]*\"|'[^']*'|[^'\">])*>";

            Regex rx = new Regex(rxPattern);

            String output = rx.Replace(text, String.Empty);



            return output;

        }



       

        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            Session["IsGoogleSearch"] = "true";
            if (!IsValid)
                return;



            Response.Redirect(

                String.Format(

                    "ExternalSearch.aspx?q={0}&cx={1}&cof={2} & Key=" + q.Text.ToString()  ,

                    HttpUtility.UrlEncode(SanitizeUserInput(q.Text.Trim())),

                    HttpUtility.UrlEncode(cx.Value),

                    HttpUtility.UrlEncode(cof.Value)

                    ),

                false

                );



            Context.ApplicationInstance.CompleteRequest();

            
        }

        private void ExecuteFunction()
        {


            Session["IsGoogleSearch"] = "true";
            Response.Redirect(

                String.Format(

                    "ExternalSearch.aspx?q={0}&cx={1}&cof={2}& Key=" + q.Text.ToString(),

                    HttpUtility.UrlEncode(SanitizeUserInput(q.Text.Trim())),

                    HttpUtility.UrlEncode(cx.Value),

                    HttpUtility.UrlEncode(cof.Value)

                    ),

                false

                );

           

            Context.ApplicationInstance.CompleteRequest();
        }
    }
}
