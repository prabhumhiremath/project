﻿
//-----------------------------------------------------------------------
// <copyright file="GWiz.Master.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>The generic functions implemented in master</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/02/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Xml.Linq;

namespace AmericanExpress.GWiz.GWizAdmin.MasterPages
{
    public partial class GWiz : System.Web.UI.MasterPage
    {
        public string title = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            title = "G-Wiz ! Knowledge Management(Beta)";
            this.Page.Title = title;
            if (!Page.IsPostBack)
            {
                GetMenus();
            }
            //lblMsgPanel.Visible = false;
           
        }
        private void GetMenus()
        {
            try
            {
                //Response.Write(this.Request.Url.AbsolutePath.Substring(1,));
                XElement xmlMenu;
                string apppath = this.Request.Url.AbsolutePath;
               
                    xmlMenu = XElement.Load(Server.MapPath(@"App_Data\Menu.xml"));
                    
                StringBuilder strMenu = new StringBuilder();
                strMenu.Append("<ul id='cssmenu1'>");
                strMenu.Append("\n<li class='seprator'></li>");
                foreach (XElement element in xmlMenu.Elements())
                {
                    if (element.HasAttributes)
                    {
                        strMenu.Append("\n <li><a ");
                        for (int j = 0; j < element.Attributes().Count(); j++)
                        {
                            if (element.Attributes().ElementAt(j).Name.ToString() != "name")
                            {
                                strMenu.Append(element.Attributes().ElementAt(j).ToString() + " ");
                            }
                        }
                        strMenu.Append(">" + element.Attribute("name").Value.ToString() + "</a></li>");

                        //strMenu.Append("\n <li><a " + element.Attribute("Id").ToString() + " " +
                        //    element.Attribute("Url").ToString() + " " + element.Attribute("Class").ToString() +
                        //    ">" + element.Attribute("Name").Value.ToString() + "</a></li>");
                    }
                    if (element.HasElements)
                    {
                        strMenu.Append("<ul>");
                        foreach (XElement subMenuElement in element.Elements())
                        {
                            strMenu.Append("\n<li><a ");
                            if (subMenuElement.HasAttributes)
                            {
                                for (int i = 0; i < subMenuElement.Attributes().Count(); i++)
                                {
                                    strMenu.Append(subMenuElement.Attributes().ElementAt(i).ToString() + " ");
                                }
                            }
                            strMenu.Append(">" + subMenuElement.Value.ToString() + "</a></li>");
                            //strMenu.Append("\n<li><a " + subMenuElement.Attribute("Style").ToString() + " " +
                            //subMenuElement.Attribute("Url").ToString() + ">" + subMenuElement.Value.ToString() + "</a></li>");
                        }
                        strMenu.Append(" </ul>");
                    }
                    strMenu.Append("\n<li class='seprator'></li>");
                }
                strMenu.Append("</ul>");
                divMenu.InnerHtml = strMenu.ToString();

            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }
    }
}
