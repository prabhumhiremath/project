﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Utilities.ExceptionMgmt
{
    //base class for all custom Exceptions
    public class GDUException:Exception
    {
        //Created to Handle the hardcoded error messages
        public string ErrorMessage { get; set; }

        public string ErrorCode
        {
            get;
            set;
        }

        public Exception BaseException
        {
            get;
            set;
        }

    }
}
