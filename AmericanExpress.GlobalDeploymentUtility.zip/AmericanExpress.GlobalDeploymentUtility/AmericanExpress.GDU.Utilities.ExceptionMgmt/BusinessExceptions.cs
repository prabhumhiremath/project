﻿//-----------------------------------------------------------------------
// <copyright file="BusinessExceptions.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>File for placing all custom exception classes</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/11/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

#region Namespace Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace AmericanExpress.GDU.Utilities.ExceptionMgmt
{
    /// <summary>
    /// Generic business exception
    /// </summary>
    public class BusinessException : Exception
    {
        public int errorCode;
        public BusinessException() : base() { }
        public BusinessException(string message):base(message){}
        public BusinessException(string message, int errorCode) : base(message) { this.errorCode = errorCode; }
    }

    #region Carrier
    /// <summary>
    /// Business Exception 
    /// </summary>
    public class CarrierExistsException : BusinessException
    {
        public CarrierExistsException(string message, int errorCode) : base(message, errorCode) { }
    }

    /// <summary>
    /// Business Exception 
    /// </summary>
    public class CarrierUpdateException : BusinessException
    {
        public CarrierUpdateException(string message, int errorCode) : base(message, errorCode) { }
    }


    /// <summary>
    /// Business Exception 
    /// </summary>
    public class CarrierDeactivateException : BusinessException
    {
        public CarrierDeactivateException(string message, int errorCode) : base(message, errorCode) { }
    }
    #endregion

    #region User
    /// <summary>
    /// Business Exception 
    /// </summary>
    public class UserExistsException : BusinessException
    {
        public UserExistsException(string message, int errorCode) : base(message, errorCode) { }
    }

    /// <summary>
    /// Business Exception 
    /// </summary>
    public class UserUpdateException : BusinessException
    {
        public UserUpdateException(string message, int errorCode) : base(message, errorCode) { }
    }


    /// <summary>
    /// Business Exception 
    /// </summary>
    public class UserDeactivateException : BusinessException
    {
        public UserDeactivateException(string message, int errorCode) : base(message, errorCode) { }
    }

    #endregion

}
