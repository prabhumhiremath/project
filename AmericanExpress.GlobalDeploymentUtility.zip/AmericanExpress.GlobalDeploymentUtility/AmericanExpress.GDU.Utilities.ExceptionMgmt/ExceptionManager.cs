﻿//-----------------------------------------------------------------------
// <copyright file="ExceptionManager.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class for handling all exceptions thrown within services</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/11/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Namesapce Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using AmericanExpress.GDU.Utilities.Diagnostics;
#endregion

namespace AmericanExpress.GDU.Utilities.ExceptionMgmt
{
    /// <summary>
    /// Class for handling all exceptions thrown within services
    /// </summary>
    public class ExceptionManager
    {
        private static DataTable _dtException = null;

        /// <summary>
        /// Private method for initializing collection and reading xml config file
        /// </summary>
        private static void Initialize()
        {
            string _exceptiomInformationFile = string.Empty;
            string exceptionName;
            string errorCode;
            string errorMsg;


            DataRow drException;

            _exceptiomInformationFile = ConfigurationManager.AppSettings[Constants.EXCEPTIONS_INFORMATION_FILE_PATH].ToString();

            _dtException = new DataTable();

            _dtException.Columns.Add(Constants.EXCEPTIONS_XML_ELEMENT_NAME, Type.GetType("System.String"));
            _dtException.Columns.Add(Constants.EXCEPTIONS_XML_ELEMENT_CODE, Type.GetType("System.Int32"));
            _dtException.Columns.Add(Constants.EXCEPTIONS_XML_ELEMENT_MSG, Type.GetType("System.String"));

            XDocument xDoc = XDocument.Load(_exceptiomInformationFile);
            IEnumerable<XElement> exceptionsList = xDoc.Root.Elements();
            foreach (XElement exception in exceptionsList)
            {
                drException = _dtException.NewRow();
                exceptionName = exception.Attribute(Constants.EXCEPTIONS_XML_ELEMENT_NAME).Value;
                errorCode = exception.Element(Constants.EXCEPTIONS_XML_ELEMENT_CODE).Value;
                errorMsg = exception.Element(Constants.EXCEPTIONS_XML_ELEMENT_MSG).Value;
                drException[Constants.EXCEPTIONS_XML_ELEMENT_NAME] = exceptionName;
                drException[Constants.EXCEPTIONS_XML_ELEMENT_CODE] = Convert.ToInt32(errorCode);
                drException[Constants.EXCEPTIONS_XML_ELEMENT_MSG] = errorMsg;
                _dtException.Rows.Add(drException);
            }

        }
        /// <summary>
        /// Centralized method for handling and logging all the exceptions
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <param name="eventId">eventId</param>
        /// <returns>localized string </returns>
        public static string HandleException(Exception exception, int eventId)
        {
            string messageCode = string.Empty;
            GDUException ex = new GDUException();
            if (_dtException == null)
            {
                Initialize();
            }
            messageCode = GetMessage(exception, eventId, ex);
            // If db exception set error code and throw exception.
            if (exception is DbException)
            {
                throw ex;
            } // If BusinessException or SqlException or GenericException set error code and error message and throw exception.
            else if (exception is BusinessException || exception is GenericException || exception is SqlException)
            {
               
                ex.ErrorMessage = GetErrorMessage(Convert.ToInt32(messageCode));
                throw ex;
            }
            return messageCode;
        }

        /// <summary>
        /// Modifies exception exception object and sets the message 
        /// </summary>
        /// <param name="exception">Exception passed in</param>
        /// <param name="eventId">Event Id</param>
        /// <param name="ex"> GWizException</param>
        /// <returns>Message Error Code</returns>
        private static string GetMessage(Exception exception, int eventId, GDUException ex)
        {
            //log  Fatal Error
            LogManager.LogErrorMessage(exception, eventId);
            ex.ErrorMessage = exception.Message;
            ex.BaseException = ex;
            // Check if excpetion ahs an error code else assign an error code.
            if (string.IsNullOrEmpty(ex.ErrorCode))
            {
                ex.ErrorCode = GetErrorCode(exception.GetType().ToString());
            }
            return ex.ErrorCode;
        }



        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorCode"></param>
        /// <returns></returns>
        public static string GetErrorMessage(int errorCode)
        {
            //Search for the "Error Code"  data .  By using the LINQ ..
            // Add the Dll refernce to DataSetExtensions to support for LINQ
            string errorMessage = string.Empty;
            if (_dtException == null)
            {
                Initialize();
            }
            var exRecord = from dr in _dtException.AsEnumerable()
                           where Convert.ToInt32(dr[Constants.EXCEPTIONS_XML_ELEMENT_CODE].ToString()) == Convert.ToInt32(errorCode)
                           select dr;

            DataRow dataRow = exRecord.FirstOrDefault();
            if (dataRow != null)
            {
                errorMessage = dataRow[Constants.EXCEPTIONS_XML_ELEMENT_MSG].ToString();
            }
            return errorMessage;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorCode"></param>
        /// <returns></returns>
        private static string GetErrorCode(string exName)
        {
            //Search for the "Error Code"  data .  By using the LINQ ..
            // Add the Dll refernce to DataSetExtensions to support for LINQ
            string errorCode = string.Empty;
            if (_dtException == null)
            {
                Initialize();
            }
            var exRecord = from dr in _dtException.AsEnumerable()
                           where dr[Constants.EXCEPTIONS_XML_ELEMENT_NAME].ToString() == exName
                           select dr;

            DataRow dataRow = exRecord.FirstOrDefault();
            if (dataRow != null)
            {
                errorCode = dataRow[Constants.EXCEPTIONS_XML_ELEMENT_CODE].ToString();
            }
            return errorCode;
        }
    }
}
