﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Util.DBSchemaHelper
{
   public class Constants
    {
       public const string SP_FILE_PATH = "SpFilePath";
       public const string ATTRIBUTE_NAME = "Name";
       public const string ELEMENT_PARAMETERS = "Parameters";
       public const string ELEMENT_SIZE = "Size";
       public const string ELEMENT_VALUE = "Value";
       public const string ELEMENT_DIRECTION = "Direction";
       public const string ELEMENT_NAME = "Name";
       public const string ELEMENT_OBJECT_ID = "Object_Id";
       public const string ELEMENT_PARAM_NAME = "Param_Name";
       public const string ELEMENT_MAX_LENGTH = "Max_Length";
       public const string ELEMENT_IS_OUTPUT = "Is_Output";
       public const string ELEMENT_TYPE_NAME = "Type_Name";
       public const string ZERO = "0";
       public const string FALSE = "false";
       public const string DIRECTION_VALUE_IN = "in";
       public const string DIRECTION_VALUE_OUT = "out";
       public const string DATA_TYPE = "DataType";
       public const string DATA_TYPE_INT = "int";
       public const string DATA_TYPE_FLOAT = "float";
       public const string DATA_TYPE_STRING = "string";
       public const string DATA_TYPE_DATETIME = "DateTime";
       public const string DATA_TYPE_CHAR = "char";
       public const string DATA_TYPE_VARCHAR = "varchar";
       public const string DATA_TYPE_NVARCHAR = "nvarchar";
       public const string DATA_TYPE_DECIMAL = "decimal";
       public const string DEVDB = "DevDB";
       public const string USP_GETPROCEDUREPARAMS = "usp_GetProcedureParams";
       public const string CONFIG_PROC_PARAM_KEY = "ProcParamSourceXml";
       public const string TRUE = "true";
       public const string DATA_TYPE_SMALL_DATETIME = "datetime";
       public const string DATA_TYPE_BOOLEAN = "bit";
    }
}
