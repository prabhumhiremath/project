﻿//-----------------------------------------------------------------------
// <copyright file="DBProceduresCollection.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>The Helper class that loads all the procedures from a given DB Schema</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

# region Using -Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using AmericanExpress.GDU.Util.DataAccessHelper;
using System.Xml.Linq;
using System.Configuration;
using System.Web;
using System.IO;
#endregion

namespace AmericanExpress.GDU.Util.DBSchemaHelper
{
    /// <summary>
    /// Represents procedures collection indexer for a DB
    /// </summary>
    public class DBProceduresCollection
    {
        #region Private Properties
        /// <summary>
        /// Gets config value for param extraction source
        /// If true params are extracted from database, if false then from XML file
        /// </summary>
        private bool ProcParamSourceAuto
        {
            get
            {
                bool procParamAuto = true;
                if (ConfigurationManager.AppSettings[Constants.CONFIG_PROC_PARAM_KEY] != null)
                {
                    if (ConfigurationManager.AppSettings[Constants.CONFIG_PROC_PARAM_KEY].ToString().ToLower() == Constants.TRUE)
                    {
                        procParamAuto = !bool.Parse(Constants.TRUE);
                    }
                }
                return procParamAuto;
            }
        }
        #endregion

        #region Private Class Members
        private DBFacade _dbFacade = null;
        private string _dataBaseName = string.Empty;
        private Dictionary<string, DBStoredProcedure> _procedures = null;
        #endregion

        #region Public Methods
        /// <summary>
        /// Class constructor. Parameterized string expects database name.
        /// This string should exactly match the string defined for DB in config file
        /// </summary>
        /// <param name="databaseName">Name of the database to connect to.</param>
        public DBProceduresCollection(string databaseName)
        {
            _dbFacade = new DBFacade(databaseName);
            _dataBaseName = databaseName;
        }

        /// <summary>
        /// Class constructor. Parameterized string expects database name.Timeout parameter expects command timeout.
        /// This string should exactly match the string defined for DB in config file
        /// </summary>
        /// <param name="databaseName">Name of the database to connect to</param>
        /// <param name="commandTimeout">command timeout</param>
        public DBProceduresCollection(string databaseName, int commandTimeout)
        {
            _dbFacade = new DBFacade(databaseName, commandTimeout);
            _dataBaseName = databaseName;
        }

        /// <summary>
        /// Indexer for the class having collection of all the Sps
        /// </summary>
        /// <param name="procedureName"></param>
        /// <returns>DBStoredProcedure Objects</returns>
        public DBStoredProcedure this[string procedureName]
        {
            get
            {
              //  if (_procedures == null) { Initialize(procedureName); }
                Initialize(procedureName);
                return _procedures[procedureName];
            }
        }

        /// <summary>
        /// Returns a dataset against a populated Db stored procedure object passed
        /// </summary>
        /// <param name="proc"></param>
        /// <returns></returns>
        public DataSet GetDataset(DBStoredProcedure proc)
        {
            DBParameter[] inputs = null;
            if (proc.Parameters != null)
            {
                inputs = proc.Parameters.Values.ToArray();
            }
            DataSet dst = _dbFacade.ExecuteSPForDataset(proc.ProcName, ref inputs);
            return dst;
        }

        /// <summary>
        /// executes a command against a populated Db stored procedure object passed
        /// </summary>
        /// <param name="proc"></param>
        public void ExecuteSP(DBStoredProcedure proc)
        {
            DBParameter[] inputs = proc.Parameters.Values.ToArray();
            _dbFacade.ExecuteSPAsNonQuery(proc.ProcName, ref inputs);
        }

        public IDataReader ExcecuteReader(DBStoredProcedure proc)
        {
            DBParameter[] inputs = proc.Parameters.Values.ToArray();
            return _dbFacade.ExecuteSPForReader(proc.ProcName, ref inputs);
        }

        /// <summary>
        /// starts atransaction in the database. make sure to commit or rollback a transaction once this method is invoked.
        /// </summary>
        public void BeginTransaction()
        {
            _dbFacade.BeginTransaction();
        }

        /// <summary>
        /// commits a running transaction
        /// </summary>
        public void CommitTransaction()
        {
            _dbFacade.CommitTransaction();
        }

        /// <summary>
        /// rolls back a transaction in progress
        /// </summary>
        public void RollBackTransaction()
        {
            _dbFacade.RollBackTransaction();
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Initializes the dictionary with all the procedures mentioned in the XML file
        /// </summary>
        private void Initialize(string procName)
        {
            _procedures = new Dictionary<string, DBStoredProcedure>();

            if (ProcParamSourceAuto == true)
            {
                PopulateProcedure(procName);
            }
            else
            {
                PopulateProcedures();
            }
        }

        /// <summary>
        /// Populates the dictionary after raeding procedures xml file.
        /// </summary>
        private void PopulateProcedures()
        {
            string parameterName = null;
            ParamTypes dataType = ParamTypes.String;
            ParamDirection direction = ParamDirection.input;
            string size = null;
            string value = null;
            string filePath = string.Empty;
            filePath = ConfigurationManager.AppSettings[_dataBaseName].ToString();
            try
            {
                XDocument xDoc = XDocument.Load(filePath);
                IEnumerable<XElement> proceduresList = xDoc.Root.Elements();

                foreach (XElement procedure in proceduresList)
                {

                    DBStoredProcedure storedProc = new DBStoredProcedure();
                    storedProc.ProcName = procedure.Attribute(Constants.ATTRIBUTE_NAME).Value.Trim();
                    _procedures.Add(storedProc.ProcName, storedProc);

                    IEnumerable<XElement> parameters = procedure.Elements(Constants.ELEMENT_PARAMETERS).Elements();
                    storedProc.Parameters = new Dictionary<string, DBParameter>(parameters.Count());
                    foreach (XElement parameterCollection in parameters)
                    {

                        parameterName = parameterCollection.Attribute(Constants.ATTRIBUTE_NAME).Value.Trim();
                        size = string.IsNullOrEmpty(parameterCollection.Element(Constants.ELEMENT_SIZE).Value.Trim()) ? Constants.ZERO : parameterCollection.Element(Constants.ELEMENT_SIZE).Value.Trim();
                        value = parameterCollection.Element(Constants.ELEMENT_VALUE).Value.Trim();
                        switch (parameterCollection.Element(Constants.ELEMENT_DIRECTION).Value.Trim())
                        {
                            case Constants.DIRECTION_VALUE_IN:
                                {
                                    direction = ParamDirection.input;
                                    break;
                                }
                            case Constants.DIRECTION_VALUE_OUT:
                                {
                                    direction = ParamDirection.output;
                                    break;
                                }

                        }
                        switch (parameterCollection.Element(Constants.DATA_TYPE).Value.Trim())
                        {
                            case Constants.DATA_TYPE_INT:
                                {
                                    dataType = ParamTypes.Integer;
                                    break;
                                }
                            case Constants.DATA_TYPE_STRING:
                                {
                                    dataType = ParamTypes.String;
                                    break;
                                }
                            case Constants.DATA_TYPE_FLOAT:
                                {
                                    dataType = ParamTypes.Float;
                                    break;
                                }
                            case Constants.DATA_TYPE_DATETIME:
                                {
                                    dataType = ParamTypes.DateTime;
                                    break;
                                }
                        }

                        storedProc.Parameters.Add(parameterName, new DBParameter(parameterName, dataType, value, direction, int.Parse(size)));
                    }

                }
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Populate procedure params from database
        /// </summary>
        /// <param name="procName"></param>
        private void PopulateProcedure(string procName)
        {
            DataTable dtProcs = null;
            string parameterName = null;
            ParamTypes dataType = ParamTypes.String;
            ParamDirection direction = ParamDirection.input;
            string size = null;
            string value = null;
            DBStoredProcedure storedProc = new DBStoredProcedure();
            //Get procedure params
            dtProcs = GetProcedureParams(procName);

            storedProc.ProcName = procName;
            storedProc.Parameters = new Dictionary<string, DBParameter>(dtProcs.Rows.Count);
            _procedures.Add(storedProc.ProcName, storedProc);

            foreach (DataRow row in dtProcs.Rows)
            {
                parameterName = row[Constants.ELEMENT_PARAM_NAME].ToString();
                size = string.IsNullOrEmpty(row[Constants.ELEMENT_MAX_LENGTH].ToString()) ? Constants.ZERO : row["MAX_LENGTH"].ToString();

                switch (row[Constants.ELEMENT_IS_OUTPUT].ToString().ToLower())
                {
                    case Constants.FALSE:
                        {
                            direction = ParamDirection.input;
                            break;
                        }
                    default:
                        {
                            direction = ParamDirection.output;
                            break;
                        }
                }

                switch (row[Constants.ELEMENT_TYPE_NAME].ToString().ToLower())
                {
                    case Constants.DATA_TYPE_INT:
                        {
                            dataType = ParamTypes.Integer;
                            break;
                        }
                    case Constants.DATA_TYPE_CHAR:
                        {
                            dataType = ParamTypes.String;
                            break;
                        }
                    case Constants.DATA_TYPE_VARCHAR:
                        {
                            dataType = ParamTypes.String;
                            break;
                        }
                    case Constants.DATA_TYPE_NVARCHAR:
                        {
                            dataType = ParamTypes.String;
                            break;
                        }
                    case Constants.DATA_TYPE_FLOAT:
                        {
                            dataType = ParamTypes.Float;
                            break;
                        }
                    case Constants.DATA_TYPE_DECIMAL:
                        {
                            dataType = ParamTypes.Float;
                            break;
                        }
                    case Constants.DATA_TYPE_SMALL_DATETIME:
                        {
                            dataType = ParamTypes.DateTime;
                            break;
                        }
                    case Constants.DATA_TYPE_BOOLEAN:
                        {
                            dataType = ParamTypes.Integer;
                            break;
                        }
                    default:
                         {
                              dataType = ParamTypes.String;
                              break;
                         }
                    }

                storedProc.Parameters.Add(parameterName, new DBParameter(parameterName, dataType, value, direction, int.Parse(size)));
            }
        }

        /// <summary>
        /// Get procedure params from database
        /// </summary>
        /// <returns></returns>
        private DataTable GetProcedureParams(string procName)
        {
            DataSet dsProcs = null;
            DataTable dtProcs = null;
            DBStoredProcedure proc = new DBStoredProcedure();

            proc.ProcName = Constants.USP_GETPROCEDUREPARAMS;
            proc.Parameters = new Dictionary<string, DBParameter>(1);
            proc.Parameters.Add(procName, new DBParameter("@inProcName", ParamTypes.String, procName, ParamDirection.input, 250));

            dsProcs = GetDataset(proc);

            if (dsProcs.Tables.Count > 0)
            {
                dtProcs = dsProcs.Tables[0];
            }
            
            return dtProcs;
        }
        #endregion
    }
}

