﻿//-----------------------------------------------------------------------
// <copyright file="LogManager.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class encapsulates AmericanExpress.Util.Logging</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Namespace Aliasing
using System;
using System.Diagnostics;
using System.Configuration;
using System.Collections.Generic;
using Log = AmericanExpress.Util.Logging;
#endregion
namespace AmericanExpress.GDU.Utilities.Diagnostics
{
    /// <summary>
    /// Class encapsulating logging details like using dictionary
    /// </summary>
    public class LogManager
    {
        #region Private const strings
        private const string WARNING_INFO = "Warning_Information";
        private const string DICT_NAME_EVENT_ID = "EventID";
        private const string ERROR = "Error";
        private const string EVENT_SOURCE_APPLICATION = "Application";
        private const string APPLICATION_NAME = "TicketExchangeService";
        #endregion

        #region Public methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="message">string informaton to be logged</param>
        /// <param name="eventID">integer event for identifying error source method</param>
        public static void LogInfoMessage(string message, int eventID)
        {
            try
            {
                IDictionary<string, string> dicAttributes = new Dictionary<String, String>();
                dicAttributes.Add(DICT_NAME_EVENT_ID, eventID.ToString());
                Log.LogManager.LogEvent(message, Log.EventType.Information, WARNING_INFO, dicAttributes);

            }
            catch
            {
                //do nothing
            }
        }

        /// <summary>
        /// Method for logging error mesage
        /// </summary>
        /// <param name="message">message to be logged</param>
        /// <param name="eventID">unique identifier for the error source method</param>
        public static void LogErrorMessage(string message, int eventID)
        {
            try
            {
                Log.LogManager.LogError(message, eventID, ERROR);
            }
            catch
            {
                //do nothing
            }
        }
        /// <summary>
        /// Logs Error
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="eventID"></param>
        public static void LogErrorMessage(Exception exception, int eventID)
        {
            try
            {
               Log.LogManager.LogError(exception,eventID, ERROR);
            }
            catch
            {
                //do nothing
            }
        }
        /// <summary>
        /// Logs error messages
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="eventID"></param>
        /// <param name="level"></param>
        public static void LogErrorMessage(Exception exception, int eventID,Log.LogSeverity level)
        {
            try
            {
                Log.LogManager.LogError(new Exception(), 5001, ERROR, level);
            }
            catch
            {
                //do nothing
            }
        }
        /// <summary>
        /// Method to initialize the event source if it is windows event log
        /// </summary>
        public static void InitializeSource()
        {
            if (!EventLog.SourceExists(APPLICATION_NAME))
            {
                EventLog.CreateEventSource(APPLICATION_NAME, EVENT_SOURCE_APPLICATION);
            }
        }
        public static void InitializeSource(string eventSource, string logName)
        {
            if (!EventLog.SourceExists(eventSource))
            {
                EventLog.CreateEventSource(eventSource, logName);
            }
        }
        #endregion
    }
}
