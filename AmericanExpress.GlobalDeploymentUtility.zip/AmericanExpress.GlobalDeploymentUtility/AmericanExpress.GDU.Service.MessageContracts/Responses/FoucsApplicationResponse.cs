﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
    public class FoucsApplicationSearchResponse
    {
        /// <summary>
        ///  
        /// </summary>
        [MessageBodyMember]
        public FocusAppDetails[] SearchResponse
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class FocusApplicationStandardResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
    }
}
