﻿//-----------------------------------------------------------------------
// <copyright file="LanguageResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a LanguageResponse class which contains PopulateLanguageResponse messagecontract which has collection of LanguageDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    public class PopulateLanguageResponse
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public LanguageDetails[] PopulateResponse
        {
            get;
            set;
        }
    }
}
