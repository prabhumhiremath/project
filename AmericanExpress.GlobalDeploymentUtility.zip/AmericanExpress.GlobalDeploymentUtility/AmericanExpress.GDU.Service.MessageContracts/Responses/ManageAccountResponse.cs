﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
  public  class ManageAccountResponse
    {
        /// <summary>
        ///  
        /// </summary>
        [MessageBodyMember]
        public ManageAccountDetails[] SearchResponse
        {
            get;
            set;
        }
    }

   
}
