﻿//-----------------------------------------------------------------------
// <copyright file="FaultContract.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class fault messagecontract.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/25/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// This is structure is used to define the custom soap fault message.
    /// Custom SOAP Fault Message class Name :CustomFaultMsg 
    /// </summary>
    [MessageContract]
    public class CustomFaultMsg
    {
        /// <summary>
        /// This property is used to pass the custom error information 
        /// from service to client.
        /// </summary>
        [MessageBodyMember]
        public string MyCustomErrMsg { get; set; }
    }
}
