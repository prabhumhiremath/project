﻿//-----------------------------------------------------------------------
// <copyright file="AccountResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountResponse class which has PopulateAccountResponse messagecontract which has collection of AccountDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.Service.DataContracts;
using System.ServiceModel;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    public class RoleMasterResponse
    {
       /* [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }*/
        [MessageBodyMember]
        public RoleMasterDetails[] PopulateResponse
        {
            get;
            set;
        }
    }
}
