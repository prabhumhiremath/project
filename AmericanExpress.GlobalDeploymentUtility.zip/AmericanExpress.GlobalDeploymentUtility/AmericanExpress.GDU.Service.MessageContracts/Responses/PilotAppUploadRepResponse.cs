﻿//-----------------------------------------------------------------------
// <copyright file="PilotAppUploadRepResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityResponse class which has PopulateCityResponse messagecontract which has collection of CityDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>17/10/2011</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.Service.DataContracts;
using System.ServiceModel;
namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
    public class PilotAppUploadRepResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }

        [MessageBodyMember]
        public PilotAppRepDetails[] PopulateResponse
        {
            get;
            set;
        }
    }
}
