﻿//-----------------------------------------------------------------------
// <copyright file="FeedbackTypeResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class contains message contracts for the feedback.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/17/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    
   public class FeedbackTypeResponse
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FeedbackTypeResponse FeedType
        {
            get;
            set;
        }

    }

    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    public class PopulateFeedbackType
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    public class FeedbackTypeReportResponse
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }        
    }
}
