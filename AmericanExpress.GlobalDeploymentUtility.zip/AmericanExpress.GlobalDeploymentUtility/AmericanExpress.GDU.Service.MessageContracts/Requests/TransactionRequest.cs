﻿//-----------------------------------------------------------------------
// <copyright file="TransactionRequest.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a TransactionRequest class which contains TransactionQuery datacontract.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/18/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{

    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
   public class TransactionRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public TransactionQuery  TransactionIdQuery
        {
            get;
            set;
        }
    }
}
