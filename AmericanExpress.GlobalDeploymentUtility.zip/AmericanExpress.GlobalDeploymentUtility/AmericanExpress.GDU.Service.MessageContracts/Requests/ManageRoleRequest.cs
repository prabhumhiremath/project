﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
   public class ManageRoleRequest
    {
        [MessageBodyMember]
        public ManageRoleQuery SearchRequest
        {
            get;
            set;
        }
    }

    [MessageContract]
    public class RoleManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageRoleQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
