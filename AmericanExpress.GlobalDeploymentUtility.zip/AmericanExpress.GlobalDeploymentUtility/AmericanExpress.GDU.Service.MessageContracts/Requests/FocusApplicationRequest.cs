﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class FocusApplicationSearchRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FocusAppQuery  SearchRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class FocusApplicationManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FocusAppQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
