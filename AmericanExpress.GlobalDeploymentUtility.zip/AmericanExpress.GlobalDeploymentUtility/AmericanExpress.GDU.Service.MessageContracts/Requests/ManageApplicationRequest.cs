﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ManageApplicationRequest
    {
        [MessageBodyMember]
        public ManageApplicationQuery SearchRequest
        {
            get;
            set;
        }
    }

    [MessageContract]
    public class ApplicationManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageApplicationQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
