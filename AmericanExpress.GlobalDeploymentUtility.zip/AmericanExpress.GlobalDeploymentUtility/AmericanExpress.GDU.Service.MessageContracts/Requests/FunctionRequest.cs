﻿
//-----------------------------------------------------------------------
// <copyright file="AccountRequest.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountRequest class which contains messagecontract query for account.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/04/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
   public class FunctionRequest
    {
        
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageFunctionQuery PopulateRequest
        {
            get;
            set;
        }
    }
}
