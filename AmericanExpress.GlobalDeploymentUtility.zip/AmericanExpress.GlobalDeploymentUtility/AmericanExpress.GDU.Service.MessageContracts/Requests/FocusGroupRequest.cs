﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class FocusGroupSearchRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FocusGroupQuery SearchRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class FocusGroupManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FocusGroupQuery ManipulateRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class FocusGroupRequest
    {
        [MessageHeader]
        public StandardInput ServiceInput
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public FocusGroupQuery PopulateRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class AppFOfficeAdsIDRequest
    {
        [MessageHeader]
        public StandardInput ServiceInput
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public AppfOfficeAdsQuery PopulateRequest
        {
            get;
            set;
        }
    }

}
