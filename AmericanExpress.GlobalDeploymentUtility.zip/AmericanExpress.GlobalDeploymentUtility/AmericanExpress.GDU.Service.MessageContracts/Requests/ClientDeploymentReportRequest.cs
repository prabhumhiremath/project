﻿//-----------------------------------------------------------------------
// <copyright file="ClientDeployementInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{    
    [MessageContract]
    public class ClientDeploymentReportRequest
    {
        [MessageBodyMember]
        public ClientDeploymentReportQuery ClientDeploymentReport
        {
            get;
            set;
        }
    }
}
