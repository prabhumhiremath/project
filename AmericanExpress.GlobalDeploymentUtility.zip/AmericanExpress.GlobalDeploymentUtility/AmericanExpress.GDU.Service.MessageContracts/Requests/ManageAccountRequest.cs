﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ManageAccountRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageAccountQuery SearchRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class AccountManipulateRequest
    {


        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageAccountQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
