﻿//-----------------------------------------------------------------------
// <copyright file="RequestToBusinessEntityConverter.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a converter class which converts service entities to the business entities.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.Service.ServiceImplimentation
{

    #region Page level Namespace
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Buss = AmericanExpress.GDU.BusinessEntities;
    using Serv = AmericanExpress.GDU.Service.DataContracts;
    using AmericanExpress.GDU.Utilities.ExceptionMgmt;
    using AmericanExpress.GDU.Service.MessageContracts.Responses;
    using AmericanExpress.GDU.Service.MessageContracts.Requests;
    using System.ServiceModel;
    #endregion

    /// <summary>
    /// Request to business converter class
    /// </summary>
    public class RequestToBusinessEntityConverter
    {
        #region Public Methods
        /// <summary>
        /// <Description>Converts service city query to business city input</Description>
        /// </summary>
        /// <param name="input">populate city request</param>
        /// <returns></returns>
        //public Buss.CityInput Convert(PopulateCityRequest input)
        //{
        //    Buss.CityInput objCityInput = new Buss.CityInput();
        //    try
        //    {
        //        objCityInput.CountryCode = input.PopulateRequest.CountryCode;
        //        objCityInput.CityName = input.PopulateRequest.CityName;
        //        objCityInput.MaxRecords = input.PopulateRequest.MaxRecords;
        //        objCityInput.MacID = input.PopulateRequest.MacID;
        //        objCityInput.IPAddress = input.PopulateRequest.IPAddress;
        //        objCityInput.ComputerName = input.PopulateRequest.ComputerName;
        //        objCityInput.CreatedUserID = input.PopulateRequest.CreatedUserID;
        //        objCityInput.CreatedUserDate = input.PopulateRequest.CreatedUserDate;
        //        objCityInput.ModifiedUserID = input.PopulateRequest.ModifiedUserID;
        //        objCityInput.ModifiedUserDate = input.PopulateRequest.ModifiedUserDate;
        //        objCityInput.DomainName = input.PopulateRequest.DomainName;
        //        objCityInput.STDinput = new Buss.StandardInput();
        //        objCityInput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objCityInput;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        public BusinessEntities.ClientDeployementInput Convert(Serv.ClientDeploymentInfo input)
        {
            Buss.ClientDeployementInput objDeploymentinput = new Buss.ClientDeployementInput();
            try
            {
                objDeploymentinput.ApplicationPath = input.ApplicationPath;
                objDeploymentinput.ComputerName = input.ComputerName;
                objDeploymentinput.ExeTimeStamp = input.ExeTimeStamp;
                objDeploymentinput.ExeVersionNo = input.ExeVersionNo;
                objDeploymentinput.IPAddress = input.IPAddress;
                objDeploymentinput.LatestVersionNo = input.LatestVersionNo;
                objDeploymentinput.NACId = input.NACId;
                objDeploymentinput.TimeStamp = input.TimeStamp;
                objDeploymentinput.UserId = input.UserId;
                objDeploymentinput.App_Name = input.App_Name;

                if (input.App_ID == null || input.App_ID.ToString() == "")
                {
                    objDeploymentinput.App_ID = "1";
                }
                else
                {
                    objDeploymentinput.App_ID = input.App_ID;
                }

            }
            catch (Exception ex)
            {

            }
            return objDeploymentinput;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="?"></param>
        /// <returns></returns>
        public BusinessEntities.ClientUsageInput Convert(Serv.ClientUsageInfo input)
        {
            Buss.ClientUsageInput objusageinput = new Buss.ClientUsageInput();
            try
            {
                objusageinput.Version = input.Version;
                objusageinput.Start_DT = input.Start_DT;
                objusageinput.IP = input.IP;
                objusageinput.End_DT = input.End_DT;
                objusageinput.NACId = input.NACId;
                objusageinput.ComputerName = input.ComputerName;
                objusageinput.TransID = input.TransID;
                if (input.App_ID.ToString() == null || input.App_ID.ToString() == "")
                {
                    objusageinput.App_ID = 1;
                }
                else
                {
                    objusageinput.App_ID = input.App_ID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objusageinput;
        }

        /// <summary>
        ///  <Description>Converts service GlobalCategoryInput query to business GlobalCategoryInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.GlobalCategoryInput Convert(Serv.GlobalCategoryQuery input)
        //{
        //    Buss.GlobalCategoryInput objGlobalCategoryInput = new Buss.GlobalCategoryInput();
        //    try
        //    {
        //        objGlobalCategoryInput.LabelID = input.LabelID;
        //        objGlobalCategoryInput.LabelName = input.LabelName;
        //        objGlobalCategoryInput.ActiveID = input.ActiveID;

        //        objGlobalCategoryInput.MacID = input.MacID;
        //        objGlobalCategoryInput.IPAddress = input.IPAddress;
        //        objGlobalCategoryInput.ComputerName = input.ComputerName;
        //        objGlobalCategoryInput.CreatedUserID = input.CreatedUserID;
        //        objGlobalCategoryInput.CreatedUserDate = input.CreatedUserDate;
        //        objGlobalCategoryInput.ModifiedUserID = input.ModifiedUserID;
        //        objGlobalCategoryInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objGlobalCategoryInput.DomainName = input.DomainName;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objGlobalCategoryInput;
        //}

        /// <summary>
        ///  <Description>Converts service OtherInfoInput query to business GlobalCategoryInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.OtherInfoInput Convert(Serv.OtherInfoQuery input)
        //{
        //    Buss.OtherInfoInput objOtherInfoInput = new Buss.OtherInfoInput();
        //    try
        //    {
        //        objOtherInfoInput.OtherInfoLabel_ID = input.OtherInfoLabel_ID;
        //        objOtherInfoInput.OtherInfoLabel_NM = input.OtherInfoLabel_NM;
        //        objOtherInfoInput.Mode = input.Mode;
        //        objOtherInfoInput.ActiveID = input.ActiveID;
        //        objOtherInfoInput.MacID = input.MacID;
        //        objOtherInfoInput.IPAddress = input.IPAddress;
        //        objOtherInfoInput.ComputerName = input.ComputerName;
        //        objOtherInfoInput.CreatedUserID = input.CreatedUserID;
        //        objOtherInfoInput.CreatedUserDate = input.CreatedUserDate;
        //        objOtherInfoInput.ModifiedUserID = input.ModifiedUserID;
        //        objOtherInfoInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objOtherInfoInput.DomainName = input.DomainName;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        //Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objOtherInfoInput;
        //}

        /// <summary>
        /// <Description>Converts service SearchLink query to business SearchLink input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.SearchLinkInput Convert(Serv.SearchLinkQuery input)
        //{
        //    Buss.SearchLinkInput objSearchLinkInput = new Buss.SearchLinkInput();
        //    try
        //    {
        //        objSearchLinkInput.AccountCode = input.AccountCode;
        //        objSearchLinkInput.CarrierCode = input.CarrierCode;
        //        objSearchLinkInput.ComputerName = input.ComputerName;
        //        objSearchLinkInput.DomainName = input.DomainName;
        //        objSearchLinkInput.FromCityCode = input.FromCityCode;
        //        objSearchLinkInput.FromCountryCode = input.FromCountryCode;
        //        objSearchLinkInput.IPAddress = input.IPAddress;
        //        objSearchLinkInput.ToCityCode = input.ToCityCode;
        //        objSearchLinkInput.ToCountryCode = input.ToCountryCode;
        //        objSearchLinkInput.UserName = input.UserName;
        //        objSearchLinkInput.AggregationRule = input.AggregationRule;
        //        objSearchLinkInput.IsAdmin = input.IsAdmin;
        //        objSearchLinkInput.Mode = input.Mode;
        //        objSearchLinkInput.GlobalCode = input.GlobalCode;
        //        objSearchLinkInput.MacID = input.MacID;
        //        objSearchLinkInput.CreatedUserID = input.CreatedUserID;
        //        objSearchLinkInput.CreatedUserDate = input.CreatedUserDate;
        //        objSearchLinkInput.ModifiedUserID = input.ModifiedUserID;
        //        objSearchLinkInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objSearchLinkInput.LanguageCode = input.LanguageCode;
        //        objSearchLinkInput.LanguageRest = input.LanguageRest;
        //        objSearchLinkInput.InputDate = input.InputDate;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);

        //    }

        //    return objSearchLinkInput;
        //}

        /// <summary>
        ///  <Description>Converts service Link query to business Link input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.Link[] Convert(Serv.Link[] input)
        //{
        //    Buss.Link[] updateLink = new Buss.Link[input.Length];
        //    Buss.LinkDetails[] updateLinkDetails = new Buss.LinkDetails[1];
        //    Buss.LinkCategoryDetails[] updateLinkCategoryDetails = new Buss.LinkCategoryDetails[1];

        //    //int incLinkDetail = 0;
        //    //int incLinkCatgDetail = 0;
        //    try
        //    {
        //        for (int counter = 0; counter < input.Length; counter++)
        //        {
        //            updateLink[counter] = new AmericanExpress.GDU.BusinessEntities.Link();
        //            updateLink[counter].LinkID = input[counter].LinkID;
        //            updateLink[counter].GlobalID = input[counter].GlobalID;
        //            updateLink[counter].LabelID = input[counter].LabelID;
        //            updateLink[counter].LabelName = input[counter].LabelName;
        //            updateLink[counter].GlobalText = input[counter].GlobalText;
        //            updateLink[counter].AccountCode = input[counter].AccountCode;
        //            updateLink[counter].CountryCode = input[counter].CountryCode;
        //            updateLink[counter].CityCode = input[counter].CityCode;
        //            updateLink[counter].CarrierCode = input[counter].CarrierCode;
        //            updateLink[counter].ClientID = input[counter].ClientID;
        //            updateLink[counter].ClientCD = input[counter].ClientCD;
        //            updateLink[counter].Search_Path = input[counter].Search_Path;
        //            updateLink[counter].MacID = input[counter].MacID;
        //            updateLink[counter].ComputerName = input[counter].ComputerName;
        //            updateLink[counter].IPAddress = input[counter].IPAddress;
        //            updateLink[counter].CreatedUserID = input[counter].CreatedUserID;
        //            updateLink[counter].CreatedUserDate = input[counter].CreatedUserDate;
        //            updateLink[counter].ModifiedUserID = input[counter].ModifiedUserID;
        //            updateLink[counter].ModifiedUserDate = input[counter].ModifiedUserDate;
        //            updateLink[counter].DomainName = input[counter].DomainName;

        //            if (input[counter].LinkDetails != null)
        //            {
        //                updateLinkDetails[0] = new Buss.LinkDetails();
        //                updateLinkDetails[0].LinkDetailID = input[counter].LinkDetails[0].LinkDetailID;
        //                updateLinkDetails[0].LinkID = input[counter].LinkDetails[0].LinkID;
        //                updateLinkDetails[0].LinkTypeCode = input[counter].LinkDetails[0].LinkTypeCode;
        //                updateLinkDetails[0].Link = input[counter].LinkDetails[0].Link;
        //                updateLinkDetails[0].LabelID = input[counter].LinkDetails[0].LabelID;
        //                updateLinkDetails[0].LabelName = input[counter].LinkDetails[0].LabelName;
        //                updateLinkDetails[0].LinkType = input[counter].LinkDetails[0].LinkType;
        //                updateLinkDetails[0].LanguageCode = input[counter].LinkDetails[0].LanguageCode;
        //                updateLinkDetails[0].DownloadFlag = input[counter].LinkDetails[0].DownloadFlag;
        //                updateLinkDetails[0].HoverText = input[counter].LinkDetails[0].HoverText;
        //                updateLinkDetails[0].GeneralText = input[counter].LinkDetails[0].GeneralText;
        //                updateLinkDetails[0].ValidFromDate = input[counter].LinkDetails[0].ValidFromDate;
        //                updateLinkDetails[0].ValidToDate = input[counter].LinkDetails[0].ValidToDate;
        //                updateLinkDetails[0].Keyword = input[counter].LinkDetails[0].Keyword;
        //                updateLinkDetails[0].MacID = input[counter].LinkDetails[0].MacID;
        //                updateLinkDetails[0].ComputerName = input[counter].LinkDetails[0].ComputerName;
        //                updateLinkDetails[0].IPAddress = input[counter].LinkDetails[0].IPAddress;
        //                updateLinkDetails[0].CreatedUserID = input[counter].LinkDetails[0].CreatedUserID;
        //                updateLinkDetails[0].CreatedUserDate = input[counter].LinkDetails[0].CreatedUserDate;
        //                updateLinkDetails[0].ModifiedUserID = input[counter].LinkDetails[0].ModifiedUserID;
        //                updateLinkDetails[0].ModifiedUserDate = input[counter].LinkDetails[0].ModifiedUserDate;
        //                updateLinkDetails[0].DomainName = input[counter].LinkDetails[0].DomainName;
        //                updateLinkDetails[0].IsApprove = input[counter].LinkDetails[0].IsApprove;

        //                if (input[counter].LinkDetails[0].LinkCategoryDetails[0] != null)
        //                {
        //                    updateLinkCategoryDetails[0] = new Buss.LinkCategoryDetails();
        //                    updateLinkCategoryDetails[0].LinkCategoryDetailID = input[counter].LinkDetails[0].LinkCategoryDetails[0].LinkCategoryDetailID;
        //                    updateLinkCategoryDetails[0].LinkDetailID = input[counter].LinkDetails[0].LinkCategoryDetails[0].LinkDetailID;
        //                    updateLinkCategoryDetails[0].Link = input[counter].LinkDetails[0].LinkCategoryDetails[0].Link;
        //                    updateLinkCategoryDetails[0].LabelID = input[counter].LinkDetails[0].LinkCategoryDetails[0].LabelID;
        //                    updateLinkCategoryDetails[0].LabelName = input[counter].LinkDetails[0].LinkCategoryDetails[0].LabelName;
        //                    updateLinkCategoryDetails[0].LinkType = input[counter].LinkDetails[0].LinkCategoryDetails[0].LinkType;
        //                    updateLinkCategoryDetails[0].LanguageCode = input[counter].LinkDetails[0].LinkCategoryDetails[0].LanguageCode;
        //                    updateLinkCategoryDetails[0].DownloadFlag = input[counter].LinkDetails[0].LinkCategoryDetails[0].DownloadFlag;
        //                    updateLinkCategoryDetails[0].HoverText = input[counter].LinkDetails[0].LinkCategoryDetails[0].HoverText;
        //                    updateLinkCategoryDetails[0].Keyword = input[counter].LinkDetails[0].LinkCategoryDetails[0].Keyword;
        //                    updateLinkCategoryDetails[0].MacID = input[counter].LinkDetails[0].LinkCategoryDetails[0].MacID;
        //                    updateLinkCategoryDetails[0].IPAddress = input[counter].LinkDetails[0].LinkCategoryDetails[0].IPAddress;
        //                    updateLinkCategoryDetails[0].ComputerName = input[counter].LinkDetails[0].LinkCategoryDetails[0].ComputerName;
        //                    updateLinkCategoryDetails[0].CreatedUserID = input[counter].LinkDetails[0].LinkCategoryDetails[0].CreatedUserID;
        //                    updateLinkCategoryDetails[0].CreatedUserDate = input[counter].LinkDetails[0].LinkCategoryDetails[0].CreatedUserDate;
        //                    updateLinkCategoryDetails[0].ModifiedUserID = input[counter].LinkDetails[0].LinkCategoryDetails[0].ModifiedUserID;
        //                    updateLinkCategoryDetails[0].ModifiedUserDate = input[counter].LinkDetails[0].LinkCategoryDetails[0].ModifiedUserDate;
        //                    updateLinkCategoryDetails[0].DomainName = input[counter].LinkDetails[0].LinkCategoryDetails[0].DomainName;
        //                    updateLinkCategoryDetails[0].IsApprove = input[counter].LinkDetails[0].LinkCategoryDetails[0].IsApprove;
        //                    updateLinkDetails[0].LinkCategoryDetails = updateLinkCategoryDetails;
        //                }

        //                updateLink[counter].LinkDetails = updateLinkDetails;
        //            }
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return updateLink;
        //}

        //public Buss.GeneralInfoLink[] Convert(Serv.GeneralInfoLink[] input)
        //{
        //    Buss.GeneralInfoLink[] generalInfoLink = new Buss.GeneralInfoLink[input.Length];
        //    Buss.GeneralInfoLinkDetails[] generalInfoLinkDetails = new Buss.GeneralInfoLinkDetails[1];
        //    try
        //    {
        //        for (int counter = 0; counter < input.Length; counter++)
        //        {
        //            generalInfoLink[counter] = new AmericanExpress.GDU.BusinessEntities.GeneralInfoLink();
        //            generalInfoLink[counter].LinkID = input[counter].LinkID;
        //            generalInfoLink[counter].GlobalID = input[counter].GlobalID;
        //            generalInfoLink[counter].AccountCode = input[counter].AccountCode;
        //            generalInfoLink[counter].CountryCode = input[counter].CountryCode;
        //            generalInfoLink[counter].CityCode = input[counter].CityCode;
        //            generalInfoLink[counter].CarrierCode = input[counter].CarrierCode;
        //            generalInfoLink[counter].DomainName = input[counter].DomainName;
        //            generalInfoLink[counter].UserName = input[counter].UserName;
        //            generalInfoLink[counter].ComputerName = input[counter].ComputerName;
        //            generalInfoLink[counter].IPAddress = input[counter].IPAddress;
        //            generalInfoLink[counter].CreatedUserID = input[counter].CreatedUserID;
        //            generalInfoLink[counter].ModifiedUserID = input[counter].ModifiedUserID;
        //            generalInfoLink[counter].NacID = input[counter].NacID;
        //            generalInfoLink[counter].CreatedUserDate = input[counter].CreatedUserDate;
        //            generalInfoLink[counter].ModifiedUserDate = input[counter].ModifiedUserDate;

        //            if (input[counter].GeneralInfoLinkDetails != null)
        //            {
        //                generalInfoLinkDetails[counter] = new AmericanExpress.GDU.BusinessEntities.GeneralInfoLinkDetails();
        //                generalInfoLinkDetails[counter].GeneralInfoID = input[counter].GeneralInfoLinkDetails[0].GeneralInfoID;
        //                generalInfoLinkDetails[counter].LinkID = input[counter].GeneralInfoLinkDetails[0].LinkID;
        //                generalInfoLinkDetails[counter].GeneralText = input[counter].GeneralInfoLinkDetails[0].GeneralText;
        //                generalInfoLinkDetails[counter].ValidFromDate = input[counter].GeneralInfoLinkDetails[0].ValidFromDate;
        //                generalInfoLinkDetails[counter].ValidToDate = input[counter].GeneralInfoLinkDetails[0].ValidToDate;
        //                generalInfoLinkDetails[counter].DisplayValidFromMonth = input[counter].GeneralInfoLinkDetails[0].DisplayValidFromMonth;
        //                generalInfoLinkDetails[counter].DisplayValidToMonth = input[counter].GeneralInfoLinkDetails[0].DisplayValidToMonth;
        //                generalInfoLinkDetails[counter].DisplayValidFromDay = input[counter].GeneralInfoLinkDetails[0].DisplayValidFromDay;
        //                generalInfoLinkDetails[counter].DisplayValidToDay = input[counter].GeneralInfoLinkDetails[0].DisplayValidToDay;
        //                generalInfoLinkDetails[counter].Visible_To_Client = input[counter].GeneralInfoLinkDetails[0].Visible_To_Client;
        //                generalInfoLinkDetails[counter].DomainName = input[counter].GeneralInfoLinkDetails[0].DomainName;
        //                generalInfoLinkDetails[counter].ComputerName = input[counter].GeneralInfoLinkDetails[0].ComputerName;
        //                generalInfoLinkDetails[counter].IPAddress = input[counter].GeneralInfoLinkDetails[0].IPAddress;
        //                generalInfoLinkDetails[counter].CreatedUserID = input[counter].GeneralInfoLinkDetails[0].CreatedUserID;
        //                generalInfoLinkDetails[counter].ModifiedUserID = input[counter].GeneralInfoLinkDetails[0].ModifiedUserID;
        //                generalInfoLinkDetails[counter].NacID = input[counter].GeneralInfoLinkDetails[0].NacID;
        //                generalInfoLinkDetails[counter].CreatedUserDate = input[counter].GeneralInfoLinkDetails[0].CreatedUserDate;
        //                generalInfoLinkDetails[counter].ModifiedUserDate = input[counter].GeneralInfoLinkDetails[0].ModifiedUserDate;
        //            }

        //            generalInfoLink[counter].GeneralInfoLinkDetails = generalInfoLinkDetails;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);

        //    }

        //    return generalInfoLink;
        //}

        /// <summary>
        ///  <Description>Converts service DeleteLink query to business DeleteLink input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.DeleteLink Convert(Serv.DeleteLink input)
        //{
        //    Buss.DeleteLink deleteLink = new Buss.DeleteLink();
        //    Buss.DeleteLinkDetails[] deleteLinkDetails = new Buss.DeleteLinkDetails[1];
        //    Buss.DeleteLinkCategoryDetails[] deleteLinkCategoryDetails = new Buss.DeleteLinkCategoryDetails[1];
        //    try
        //    {
        //        deleteLink.LinkID = input.LinkID;
        //        deleteLink.DomainName = input.DomainName;
        //        deleteLink.UserName = input.UserName;
        //        deleteLink.ComputerName = input.ComputerName;
        //        deleteLink.IPAddress = input.IPAddress;
        //        deleteLink.CreatedUserID = input.CreatedUserID;
        //        deleteLink.CreatedUserDate = input.CreatedUserDate;
        //        deleteLink.ModifiedUserID = input.ModifiedUserID;
        //        deleteLink.ModifiedUserDate = input.ModifiedUserDate;
        //        deleteLink.MacID = input.MacID;
        //        deleteLink.Mode = input.Mode;

        //        if (input.LinkDetailID != null)
        //        {
        //            deleteLinkDetails[0] = new Buss.DeleteLinkDetails();
        //            deleteLinkDetails[0].LinkDetailID = input.LinkDetailID[0].LinkDetailID;
        //            deleteLinkDetails[0].MacID = input.LinkDetailID[0].MacID;
        //            deleteLinkDetails[0].ComputerName = input.LinkDetailID[0].ComputerName;
        //            deleteLinkDetails[0].IPAddress = input.LinkDetailID[0].IPAddress;
        //            deleteLinkDetails[0].CreatedUserID = input.LinkDetailID[0].CreatedUserID;
        //            deleteLinkDetails[0].CreatedUserDate = input.LinkDetailID[0].CreatedUserDate;
        //            deleteLinkDetails[0].ModifiedUserID = input.LinkDetailID[0].ModifiedUserID;
        //            deleteLinkDetails[0].ModifiedUserDate = input.LinkDetailID[0].ModifiedUserDate;
        //            deleteLinkDetails[0].DomainName = input.LinkDetailID[0].DomainName;
        //            deleteLinkDetails[0].Mode = input.LinkDetailID[0].Mode;

        //            if (input.LinkDetailID[0].LinkCategoryDetailID != null)
        //            {
        //                deleteLinkCategoryDetails[0] = new Buss.DeleteLinkCategoryDetails();
        //                deleteLinkCategoryDetails[0].LinkCategoryDetailID = input.LinkDetailID[0].LinkCategoryDetailID[0].LinkCategoryDetailID;
        //                deleteLinkCategoryDetails[0].MacID = input.LinkDetailID[0].LinkCategoryDetailID[0].MacID;
        //                deleteLinkCategoryDetails[0].IPAddress = input.LinkDetailID[0].LinkCategoryDetailID[0].IPAddress;
        //                deleteLinkCategoryDetails[0].ComputerName = input.LinkDetailID[0].LinkCategoryDetailID[0].ComputerName;
        //                deleteLinkCategoryDetails[0].CreatedUserID = input.LinkDetailID[0].LinkCategoryDetailID[0].CreatedUserID;
        //                deleteLinkCategoryDetails[0].CreatedUserDate = input.LinkDetailID[0].LinkCategoryDetailID[0].CreatedUserDate;
        //                deleteLinkCategoryDetails[0].ModifiedUserID = input.LinkDetailID[0].LinkCategoryDetailID[0].ModifiedUserID;
        //                deleteLinkCategoryDetails[0].ModifiedUserDate = input.LinkDetailID[0].LinkCategoryDetailID[0].ModifiedUserDate;
        //                deleteLinkCategoryDetails[0].DomainName = input.LinkDetailID[0].LinkCategoryDetailID[0].DomainName;
        //                deleteLinkCategoryDetails[0].Mode = input.LinkDetailID[0].LinkCategoryDetailID[0].Mode;
        //            }
        //        }

        //        deleteLinkDetails[0].LinkCategoryDetailID = deleteLinkCategoryDetails;
        //        deleteLink.LinkDetailID = deleteLinkDetails;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return deleteLink;

        //}
        /// <summary>
        ///  <Description>Converts service SearchOtherInfo query to business SearchOtherInfo input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.SearchOtherInfoInput Convert(Serv.SearchOtherInfoQuery input)
        //{
        //    Buss.SearchOtherInfoInput objSearchOtherInfoInput = new Buss.SearchOtherInfoInput();
        //    try
        //    {
        //        objSearchOtherInfoInput.ComputerName = input.ComputerName;
        //        objSearchOtherInfoInput.DomainName = input.DomainName;
        //        objSearchOtherInfoInput.IPAddress = input.IPAddress;
        //        objSearchOtherInfoInput.UserName = input.UserName;
        //        objSearchOtherInfoInput.OtherInfoCode = input.OtherInfoCode;
        //        objSearchOtherInfoInput.MacID = input.MacID;
        //        objSearchOtherInfoInput.CreatedUserID = input.CreatedUserID;
        //        objSearchOtherInfoInput.CreatedUserDate = input.CreatedUserDate;
        //        objSearchOtherInfoInput.ModifiedUserID = input.ModifiedUserID;
        //        objSearchOtherInfoInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objSearchOtherInfoInput.LanguageCD = input.LanguageCD;
        //        objSearchOtherInfoInput.Mode = input.Mode;
        //        objSearchOtherInfoInput.InputDate = input.InputDate;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objSearchOtherInfoInput;
        //}

        /// <summary>
        ///  <Description>Converts service CountryQuery query to business CountryInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.CountryInput Convert(PopulateCountryRequest input)
        //{
        //    Buss.CountryInput CountryInput = new Buss.CountryInput();
        //    try
        //    {
        //        CountryInput.CountryCode = input.PopulateRequest.CountryCode;
        //        CountryInput.CountryName = input.PopulateRequest.CountryName;
        //        CountryInput.MaxRecord = input.PopulateRequest.MaxRecord;
        //        CountryInput.MacID = input.PopulateRequest.MacID;
        //        CountryInput.IPAddress = input.PopulateRequest.IPAddress;
        //        CountryInput.ComputerName = input.PopulateRequest.ComputerName;
        //        CountryInput.CreatedUserID = input.PopulateRequest.CreatedUserID;
        //        CountryInput.CreatedUserDate = input.PopulateRequest.CreatedUserDate;
        //        CountryInput.ModifiedUserID = input.PopulateRequest.ModifiedUserID;
        //        CountryInput.ModifiedUserDate = input.PopulateRequest.ModifiedUserDate;
        //        CountryInput.DomainName = input.PopulateRequest.DomainName;
        //        CountryInput.STDinput = new Buss.StandardInput();
        //        CountryInput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
        //    }

        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return CountryInput;
        //}

        /// <summary>
        ///  <Description>Converts service CountryQuery query to business CountryInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.MappingInput Convert(Serv.MappingQuery input)
        //{
        //    Buss.MappingInput mappingInput = new Buss.MappingInput();
        //    try
        //    {
        //        mappingInput.Input_CD = input.Input_CD;
        //        mappingInput.Input_Type = input.Input_Type;
        //        mappingInput.Mapping_Input_Type = input.Mapping_Input_Type;
        //    }

        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return mappingInput;
        //}


        public Buss.StandardInput Convert(StandardInput input)
        {
            Buss.StandardInput objinput = new Buss.StandardInput();
            try
            {
                objinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.EnumType.ToString());

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objinput;
        }

        //public Buss.AccountInput Convert(AccountRequest input)
        //{
        //    Buss.AccountInput objinput = new Buss.AccountInput();
        //    try
        //    {
        //        objinput.STDinput = new Buss.StandardInput();
        //        objinput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
        //        objinput.ClientID = input.PopulateRequest.ClientID;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}



        //public Buss.AccountMappingInput[] Convert(Serv.AccountMapping input)
        //{
        //    Buss.AccountMappingInput[] objinput = new Buss.AccountMappingInput[input.MapAccountQuery.Length];
        //    try
        //    {
        //        for (int iCount = 0; iCount < input.MapAccountQuery.Length; iCount++)
        //        {
        //            objinput[iCount] = new Buss.AccountMappingInput();
        //            objinput[iCount].ComputerName = input.ComputerName;
        //            objinput[iCount].CreatedUserDate = input.CreatedUserDate;
        //            objinput[iCount].CreatedUserID = input.CreatedUserID;
        //            objinput[iCount].DomainName = input.DomainName;
        //            objinput[iCount].IPAddress = input.IPAddress;
        //            objinput[iCount].MacID = input.MacID;
        //            objinput[iCount].ModifiedUserDate = input.ModifiedUserDate;
        //            objinput[iCount].ModifiedUserID = input.ModifiedUserID;
        //            objinput[iCount].RealAcc = input.MapAccountQuery[iCount].RealAcc;
        //            objinput[iCount].MappingCD = input.MapAccountQuery[iCount].MappingCD;
        //            objinput[iCount].VirtualAcc = input.MapAccountQuery[iCount].VirtualAcc;
        //            objinput[iCount].Mode = input.MapAccountQuery[iCount].Mode;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}

        //public Buss.CityMappingInput[] Convert(Serv.CityMapping input)
        //{
        //    Buss.CityMappingInput[] objinput = new Buss.CityMappingInput[input.MapCityQuery.Length];
        //    try
        //    {
        //        for (int iCount = 0; iCount < input.MapCityQuery.Length; iCount++)
        //        {
        //            objinput[iCount] = new Buss.CityMappingInput();
        //            objinput[iCount].ComputerName = input.ComputerName;
        //            objinput[iCount].CreatedUserDate = input.CreatedUserDate;
        //            objinput[iCount].CreatedUserID = input.CreatedUserID;
        //            objinput[iCount].DomainName = input.DomainName;
        //            objinput[iCount].IPAddress = input.IPAddress;
        //            objinput[iCount].MacID = input.MacID;
        //            objinput[iCount].ModifiedUserDate = input.ModifiedUserDate;
        //            objinput[iCount].ModifiedUserID = input.ModifiedUserID;
        //            objinput[iCount].VirtualCity = input.MapCityQuery[iCount].VirtualCity;
        //            objinput[iCount].RealCity = input.MapCityQuery[iCount].RealCity;
        //            objinput[iCount].MappingCD = input.MapCityQuery[iCount].MappingCD;
        //            objinput[iCount].Mode = input.MapCityQuery[iCount].Mode;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}


        //public Buss.CountryMappingInput[] Convert(Serv.CountryMapping input)
        //{
        //    Buss.CountryMappingInput[] objinput = new Buss.CountryMappingInput[input.MapCountryQuery.Length];
        //    try
        //    {
        //        for (int iCount = 0; iCount < input.MapCountryQuery.Length; iCount++)
        //        {
        //            objinput[iCount] = new Buss.CountryMappingInput();
        //            objinput[iCount].ComputerName = input.ComputerName;
        //            objinput[iCount].CreatedUserDate = input.CreatedUserDate;
        //            objinput[iCount].CreatedUserID = input.CreatedUserID;
        //            objinput[iCount].DomainName = input.DomainName;
        //            objinput[iCount].IPAddress = input.IPAddress;
        //            objinput[iCount].MacID = input.MacID;
        //            objinput[iCount].ModifiedUserDate = input.ModifiedUserDate;
        //            objinput[iCount].ModifiedUserID = input.ModifiedUserID;
        //            objinput[iCount].RealCoun = input.MapCountryQuery[iCount].RealCountry;
        //            objinput[iCount].MappingCD = input.MapCountryQuery[iCount].MappingCD;
        //            objinput[iCount].VirtualCoun = input.MapCountryQuery[iCount].VirtualCountry;
        //            objinput[iCount].Mode = input.MapCountryQuery[iCount].Mode;
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}

        /// <summary>
        ///  <Description>Converts service FeedBackDetails query to business FeedbackInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.FeedbackInput Convert(Serv.FeedBackDetails input)
        //{
        //    Buss.FeedbackInput objFeedbackInput = new Buss.FeedbackInput();
        //    try
        //    {
        //        objFeedbackInput.AdsId = input.AdsId;
        //        objFeedbackInput.CreatedDate = input.CreatedDate;
        //        objFeedbackInput.CreatedUserId = input.CreatedUserId;
        //        objFeedbackInput.FeedBackId = input.FeedBackId;
        //        objFeedbackInput.FeedbackRemark = input.FeedbackRemark;
        //        objFeedbackInput.LinkTypeCode = input.LinkTypeCode;
        //        objFeedbackInput.Mode = input.Mode;
        //        objFeedbackInput.ModifiedDate = input.ModifiedDate;
        //        objFeedbackInput.ModifiedUserID = input.ModifiedUserID;
        //        objFeedbackInput.Rating = input.Rating;
        //        objFeedbackInput.LabelId = input.LabelId;
        //        objFeedbackInput.FeedBackType = input.FeedBackType;
        //        objFeedbackInput.ClientID = input.ClientID;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objFeedbackInput;

        //}

        /// <summary>
        ///  <Description>Converts service TransactionQuery query to business TransactionIdInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.TransactionIdInput Convert(Serv.TransactionQuery input)
        //{
        //    Buss.TransactionIdInput objTransactionInput = new Buss.TransactionIdInput();
        //    try
        //    {
        //        objTransactionInput.AccountCode = input.AccountCode;
        //        objTransactionInput.CarrierCode = input.CarrierCode;
        //        objTransactionInput.CityCode = input.CityCode;
        //        objTransactionInput.CountryCode = input.CountryCode;
        //        objTransactionInput.GlobalCatCode = input.GlobalCatCode;
        //        objTransactionInput.OtherInfoCode = input.OtherInfoCode;
        //        objTransactionInput.MacID = input.MacID;
        //        objTransactionInput.IPAddress = input.IPAddress;
        //        objTransactionInput.ComputerName = input.ComputerName;
        //        objTransactionInput.CreatedUserID = input.CreatedUserID;
        //        objTransactionInput.CreatedUserDate = input.CreatedUserDate;
        //        objTransactionInput.ModifiedUserID = input.ModifiedUserID;
        //        objTransactionInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objTransactionInput.DomainName = input.DomainName;
        //        objTransactionInput.clientID = input.clientID;

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objTransactionInput;
        //}

        /// <summary>
        /// <Description>Converts service OtherInfo query to business OtherInfo input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.OtherInfo Convert(Serv.OtherInfo input)
        //{
        //    Buss.OtherInfo otherInfo = new Buss.OtherInfo();
        //    Buss.UpdateOtherInfoDetails[] otherInfoDetails = new Buss.UpdateOtherInfoDetails[1];
        //    try
        //    {
        //        otherInfo.OtherInfoID = input.OtherInfoID;
        //        otherInfo.OtherInfoLabelID = input.OtherInfoLabelID;
        //        otherInfo.Search_Path = input.Search_Path;
        //        otherInfo.LinkTypeCode = input.LinkTypeCode;
        //        otherInfo.LabelID = input.LabelID;
        //        otherInfo.LabelName = input.LabelName;
        //        otherInfo.Link = input.Link;
        //        otherInfo.LinkType = input.LinkType;
        //        otherInfo.DownloadFlag = input.DownloadFlag;
        //        otherInfo.HoverText = input.HoverText;
        //        otherInfo.Keyword_Txt = input.Keyword;
        //        otherInfo.LanguageCode = input.LanguageCode;
        //        otherInfo.GeneralText = input.GeneralText;
        //        otherInfo.Priority = input.Priority;
        //        otherInfo.DomainName = input.DomainName;
        //        otherInfo.UserName = input.UserName;
        //        otherInfo.ComputerName = input.ComputerName;
        //        otherInfo.IPAddress = input.IPAddress;
        //        otherInfo.ValidFromDate = input.ValidFromDate;
        //        otherInfo.ValidToDate = input.ValidToDate;
        //        otherInfo.MacID = input.MacID;
        //        otherInfo.CreatedUserID = input.CreatedUserID;
        //        otherInfo.CreatedUserDate = input.CreatedUserDate;
        //        otherInfo.ModifiedUserID = input.ModifiedUserID;
        //        otherInfo.ModifiedUserDate = input.ModifiedUserDate;
        //        otherInfo.IsApprove = input.IsApprove;                

        //        if (input.OtherInfoDetails != null)
        //        {
        //            otherInfoDetails[0] = new Buss.UpdateOtherInfoDetails();
        //            otherInfoDetails[0].OtherInfoDetailID = input.OtherInfoDetails[0].OtherInfoDetailID;
        //            otherInfoDetails[0].OtherInfoID = input.OtherInfoDetails[0].OtherInfoID;
        //            otherInfoDetails[0].LabelID = input.OtherInfoDetails[0].LabelID;
        //            otherInfoDetails[0].LabelName = input.OtherInfoDetails[0].LabelName;
        //            otherInfoDetails[0].Link = input.OtherInfoDetails[0].Link;
        //            otherInfoDetails[0].LinkType = input.OtherInfoDetails[0].LinkType;
        //            otherInfoDetails[0].DownloadFlag = input.OtherInfoDetails[0].DownloadFlag;
        //            otherInfoDetails[0].HoverText = input.OtherInfoDetails[0].HoverText;
        //            otherInfoDetails[0].Keyword_Txt = input.OtherInfoDetails[0].Keyword;
        //            otherInfoDetails[0].LanguageCode = input.OtherInfoDetails[0].LanguageCode;
        //            otherInfoDetails[0].GeneralText = input.OtherInfoDetails[0].GeneralText;
        //            otherInfoDetails[0].Priority = input.OtherInfoDetails[0].Priority;
        //            otherInfoDetails[0].MacID = input.OtherInfoDetails[0].MacID;
        //            otherInfoDetails[0].IPAddress = input.OtherInfoDetails[0].IPAddress;
        //            otherInfoDetails[0].ComputerName = input.OtherInfoDetails[0].ComputerName;
        //            otherInfoDetails[0].CreatedUserID = input.OtherInfoDetails[0].CreatedUserID;
        //            otherInfoDetails[0].CreatedUserDate = input.OtherInfoDetails[0].CreatedUserDate;
        //            otherInfoDetails[0].ModifiedUserID = input.OtherInfoDetails[0].ModifiedUserID;
        //            otherInfoDetails[0].ModifiedUserDate = input.OtherInfoDetails[0].ModifiedUserDate;
        //            otherInfoDetails[0].DomainName = input.OtherInfoDetails[0].DomainName;
        //            otherInfoDetails[0].IsApprove = input.OtherInfoDetails[0].IsApprove;
        //        }

        //        otherInfo.OtherInfoDetails = otherInfoDetails;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return otherInfo;
        //}

        //public Buss.GeneralInfoOtherInfoDetails Convert(Serv.GeneralInfoOtherInfoDetails input)
        //{
        //    Buss.GeneralInfoOtherInfoDetails generalInfoOtherInfoDetails = new Buss.GeneralInfoOtherInfoDetails();
        //    try
        //    {
        //        generalInfoOtherInfoDetails.oi_generalinfo_id = input.oi_generalinfo_id;
        //        generalInfoOtherInfoDetails.otherinfo_id = input.otherinfo_id;
        //        generalInfoOtherInfoDetails.GeneralText = input.GeneralText;
        //        generalInfoOtherInfoDetails.ValidFromDate = input.ValidFromDate;
        //        generalInfoOtherInfoDetails.ValidToDate = input.ValidToDate;
        //        generalInfoOtherInfoDetails.DisplayValidFromMonth = input.DisplayValidFromMonth;
        //        generalInfoOtherInfoDetails.DisplayValidToMonth = input.DisplayValidToMonth;
        //        generalInfoOtherInfoDetails.DisplayValidFromDay = input.DisplayValidFromDay;
        //        generalInfoOtherInfoDetails.DisplayValidToDay = input.DisplayValidToDay;
        //        generalInfoOtherInfoDetails.Visible_To_Client = input.Visible_To_Client;
        //        generalInfoOtherInfoDetails.DomainName = input.DomainName;
        //        generalInfoOtherInfoDetails.ComputerName = input.ComputerName;
        //        generalInfoOtherInfoDetails.IPAddress = input.IPAddress;
        //        generalInfoOtherInfoDetails.NacID = input.NacID;
        //        generalInfoOtherInfoDetails.CreatedUserID = input.CreatedUserID;
        //        generalInfoOtherInfoDetails.ModifiedUserID = input.ModifiedUserID;
        //        generalInfoOtherInfoDetails.CreatedUserDate = input.CreatedUserDate;
        //        generalInfoOtherInfoDetails.ModifiedUserDate = input.ModifiedUserDate;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return generalInfoOtherInfoDetails;
        //}

        #region Carrier
        /// <summary>
        /// <Description>Converts service CarrierQuery query to business CarrierInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.CarrierInput Convert(Serv.CarrierQuery input)
        //{
        //    Buss.CarrierInput objCarrierInput = new Buss.CarrierInput();
        //    try
        //    {
        //        objCarrierInput.CarrierCode = input.CarrierCode;
        //        objCarrierInput.CarrierName = input.CarrierName;
        //        objCarrierInput.ModifiedDate = input.ModifiedDate;
        //        objCarrierInput.MacID = input.MacID;
        //        objCarrierInput.IPAddress = input.IPAddress;
        //        objCarrierInput.ComputerName = input.ComputerName;
        //        objCarrierInput.CreatedUserID = input.CreatedUserID;
        //        objCarrierInput.CreatedUserDate = input.CreatedUserDate;
        //        objCarrierInput.ModifiedUserID = input.ModifiedUserID;
        //        objCarrierInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objCarrierInput.DomainName = input.DomainName;
        //        objCarrierInput.IsDeactive = input.IsDeactive;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objCarrierInput;
        //}


        /// <summary>
        /// <Description>Converts service CarrierDetails query to business CarrierInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.CarrierInput Convert(Serv.CarrierDetails input)
        //{
        //    Buss.CarrierInput objCarrierInput = new Buss.CarrierInput();
        //    try
        //    {
        //        objCarrierInput.CarrierCode = input.CarrierCode;
        //        objCarrierInput.CarrierName = input.CarrierName;
        //        objCarrierInput.ModifiedDate = input.ModifiedDate;
        //        objCarrierInput.UserID = input.UserName;
        //        objCarrierInput.Mode = input.Mode;
        //        objCarrierInput.MacID = input.MacID;
        //        objCarrierInput.IPAddress = input.IPAddress;
        //        objCarrierInput.ComputerName = input.ComputerName;
        //        objCarrierInput.CreatedUserID = input.CreatedUserID;
        //        objCarrierInput.CreatedUserDate = input.CreatedUserDate;
        //        objCarrierInput.ModifiedUserID = input.ModifiedUserID;
        //        objCarrierInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objCarrierInput.DomainName = input.DomainName;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objCarrierInput;
        //}

        #endregion
        #region User
        /// <summary>
        /// <Description>Converts service UserQuery query to business UserInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Buss.UserInput Convert(Serv.UserQuery input)
        {
            Buss.UserInput objUserInput = new Buss.UserInput();
            try
            {
                objUserInput.UserId = input.UserId;
                objUserInput.UserName = input.UserName;
                objUserInput.UserRole = input.UserRole;
                objUserInput.LanguageCode = input.LanguageCode;
                objUserInput.UserRoleCode = input.UserRoleCode;
                objUserInput.IsDeactive = input.IsDeactive;
                objUserInput.EmailAddress = input.EmailAddress;
                objUserInput.Language = input.Language;
                objUserInput.Mode = input.Mode;
                objUserInput.MacID = input.MacID;
                objUserInput.IPAddress = input.IPAddress;
                objUserInput.ComputerName = input.ComputerName;
                objUserInput.CreatedUserID = input.CreatedUserID;
                objUserInput.CreatedUserDate = input.CreatedUserDate;
                objUserInput.ModifiedUserID = input.ModifiedUserID;
                objUserInput.ModifiedUserDate = input.ModifiedUserDate;
                objUserInput.DomainName = input.DomainName;
                objUserInput.ClientId = input.ClientId;
                objUserInput.AuthorizedRoleIds = input.AuthorizedRoleIds;
                objUserInput.DefaultClientID = input.DefaultClientID;
                objUserInput.System_CD = input.System_CD;
                objUserInput.RequestedBy = input.RequestedBy;
                objUserInput.IsGrouping = input.IsGrouping;

                objUserInput.PageSize = input.PageSize;
                objUserInput.CurrentPage = input.CurrentPage;
                objUserInput.SortExpression = input.SortExpression;
                objUserInput.SortOrder = input.SortOrder;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objUserInput;
        }
        #endregion


        //public Buss.ManageAccountInput Convert(Serv.ManageAccountQuery input)
        //{
        //    Buss.ManageAccountInput objUserInput = new Buss.ManageAccountInput();
        //    try
        //    {
        //        objUserInput.AccountCode = input.AccountCode;
        //        objUserInput.AccountName = input.AccountName;
        //        objUserInput.IsGlobal = input.IsGlobal;
        //        objUserInput.IsVirtual = input.IsVirtual;
        //        objUserInput.IsDeactive = input.IsDeactive;
        //        objUserInput.Mode = input.Mode;
        //        objUserInput.MacID = input.MacID;
        //        objUserInput.IPAddress = input.IPAddress;
        //        objUserInput.ComputerName = input.ComputerName;
        //        objUserInput.CreatedUserID = input.CreatedUserID;
        //        objUserInput.CreatedUserDate = input.CreatedUserDate;
        //        objUserInput.ModifiedUserID = input.ModifiedUserID;
        //        objUserInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objUserInput.ClientID = input.ClientID;
        //        objUserInput.AccountType = input.AccountType;

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objUserInput;
        //}

        //#region Manage Country
        //public Buss.ManageCountryInput Convert(Serv.ManageCountryQuery input)
        //{
        //    Buss.ManageCountryInput objUserInput = new Buss.ManageCountryInput();
        //    try
        //    {
        //        objUserInput.CountryCode = input.CountryCode;
        //        objUserInput.CountryName = input.CountryName;
        //        objUserInput.IsGlobal = input.IsGlobal;
        //        objUserInput.IsVirtual = input.IsVirtual;
        //        objUserInput.IsDeactive = input.IsDeactive;
        //        objUserInput.CreatedUserID = input.CreatedUserID;
        //        objUserInput.CreatedUserDate = input.CreatedUserDate;
        //        objUserInput.ModifiedUserID = input.ModifiedUserID;
        //        objUserInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objUserInput.Mode = input.Mode;
        //        objUserInput.CountryType = input.CountryType;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objUserInput;
        //}
        //#endregion

        //public Buss.ManageCityInput Convert(Serv.ManageCityQuery input)
        //{
        //    Buss.ManageCityInput objUserInput = new Buss.ManageCityInput();
        //    try
        //    {
        //        objUserInput.CityCode = input.CityCode;
        //        objUserInput.CityName = input.CityName;
        //        objUserInput.IsGlobal = input.IsGlobal;
        //        objUserInput.IsVirtual = input.IsVirtual;
        //        objUserInput.IsDeactive = input.IsDeactive;
        //        objUserInput.Mode = input.Mode;
        //        objUserInput.MacID = input.MacID;
        //        objUserInput.IPAddress = input.IPAddress;
        //        objUserInput.ComputerName = input.ComputerName;
        //        objUserInput.CreatedUserID = input.CreatedUserID;
        //        objUserInput.CreatedUserDate = input.CreatedUserDate;
        //        objUserInput.ModifiedUserID = input.ModifiedUserID;
        //        objUserInput.ModifiedUserDate = input.ModifiedUserDate;
        //        objUserInput.CountryCode = input.CountryCode;
        //        objUserInput.CityType = input.CityType;

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objUserInput;
        //}
        //#region AggregationRule

        ///// <summary>
        ///// Converts service class to bussiness entity
        ///// </summary>
        ///// <param name="Input"></param>
        ///// <returns></returns>
        //public Buss.AggregationRule[] Convert(Serv.AgggregationRule[] input)
        //{

        //    Buss.AggregationRule[] aggregationRules = new AmericanExpress.GDU.BusinessEntities.AggregationRule[input.Count()];
        //    try
        //    {
        //        int counter = 0;
        //        foreach (Serv.AgggregationRule AggregationRule in input)
        //        {
        //            aggregationRules[counter] = new AmericanExpress.GDU.BusinessEntities.AggregationRule();
        //            aggregationRules[counter].Aggregation_Rule_Id = AggregationRule.Aggregation_Rule_Id;
        //            aggregationRules[counter].Aggregation_Rule_NM = AggregationRule.Aggregation_Rule_NM;
        //            aggregationRules[counter].Aggregation_Rule_Sequence = AggregationRule.Aggregation_Rule_Sequence;
        //            counter += 1;
        //        }

        //    }

        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return aggregationRules;
        //}
        //#endregion

        #endregion

        #region Report Functions
        /// <summary>
        /// <Description>Converts service ReportQuery query to business ReportInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Buss.ReportInput Convert(Serv.ReportQuery input)
        {
            Buss.ReportInput reportInput = new Buss.ReportInput();
            try
            {
                reportInput.strAccount = input.strAccount;
                reportInput.strCity = input.strCity;
                reportInput.strCountry = input.strCountry;
                reportInput.strClientId = input.strClientId;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportInput;
        }
        /// <summary>
        /// <Description>Converts service OtherInfoReportQuery query to business OtherInfoReportInput input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.OtherInfoReportInput Convert(Serv.OtherInfoReportQuery input)
        //{
        //    Buss.OtherInfoReportInput otherInfoInput = new Buss.OtherInfoReportInput();
        //    try
        //    {
        //        otherInfoInput.OtherInfoLabelID = input.OtherInfoLabel_ID;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return otherInfoInput;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Buss.FeedbackReportInput Convert(Serv.FeedbackReportQuery input)
        //{

        //    Buss.FeedbackReportInput reportInput = new Buss.FeedbackReportInput();
        //    try
        //    {
        //        reportInput.FeedbackType = input.FeedbackType;
        //        reportInput.FromDate = input.FromDate;
        //        reportInput.ToDate = input.ToDate;
        //        reportInput.FeedbackClient = input.FeedbackClient;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return reportInput;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Buss.ClientDeploymentReportInput Convert(Serv.ClientDeploymentReportQuery input)
        {
            Buss.ClientDeploymentReportInput reportInput = new Buss.ClientDeploymentReportInput();
            try
            {
                reportInput.UserId = input.UserId;
                reportInput.Version = input.Version;
                reportInput.NonMaxFlag = input.NonMaxFlag;
                reportInput.clientId = input.clientId;
                reportInput.App_ID = input.App_ID;
                reportInput.System_CD = input.System_CD;

                reportInput.PageSize = input.PageSize;
                reportInput.CurrentPage = input.CurrentPage;
                reportInput.SortExpression = input.SortExpression;
                reportInput.SortOrder = input.SortOrder;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportInput;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Buss.ClientUsageReportInput Convert(Serv.ClientUsageReportQuery input)
        {
            Buss.ClientUsageReportInput reportInput = new Buss.ClientUsageReportInput();
            try
            {
                reportInput.UserId = input.UserId;
                reportInput.Version = input.Version;
                reportInput.FromDate = input.Start_DT;
                reportInput.ToDate = input.End_DT;
                reportInput.ClientID = input.Client_ID;
                reportInput.App_ID = input.App_ID;
                reportInput.System_CD = input.System_CD;
                reportInput.PageIndex = input.PageIndex;
                reportInput.PageSize = input.PageSize;
                reportInput.SortColumn = input.SortColumn;
                reportInput.SortOrder = input.SortOrder;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportInput;
        }
        #endregion

        #region UserAuthentication

        public Buss.UserAuthenticationInput Convert(Serv.UserAuthenticationQuery input)
        {
            Buss.UserAuthenticationInput userAuthenticationInput = new Buss.UserAuthenticationInput();
            try
            {
                userAuthenticationInput.UserID = input.UserID;
                userAuthenticationInput.Group = input.Group;
                userAuthenticationInput.NacID = input.NacID;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return userAuthenticationInput;
        }

        #endregion
        public Buss.ClientRelease Convert(Serv.ClientRelease input)
        {
            Buss.ClientRelease clientRelease = new Buss.ClientRelease();

            try
            {
                clientRelease.ClientReleaseVer = new Buss.ClientReleaseInput();
                clientRelease.ClientReleaseVer.CREATED_DT = input.ClientReleaseVer.CREATED_DT;
                clientRelease.ClientReleaseVer.CREATED_USER_ID = input.ClientReleaseVer.CREATED_USER_ID;
                clientRelease.ClientReleaseVer.MODIFIED_DT = input.ClientReleaseVer.MODIFIED_DT;
                clientRelease.ClientReleaseVer.MODIFIED_USER_ID = input.ClientReleaseVer.MODIFIED_USER_ID;
                clientRelease.ClientReleaseVer.RELEASE_DT = input.ClientReleaseVer.RELEASE_DT;
                clientRelease.ClientReleaseVer.RELEASE_ID = input.ClientReleaseVer.RELEASE_ID;
                clientRelease.ClientReleaseVer.RELEASE_VERSION = input.ClientReleaseVer.RELEASE_VERSION;
                clientRelease.ClientReleaseVer.App_ID = input.ClientReleaseVer.App_ID;
                clientRelease.ClientReleaseVer.IsConnected = input.ClientReleaseVer.IsConnected;
                clientRelease.ClientReleaseVer.IsRollBack = input.ClientReleaseVer.IsRollBack;
                clientRelease.ClientReleaseVer.IP = input.ClientReleaseVer.IP;
                clientRelease.ClientReleaseVer.System_CD = input.ClientReleaseVer.System_CD;
                clientRelease.ClientReleaseVer.APP_TYPE = input.ClientReleaseVer.APP_TYPE;
                clientRelease.ClientReleaseVer.Computer_NM = input.ClientReleaseVer.Computer_NM;

                clientRelease.ClientReleaseDtl = new Buss.ClientReleaseDtlInput[input.ClientReleaseDtl.Length];

                for (int iCounter = 0; iCounter < input.ClientReleaseDtl.Length; iCounter++)
                {
                    clientRelease.ClientReleaseDtl[iCounter] = new AmericanExpress.GDU.BusinessEntities.ClientReleaseDtlInput();
                    clientRelease.ClientReleaseDtl[iCounter].CREATED_DT = input.ClientReleaseDtl[iCounter].CREATED_DT;
                    clientRelease.ClientReleaseDtl[iCounter].CREATED_USER_ID = input.ClientReleaseDtl[iCounter].CREATED_USER_ID;
                    clientRelease.ClientReleaseDtl[iCounter].FILE_NM = input.ClientReleaseDtl[iCounter].FILE_NM;
                    clientRelease.ClientReleaseDtl[iCounter].FILE_VERSION = input.ClientReleaseDtl[iCounter].FILE_VERSION;
                    clientRelease.ClientReleaseDtl[iCounter].MODIFIED_DT = input.ClientReleaseDtl[iCounter].MODIFIED_DT;
                    clientRelease.ClientReleaseDtl[iCounter].MODIFIED_USER_ID = input.ClientReleaseDtl[iCounter].MODIFIED_USER_ID;
                    clientRelease.ClientReleaseDtl[iCounter].RELEASE_ID = input.ClientReleaseDtl[iCounter].RELEASE_ID;
                    clientRelease.ClientReleaseDtl[iCounter].FILE_PATH = input.ClientReleaseDtl[iCounter].FILE_PATH;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return clientRelease;
        }
        //#region search label

        //public Buss.SearchLabelInput Convert(Serv.SearchLabelQuery input)
        //{
        //    Buss.SearchLabelInput searchLabelInput = new Buss.SearchLabelInput();
        //    try
        //    {
        //        searchLabelInput.Type = input.Type;
        //        searchLabelInput.ClientCode = input.ClientCode;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return searchLabelInput;
        //}
        //#endregion

        //public Buss.ManageClientInput Convert(Serv.ManageClientQuery input)
        //{
        //    Buss.ManageClientInput objUserInput = new Buss.ManageClientInput();
        //    try
        //    {
        //        objUserInput.ClientId = input.ClientId;
        //        objUserInput.ClientName = input.ClientName;
        //        objUserInput.ClientAbbr = input.ClientAbbr;
        //        objUserInput.CREATED_DT = input.CREATED_DT;
        //        objUserInput.CREATED_USER_ID = input.CREATED_USER_ID;
        //        objUserInput.Mode = input.Mode;
        //        objUserInput.IsDeactive = input.IsDeactive;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objUserInput;
        //}

        public Buss.ApplicationInput Convert(ApplicationRequest input)
        {
            Buss.ApplicationInput objinput = new Buss.ApplicationInput();
            try
            {
                objinput.ApplicationNM = input.PopulateRequest.ApplicationNM;
                objinput.ApplicationAbbr = input.PopulateRequest.ApplicationAbbr;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objinput;
        }

        public Buss.AppUserInput Convert(Serv.AppUserQuery input)
        {
            Buss.AppUserInput objAppUserInput = new Buss.AppUserInput();
            try
            {
                objAppUserInput.UserId = input.UserId;
                objAppUserInput.Mode = input.Mode;
                objAppUserInput.Role_CD = input.Role_CD;
                objAppUserInput.ModifiedUserDate = input.ModifiedUserDate;
                objAppUserInput.AuthorizedRoleIds = input.AuthorizedRoleIds;
                objAppUserInput.App_ID = input.App_ID;
                objAppUserInput.InFlag = input.InFlag;
                objAppUserInput.System_CD = input.System_CD;
                objAppUserInput.UserName = input.UserName;
                objAppUserInput.App_Version = input.App_Version;
                objAppUserInput.APP_TYPE = input.App_Type;

                objAppUserInput.PageIndex = input.PageIndex;
                objAppUserInput.PageSize = input.PageSize;
                objAppUserInput.SortColumn = input.SortColumn;
                objAppUserInput.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppUserInput;
        }

        public Buss.AppUploadedReportInput Convert(Serv.AppUploadedReportQuery input)
        {
            Buss.AppUploadedReportInput reportInput = new Buss.AppUploadedReportInput();
            try
            {
                reportInput.UserId = input.UserId;
                reportInput.From_Dt = input.From_DT;
                reportInput.To_Date = input.To_Date;
                reportInput.RollBack = input.RollBack;
                reportInput.App_ID = input.App_ID;
                reportInput.APP_TYPE = input.APP_TYPE;

                reportInput.CurrentPage = input.CurrentPage;
                reportInput.PageSize = input.PageSize;
                reportInput.SortExpression = input.SortExpression;
                reportInput.SortOrder = input.SortOrder;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportInput;
        }

        public Buss.PilotAppUploadInput Convert(Serv.PilotAppRepQuery input)
        {
            Buss.PilotAppUploadInput reportInput = new Buss.PilotAppUploadInput();
            try
            {
                reportInput.AppId = input.App_Id;
                reportInput.AppVersion = input.Version;
                reportInput.AdsId = input.AdsId;
                reportInput.IPAddress = input.IPAddress;
                reportInput.MachineName = input.MachineName;
                reportInput.OfficeId = input.OfficeId;
                reportInput.APP_NAME = input.APP_NAME;

                reportInput.CurrentPage = input.CurrentPage;
                reportInput.PageSize = input.PageSize;
                reportInput.SortExpression = input.SortExpression;
                reportInput.SortOrder = input.SortOrder;
                //Market Release
                reportInput.AppCodeBase = input.AppCodeBase;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return reportInput;
        }


        public Buss.ManageApplicationInput Convert(Serv.ManageApplicationQuery input)
        {
            Buss.ManageApplicationInput objApplicationInput = new Buss.ManageApplicationInput();
            try
            {
                objApplicationInput.ApplicationNM = input.ApplicationNM;
                objApplicationInput.ApplicationAbbr = input.ApplicationAbbr;
                objApplicationInput.IsDeactive = input.IsDeactive;
                objApplicationInput.ApplicationDeployPath = input.ApplicationDeployPath;
                objApplicationInput.AppMode = input.AppMode;
                objApplicationInput.AppType = input.AppType;
                objApplicationInput.AppExeName = input.ApplicationExeName;
                objApplicationInput.AppId = input.AppId;
                objApplicationInput.EntryPoint = input.EntryPoint;

                objApplicationInput.PageIndex = input.PageIndex;
                objApplicationInput.PageSize = input.PageSize;
                objApplicationInput.SortColumn = input.SortColumn;
                objApplicationInput.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objApplicationInput;
        }


        public Buss.ManageAppFocusInput Convert(Serv.ManageAppFocusQuery input)
        {
            Buss.ManageAppFocusInput objAppFocusInput = new Buss.ManageAppFocusInput();
            try
            {
                objAppFocusInput.XmlData = input.XmlData;
                objAppFocusInput.ComputerName = input.ComputerName;
                objAppFocusInput.IPAddress = input.IPAddress; ;
                objAppFocusInput.ADSId = input.ADSId;
                objAppFocusInput.currentEndDate = input.currentEndDate;
                objAppFocusInput.FILE_TYPE = input.FILE_TYPE;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppFocusInput;
        }


        public Buss.ManageRoleInput Convert(Serv.ManageRoleQuery input)
        {
            Buss.ManageRoleInput objRoleInput = new Buss.ManageRoleInput();
            try
            {
                objRoleInput.ClientId = input.ClientId;
                objRoleInput.RoleId = input.RoleCode;
                objRoleInput.RoleName = input.RoleName;
                objRoleInput.IsDeactive = input.IsDeactive;
                objRoleInput.AuthorizedFunctionIds = input.AuthorizedFunctionIds;
                objRoleInput.CreatedBy = input.CreatedBy;
                objRoleInput.Flag = input.Flag;
                objRoleInput.FunctionId = input.FunctionId;
                objRoleInput.ModifiedDt = input.ModifiedDt;
                objRoleInput.RoleTypeCD = input.RoleTypeCD;
                objRoleInput.System_CD = input.System_CD;

                objRoleInput.PageSize = input.PageSize;
                objRoleInput.CurrentPage = input.CurrentPage;
                objRoleInput.SortExpression = input.SortExpression;
                objRoleInput.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleInput;
        }
        //public Buss.ClientInput Convert(ClientRequest input)
        //{
        //    Buss.ClientInput objinput = new Buss.ClientInput();
        //    try
        //    {
        //        objinput.ClientId = input.PopulateRequest.ClientId;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}

        //public Buss.ClientAccInput Convert(ClientAccRequest input)
        //{
        //    Buss.ClientAccInput objinput = new Buss.ClientAccInput();
        //    try
        //    {
        //        objinput.STDinput = new Buss.StandardInput();
        //        objinput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
        //        objinput.AccountCD = input.PopulateRequest.AccountCD;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return objinput;
        //}

        public Buss.FunctionInput Convert(Serv.ManageFunctionQuery input)
        {
            Buss.FunctionInput objinput = new Buss.FunctionInput();
            try
            {
                objinput.RoleCode = input.RoleCode;
                objinput.ClientId = input.ClientId;
                objinput.FunctionType = input.FunctionType;
                objinput.System_CD = input.System_CD;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objinput;
        }

        public Buss.RoleInput Convert(Serv.RoleQuery input)
        {
            Buss.RoleInput objRoleInput = new Buss.RoleInput();
            try
            {
                objRoleInput.UserId = input.UserId;
                objRoleInput.RoleType = input.RoleType;
                objRoleInput.System_CD = input.System_CD;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleInput;
        }

        /// <summary>
        /// <Description>Converts service DurationTime query to business city input</Description>
        /// </summary>
        /// <param name="input">populate DurationTime request</param>
        /// <returns></returns>
        /// 
        public Buss.DurationTimeInput Convert(Serv.DurationTime input)
        {
            Buss.DurationTimeInput objDuration = new Buss.DurationTimeInput();
            try
            {
                objDuration.TimeDuration = input.TimeDuration;
                objDuration.UserId = input.UserId;
                objDuration.TimeFormat = input.TimeFormat;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objDuration;
        }

        public Buss.AppFocusReportInput Convert(Serv.AppFocusReportQuery input)
        {
            Buss.AppFocusReportInput objAppFocusRep = new Buss.AppFocusReportInput();
            try
            {
                objAppFocusRep.AppName = input.AppName;
                objAppFocusRep.FromDate = input.FromDate;
                objAppFocusRep.ToDate = input.ToDate;
                objAppFocusRep.UserName = input.UserName;
                objAppFocusRep.OfficeId = input.OfficeId;
                objAppFocusRep.GroupSeqNo = input.GroupSeqNo;
                objAppFocusRep.ADS_ID = input.ADSId;
                objAppFocusRep.OfficeGroupId = input.OfficeGroupId;
                objAppFocusRep.PageSize = input.PageSize;
                objAppFocusRep.CurrentPage = input.CurrentPage;
                objAppFocusRep.SortExpression = input.SortExpression;
                objAppFocusRep.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                throw ex;
            }

            return objAppFocusRep;
        }

        public Buss.FocusAppInput Convert(Serv.FocusAppQuery input)
        {
            Buss.FocusAppInput objAppUserInput = new Buss.FocusAppInput();
            try
            {
                objAppUserInput.App_DESC = input.APP_DS;
                objAppUserInput.ID = input.ID;

                objAppUserInput.PageSize = input.PageSize;
                objAppUserInput.CurrentPage = input.CurrentPage;
                objAppUserInput.SortExpression = input.SortExpression;
                objAppUserInput.SortOrder = input.SortOrder;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppUserInput;
        }
        //public Buss.AppFocusOfficeInput Convert(Serv.AppFocusOfficeQuery input)
        //{
        //    Buss.AppFocusOfficeInput objAppFocusOfficeInput = new Buss.AppFocusOfficeInput();
        //    try
        //    {
        //        objAppFocusOfficeInput.ID = input.Id;
        //        objAppFocusOfficeInput.Office_Desc = input.OfficeDesc;

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objAppFocusOfficeInput;
        //}

        public Buss.AppFocusOfficeInput Convert(Serv.AppFocusOfficeQuery input)
        {
            Buss.AppFocusOfficeInput objAppFocusOfficeInput = new Buss.AppFocusOfficeInput();
            try
            {
                objAppFocusOfficeInput.ID = input.Id;
                objAppFocusOfficeInput.Office_Desc = input.OfficeDesc;
                objAppFocusOfficeInput.User_ID = input.USER_ID;
                objAppFocusOfficeInput.Mode = input.MODE;
                objAppFocusOfficeInput.IsActive = input.ISACTIVE;
                objAppFocusOfficeInput.IsReport = input.ISREPORT;
                objAppFocusOfficeInput.STATUS = input.STATUS;

                objAppFocusOfficeInput.PageSize = input.PageSize;
                objAppFocusOfficeInput.CurrentPage = input.CurrentPage;
                objAppFocusOfficeInput.SortExpression = input.SortExpression;
                objAppFocusOfficeInput.SortOrder = input.SortOrder;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppFocusOfficeInput;
        }

        public Buss.FocusGroupInput Convert(Serv.FocusGroupQuery input)
        {
            Buss.FocusGroupInput objAppFGroupInput = new Buss.FocusGroupInput();
            try
            {
                objAppFGroupInput.ID = input.ID;
                objAppFGroupInput.Group_NM = input.GROUP_NM;
                objAppFGroupInput.User_ID = input.USER_ID;
                objAppFGroupInput.Mode = input.MODE;
                objAppFGroupInput.IsActive = input.ISACTIVE;

                objAppFGroupInput.PageSize = input.PageSize;
                objAppFGroupInput.CurrentPage = input.CurrentPage;
                objAppFGroupInput.SortExpression = input.SortExpression;
                objAppFGroupInput.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppFGroupInput;
        }

        public Buss.FocusGroupInput Convert(FocusGroupRequest input)
        {
            Buss.FocusGroupInput CountryInput = new Buss.FocusGroupInput();
            try
            {
                CountryInput.ID = input.PopulateRequest.ID;
                CountryInput.Group_NM = input.PopulateRequest.GROUP_NM;

                CountryInput.STDinput = new Buss.StandardInput();
                CountryInput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
            }

            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return CountryInput;
        }

        public Buss.FocusGroupMappingInput Convert(Serv.OfficeGroupMappingQuery input)
        {
            Buss.FocusGroupMappingInput objAppFGroupInput = new Buss.FocusGroupMappingInput();
            try
            {
                objAppFGroupInput.GROUP_ID = input.GroupID;
                objAppFGroupInput.OFFICE_ID = input.OfficeID;
                objAppFGroupInput.OFFICE_DS = input.OfficeDS;
                objAppFGroupInput.CreatedUserID = input.CreatedUserID;



            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppFGroupInput;
        }

        public Buss.OfficeGroupMappingReportInput Convert(Serv.OfficeGroupMappingReportQuery input)
        {
            Buss.OfficeGroupMappingReportInput reportInput = new Buss.OfficeGroupMappingReportInput();
            try
            {
                reportInput.GroupID = input.GroupID;
                reportInput.PageIndex = input.PageIndex;
                reportInput.PageSize = input.PageSize;
                reportInput.SortColumn = input.SortColumn;
                reportInput.SortOrder = input.SortOrder;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportInput;
        }


        public Buss.ManagePilotAppExcelSheetInput Convert(Serv.ManagePilotAppExcelSheetQuery input)
        {
            Buss.ManagePilotAppExcelSheetInput objPilotAppExcelInput = new Buss.ManagePilotAppExcelSheetInput();
            try
            {
                objPilotAppExcelInput.DtExcelData = input.DtExcelData;
                objPilotAppExcelInput.XmlData = input.XmlData;
                objPilotAppExcelInput.GroupID = input.GroupID;
                objPilotAppExcelInput.AppId = input.AppId;
                objPilotAppExcelInput.AppVersion = input.AppVersion;
                objPilotAppExcelInput.CreatedUserId = input.CreatedUserId;
                objPilotAppExcelInput.UploadType = input.UploadType;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objPilotAppExcelInput;
        }

        public Buss.AppFOfficeAdsMappingID Convert(AppFOfficeAdsIDRequest input)
        {
            Buss.AppFOfficeAdsMappingID AdsIDInput = new Buss.AppFOfficeAdsMappingID();
            try
            {
                AdsIDInput.ADS_ID = input.PopulateRequest.ADS_ID;
                AdsIDInput.GROUP_ID = input.PopulateRequest.GROUP_ID;
                AdsIDInput.TYPE = input.PopulateRequest.Type;
                AdsIDInput.CreatedUserID = input.PopulateRequest.CreatedUserID;
                AdsIDInput.STDinput = new Buss.StandardInput();
                AdsIDInput.STDinput.EnumType = (Buss.InputType)Enum.Parse(typeof(Buss.InputType), input.ServiceInput.EnumType.ToString());
            }

            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AdsIDInput;
        }
        public Buss.TravelSuiteAppFocusReportInput Convert(Serv.TravelSuiteAppFocusReportQuery input)
        {
            Buss.TravelSuiteAppFocusReportInput objTravelSuiteAppFocusRep = new Buss.TravelSuiteAppFocusReportInput();
            try
            {
                objTravelSuiteAppFocusRep.AppName = input.AppName;
                objTravelSuiteAppFocusRep.FromDate = input.FromDate;
                objTravelSuiteAppFocusRep.ToDate = input.ToDate;
                objTravelSuiteAppFocusRep.UserName = input.UserName;
                objTravelSuiteAppFocusRep.OfficeId = input.OfficeId;
                objTravelSuiteAppFocusRep.GroupSeqNo = input.GroupSeqNo;
                objTravelSuiteAppFocusRep.ADS_ID = input.ADSId;
                objTravelSuiteAppFocusRep.OfficeGroupId = input.OfficeGroupId;

                objTravelSuiteAppFocusRep.CurrentPage = input.CurrentPage;
                objTravelSuiteAppFocusRep.PageSize = input.PageSize;
                objTravelSuiteAppFocusRep.SortExpression = input.SortExpression;
                objTravelSuiteAppFocusRep.SortOrder = input.SortOrder;
            }
            catch (GDUException ex)
            {
                throw ex;
            }

            return objTravelSuiteAppFocusRep;
        }

        public Buss.PilotApplicationDeploymentReportInput Convert(Serv.PilotApplicationDeploymentReportQuery input)
        {
            Buss.PilotApplicationDeploymentReportInput reportInput = new Buss.PilotApplicationDeploymentReportInput();
            try
            {
                reportInput.UserId = input.UserId;
                reportInput.Version = input.Version;
                reportInput.NonMaxFlag = input.NonMaxFlag;
                reportInput.clientId = input.clientId;
                reportInput.App_ID = input.App_ID;
                reportInput.System_CD = input.System_CD;

                reportInput.PageIndex = input.PageIndex;
                reportInput.PageSize = input.PageSize;
                reportInput.SortColumn = input.SortColumn;
                reportInput.SortOrder = input.SortOrder;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportInput;
        }

        public Buss.AddOfficeInput Convert(Serv.AddOfficeQuery input)
        {
            Buss.AddOfficeInput objAddOfficeInput = new Buss.AddOfficeInput();
            try
            {
                objAddOfficeInput.OfficeId = input.OfficeId;
                objAddOfficeInput.ADSId = input.ADSId;

            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAddOfficeInput;
        }

        #region ACWBusinessConverter

        public Buss.ACWReportInput Convert(Serv.ACWCoralReportQuery input)
        {
            Buss.ACWReportInput reportInput = new AmericanExpress.GDU.BusinessEntities.ACWReportInput();
            try
            {
                reportInput.AppName = input.AppName;
                reportInput.FromDate = input.FromDate;
                reportInput.ToDate = input.ToDate;
                reportInput.GroupId = input.GroupId;
                reportInput.OfficeId = input.OfficeId;
                reportInput.UserName = input.UserName;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return reportInput;
        }

        #endregion ACWBusinessConverter

        //#region PendingRquest Converter
        //public Buss.PendingApprovalInput Convert(Serv.PendingApprovalQuery input)
        //{
        //    Buss.PendingApprovalInput pendingApprovalInput = new AmericanExpress.GDU.BusinessEntities.PendingApprovalInput();
        //    try
        //    {
        //        pendingApprovalInput.AccountCode = input.AccountCode;
        //        pendingApprovalInput.CarrierCode = input.CarrierCode;
        //        pendingApprovalInput.CityCode = input.CityCode;
        //        pendingApprovalInput.ClientCode = input.ClientCode;
        //        pendingApprovalInput.CountryCode = input.CountryCode;
        //        pendingApprovalInput.GlobalCategoryCode = input.GlobalCategoryCode;
        //        pendingApprovalInput.Mode = input.Mode;
        //        pendingApprovalInput.OtherInfoCode = input.OtherInfoCode;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return pendingApprovalInput;
        //}
        //#endregion

        #region PendingRquest Converter
        public Buss.TransitDataInput Convert(Serv.TransitDataQuery input)
        {
            Buss.TransitDataInput TransitDataInputInput = new AmericanExpress.GDU.BusinessEntities.TransitDataInput();
            try
            {
                TransitDataInputInput.mode = input.mode;
                TransitDataInputInput.code = input.code;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return TransitDataInputInput;
        }

        #endregion

        #region Manage Pending Approval Converter

        //public Buss.ManagePendingApprovalInput[] Convert(Serv.ManagePendingApprovalQuery[] input)
        //{
        //    Buss.ManagePendingApprovalInput[] objUserInput = new Buss.ManagePendingApprovalInput[input.Length];
        //    try
        //    {
        //        for (int iCount = 0; iCount < input.Length; iCount++)
        //        {
        //            objUserInput[iCount] = new Buss.ManagePendingApprovalInput();
        //            objUserInput[iCount].isApprove = input[iCount].isApprove;
        //            objUserInput[iCount].labelId = input[iCount].labelId;
        //            objUserInput[iCount].linkCatDtlId = input[iCount].linkCatDtlId;
        //            objUserInput[iCount].linkDtlId = input[iCount].linkDtlId;
        //            objUserInput[iCount].linkId = input[iCount].linkId;
        //            objUserInput[iCount].mode = input[iCount].mode;
        //            objUserInput[iCount].uploadType = input[iCount].uploadType;
        //        }

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objUserInput;
        //}

        //public Buss.ClientGlobalAlertInput Convert(ClientGlobalAlertRequest GlobalAlertRequest)
        //{
        //    Buss.ClientGlobalAlertInput objClientGlobalAlertInput = new AmericanExpress.GDU.BusinessEntities.ClientGlobalAlertInput();
        //    try
        //    {
        //        objClientGlobalAlertInput.ClientId = GlobalAlertRequest.Request.ClientID;

        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objClientGlobalAlertInput;
        //}


        //public Buss.AuditTrialInput Convert(Serv.AuditTrialQuery input)
        //{
        //    Buss.AuditTrialInput objUserInput = new Buss.AuditTrialInput();
        //    try
        //    {
        //        objUserInput.LabelId = input.LabelId;
        //        objUserInput.Mode = input.Mode;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    return objUserInput;
        //}


        #endregion

        //public Buss.GetAppLatestVersion Convert(Serv.Get getAppLatestVersion)
        //{
        //    Buss.GetAppLatestVersion input = new Buss.GetAppLatestVersion();
        //    try
        //    {
        //        input.App_ID = getAppLatestVersion.App_ID;
        //        input.App_Type = getAppLatestVersion.App_Type;

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return input;

        //}

        public Buss.GetAppLatestVersionInput Convert(GetAppLatestVersionRequest Request)
        {
            Buss.GetAppLatestVersionInput input = new Buss.GetAppLatestVersionInput();
            try
            {
                input.App_ID = Request.getAppLatestVersion.App_ID;
                input.App_Type = Request.getAppLatestVersion.App_Type;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return input;
        }
    }
}
