﻿//-----------------------------------------------------------------------
// <copyright file="GWizService.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class converts service entities to the business entities and vice versa.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.Service.ServiceImplimentation
{
    #region Page Level Namespace
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.ServiceModel;
    using System.Text;
    using AmericanExpress.GDU.Service.DataContracts;
    using AmericanExpress.GDU.Service.ServiceContract;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    using AmericanExpress.GDU.Utilities.DependencyInjector;
    using AmericanExpress.GDU.Service.MessageContracts.Responses;
    using AmericanExpress.GDU.Service.MessageContracts.Requests;
    using AmericanExpress.GDU.Utilities.ExceptionMgmt;
    #endregion

    /// <summary>
    /// GWiz Service Class
    /// </summary>
    public class GDUService : InjectableClass, IGDUService
    {
        GDU.BusinessInterface.IGDUBusinessProvider _iGWizBusinessProvider;
        const string EVENT_SOURCE_NAME = "GWiz";
        const string LOG_NAME = "Application";

        public GDUService()
        {
            LogManager.InitializeSource(EVENT_SOURCE_NAME, LOG_NAME);
        }

        [InjectionDependency("GWizBusinessLibrary")]
        public GDU.BusinessInterface.IGDUBusinessProvider BusinessObject
        {
            get { return this._iGWizBusinessProvider; }
            set { this._iGWizBusinessProvider = value; }
        }


        #region Link
        /// <summary>
        /// <Description>this method is for conversion of search link request</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public SearchLinkResponse SearchLink(SearchLinkRequest request)
        //{
        //    SearchLinkResponse objSearchLinkResponse = new SearchLinkResponse();
        //    StandardResponse std = new StandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objSearchLinkResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchLinkData(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResponse.ServiceResponse = new StandardResponse();
        //        objSearchLinkResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchLinkResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6000);
        //    }

        //    return objSearchLinkResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of manipulate link request</Description>
        /// </summary>
        /// <param name="request">manupulate link request</param>
        /// <returns>return manupulate response</returns>
        //public ManupulateResponse ManupulateLink(ManupulateLinkRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(_iGWizBusinessProvider.UpdateLinks(businessConverter.Convert(request.ManupulateLinkDetail)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6001);
        //    }

        //    return manupulateResponse;
        //}

        /// <summary>
        /// this method is for conversion of manipulate general info link request
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public ManupulateResponse ManupulateGeneralInfoLink(ManupulateGeneralInfoLinkRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.UpdateGeneralInfoLinks(businessConverter.Convert(request.ManupulateGeneralInfoLink)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6001);
        //    }

        //    return manupulateResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of transaction id</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public TransactionResponse GetTransactionId(TransactionRequest request)
        //{
        //    TransactionResponse objTransactionResponse = new TransactionResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objTransactionResponse = responseConverter.Convert(this._iGWizBusinessProvider.GetTransactionId(businessConverter.Convert(request.TransactionIdQuery)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objTransactionResponse.ServiceResponse = new StandardResponse();
        //        objTransactionResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objTransactionResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6002);
        //    }

        //    return objTransactionResponse;
        //}
        /// <summary>
        /// <Description>this method is for conversion of feedback response</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public ManupulateResponse FeedbackResponse(FeedbackRequest request)
        //{
        //    ManupulateResponse objManupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objManupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.SaveFeedback(businessConverter.Convert(request.FeedbackDetail)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objManupulateResponse.Status = new StandardResponse();
        //        objManupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        objManupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6003);
        //    }

        //    return objManupulateResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of populate feedback type</Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateFeedbackType PopulateFeedbackType()
        //{
        //    PopulateFeedbackType objPopulateResponse = new PopulateFeedbackType();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFeedbackType());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateResponse.ServiceResponse = new StandardResponse();
        //        objPopulateResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6004);
        //    }

        //    return objPopulateResponse;
        //}
        #endregion

        #region OtherInfo Link
        /// <summary>
        /// <Description>this method is for conversion of search other info</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public SearchOtherInfoResponse SearchOtherInfo(SearchOtherInfoRequest request)
        //{
        //    SearchOtherInfoResponse objOtherinfoResponse = new SearchOtherInfoResponse();

        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objOtherinfoResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchOtherInfo(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objOtherinfoResponse.ServiceResponse = new StandardResponse();
        //        objOtherinfoResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objOtherinfoResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6005);
        //    }

        //    return objOtherinfoResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of ManupulateOtherInfoDetail</Description>
        /// </summary>
        /// <param name="request">manupulate other info request</param>
        /// <returns>manupulate response</returns>
        //public ManupulateResponse ManupulateOtherInfoDetail(ManupulateOtherInfoRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.UpdateOtherInfo(businessConverter.Convert(request.ManupulateOtherInfoDetail)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6006);
        //    }

        //    return manupulateResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of ManupulateOtherInfoDetail</Description>
        /// </summary>
        /// <param name="request">Manupulate General Info Other Request</param>
        /// <returns>Manupulate Response</returns>
        //public ManupulateResponse ManupulateGeneralInfoOtherInfoDetail(ManupulateGeneralInfoOtherInfoRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.UpdateGeneralInfoOtherInfo(businessConverter.Convert(request.ManupulateGeneralInfoOtherInfoDetails)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6006);
        //    }

        //    return manupulateResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of ManupulateOtherInfo</Description>
        /// </summary>
        /// <param name="request">Other Info Request</param>
        /// <returns>Manupulate Response</returns>
        //public ManupulateResponse ManupulateOtherInfo(OtherInfoRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.AddUpdateOtherInfoLink(businessConverter.Convert(request.OtherInfo)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6007);
        //    }

        //    return manupulateResponse;
        //}
        /// <summary>
        /// <Description>this method is for conversion of delete OtherInfo/Description>
        /// </summary>
        /// <param name="request">Other Info Request</param>
        /// <returns></returns>
        //public ManupulateResponse DeleteOtherInfo(OtherInfoRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.DeleteOtherInfo(businessConverter.Convert(request.OtherInfo)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6008);
        //    }

        //    return manupulateResponse;
        //}
        #endregion

        #region Global Category
        /// <summary>
        /// <Description>this method is for conversion of ManupulateGlobalCategory</Description>
        /// </summary>
        /// <param name="request">Global Category Request</param>
        /// <returns></returns>
        //public ManupulateResponse ManupulateGlobalCategory(GlobalCategoryRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.AddUpdateGlobalCategory(businessConverter.Convert(request.GlobalCategory)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6009);
        //    }

        //    return manupulateResponse;
        //}
        /// <summary>
        /// <Description>this method is for conversion of DeleteGlobalCategory</Description>
        /// </summary>
        /// <param name="request">Global Category Request</param>
        /// <returns>Manupulate Response </returns>
        //public ManupulateResponse DeleteGlobalCategory(GlobalCategoryRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.DeleteGlobalcategory(businessConverter.Convert(request.GlobalCategory)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6010);
        //    }

        //    return manupulateResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of populateGlobalCategory</Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateCategoryResponse PopulateGlobalCategory()
        //{
        //    PopulateCategoryResponse objPopulateCategoryResponse = new PopulateCategoryResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        objPopulateCategoryResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateGlobalCategory());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCategoryResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCategoryResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCategoryResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6011);
        //    }

        //    return objPopulateCategoryResponse;
        //}
        #endregion

        #region Language
        /// <summary>
        /// <Description>this method is for conversion of populatelanguage</Description>
        /// </summary>
        /// <returns></returns>
        public PopulateLanguageResponse PopulateLanguage()
        {
            PopulateLanguageResponse objPopulateLanguageResponse = new PopulateLanguageResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateLanguageResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateLanguage());
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateLanguageResponse.ServiceResponse = new StandardResponse();
                objPopulateLanguageResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateLanguageResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6012);
            }

            return objPopulateLanguageResponse;
        }
        #endregion

        #region Link Type
        /// <summary>
        /// <Description>this method is for conversion of populate link type/Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateLinkTypeResponse PopulateLinkType()
        //{
        //    PopulateLinkTypeResponse objPopulateLinkTypeResponse = new PopulateLinkTypeResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateLinkTypeResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateLinkType());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateLinkTypeResponse.ServiceResponse = new StandardResponse();
        //        objPopulateLinkTypeResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateLinkTypeResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6013);
        //    }

        //    return objPopulateLinkTypeResponse;
        //}
        #endregion

        #region Category
        /// <summary>
        /// <Description>this method is for conversion of populate category</Description>
        /// </summary>
        /// <param name="request">Search Link Request</param>
        /// <returns>Populate Category Response</returns>
        //public PopulateCategoryResponse PopulateCategory(SearchLinkRequest request)
        //{
        //    PopulateCategoryResponse objPopulateCategoryResponse = new PopulateCategoryResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        objPopulateCategoryResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateCategory(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCategoryResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCategoryResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCategoryResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6014);
        //    }

        //    return objPopulateCategoryResponse;
        //}
        #endregion

        #region Account
        /// <summary>
        /// <Description>this method is for conversion of populateaccount</Description>
        /// </summary>
        /// <returns>Populate Account Response</returns>
        //public PopulateAccountResponse PopulateAccount(AccountRequest request)
        //{
        //    PopulateAccountResponse objPopulateAccountResponse = new PopulateAccountResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //        objPopulateAccountResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAccount(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateAccountResponse.ServiceResponse = new StandardResponse();
        //        objPopulateAccountResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateAccountResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objPopulateAccountResponse;
        //}

        //public ManageAccountResponse SearchAccounts(ManageAccountRequest Request)
        //{
        //    ManageAccountResponse accResponse = new ManageAccountResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        accResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchAccounts(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return accResponse;
        //}
        #endregion

        //#region Manage Country
        //public ManageCountryResponse SearchCountry(ManageCountryRequest Request)
        //{
        //    ManageCountryResponse countryResponse = new ManageCountryResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        countryResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchCountry(businessConverter.Convert(Request.SearchRequest)));
        //        ////countryResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchCountry(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return countryResponse;
        //}
        //#endregion

        //public ManageCityResponse SearchCities(ManageCityRequest Request)
        //{
        //    ManageCityResponse cityResponse = new ManageCityResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        cityResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchCities(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return cityResponse;
        //}

        public AppUserSearchResponse SearchAppUsers(AppUserSearchRequest Request)
        {
            AppUserSearchResponse AppuserResponse = new AppUserSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                AppuserResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchAppUsers(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AppuserResponse;
        }

        public AppUserStandardResponse ManageAppUsers(AppUserManipulateRequest Request)
        {
            AppUserStandardResponse AppuserResponse = new AppUserStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                AppuserResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageAppUsers(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AppuserResponse;
        }

        #region Country
        /// <summary>
        /// <Description>this method is for conversion of populate country</Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateCountryResponse PopulateCountry(PopulateCountryRequest request)
        //{
        //    PopulateCountryResponse objPopulateCountryResponse = new PopulateCountryResponse();
        //    try
        //    {
        //        RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //        BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //        objPopulateCountryResponse = responseConverter.Convert(this._iGWizBusinessProvider.LoadCountry(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCountryResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCountryResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCountryResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6016);
        //    }

        //    return objPopulateCountryResponse;
        //}
        /// <summary>
        /// <Description>this method is for conversion of populate country</Description>
        /// </summary>
        /// <param name="request">Populate Country Request</param>
        /// <returns> Populate Country Response</returns>
        //public PopulateCountryResponse LoadCountry(PopulateCountryRequest request)
        //{
        //    PopulateCountryResponse objPopulateCountryResponse = new PopulateCountryResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        objPopulateCountryResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateCountry(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCountryResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCountryResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCountryResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6017);
        //    }

        //    return objPopulateCountryResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of delete link</Description>
        /// </summary>
        /// <param name="request">Delete Link Request</param>
        /// <returns>Manupulate Response</returns>
        //public ManupulateResponse DeleteLink(DeleteLinkRequest request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.DeleteLink(businessConverter.Convert(request.DeleteLinkDetails)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6018);
        //    }

        //    return manupulateResponse;
        //}

        //public ManupulateResponse MapAccount(AccountMappingRequest Request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.MapAccount(businessConverter.Convert(Request.MapAccount)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6018);
        //    }

        //    return manupulateResponse;
        //}
        #endregion

        #region MappingCity
        //public ManupulateResponse MapCity(CityMappingRequest Request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        ////manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.MapCity(businessConverter.Convert(Request.MapCity)));
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.MapCity(businessConverter.Convert(Request.MapCity)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6018);
        //    }

        //    return manupulateResponse;
        //}

        //public ManupulateResponse MapCountry(CountryMappingRequest Request)
        //{
        //    ManupulateResponse manupulateResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        ////manupulateResponse.Status = responseConverter.Convert(_iGWizBusinessProvider.MapCountry(businessConverter.Convert(Request.MapCountry)));
        //        manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.MapCountry(businessConverter.Convert(Request.MapCountry)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        manupulateResponse.Status = new StandardResponse();
        //        manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
        //        manupulateResponse.Status.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6018);
        //    }

        //    return manupulateResponse;
        //}
        #endregion

        #region City
        /// <summary>
        /// <Description>this method is for conversion of populate city</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public PopulateCityResponse PopulateCity(PopulateCityRequest request)
        //{
        //    PopulateCityResponse objPopulateCityResponse = new PopulateCityResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateCityResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateCity(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCityResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCityResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCityResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6019);
        //    }


        //    return objPopulateCityResponse;
        //}

        ////public PopulateCityResponse PopulateCity(PopulateCityRequest request, string strJquery)
        ////{
        ////    PopulateCityResponse objPopulateCityResponse = new PopulateCityResponse();
        ////    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        ////    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();

        ////    objPopulateCityResponse.PopulateResponse = responseConverter.Convert(_iGWizBusinessProvider.PopulateCity(businessConverter.Convert(request.PopulateRequest),strJquery));

        ////    return objPopulateCityResponse;
        ////}
        ////PopulateCityResponse PopulateCity
        #endregion

        #region Carrier
        /// <summary>
        /// <Description>this method is for conversion of populate carrier</Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateCarrierResponse PopulateCarrier()
        //{
        //    return new PopulateCarrierResponse();
        //}

        /// <summary>
        /// <Description>this method is for conversion of search carrier</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public DisplayCarrierSearchResponse SearchCarriers(CarrierSearchRequest Request)
        //{
        //    DisplayCarrierSearchResponse carrierResponse = new DisplayCarrierSearchResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        carrierResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchCarrier(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        carrierResponse.ServiceResponse = new StandardResponse();
        //        carrierResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        carrierResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6020);
        //    }

        //    return carrierResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of Mannage carriers</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public CarrierStandardResponse ManageCarriers(CarrierManupulateRequest Request)
        //{
        //    CarrierStandardResponse carrierResponse = new CarrierStandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        carrierResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageCarriers(businessConverter.Convert(Request.ManupulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return carrierResponse;
        //}
        #endregion

        #region OtherInfo
        /// <summary>
        /// <Description>this method is for conversion of populate other info</Description>
        /// </summary>
        /// <returns></returns>
        //public PopulateOtherInfoResponse PopulateOtherInfo()
        //{
        //    PopulateOtherInfoResponse objPopulateOtherInfoResponse = new PopulateOtherInfoResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateOtherInfoResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateOtherInfo());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateOtherInfoResponse.ServiceResponse = new StandardResponse();
        //        objPopulateOtherInfoResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateOtherInfoResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6022);
        //    }

        //    return objPopulateOtherInfoResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of populate other info category</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public PopulateCategoryResponse PopulateOtherInfoCategory(OtherInfoRequest request)
        //{
        //    PopulateCategoryResponse objPopulateCategoryResponse = new PopulateCategoryResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        objPopulateCategoryResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateOtherInfoCategory(businessConverter.Convert(request.OtherInfo)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateCategoryResponse.ServiceResponse = new StandardResponse();
        //        objPopulateCategoryResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateCategoryResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6023);
        //    }

        //    return objPopulateCategoryResponse;
        //}
        #endregion

        #region Reporting Functions
        /// <summary>
        /// <Description>this method is for conversion of populate gwiz report</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public ReportResponse PopulateGwizReport(ReportRequest Request)
        //{
        //    ReportResponse reportResponse = new ReportResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        reportResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateGwizReport(businessConverter.Convert(Request.PopulateReportRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return reportResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of PopulateGWizOtherInfoReport</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public OtherInfoReportResponse PopulateGWizOtherInfoReport(OtherInfoReportRequest Request)
        //{
        //    OtherInfoReportResponse otherInfoReportResponse = new OtherInfoReportResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        otherInfoReportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateGWizOtherInfoReport(businessConverter.Convert(Request.PopulateOtherInfoReportRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return otherInfoReportResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of PupulateGWizBrokenInfoReport</Description>
        /// </summary>
        /// <returns>Report Response</returns>
        //public ReportResponse PupulateGWizBrokenInfoReport()
        //{
        //    ReportResponse reportResponse = new ReportResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        reportResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PupulateGWizBrokenInfoReport());
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return reportResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of PupulateGWizOtherBrokenInfoReport</Description>
        /// </summary>
        /// <returns>Other Info Report Response</returns>
        //public OtherInfoReportResponse PupulateGWizOtherBrokenInfoReport()
        //{
        //    OtherInfoReportResponse otherInfoReportResponse = new OtherInfoReportResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        otherInfoReportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PupulateGWizOtherBrokenInfoReport());
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return otherInfoReportResponse;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public FeedbackTypeReportResponse PupulateGWizFeedbackTypeReport(FeedbackReportRequest Request)
        //{
        //    FeedbackTypeReportResponse feedbackTypeResponse = new FeedbackTypeReportResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter requestConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        feedbackTypeResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFeedbackTypeReport(requestConverter.Convert(Request.PopulateReportRequest)));
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return feedbackTypeResponse;
        //}

        /// <summary>
        /// <Description>this method is for conversion of populate gwiz report</Description>
        /// </summary>
        /// <param name="Request">Client Deployment Report Request </param>
        /// <returns>Client Deployment Report Response</returns>
        public ClientDeploymentReportResponse PopulateGWizClientDeploymentReport(ClientDeploymentReportRequest Request)
        {
            ClientDeploymentReportResponse reportResponse = new ClientDeploymentReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                //// _iGWizBusinessProvider.PopulateClientDeploymentReport( businessConverter.Convert(Request.UserID));
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateClientDeploymentReport(businessConverter.Convert(Request.ClientDeploymentReport)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }
        #endregion

        /// <summary>
        /// <Description>this method is for conversion of populate gwiz report</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public ClientUsageReportResponse PopulateGWizClientUsageReport(ClientUsageReportRequest Request)
        {
            ClientUsageReportResponse reportResponse = new ClientUsageReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateClientUsageReport(businessConverter.Convert(Request.ClientUsageReport)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        #region User
        /// <summary>
        /// <Description>this method is for conversion of search users</Description>
        /// </summary>
        /// <param name="Request">User Search Request</param>
        /// <returns>User Search Response</returns>
        public UserSearchResponse SearchUsers(UserSearchRequest Request)
        {
            UserSearchResponse userResponse = new UserSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                userResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchUsers(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return userResponse;
        }

        public UserSearchResponse PopulateSearchUsers(UserSearchRequest Request)
        {
            UserSearchResponse userResponse = new UserSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                userResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateSearchUsers(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return userResponse;
        }

        //public ManupulateResponse ManageAccounts(AccountManipulateRequest Request)
        //{
        //    ManupulateResponse accResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        accResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageAccounts(businessConverter.Convert(Request.ManipulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return accResponse;
        //}


        public ManupulateResponse ManageRole(RoleManipulateRequest Request)
        {
            ManupulateResponse roleResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                roleResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageRole(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return roleResponse;
        }

        //public ManupulateResponse ManageCities(CityManipulateRequest Request)
        //{
        //    ManupulateResponse cityResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        cityResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageCities(businessConverter.Convert(Request.ManipulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return cityResponse;

        //}
        /// <summary>
        ///  <Description>this method is for conversion of manage Countries</Description>
        /// </summary>
        /// <param name="Request">Country Manipulate Request</param>
        /// <returns>Manupulate Response</returns>
        //public ManupulateResponse ManageCountry(CountryManipulateRequest Request)
        //{
        //    ManupulateResponse countryResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        countryResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageCountry(businessConverter.Convert(Request.ManipulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return countryResponse;
        //}

        /// <summary>
        ///  <Description>this method is for conversion of manage users</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public UserStandardResponse ManageUsers(UserManipulateRequest Request)
        {
            UserStandardResponse userResponse = new UserStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                userResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageUsers(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return userResponse;
        }


        public UserStandardResponse ManageUserPersonalProfile(UserManipulateRequest Request)
        {
            UserStandardResponse userResponse = new UserStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                userResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageUserProfile(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return userResponse;
        }
        #endregion

        #region Version
        /// <summary>
        /// <Description>this method is for conversion of search Versions</Description>
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public VerSearchResponse SearchVersions(AppUserSearchRequest AppRequest)
        {
            VerSearchResponse verResponse = new VerSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                //verResponse.VersionSearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateVersions());
                verResponse.VersionSearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateVersions(businessConverter.Convert(AppRequest.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return verResponse;
        }
        #endregion

        #region UserRole
        /// <summary>
        ///  <Description>this method is for conversion of PopulateUserRole</Description>
        /// </summary>
        /// <returns></returns>
        public PopulateUserRoleResponse PopulateUserRole()
        {
            PopulateUserRoleResponse objPopulateRoleResponse = new PopulateUserRoleResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateRoleResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateUserRole());
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objPopulateRoleResponse;
        }
        #endregion

        #region Aggregation
        /// <summary>
        /// populate Aggregation Rule
        /// </summary>
        /// <returns></returns>
        //public PopulateAggregationRuleResponse PopulateAggregationRule()
        //{
        //    PopulateAggregationRuleResponse objPopulateAggregateRuleResponse = new PopulateAggregationRuleResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateAggregateRuleResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAggregationRule());
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objPopulateAggregateRuleResponse;
        //}

        /// <summary>
        /// Manage aggregation rules.
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public StandardAggregationRuleResponse ManageAggregationRule(AggregationRuleRequest Request)
        //{
        //    StandardAggregationRuleResponse standardAggregationRuleResponse = new StandardAggregationRuleResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        standardAggregationRuleResponse.StandardResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageAggregationRule(businessConverter.Convert(Request.PopulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return standardAggregationRuleResponse;
        //}
        #endregion

        #region UserAuthentication
        public UserAuthenticationResponse UserAuthentication(UserAuthenticationRequest request)
        {
            UserAuthenticationResponse userAuthenticationResponse = new UserAuthenticationResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            try
            {
                userAuthenticationResponse = responseConverter.Convert(this._iGWizBusinessProvider.UserAuthentication(businessConverter.Convert(request.UserAuthenticationQuery)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                userAuthenticationResponse.ServiceResponse = new StandardResponse();
                userAuthenticationResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                userAuthenticationResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6017);
            }

            return userAuthenticationResponse;
        }
        #endregion

        #region ClientDeployment
        public ManupulateResponse ClientDeploymentDetailResponse(ClientDeploymentRequest request)
        {
            ManupulateResponse manupulateResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.AddClientDeploymentDetail(businessConverter.Convert(request.DeploymentInfo)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                manupulateResponse.Status = new StandardResponse();
                manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
                manupulateResponse.Status.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6018);
            }

            return manupulateResponse;
        }
        #endregion

        #region ClientUsage
        public ManupulateResponse ClientUsageDetailResponse(ClientUsageRequest request)
        {
            ManupulateResponse manupulateResponse = new ManupulateResponse();
            StandardResponse std = new StandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.AddClientUsageDetail(businessConverter.Convert(request.Usageinfo)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                manupulateResponse.Status = new StandardResponse();
                manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
                manupulateResponse.Status.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6018);
            }

            return manupulateResponse;
        }
        #endregion

        #region search label
        //public SearchLabelResponse SearchLabel(SearchLabelRequest request)
        //{
        //    SearchLabelResponse searchLabelResponse = new SearchLabelResponse();

        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    try
        //    {
        //        searchLabelResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchLabel(businessConverter.Convert(request.SearchLabelQuery)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        searchLabelResponse.ServiceResponse = new StandardResponse();
        //        searchLabelResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        searchLabelResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6017);
        //    }

        //    return searchLabelResponse;
        //}

        //public ClientInfoResponse PopulateClientInfo()
        //{
        //    ClientInfoResponse objPopulateClientResponse = new ClientInfoResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateClientResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateClient());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateClientResponse.ServiceResponse = new StandardResponse();
        //        objPopulateClientResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateClientResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objPopulateClientResponse;
        //}

        //public ClientInfoResponse PopulateUserClientInfo(UserSearchRequest request)
        //{
        //    ClientInfoResponse objPopulateUserClientResponse = new ClientInfoResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateUserClientResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateUserClient(businessConverter.Convert(request.SearchRequest)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateUserClientResponse.ServiceResponse = new StandardResponse();
        //        objPopulateUserClientResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateUserClientResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objPopulateUserClientResponse;
        //}
        //public MappingResponse MappingDetails(MappingRequest Request)
        //{
        //    MappingResponse objMappingResponse = new MappingResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objMappingResponse.MappingDetail = responseConverter.Convert(this._iGWizBusinessProvider.GetMappingDetails(businessConverter.Convert(Request.MappingInput)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objMappingResponse.ServiceResponse = new StandardResponse();
        //        objMappingResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objMappingResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objMappingResponse;
        //}
        #endregion

        public ManupulateResponse ClientReleaseResponse(ClientReleaseRequest request)
        {
            ManupulateResponse manupulateResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.SaveClientReleaseInfo(businessConverter.Convert(request.ClientRelease)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                manupulateResponse.Status = new StandardResponse();
                manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
                manupulateResponse.Status.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6018);
            }

            return manupulateResponse;
        }

        #region Client
        /// <summary>
        /// <Description>this method is for conversion of populateaccount</Description>
        /// </summary>
        /// <returns>Populate Account Response</returns>
        //public PopulateClientResponse PopulateClientResponse(ClientRequest request)
        //{
        //    PopulateClientResponse objPopulateClientResponse = new PopulateClientResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //        objPopulateClientResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateClientResponse(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateClientResponse.ServiceResponse = new StandardResponse();
        //        objPopulateClientResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateClientResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objPopulateClientResponse;
        //}

        //public ManageClientResponse SearchClients(ManageClientRequest Request)
        //{
        //    ManageClientResponse clientResponse = new ManageClientResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        clientResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchClients(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return clientResponse;
        //}
        #endregion

        #region Application
        public ManageApplicationResponse SearchApplication(ManageApplicationRequest Request)
        {
            ManageApplicationResponse applicationResponse = new ManageApplicationResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                applicationResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchApplication(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return applicationResponse;
        }
        #endregion


        public ManupulateResponse ManageApplication(ApplicationManipulateRequest Request)
        {
            ManupulateResponse applicationResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                applicationResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageApplication(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return applicationResponse;
        }

        public PopulateApplicationResponse PopulateApplicationResponse(ApplicationRequest request)
        {
            PopulateApplicationResponse objPopulateApplicationResponse = new PopulateApplicationResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
                objPopulateApplicationResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateApplicationResponse(businessConverter.Convert(request)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateApplicationResponse.ServiceResponse = new StandardResponse();
                objPopulateApplicationResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateApplicationResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objPopulateApplicationResponse;
        }

        public AppUploadedReportResponse PopulateGWizAppUploadedReport(AppUploadedReportRequest Request)
        {
            AppUploadedReportResponse reportResponse = new AppUploadedReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppUploadedReport(businessConverter.Convert(Request.AppUploadedReport)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        #region Roles
        public ManageRoleResponse SearchRoles(ManageRoleRequest Request)
        {
            ManageRoleResponse roleResponse = new ManageRoleResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                roleResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchRoles(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return roleResponse;
        }

        public ManageRoleResponse SearchClientRoles(ManageRoleRequest Request)
        {
            ManageRoleResponse roleResponse = new ManageRoleResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                roleResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchClientRoles(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return roleResponse;
        }

        public RoleResponse PopulateRoles(PopulateRoleRequest request)
        {
            RoleResponse objPopulateRoleResponse = new RoleResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
                objPopulateRoleResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateRoles(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                /*objPopulateFunctionsResponse.ServiceResponse = new StandardResponse();
                objPopulateFunctionsResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateFunctionsResponse.ServiceResponse.ResponseMessage = msg;*/
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objPopulateRoleResponse;
        }

        public RoleMasterResponse PopulateRoleMaster()
        {
            RoleMasterResponse objPopulateRoleMasterResponse = new RoleMasterResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                //RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
                objPopulateRoleMasterResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateRoleMaster());
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                /*objPopulateFunctionsResponse.ServiceResponse = new StandardResponse();
                objPopulateFunctionsResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateFunctionsResponse.ServiceResponse.ResponseMessage = msg;*/
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objPopulateRoleMasterResponse;
        }
        #endregion

        #region Functions

        public FunctionResponse PopulateFunctions(FunctionRequest request)
        {
            FunctionResponse objPopulateFunctionsResponse = new FunctionResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
                objPopulateFunctionsResponse.PopulateResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFunctions(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                /*objPopulateFunctionsResponse.ServiceResponse = new StandardResponse();
                objPopulateFunctionsResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateFunctionsResponse.ServiceResponse.ResponseMessage = msg;*/
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objPopulateFunctionsResponse;
        }

        #endregion

        //public ManupulateResponse ManageClients(ClientManipulateRequest Request)
        //{
        //    ManupulateResponse accResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        accResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageClients(businessConverter.Convert(Request.ManipulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return accResponse;
        //}

        //public PopulateClientAccResponse PopulateClientAcc(ClientAccRequest request)
        //{
        //    PopulateClientAccResponse objPopulateClientAccResponse = new PopulateClientAccResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //        objPopulateClientAccResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateClientbyAcc(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateClientAccResponse.ServiceResponse = new StandardResponse();
        //        objPopulateClientAccResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateClientAccResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6015);
        //    }

        //    return objPopulateClientAccResponse;
        //}

        public ApplicationInfoResponse PopulateAppInfo()
        {
            ApplicationInfoResponse objPopulateAppResponse = new ApplicationInfoResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAppResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateApplication());
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateAppResponse.ServiceResponse = new StandardResponse();
                objPopulateAppResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateAppResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objPopulateAppResponse;
        }

        public UserMenuResponse SearchUserMenu(UserSearchRequest request)
        {
            UserMenuResponse objUserMenuResponse = new UserMenuResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
                objUserMenuResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchUserMenu(businessConverter.Convert(request.SearchRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                /*objPopulateFunctionsResponse.ServiceResponse = new StandardResponse();
                objPopulateFunctionsResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateFunctionsResponse.ServiceResponse.ResponseMessage = msg;*/
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objUserMenuResponse;


        }

        public ManupulateResponse ManageAppFocus(AppFocusManipulateRequest Request)
        {
            ManupulateResponse appFocusResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                appFocusResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManageAppFocus(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return appFocusResponse;
        }

        #region Time Duration
        /// <summary>
        /// <Description>this method is for conversion of populate city</Description>
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public DurationTimeStandardResponse ManageTimeDuration(TimeDurationManipulateRequest request)
        {
            DurationTimeStandardResponse objPopulateTimeDurationResponse = new DurationTimeStandardResponse();


            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateTimeDurationResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageDurationTime(businessConverter.Convert(request.ManipulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateTimeDurationResponse.ServiceResponse = new StandardResponse();
                objPopulateTimeDurationResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateTimeDurationResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6019);
            }


            return objPopulateTimeDurationResponse;
        }
        public DurationTimeSearchResponse SearchTimeDuration(TimeDurationSearchRequest Request)
        {
            DurationTimeSearchResponse TimeDurationResponse = new DurationTimeSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                TimeDurationResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchDurationTime(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return TimeDurationResponse;
        }


        #endregion

        public AppFocusReportResponse PopulateAppFocusReport(AppFocusReportRequest request)
        {
            AppFocusReportResponse objPopulateAppFocusRepResponse = new AppFocusReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAppFocusRepResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppFocusReport(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                //string msg = ExceptionManager.GetErrorMessage(8050);
                //objPopulateAppFocusRepResponse.ServiceResponse = new StandardResponse();
                //objPopulateAppFocusRepResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                //objPopulateAppFocusRepResponse.ServiceResponse.ResponseMessage = msg;
                //LogManager.LogErrorMessage(ex, 6019);
            }

            return objPopulateAppFocusRepResponse;
        }

        public AppFocusReportResponse PopulateAppFocusReportDetail(AppFocusReportRequest request)
        {
            AppFocusReportResponse objPopulateAppFocusRepResponse = new AppFocusReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAppFocusRepResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppFocusReportDetail(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateAppFocusRepResponse.ServiceResponse = new StandardResponse();
                objPopulateAppFocusRepResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateAppFocusRepResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6019);
            }

            return objPopulateAppFocusRepResponse;
        }

        #region FocusReportDetails
        /// <summary>
        /// <Description>this method is for conversion of populate Focus Report Details</Description>
        /// </summary>
        /// <returns></returns>
        public RptFocusAppNameResponse PopulateFocusReportApplicationName()
        {
            RptFocusAppNameResponse objPopulateAPPFApplicationResponse = new RptFocusAppNameResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAPPFApplicationResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFocusReportAppName());
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateAPPFApplicationResponse.ServiceResponse = new StandardResponse();
                objPopulateAPPFApplicationResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateAPPFApplicationResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6012);
            }

            return objPopulateAPPFApplicationResponse;
        }
        //public RptFocusOfficeIDResponse PopulateFocusReportOfficeID()
        //{
        //    RptFocusOfficeIDResponse objPopulateAPPFOfficeResponse = new RptFocusOfficeIDResponse();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objPopulateAPPFOfficeResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFocusReportOfficeID());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPopulateAPPFOfficeResponse.ServiceResponse = new StandardResponse();
        //        objPopulateAPPFOfficeResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPopulateAPPFOfficeResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6012);
        //    }

        //    return objPopulateAPPFOfficeResponse;
        //}
        public RptFocusOfficeIDResponse PopulateFocusReportOfficeID(FocusGroupRequest request)
        {
            RptFocusOfficeIDResponse objPopulateAPPFOfficeResponse = new RptFocusOfficeIDResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAPPFOfficeResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateFocusReportOfficeID(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateAPPFOfficeResponse.ServiceResponse = new StandardResponse();
                objPopulateAPPFOfficeResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateAPPFOfficeResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6012);
            }

            return objPopulateAPPFOfficeResponse;
        }
        #endregion

        #region FocusApplciation
        /// <summary>
        /// <Description>this method is for search Application</Description>
        /// </summary>
        /// <returns></returns>
        public FoucsApplicationSearchResponse SearchFocusApplication(FocusApplicationSearchRequest Request)
        {
            FoucsApplicationSearchResponse FocusAppResponse = new FoucsApplicationSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                FocusAppResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchFocusApp(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return FocusAppResponse;
        }

        public FoucsApplicationSearchResponse PopulateSearchFocusApplication(FocusApplicationSearchRequest Request)
        {
            FoucsApplicationSearchResponse FocusAppResponse = new FoucsApplicationSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                FocusAppResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateSearchFocusApp(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return FocusAppResponse;
        }
        public FocusApplicationStandardResponse ManageFocusApplication(FocusApplicationManipulateRequest Request)
        {
            FocusApplicationStandardResponse AppuserResponse = new FocusApplicationStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                AppuserResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageFocusApplications(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AppuserResponse;
        }

        public AppFocusReportResponse PopulateAppUserFocusReportDetail(AppFocusReportRequest request)
        {
            AppFocusReportResponse objPopulateAppFocusRepResponse = new AppFocusReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateAppFocusRepResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppUserFocusReportDetail(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateAppFocusRepResponse.ServiceResponse = new StandardResponse();
                objPopulateAppFocusRepResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateAppFocusRepResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6019);
            }

            return objPopulateAppFocusRepResponse;
        }
        #endregion

        #region AppFocusOffice
        public AppFocusOfficeSearchResponse SearchAppFocusOffice(AppFocusOfficeSearchRequest Request)
        {
            AppFocusOfficeSearchResponse FocusAppResponse = new AppFocusOfficeSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                FocusAppResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchAppFocusOffice(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return FocusAppResponse;
        }
        public ApplFocusOfficeStandardResponse ManageAppFocusOffice(AppFocusOfficeManuplateRequest Request)
        {
            ApplFocusOfficeStandardResponse AppuserResponse = new ApplFocusOfficeStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                AppuserResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageAppFocusOffice(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AppuserResponse;
        }

        public FoucsGroupSearchResponse SearchAPPFocusGroup(FocusGroupSearchRequest Request)
        {
            FoucsGroupSearchResponse FocusGroupResponse = new FoucsGroupSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                FocusGroupResponse.SearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchAPPFGroup(businessConverter.Convert(Request.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return FocusGroupResponse;
        }
        public FocusGroupStandardResponse ManageAppFocusGroup(FocusGroupManipulateRequest Request)
        {
            FocusGroupStandardResponse AppFGroupResponse = new FocusGroupStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                AppFGroupResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageAppFocusGroup(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return AppFGroupResponse;
        }

        public PopulateFocusGroupResponse LoadOfficeGroup(FocusGroupRequest Request)
        {
            PopulateFocusGroupResponse objPopulateOfficeGroupResponse = new PopulateFocusGroupResponse();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            try
            {
                objPopulateOfficeGroupResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateOfficeGroup(businessConverter.Convert(Request)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateOfficeGroupResponse.ServiceResponse = new StandardResponse();
                objPopulateOfficeGroupResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateOfficeGroupResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6017);
            }

            return objPopulateOfficeGroupResponse;
        }

        public AppFOfficeGroupMappingResponse GetMappingOfficeGroupDetails(FocusGroupMappingRequest Request)
        {
            AppFOfficeGroupMappingResponse objMappingResponse = new AppFOfficeGroupMappingResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objMappingResponse.MappingDetail = responseConverter.Convert(this._iGWizBusinessProvider.GetMappingOfficeGroupDetails(businessConverter.Convert(Request.MappingRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objMappingResponse.ServiceResponse = new StandardResponse();
                objMappingResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objMappingResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objMappingResponse;
        }

        public FocusGroupStandardResponse MappedOfficeGroupdtls(FocusGroupMappingRequest Request)
        {
            FocusGroupStandardResponse manupulateResponse = new FocusGroupStandardResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                ////manupulateResponse.Status = responseConverter.Convert(_iGWizBusinessProvider.MapCountry(businessConverter.Convert(Request.MapCountry)));
                manupulateResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.MappedOfficeGroupdtls(businessConverter.Convert(Request.MappingRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                manupulateResponse.ServiceResponse = new StandardResponse();
                manupulateResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                manupulateResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6018);
            }

            return manupulateResponse;
        }
        #endregion

        #region AppVersion
        public VerSearchResponse SearchPreVersions(AppUserSearchRequest AppRequest)
        {
            VerSearchResponse verResponse = new VerSearchResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                verResponse.VersionSearchResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulatePreVersions(businessConverter.Convert(AppRequest.SearchRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return verResponse;
        }

        public ManupulateResponse UpdateAppPreVersion(ClientReleaseRequest request)
        {
            ManupulateResponse manupulateResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.UpdatePreVersionRelease(businessConverter.Convert(request.ClientRelease)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                manupulateResponse.Status = new StandardResponse();
                manupulateResponse.Status.ResponseCodeStatus = StdResponseCode.Failed;
                manupulateResponse.Status.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6018);
            }

            return manupulateResponse;
        }

        public OfficeGroupMappingReportResponse PopulateOfficeGroupMappingReport(OficeGroupMappingReportRequest Request)
        {
            OfficeGroupMappingReportResponse reportResponse = new OfficeGroupMappingReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateOfficeGroupMappingReport(businessConverter.Convert(Request.OfficeGroupMappingReportRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        public AppUploadedReportResponse PopulatePilotAppUploadReport(AppUploadedReportRequest Request)
        {
            AppUploadedReportResponse reportResponse = new AppUploadedReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulatePilotAppReport(businessConverter.Convert(Request.AppUploadedReport)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        public PilotAppUploadRepResponse PopulatePilotUserDetails(PilotAppUploadRepRequest Request)
        {
            PilotAppUploadRepResponse reportResponse = new PilotAppUploadRepResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulatePilotUserDetails(businessConverter.Convert(Request.PopulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }
        #endregion

        #region PilotApp_ImportExcelSheet
        public ManupulateResponse ImportPilotAppData(PilotAppExcelSheetManipulateRequest Request)
        {
            ManupulateResponse pilotAppExcelSheetResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                pilotAppExcelSheetResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ImportPilotAppData(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return pilotAppExcelSheetResponse;
        }

        #endregion

        public AppfOfficeAdsIDResponse PopulateAppFOfficeADSID(AppFOfficeAdsIDRequest Request)
        {
            AppfOfficeAdsIDResponse objMappingResponse = new AppfOfficeAdsIDResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objMappingResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppfAdsID(businessConverter.Convert(Request)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objMappingResponse.ServiceResponse = new StandardResponse();
                objMappingResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objMappingResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objMappingResponse;
        }
        public AppfOfficeAdsIDResponse ManageAppFOfficeADSID(AppFOfficeAdsIDRequest Request)
        {
            AppfOfficeAdsIDResponse objMappingResponse = new AppfOfficeAdsIDResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objMappingResponse.ServiceResponse = responseConverter.Convert(this._iGWizBusinessProvider.ManageAppfAdsID(businessConverter.Convert(Request)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objMappingResponse.ServiceResponse = new StandardResponse();
                objMappingResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objMappingResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6015);
            }

            return objMappingResponse;
        }

        #region PopulateTravelSuiteAppFocusReport

        public TravelSuiteAppFocusReportResponse PopulateTravelSuiteAppFocusReport(TravelSuiteAppFocusReportRequest request)
        {
            TravelSuiteAppFocusReportResponse objPopulateTravleSuitResponse = new TravelSuiteAppFocusReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                objPopulateTravleSuitResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateTravelSuiteAppFocusReport(businessConverter.Convert(request.PopulateRequest)));
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                objPopulateTravleSuitResponse.ServiceResponse = new StandardResponse();
                objPopulateTravleSuitResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objPopulateTravleSuitResponse.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 6019);
            }

            return objPopulateTravleSuitResponse;
        }

        #endregion

        public PilotApplicationDeploymentReportResponse PopulatePilotApplicationDeploymentReport(PilotApplicationDeploymentReportRequest Request)
        {
            PilotApplicationDeploymentReportResponse reportResponse = new PilotApplicationDeploymentReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                //// _iGWizBusinessProvider.PopulateClientDeploymentReport( businessConverter.Convert(Request.UserID));
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulatePilotApplicationDeploymentReport(businessConverter.Convert(Request.PilotApplicationDeploymentReport)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        #region CheckPilotAppUser
        //public PilotAppUploadRepResponse CheckPilotAppUser(PilotAppUploadRepRequest Request)
        //{
        //    PilotAppUploadRepResponse reportResponse = new PilotAppUploadRepResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.CheckPilotAppUser(businessConverter.Convert(Request.PopulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return reportResponse;
        //}

        public ManupulateResponse CheckPilotAppUser(PilotAppUploadRepRequest Request)
        {
            ManupulateResponse manupulateResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                manupulateResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.CheckPilotAppUser(businessConverter.Convert(Request.PopulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return manupulateResponse;
        }

        public ManupulateResponse AddOffice(AddOfficeManipulateRequest Request)
        {
            ManupulateResponse reportResponse = new ManupulateResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.AddOffice(businessConverter.Convert(Request.ManipulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

        #endregion

        #region PopulateACWReport
        public ACWReportResponse PopulateACWReport(ACWReportRequest Request)
        {
            ACWReportResponse reportResponse = new ACWReportResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateACWReport(businessConverter.Convert(Request.PopulateRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                throw new FaultException<CustomFaultMsg>(custmErr);

            }
            return reportResponse;
        }

        #endregion

        #region PopulateAppFIndicator
        public AppFocusIndicatorResponse PopulateAppFIndicator()
        {
            AppFocusIndicatorResponse IndicatorResponse = new AppFocusIndicatorResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                IndicatorResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateAppFocusIndicator());
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                throw new FaultException<CustomFaultMsg>(custmErr);

            }
            return IndicatorResponse;
        }

        #endregion

        #region PopulateGlobalAlert
        //public GlobalAlertResponse PopulateGlobalAlert()
        //{
        //    GlobalAlertResponse AlertResponse = new GlobalAlertResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        AlertResponse = responseConverter.Convert(this._iGWizBusinessProvider.PopulateGlobalAlert());
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        throw new FaultException<CustomFaultMsg>(custmErr);

        //    }
        //    return AlertResponse;
        //}


        //public SearchLinkResponse SearchLinkGlobalAlert()
        //{
        //    SearchLinkResponse objSearchLinkResponse = new SearchLinkResponse();
        //    StandardResponse std = new StandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objSearchLinkResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchLinkDataGlobalAlert());
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResponse.ServiceResponse = new StandardResponse();
        //        objSearchLinkResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchLinkResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6000);
        //    }

        //    return objSearchLinkResponse;
        //}

        //public SearchLinkResponse SearchLinkGlobalAlert(ClientGlobalAlertRequest request)
        //{
        //    SearchLinkResponse objSearchLinkResponse = new SearchLinkResponse();
        //    StandardResponse std = new StandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objSearchLinkResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchLinkDataGlobalAlert(businessConverter.Convert(request)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResponse.ServiceResponse = new StandardResponse();
        //        objSearchLinkResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchLinkResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6000);
        //    }

        //    return objSearchLinkResponse;
        //}

        #endregion

        //#region Populate PendingApprovalReport
        //public PendingApprovalResponse PopulatePendingApproval(PendingApprovalRequest Request)
        //{
        //    PendingApprovalResponse response = new PendingApprovalResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        response = responseConverter.Convert(this._iGWizBusinessProvider.PopulatePendingApproval(businessConverter.Convert(Request.PopulatePendingApprovalRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        throw new FaultException<CustomFaultMsg>(custmErr);

        //    }
        //    return response;
        //}
        //#endregion


        #region Populate PopulateTransitData
        public TransitDataResponse SearchTransitData(TransitDataRequest Request)
        {
            TransitDataResponse response = new TransitDataResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                response = responseConverter.Convert(this._iGWizBusinessProvider.PopulateTransitData(businessConverter.Convert(Request.PopulateTransitDataRequest)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                throw new FaultException<CustomFaultMsg>(custmErr);

            }
            return response;
        }
        #endregion

        //#region Manage Pending Approval
        //public ManupulateResponse ManagePendingApproval(ManagePendingApprovalRequest Request)
        //{
        //    ManupulateResponse approvalResponse = new ManupulateResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        approvalResponse.Status = responseConverter.Convert(this._iGWizBusinessProvider.ManagePendingApproval(businessConverter.Convert(Request.ManipulateRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return approvalResponse;

        //}
        //#endregion

        //public SearchLinkResponse SearchLinkClientAlert(SearchLinkRequest request)
        //{
        //    SearchLinkResponse objSearchLinkResponse = new SearchLinkResponse();
        //    StandardResponse std = new StandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objSearchLinkResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchLinkDataClientAlert(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchLinkResponse.ServiceResponse = new StandardResponse();
        //        objSearchLinkResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchLinkResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6000);
        //    }

        //    return objSearchLinkResponse;
        //}

        //public SearchClientTotalAlertResponse SearchClientTotalAlert(SearchLinkRequest request)
        //{
        //    SearchClientTotalAlertResponse objSearchTotalAlertResponse = new SearchClientTotalAlertResponse();
        //    StandardResponse std = new StandardResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objSearchTotalAlertResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchClientTotalAlert(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objSearchTotalAlertResponse.ServiceResponse = new StandardResponse();
        //        objSearchTotalAlertResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objSearchTotalAlertResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6000);
        //    }

        //    return objSearchTotalAlertResponse;
        //}

        //public SearchOtherInfoTotalAlertResponse SearchOtherInfoTotalAlert(SearchOtherInfoRequest request)
        //{
        //    SearchOtherInfoTotalAlertResponse objOtherinfoResponse = new SearchOtherInfoTotalAlertResponse();

        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        objOtherinfoResponse = responseConverter.Convert(this._iGWizBusinessProvider.SearchOtherInfoTotalAlert(businessConverter.Convert(request.Query)));
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objOtherinfoResponse.ServiceResponse = new StandardResponse();
        //        objOtherinfoResponse.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objOtherinfoResponse.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 6005);
        //    }

        //    return objOtherinfoResponse;
        //}

        //public AuditTrialResponse GetAuditTrial(AuditTrialRequest Request)
        //{
        //    AuditTrialResponse accResponse = new AuditTrialResponse();
        //    RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
        //    BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
        //    try
        //    {
        //        accResponse = responseConverter.Convert(this._iGWizBusinessProvider.GetAuditTrial(businessConverter.Convert(Request.SearchRequest)));
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return accResponse;
        //}

        public GetAppLatestVersionResponse GetAppLatestVersion(GetAppLatestVersionRequest Request)
        {
            GetAppLatestVersionResponse reportResponse = new GetAppLatestVersionResponse();
            RequestToBusinessEntityConverter businessConverter = new RequestToBusinessEntityConverter();
            BusinessEntityToResponseConveter responseConverter = new BusinessEntityToResponseConveter();
            try
            {
                //// _iGWizBusinessProvider.PopulateClientDeploymentReport( businessConverter.Convert(Request.UserID));
                reportResponse = responseConverter.Convert(this._iGWizBusinessProvider.GetAppLatestVersion(businessConverter.Convert(Request)));
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return reportResponse;
        }

    }
}
