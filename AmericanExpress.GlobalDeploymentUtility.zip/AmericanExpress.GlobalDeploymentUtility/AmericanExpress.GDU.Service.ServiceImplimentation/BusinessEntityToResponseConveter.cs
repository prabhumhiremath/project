﻿//-----------------------------------------------------------------------
// <copyright file="BusinessEntityToResponseConveter.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a converter class which converts business response to the service entities.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Buss = AmericanExpress.GDU.BusinessEntities;
using Serv = AmericanExpress.GDU.Service.DataContracts;
using AmericanExpress.GDU.Utilities.ExceptionMgmt;
using System.ServiceModel;
using AmericanExpress.GDU.Service.MessageContracts.Responses;
using AmericanExpress.GDU.Utilities.Diagnostics;
#endregion
namespace AmericanExpress.GDU.Service.ServiceImplimentation
{
    public class BusinessEntityToResponseConveter
    {
        #region Public Methods
        /// <summary>
        ///  <Description>Converts business SearchInfoResult response to service SearchOtherInfoResult input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public SearchOtherInfoResponse Convert(Buss.SearchInfoResult[] input)
        //{
        //    SearchOtherInfoResponse response = new SearchOtherInfoResponse();
        //    int incOtherResult = 0;
        //    int otherInfoCount = 0;
        //    int otherInfoDetailCount = 0;
        //    Serv.SearchOtherInfoResult[] objOtherInfoResult = new Serv.SearchOtherInfoResult[input.Length];
        //    Serv.SearchOtherInfo[] objSearchOtherInfo = null;
        //    Serv.SearchOtherInfoDetails[] objSearchOtherInfoDetails = null;
        //    response.Response = objOtherInfoResult;
        //    try
        //    {
        //        foreach (Buss.SearchInfoResult SearchOtherInfo in input)
        //        {
        //            if (SearchOtherInfo != null)
        //            {
        //                if (SearchOtherInfo.SearchOthResult != null)
        //                {
        //                    otherInfoCount = 0;
        //                    objOtherInfoResult[incOtherResult] = new Serv.SearchOtherInfoResult();
        //                    objSearchOtherInfo = new Serv.SearchOtherInfo[SearchOtherInfo.SearchOthResult.Length];
        //                    foreach (Buss.SearchOtherInfo otherInfo in SearchOtherInfo.SearchOthResult)
        //                    {
        //                        if (otherInfo != null)
        //                        {
        //                            objSearchOtherInfo[otherInfoCount] = new AmericanExpress.GDU.Service.DataContracts.SearchOtherInfo();
        //                            objSearchOtherInfo[otherInfoCount].OtherInfoID = otherInfo.OtherInfoID;
        //                            objSearchOtherInfo[otherInfoCount].DownloadFlag = otherInfo.DownloadFlag;
        //                            objSearchOtherInfo[otherInfoCount].GeneralText = otherInfo.GeneralText;
        //                            objSearchOtherInfo[otherInfoCount].IsAlertRangeVisible = otherInfo.IsAlertRangeVisible;
        //                            objSearchOtherInfo[otherInfoCount].HoverText = otherInfo.HoverText;
        //                            objSearchOtherInfo[otherInfoCount].Keyword_txt = otherInfo.Keyword_Txt;
        //                            objSearchOtherInfo[otherInfoCount].IsBrowsable = otherInfo.IsBrowsable;
        //                            objSearchOtherInfo[otherInfoCount].LabelID = otherInfo.LabelID;
        //                            objSearchOtherInfo[otherInfoCount].LabelName = otherInfo.LabelName;
        //                            objSearchOtherInfo[otherInfoCount].LanguageCode = otherInfo.LanguageCode;
        //                            objSearchOtherInfo[otherInfoCount].Link = otherInfo.Link;
        //                            objSearchOtherInfo[otherInfoCount].LinkType = otherInfo.LinkType;
        //                            objSearchOtherInfo[otherInfoCount].LinkTypeCode = otherInfo.LinkTypeCode;
        //                            objSearchOtherInfo[otherInfoCount].OtherInfoID = otherInfo.OtherInfoID;
        //                            objSearchOtherInfo[otherInfoCount].OtherInfoLabelID = otherInfo.OtherInfoLabelID;
        //                            objSearchOtherInfo[otherInfoCount].Priority = otherInfo.Priority;
        //                            objSearchOtherInfo[otherInfoCount].Rating = otherInfo.Rating;
        //                            objSearchOtherInfo[otherInfoCount].ValidFromDate = otherInfo.ValidFromDate;
        //                            objSearchOtherInfo[otherInfoCount].ValidToDate = otherInfo.ValidToDate;
        //                            objSearchOtherInfo[otherInfoCount].DisplayValidFromMonth = otherInfo.DisplayValidFromMonth;
        //                            objSearchOtherInfo[otherInfoCount].DisplayValidToMonth = otherInfo.DisplayValidToMonth;
        //                            objSearchOtherInfo[otherInfoCount].DisplayValidFromDay = otherInfo.DisplayValidFromDay;
        //                            objSearchOtherInfo[otherInfoCount].DisplayValidToDay = otherInfo.DisplayValidToDay;

        //                            objSearchOtherInfo[otherInfoCount].MacID = otherInfo.MacID;
        //                            objSearchOtherInfo[otherInfoCount].IPAddress = otherInfo.IPAddress;
        //                            objSearchOtherInfo[otherInfoCount].ComputerName = otherInfo.ComputerName;
        //                            objSearchOtherInfo[otherInfoCount].CreatedUserID = otherInfo.CreatedUserID;
        //                            objSearchOtherInfo[otherInfoCount].CreatedUserDate = otherInfo.CreatedUserDate;
        //                            objSearchOtherInfo[otherInfoCount].ModifiedUserID = otherInfo.ModifiedUserID;
        //                            objSearchOtherInfo[otherInfoCount].ModifiedUserDate = otherInfo.ModifiedUserDate;
        //                            objSearchOtherInfo[otherInfoCount].DomainName = otherInfo.DomainName;

        //                            if (otherInfo.OtherInfoDetails != null)
        //                            {
        //                                otherInfoDetailCount = 0;
        //                                objSearchOtherInfoDetails = new AmericanExpress.GDU.Service.DataContracts.SearchOtherInfoDetails[otherInfo.OtherInfoDetails.Length];

        //                                foreach (Buss.SearchOtherInfoDetails otherInfoDetails in otherInfo.OtherInfoDetails)
        //                                {
        //                                    if (otherInfoDetails != null)
        //                                    {
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount] = new AmericanExpress.GDU.Service.DataContracts.SearchOtherInfoDetails();
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].DownloadFlag = otherInfoDetails.DownloadFlag;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].GeneralText = otherInfoDetails.GeneralText;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].IsAlertRangeVisible = otherInfoDetails.IsAlertRangeVisible;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].HoverText = otherInfoDetails.HoverText;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].Keyword_txt = otherInfoDetails.Keyword_Txt;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].IsBrowsable = otherInfoDetails.IsBrowsable;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].LabelID = otherInfoDetails.LabelID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].LabelName = otherInfoDetails.LabelName;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].LanguageCode = otherInfoDetails.LanguageCode;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].Link = otherInfoDetails.Link;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].LinkType = otherInfoDetails.LinkType;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].OtherInfoDetailID = otherInfoDetails.OtherInfoDetailID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].OtherInfoID = otherInfoDetails.OtherInfoID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].Priority = otherInfoDetails.Priority;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].Rating = otherInfoDetails.Rating;

        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].MacID = otherInfoDetails.MacID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].IPAddress = otherInfoDetails.IPAddress;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].ComputerName = otherInfoDetails.ComputerName;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].CreatedUserID = otherInfoDetails.CreatedUserID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].CreatedUserDate = otherInfoDetails.CreatedUserDate;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].ModifiedUserID = otherInfoDetails.ModifiedUserID;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].ModifiedUserDate = otherInfoDetails.ModifiedUserDate;
        //                                        objSearchOtherInfoDetails[otherInfoDetailCount].DomainName = otherInfoDetails.DomainName;

        //                                        otherInfoDetailCount++;
        //                                    }
        //                                }

        //                                objSearchOtherInfo[otherInfoCount].OtherInfoDetails = objSearchOtherInfoDetails;
        //                            }

        //                            otherInfoCount++;
        //                        }
        //                    }

        //                    objOtherInfoResult[incOtherResult].SearchOthrOnfoResult = objSearchOtherInfo;
        //                    incOtherResult++;
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4000);
        //    }

        //    return response;
        //}
        /// <summary>
        /// <Description>Converts business OtherInfoDetails response to service OtherInfoPopulate input</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateOtherInfoResponse Convert(Buss.OtherInfoDetails[] input)
        //{
        //    PopulateOtherInfoResponse response = new PopulateOtherInfoResponse();
        //    int increment = 0;
        //    Serv.OtherInfoPopulate[] objOtherInfoPopulate = new Serv.OtherInfoPopulate[input.Length];
        //    response.PopulateResponse = objOtherInfoPopulate;
        //    try
        //    {
        //        foreach (Buss.OtherInfoDetails otherInfoDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].OtherInfoID))
        //                {
        //                    objOtherInfoPopulate[increment] = new AmericanExpress.GDU.Service.DataContracts.OtherInfoPopulate();
        //                    objOtherInfoPopulate[increment].OtherInfoID = otherInfoDetails.OtherInfoID;
        //                    objOtherInfoPopulate[increment].OtherInfoName = otherInfoDetails.OtherInfoName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.OtherInfoPopulate[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4001);
        //    }

        //    return response;
        //}
        /// <summary>
        /// <Description>Converts business TransactionIdDetails response to service TransactionResult input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public TransactionResponse Convert(Buss.TransactionIdDetails input)
        //{
        //    TransactionResponse response = new TransactionResponse();
        //    Serv.TransactionResult objTransactionResult = new Serv.TransactionResult();
        //    response.TransactionIdResponse = objTransactionResult;
        //    try
        //    {
        //        objTransactionResult.TransactionId = input.TransactionId;
        //        objTransactionResult.TransactionType = input.TransactionType;
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input.STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input.STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        LogManager.LogErrorMessage(ex, 4002);
        //    }

        //    return response;
        //}
        /// <summary>
        ///  <Description>Converts business LinkTypeDetails response to service LinkTypeDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateLinkTypeResponse Convert(Buss.LinkTypeDetails[] input)
        //{
        //    PopulateLinkTypeResponse response = new PopulateLinkTypeResponse();
        //    int increment = 0;
        //    Serv.LinkTypeDetails[] objLinkTypeDetails = new Serv.LinkTypeDetails[input.Length];
        //    response.PopulateResponse = objLinkTypeDetails;
        //    try
        //    {
        //        foreach (Buss.LinkTypeDetails linkTypeDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].LinkTypeCode))
        //                {
        //                    objLinkTypeDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.LinkTypeDetails();
        //                    objLinkTypeDetails[increment].LinkTypeCode = linkTypeDetails.LinkTypeCode;
        //                    objLinkTypeDetails[increment].LinkTypeName = linkTypeDetails.LinkTypeName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.LinkTypeDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4003);
        //    }

        //    return response;
        //}
        /// <summary>
        ///  <Description>Converts business LanguageDetails response to service LanguageDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public PopulateLanguageResponse Convert(Buss.LanguageDetails[] input)
        {
            PopulateLanguageResponse response = new PopulateLanguageResponse();
            int increment = 0;
            Serv.LanguageDetails[] objLanguageDetails = new Serv.LanguageDetails[input.Length];
            response.PopulateResponse = objLanguageDetails;
            try
            {
                foreach (Buss.LanguageDetails languageDetails in input)
                {

                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(input[increment].LanguageCode))
                        {
                            objLanguageDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.LanguageDetails();
                            objLanguageDetails[increment].LanguageCode = languageDetails.LanguageCode;
                            objLanguageDetails[increment].LanguageName = languageDetails.LanguageName;

                            objLanguageDetails[increment].MacID = languageDetails.MacID;
                            objLanguageDetails[increment].IPAddress = languageDetails.IPAddress;
                            objLanguageDetails[increment].ComputerName = languageDetails.ComputerName;
                            objLanguageDetails[increment].CreatedUserID = languageDetails.CreatedUserID;
                            objLanguageDetails[increment].CreatedUserDate = languageDetails.CreatedUserDate;
                            objLanguageDetails[increment].ModifiedUserID = languageDetails.ModifiedUserID;
                            objLanguageDetails[increment].ModifiedUserDate = languageDetails.ModifiedUserDate;
                            objLanguageDetails[increment].DomainName = languageDetails.DomainName;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.LanguageDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4004);
            }

            return response;
        }
        /// <summary>
        /// <Description>Converts business CategoryDetails response to service CategoryDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateCategoryResponse Convert(Buss.CategoryDetails[] input)
        //{
        //    PopulateCategoryResponse response = new PopulateCategoryResponse();
        //    int increment = 0;
        //    Serv.CategoryDetails[] objCategoryDetails = new Serv.CategoryDetails[input.Length];
        //    response.PopulateResponse = objCategoryDetails;
        //    try
        //    {
        //        foreach (Buss.CategoryDetails categoryDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (input[increment].CategoryCode != null)
        //                {
        //                    objCategoryDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.CategoryDetails();
        //                    objCategoryDetails[increment].CategoryCode = categoryDetails.CategoryCode;
        //                    objCategoryDetails[increment].CategoryName = categoryDetails.CategoryName;

        //                    objCategoryDetails[increment].MacID = categoryDetails.MacID;
        //                    objCategoryDetails[increment].IPAddress = categoryDetails.IPAddress;
        //                    objCategoryDetails[increment].ComputerName = categoryDetails.ComputerName;
        //                    objCategoryDetails[increment].CreatedUserID = categoryDetails.CreatedUserID;
        //                    objCategoryDetails[increment].CreatedUserDate = categoryDetails.CreatedUserDate;
        //                    objCategoryDetails[increment].ModifiedUserID = categoryDetails.ModifiedUserID;
        //                    objCategoryDetails[increment].ModifiedUserDate = categoryDetails.ModifiedUserDate;
        //                    objCategoryDetails[increment].DomainName = categoryDetails.DomainName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.CategoryDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4005);
        //    }

        //    return response;
        //}
        /// <summary>
        ///  <Description>Converts business AccountDetails response to service AccountDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateAccountResponse Convert(Buss.AccountDetails[] input)
        //{
        //    PopulateAccountResponse response = new PopulateAccountResponse();
        //    int increment = 0;
        //    Serv.AccountDetails[] objAccountDetails = new Serv.AccountDetails[input.Length];
        //    response.PopulateResponse = objAccountDetails;
        //    try
        //    {
        //        foreach (Buss.AccountDetails accountDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].AccountCode))
        //                {
        //                    objAccountDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AccountDetails();
        //                    objAccountDetails[increment].AccountCode = accountDtl.AccountCode;
        //                    objAccountDetails[increment].AccountName = accountDtl.AccountName;
        //                    objAccountDetails[increment].GDSType = accountDtl.GDSType;
        //                    objAccountDetails[increment].AccountType = accountDtl.AccountType;
        //                    objAccountDetails[increment].IsGlobal = accountDtl.IsGlobal;

        //                    objAccountDetails[increment].MacID = accountDtl.MacID;
        //                    objAccountDetails[increment].IPAddress = accountDtl.IPAddress;
        //                    objAccountDetails[increment].ComputerName = accountDtl.ComputerName;
        //                    objAccountDetails[increment].CreatedUserID = accountDtl.CreatedUserID;
        //                    objAccountDetails[increment].CreatedUserDate = accountDtl.CreatedUserDate;
        //                    objAccountDetails[increment].ModifiedUserID = accountDtl.ModifiedUserID;
        //                    objAccountDetails[increment].ModifiedUserDate = accountDtl.ModifiedUserDate;
        //                    objAccountDetails[increment].DomainName = accountDtl.DomainName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.AccountDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4006);
        //    }

        //    return response;
        //}
        /// <summary>
        ///  <Description>Converts business CountryDetails response to service CountryDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateCountryResponse Convert(Buss.CountryDetails[] input)
        //{
        //    PopulateCountryResponse response = new PopulateCountryResponse();
        //    int increment = 0;
        //    Serv.CountryDetails[] objCountryDetails = new Serv.CountryDetails[input.Length];
        //    response.PopulateResponse = objCountryDetails;
        //    try
        //    {
        //        foreach (Buss.CountryDetails accountDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].CountryCode))
        //                {
        //                    objCountryDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.CountryDetails();
        //                    objCountryDetails[increment].CountryCode = accountDtl.CountryCode;
        //                    objCountryDetails[increment].CountryName = accountDtl.CountryName;
        //                    objCountryDetails[increment].CountryType = accountDtl.CountryType;
        //                    objCountryDetails[increment].IsGlobal = accountDtl.IsGlobal;
        //                    objCountryDetails[increment].MacID = accountDtl.MacID;
        //                    objCountryDetails[increment].IPAddress = accountDtl.IPAddress;
        //                    objCountryDetails[increment].ComputerName = accountDtl.ComputerName;
        //                    objCountryDetails[increment].CreatedUserID = accountDtl.CreatedUserID;
        //                    objCountryDetails[increment].CreatedUserDate = accountDtl.CreatedUserDate;
        //                    objCountryDetails[increment].ModifiedUserID = accountDtl.ModifiedUserID;
        //                    objCountryDetails[increment].ModifiedUserDate = accountDtl.ModifiedUserDate;
        //                    objCountryDetails[increment].DomainName = accountDtl.DomainName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.CountryDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4007);
        //    }

        //    return response;
        //}
        /// <summary>
        /// <Description>Converts business CityDetails response to service CityDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateCityResponse Convert(Buss.CityDetails[] input)
        //{
        //    PopulateCityResponse response = new PopulateCityResponse();
        //    int increment = 0;
        //    Serv.CityDetails[] objCityDetails = new Serv.CityDetails[input.Length];
        //    response.PopulateResponse = objCityDetails;
        //    try
        //    {
        //        foreach (Buss.CityDetails accountDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].CityCode))
        //                {
        //                    objCityDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.CityDetails();
        //                    objCityDetails[increment].CountryCode = accountDtl.CountryCode;
        //                    objCityDetails[increment].CityCode = accountDtl.CityCode;
        //                    objCityDetails[increment].CityName = accountDtl.CityName;
        //                    objCityDetails[increment].IsGlobal = accountDtl.IsGlobal;
        //                    objCityDetails[increment].MacID = accountDtl.MacID;
        //                    objCityDetails[increment].IPAddress = accountDtl.IPAddress;
        //                    objCityDetails[increment].ComputerName = accountDtl.ComputerName;
        //                    objCityDetails[increment].CreatedUserID = accountDtl.CreatedUserID;
        //                    objCityDetails[increment].CreatedUserDate = accountDtl.CreatedUserDate;
        //                    objCityDetails[increment].ModifiedUserID = accountDtl.ModifiedUserID;
        //                    objCityDetails[increment].ModifiedUserDate = accountDtl.ModifiedUserDate;
        //                    objCityDetails[increment].DomainName = accountDtl.DomainName;
        //                    objCityDetails[increment].CityType = accountDtl.CityType;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.CityDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4008);
        //    }

        //    return response;
        //}
        /// <summary>
        ///  <Description>Converts business SearchLinkResult response to service SearchLinkResult input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public SearchLinkResponse Convert(Buss.SearchLinkResult[] input)
        //{
        //    int incLinkResult = 0;
        //    int incLink = 0;
        //    int incLinkDetail = 0;
        //    int incLinkCatgDetail = 0;
        //    SearchLinkResponse response = new SearchLinkResponse();
        //    Serv.SearchLinkResult[] objSearchLinkResult = new Serv.SearchLinkResult[input.Length];
        //    Serv.SearchLink[] objSearchLink = null;
        //    Serv.SearchLinkDetails[] objSearchLinkDetails = null;
        //    Serv.SearchLinkCategoryDetails[] objSearchLinkCategoryDetails = null;
        //    response.Response = objSearchLinkResult;
        //    try
        //    {
        //        foreach (Buss.SearchLinkResult searchLinkResult in input)
        //        {
        //            if (searchLinkResult != null)
        //            {
        //                if (searchLinkResult.SearchLnkResult != null)
        //                {
        //                    incLink = 0;
        //                    objSearchLinkResult[incLinkResult] = new AmericanExpress.GDU.Service.DataContracts.SearchLinkResult();

        //                    objSearchLink = new Serv.SearchLink[searchLinkResult.SearchLnkResult.Length];

        //                    foreach (Buss.SearchLink searchLink in searchLinkResult.SearchLnkResult)
        //                    {
        //                        if (searchLink != null)
        //                        {
        //                            objSearchLink[incLink] = new AmericanExpress.GDU.Service.DataContracts.SearchLink();
        //                            objSearchLink[incLink].AccountCode = searchLink.AccountCode;
        //                            objSearchLink[incLink].CarrierCode = searchLink.CarrierCode;
        //                            objSearchLink[incLink].CityCode = searchLink.CityCode;
        //                            objSearchLink[incLink].CountryCode = searchLink.CountryCode;
        //                            objSearchLink[incLink].AccountName = searchLink.AccountName;
        //                            objSearchLink[incLink].CountryName = searchLink.CountryName;
        //                            objSearchLink[incLink].CityName = searchLink.CityName;
        //                            objSearchLink[incLink].IsGlobalAcc = searchLink.IsGlobalAcc;
        //                            objSearchLink[incLink].IsVirtualAcc = searchLink.IsVirtualAcc;
        //                            objSearchLink[incLink].IsGlobalCountry = searchLink.IsGlobalCountry;
        //                            objSearchLink[incLink].IsVirtualCountry = searchLink.IsVirtualCountry;
        //                            objSearchLink[incLink].IsGlobalCity = searchLink.IsGlobalCity;
        //                            objSearchLink[incLink].IsVirtualCity = searchLink.IsVirtualCity;
        //                            objSearchLink[incLink].GlobalID = searchLink.GlobalID;
        //                            objSearchLink[incLink].GlobalText = searchLink.GlobalText;
        //                            objSearchLink[incLink].IsBrowsable = searchLink.IsBrowsable;
        //                            objSearchLink[incLink].LabelID = searchLink.LabelID;
        //                            objSearchLink[incLink].LabelName = searchLink.LabelName;
        //                            objSearchLink[incLink].LinkID = searchLink.LinkID;
        //                            objSearchLink[incLink].Rating = searchLink.Rating;

        //                            objSearchLink[incLink].MacID = searchLink.MacID;
        //                            objSearchLink[incLink].IPAddress = searchLink.IPAddress;
        //                            objSearchLink[incLink].ComputerName = searchLink.ComputerName;
        //                            objSearchLink[incLink].CreatedUserID = searchLink.CreatedUserID;
        //                            objSearchLink[incLink].CreatedUserDate = searchLink.CreatedUserDate;
        //                            objSearchLink[incLink].ModifiedUserID = searchLink.ModifiedUserID;
        //                            objSearchLink[incLink].ModifiedUserDate = searchLink.ModifiedUserDate;
        //                            objSearchLink[incLink].DomainName = searchLink.DomainName;
        //                            if (searchLink.LinkDetails != null)
        //                            {
        //                                incLinkDetail = 0;
        //                                objSearchLinkDetails = new Serv.SearchLinkDetails[searchLink.LinkDetails.Length];
        //                                foreach (Buss.SearchLinkDetails searchLinkDtl in searchLink.LinkDetails)
        //                                {
        //                                    if (searchLink.LinkDetails[incLinkDetail] != null)
        //                                    {
        //                                        objSearchLinkDetails[incLinkDetail] = new AmericanExpress.GDU.Service.DataContracts.SearchLinkDetails();
        //                                        objSearchLinkDetails[incLinkDetail].DownloadFlag = searchLinkDtl.DownloadFlag;
        //                                        objSearchLinkDetails[incLinkDetail].GeneralText = searchLinkDtl.GeneralText;
        //                                        objSearchLinkDetails[incLinkDetail].IsAlertRangeVisible = searchLinkDtl.IsAlertRangeVisible;
        //                                        objSearchLinkDetails[incLinkDetail].HoverText = searchLinkDtl.HoverText;
        //                                        objSearchLinkDetails[incLinkDetail].Keyword_txt = searchLinkDtl.Keyword_Txt;
        //                                        objSearchLinkDetails[incLinkDetail].IsBrowsable = searchLinkDtl.IsBrowsable;
        //                                        objSearchLinkDetails[incLinkDetail].LabelID = searchLinkDtl.LabelID;
        //                                        objSearchLinkDetails[incLinkDetail].LabelName = searchLinkDtl.LabelName;
        //                                        objSearchLinkDetails[incLinkDetail].LanguageCode = searchLinkDtl.LanguageCode;
        //                                        objSearchLinkDetails[incLinkDetail].Link = searchLinkDtl.Link;
        //                                        objSearchLinkDetails[incLinkDetail].LinkDetailID = searchLinkDtl.LinkDetailID;
        //                                        objSearchLinkDetails[incLinkDetail].LinkID = searchLinkDtl.LinkID;
        //                                        objSearchLinkDetails[incLinkDetail].LinkType = searchLinkDtl.LinkType;
        //                                        objSearchLinkDetails[incLinkDetail].LinkTypeCode = searchLinkDtl.LinkTypeCode;
        //                                        objSearchLinkDetails[incLinkDetail].Rating = searchLinkDtl.Rating;
        //                                        objSearchLinkDetails[incLinkDetail].ValidFromDate = searchLinkDtl.ValidFromDate;
        //                                        objSearchLinkDetails[incLinkDetail].ValidToDate = searchLinkDtl.ValidToDate;
        //                                        objSearchLinkDetails[incLinkDetail].DisplayValidFromMonth = searchLinkDtl.DisplayValidFromMonth;
        //                                        objSearchLinkDetails[incLinkDetail].DisplayValidToMonth = searchLinkDtl.DisplayValidToMonth;
        //                                        objSearchLinkDetails[incLinkDetail].DisplayValidFromDay = searchLinkDtl.DisplayValidFromDay;
        //                                        objSearchLinkDetails[incLinkDetail].DisplayValidToDay = searchLinkDtl.DisplayValidToDay;

        //                                        objSearchLinkDetails[incLinkDetail].MacID = searchLinkDtl.MacID;
        //                                        objSearchLinkDetails[incLinkDetail].IPAddress = searchLinkDtl.IPAddress;
        //                                        objSearchLinkDetails[incLinkDetail].ComputerName = searchLinkDtl.ComputerName;
        //                                        objSearchLinkDetails[incLinkDetail].CreatedUserID = searchLinkDtl.CreatedUserID;
        //                                        objSearchLinkDetails[incLinkDetail].CreatedUserDate = searchLinkDtl.CreatedUserDate;
        //                                        objSearchLinkDetails[incLinkDetail].ModifiedUserID = searchLinkDtl.ModifiedUserID;
        //                                        objSearchLinkDetails[incLinkDetail].ModifiedUserDate = searchLinkDtl.ModifiedUserDate;
        //                                        objSearchLinkDetails[incLinkDetail].DomainName = searchLinkDtl.DomainName;

        //                                        if (searchLinkDtl.LinkCategoryDetails != null)
        //                                        {
        //                                            incLinkCatgDetail = 0;
        //                                            objSearchLinkCategoryDetails = new Serv.SearchLinkCategoryDetails[searchLinkDtl.LinkCategoryDetails.Length];
        //                                            foreach (Buss.SearchLinkCategoryDetails searchLinkCatgDtl in searchLinkDtl.LinkCategoryDetails)
        //                                            {
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail] = new AmericanExpress.GDU.Service.DataContracts.SearchLinkCategoryDetails();
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].DownloadFlag = searchLinkCatgDtl.DownloadFlag;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].HoverText = searchLinkCatgDtl.HoverText;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].Keyword_txt = searchLinkCatgDtl.Keyword_Txt;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].IsBrowsable = searchLinkCatgDtl.IsBrowsable;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LabelID = searchLinkCatgDtl.LabelID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LabelName = searchLinkCatgDtl.LabelName;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LanguageCode = searchLinkCatgDtl.LanguageCode;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].Link = searchLinkCatgDtl.Link;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LinkCategoryDetailID = searchLinkCatgDtl.LinkCategoryDetailID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LinkDetailID = searchLinkCatgDtl.LinkDetailID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].LinkType = searchLinkCatgDtl.LinkType;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].Rating = searchLinkCatgDtl.Rating;

        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].MacID = searchLinkCatgDtl.MacID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].IPAddress = searchLinkCatgDtl.IPAddress;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].ComputerName = searchLinkCatgDtl.ComputerName;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].CreatedUserID = searchLinkCatgDtl.CreatedUserID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].CreatedUserDate = searchLinkCatgDtl.CreatedUserDate;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].ModifiedUserID = searchLinkCatgDtl.ModifiedUserID;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].ModifiedUserDate = searchLinkCatgDtl.ModifiedUserDate;
        //                                                objSearchLinkCategoryDetails[incLinkCatgDetail].DomainName = searchLinkCatgDtl.DomainName;
        //                                                incLinkCatgDetail++;
        //                                            }

        //                                            objSearchLinkDetails[incLinkDetail].LinkCategoryDetails = objSearchLinkCategoryDetails;
        //                                        }

        //                                        incLinkDetail++;
        //                                    }
        //                                }

        //                                objSearchLink[incLink].LinkDetails = objSearchLinkDetails;
        //                            }

        //                            incLink++;
        //                        }
        //                    }

        //                    objSearchLinkResult[incLinkResult].SearchLnkResult = objSearchLink;
        //                    incLinkResult++;
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4009);
        //    }

        //    return response;
        //}

        /// <summary>
        ///  <Description>Converts business StandardResponse response to service StandardResponse input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public StandardResponse Convert(Buss.StandardResponse input)
        {
            StandardResponse std = new StandardResponse();
            try
            {
                std.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input.ResponseCodeStatus.ToString());
                std.ResponseMessage = input.ResponseMessage;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                LogManager.LogErrorMessage(ex, 4010);
            }

            return std;
        }

        #region Carrier
        /// <summary>
        /// <Description>Converts business CarrierDetails response to service CarrierDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public DisplayCarrierSearchResponse Convert(Buss.CarrierDetails[] input)
        //{
        //    DisplayCarrierSearchResponse response = new DisplayCarrierSearchResponse();
        //    int increment = 0;
        //    Serv.CarrierDetails[] objCarrierDetails = new Serv.CarrierDetails[input.Length];
        //    response.SearchResponses = objCarrierDetails;
        //    try
        //    {
        //        foreach (Buss.CarrierDetails carrierDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].CarrierCode))
        //                {
        //                    objCarrierDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.CarrierDetails();
        //                    objCarrierDetails[increment].CarrierCode = carrierDtl.CarrierCode;
        //                    objCarrierDetails[increment].CarrierName = carrierDtl.CarrierName;
        //                    objCarrierDetails[increment].ModifiedDate = carrierDtl.ModifiedDate;

        //                    objCarrierDetails[increment].MacID = carrierDtl.MacID;
        //                    objCarrierDetails[increment].IPAddress = carrierDtl.IPAddress;
        //                    objCarrierDetails[increment].ComputerName = carrierDtl.ComputerName;
        //                    objCarrierDetails[increment].CreatedUserID = carrierDtl.CreatedUserID;
        //                    objCarrierDetails[increment].CreatedUserDate = carrierDtl.CreatedUserDate;
        //                    objCarrierDetails[increment].ModifiedUserID = carrierDtl.ModifiedUserID;
        //                    objCarrierDetails[increment].ModifiedUserDate = carrierDtl.ModifiedUserDate;
        //                    objCarrierDetails[increment].DomainName = carrierDtl.DomainName;
        //                    objCarrierDetails[increment].IsDeactive = carrierDtl.IsDeactive;
        //                    objCarrierDetails[increment].GlobalCD = carrierDtl.GlobalCD;

        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.SearchResponses = new Serv.CarrierDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4011);
        //    }

        //    return response;
        //}
        #endregion

        //public Serv.ManageAccountDetails[] Convert(Buss.ManageAccountDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.ManageAccountDetails[] objAccDetails = new Serv.ManageAccountDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.ManageAccountDetails accDtl in input)
        //        {
        //            objAccDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageAccountDetails();
        //            objAccDetails[increment].AccountCode = accDtl.AccountCode;
        //            objAccDetails[increment].AccountName = accDtl.AccountName;
        //            objAccDetails[increment].IsGlobal = accDtl.IsGlobal;
        //            objAccDetails[increment].IsVirtual = accDtl.IsVirtual;
        //            objAccDetails[increment].IsDeactive = accDtl.IsDeactive;
        //            objAccDetails[increment].MacID = accDtl.MacID;
        //            objAccDetails[increment].IPAddress = accDtl.IPAddress;
        //            objAccDetails[increment].ComputerName = accDtl.ComputerName;
        //            objAccDetails[increment].CreatedUserID = accDtl.CreatedUserID;
        //            objAccDetails[increment].CreatedUserDate = accDtl.CreatedUserDate;
        //            objAccDetails[increment].ModifiedUserID = accDtl.ModifiedUserID;
        //            objAccDetails[increment].ModifiedUserDate = accDtl.ModifiedUserDate;
        //            objAccDetails[increment].ClientID = accDtl.ClientID;
        //            objAccDetails[increment].GlobalCD = accDtl.GlobalCD;
        //            objAccDetails[increment].VirtualCD = accDtl.VirtualCD;
        //            objAccDetails[increment].AccountType = accDtl.AccountType;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objAccDetails;
        //}

        //#region Mangae Country
        //public Serv.ManageCountryDetails[] Convert(Buss.ManageCountryDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.ManageCountryDetails[] objCountryDetails = new Serv.ManageCountryDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.ManageCountryDetails contryDtl in input)
        //        {
        //            objCountryDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageCountryDetails();
        //            objCountryDetails[increment].CountryCode = contryDtl.CountryCode;
        //            objCountryDetails[increment].CountryName = contryDtl.CountryName;
        //            objCountryDetails[increment].IsGlobal = contryDtl.IsGlobal;
        //            objCountryDetails[increment].IsVirtual = contryDtl.IsVirtual;
        //            objCountryDetails[increment].IsDeactive = contryDtl.IsDeactive;
        //            objCountryDetails[increment].CreatedUserID = contryDtl.CreatedUserID;
        //            objCountryDetails[increment].CreatedUserDate = contryDtl.CreatedUserDate;
        //            objCountryDetails[increment].ModifiedUserID = contryDtl.ModifiedUserID;
        //            objCountryDetails[increment].ModifiedUserDate = contryDtl.ModifiedUserDate;
        //            objCountryDetails[increment].CountryType = contryDtl.CountryType;
        //            objCountryDetails[increment].GlobalCD = contryDtl.GlobalCD;
        //            objCountryDetails[increment].VirtualCD = contryDtl.VirtualCD;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objCountryDetails;
        //}
        //#endregion

        //public Serv.ManageCityDetails[] Convert(Buss.ManageCityDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.ManageCityDetails[] objCityDetails = new Serv.ManageCityDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.ManageCityDetails cityDtl in input)
        //        {
        //            objCityDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageCityDetails();
        //            objCityDetails[increment].CityCode = cityDtl.CityCode;
        //            objCityDetails[increment].CityName = cityDtl.CityName;
        //            objCityDetails[increment].IsGlobal = cityDtl.IsGlobal;
        //            objCityDetails[increment].IsVirtual = cityDtl.IsVirtual;
        //            objCityDetails[increment].IsDeactive = cityDtl.IsDeactive;
        //            objCityDetails[increment].MacID = cityDtl.MacID;
        //            objCityDetails[increment].IPAddress = cityDtl.IPAddress;
        //            objCityDetails[increment].ComputerName = cityDtl.ComputerName;
        //            objCityDetails[increment].CreatedUserID = cityDtl.CreatedUserID;
        //            objCityDetails[increment].CreatedUserDate = cityDtl.CreatedUserDate;
        //            objCityDetails[increment].ModifiedUserID = cityDtl.ModifiedUserID;
        //            objCityDetails[increment].ModifiedUserDate = cityDtl.ModifiedUserDate;
        //            objCityDetails[increment].CountryCode = cityDtl.CountryCode;
        //            objCityDetails[increment].GlobalCD = cityDtl.GlobalCD;
        //            objCityDetails[increment].VirtualCD = cityDtl.VirtualCD;
        //            objCityDetails[increment].CityType = cityDtl.CityType;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objCityDetails;
        //}

        //public Serv.MappingDetails[] Convert(Buss.MappingDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.MappingDetails[] objMappDetails = new Serv.MappingDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.MappingDetails mappDtl in input)
        //        {
        //            objMappDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.MappingDetails();
        //            objMappDetails[increment].Mapping_CD = mappDtl.Mapping_CD;
        //            objMappDetails[increment].Real_CD = mappDtl.Real_CD;
        //            objMappDetails[increment].Virtual_CD = mappDtl.Virtual_CD;
        //            objMappDetails[increment].Real_NM = mappDtl.Real_NM;
        //            objMappDetails[increment].Mode = mappDtl.Mode;
        //            objMappDetails[increment].InTransaction = mappDtl.InTransaction;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objMappDetails;
        //}

        #region User
        /// <summary>
        /// <Description>Converts business UserDetails response to service UserDetails input</Description> 
        /// </summary>
        /// <param name="input">input</param>
        /// <returns></returns>
        public Serv.UserDetails[] Convert(Buss.UserDetails[] input)
        {
            int increment = 0;
            Serv.UserDetails[] objUserDetails = new Serv.UserDetails[input.Length];
            try
            {
                foreach (Buss.UserDetails userDtl in input)
                {
                    objUserDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.UserDetails();
                    objUserDetails[increment].UserId = userDtl.UserId;
                    objUserDetails[increment].UserName = userDtl.UserName;
                    objUserDetails[increment].UserRole = userDtl.UserRole;
                    objUserDetails[increment].Language = userDtl.Language;
                    objUserDetails[increment].UserRoleCode = userDtl.UserRoleCode;
                    objUserDetails[increment].LanguageCode = userDtl.LanguageCode;
                    objUserDetails[increment].EmailAddress = userDtl.EmailAddress;
                    objUserDetails[increment].IsDeactive = userDtl.IsDeactive;

                    objUserDetails[increment].MacID = userDtl.MacID;
                    objUserDetails[increment].IPAddress = userDtl.IPAddress;
                    objUserDetails[increment].ComputerName = userDtl.ComputerName;
                    objUserDetails[increment].CreatedUserID = userDtl.CreatedUserID;
                    objUserDetails[increment].CreatedUserDate = userDtl.CreatedUserDate;
                    objUserDetails[increment].ModifiedUserID = userDtl.ModifiedUserID;
                    objUserDetails[increment].ModifiedUserDate = userDtl.ModifiedUserDate;
                    objUserDetails[increment].DomainName = userDtl.DomainName;
                    objUserDetails[increment].DefaultClientID = userDtl.DefaultClientID;

                    objUserDetails[increment].TotalRecord = userDtl.TotalRecord;

                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objUserDetails;
        }
        #endregion

        #region UserRoleDetails
        /// <summary>
        ///  <Description>Converts business UserRoleDetails response to service UserRoleDetails input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Serv.UserRoleDetails[] Convert(Buss.UserRoleDetails[] input)
        {
            int increment = 0;
            Serv.UserRoleDetails[] objRoleDetails = new Serv.UserRoleDetails[input.Length];
            try
            {
                foreach (Buss.UserRoleDetails roleDetails in input)
                {
                    objRoleDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.UserRoleDetails();
                    objRoleDetails[increment].RoleCode = roleDetails.RoleCode;
                    objRoleDetails[increment].RoleName = roleDetails.RoleName;
                    objRoleDetails[increment].MacID = roleDetails.MacID;
                    objRoleDetails[increment].IPAddress = roleDetails.IPAddress;
                    objRoleDetails[increment].ComputerName = roleDetails.ComputerName;
                    objRoleDetails[increment].CreatedUserID = roleDetails.CreatedUserID;
                    objRoleDetails[increment].CreatedUserDate = roleDetails.CreatedUserDate;
                    objRoleDetails[increment].ModifiedUserID = roleDetails.ModifiedUserID;
                    objRoleDetails[increment].ModifiedUserDate = roleDetails.ModifiedUserDate;
                    objRoleDetails[increment].DomainName = roleDetails.DomainName;
                    objRoleDetails[increment].ClientID = roleDetails.ClientID;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleDetails;
        }
        #endregion

        #region feedback
        /// <summary>
        /// <Description>Converts business FeedbackType response to service FeedbackType input</Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public PopulateFeedbackType Convert(Buss.FeedbackType[] input)
        //{
        //    PopulateFeedbackType response = new PopulateFeedbackType();
        //    int increment = 0;
        //    Serv.FeedbackType[] objDetails = new Serv.FeedbackType[input.Length];
        //    response.PopulateResponse = objDetails;
        //    try
        //    {
        //        foreach (Buss.FeedbackType feedbackDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].FeedbackTypeCode))
        //                {
        //                    objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.FeedbackType();
        //                    objDetails[increment].FeedBackTypeCode = feedbackDetails.FeedbackTypeCode;
        //                    objDetails[increment].FeedBackTypeDesc = feedbackDetails.FeedbackTypeDesc;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.FeedbackType[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4012);
        //    }

        //    return response;
        //}
        #endregion

        #endregion

        #region report
        /// <summary>
        /// Report Details
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public Serv.ReportDetails[] Convert(Buss.ReportDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.ReportDetails[] objReportDetails = new Serv.ReportDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.ReportDetails reportDtl in input)
        //        {
        //            objReportDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ReportDetails();
        //            objReportDetails[increment].Account = reportDtl.Account;
        //            objReportDetails[increment].City = reportDtl.City;
        //            objReportDetails[increment].Country = reportDtl.Country;
        //            objReportDetails[increment].lc_file_type = reportDtl.lc_file_type;
        //            objReportDetails[increment].lc_Hover_Txt = reportDtl.lc_Hover_Txt;
        //            objReportDetails[increment].lc_Label = reportDtl.lc_Label;
        //            objReportDetails[increment].lc_Language = reportDtl.lc_Language;
        //            objReportDetails[increment].lc_Link = reportDtl.lc_Link;
        //            objReportDetails[increment].lc_Link_Type = reportDtl.lc_Link_Type;
        //            objReportDetails[increment].lcd_File_Path = reportDtl.lcd_File_Path;
        //            objReportDetails[increment].lcd_Hover_Txt = reportDtl.lcd_Hover_Txt;
        //            objReportDetails[increment].lcd_Label = reportDtl.lcd_Label;
        //            objReportDetails[increment].lcd_language = reportDtl.lcd_language;
        //            objReportDetails[increment].lcd_Link = reportDtl.lcd_Link;
        //            objReportDetails[increment].lcd_Link_Type = reportDtl.lcd_Link_Type;
        //            objReportDetails[increment].lc_LinkType_NM = reportDtl.lc_LinkType_NM;
        //            objReportDetails[increment].Link_ID = reportDtl.Link_ID;
        //            objReportDetails[increment].Link_Dtl_ID = reportDtl.Link_Dtl_ID;
        //            objReportDetails[increment].Link_Cat_Dtl_ID = reportDtl.Link_Cat_Dtl_ID;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objReportDetails;
        //}

        /// <summary>
        /// OtherInfoReportDetails
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public OtherInfoReportResponse Convert(Buss.OtherInfoReportDetails[] input)
        //{
        //    OtherInfoReportResponse response = new OtherInfoReportResponse();
        //    int increment = 0;
        //    Serv.OtherInfoReportDetails[] otherInfoReportDetails = new Serv.OtherInfoReportDetails[input.Length];
        //    response.PopulateResponse = otherInfoReportDetails;
        //    try
        //    {
        //        foreach (Buss.OtherInfoReportDetails otherinforeportDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].LinkType_NM))
        //                {
        //                    otherInfoReportDetails[increment] = new Serv.OtherInfoReportDetails();
        //                    otherInfoReportDetails[increment].Label_NM = otherinforeportDtl.Label_NM;
        //                    otherInfoReportDetails[increment].LinkType_NM = otherinforeportDtl.LinkType_NM;
        //                    otherInfoReportDetails[increment].OtherInfo_Hover_Txt = otherinforeportDtl.OtherInfo_Hover_Txt;
        //                    otherInfoReportDetails[increment].OtherInfo_Language_NM = otherinforeportDtl.OtherInfo_Language_NM;
        //                    otherInfoReportDetails[increment].OtherInfo_Link = otherinforeportDtl.OtherInfo_Link;
        //                    otherInfoReportDetails[increment].OtherInfo_Link_Type = otherinforeportDtl.OtherInfo_Link_Type;
        //                    otherInfoReportDetails[increment].OtherInfoDetail_hover_txt = otherinforeportDtl.OtherInfoDetail_hover_txt;
        //                    otherInfoReportDetails[increment].OtherInfoDetail_label = otherinforeportDtl.OtherInfoDetail_label;
        //                    otherInfoReportDetails[increment].OtherInfoDetail_language = otherinforeportDtl.OtherInfoDetail_language;
        //                    otherInfoReportDetails[increment].OtherInfoDetail_Link = otherinforeportDtl.OtherInfoDetail_Link;
        //                    otherInfoReportDetails[increment].OtherInfoDetail_Link_Type = otherinforeportDtl.OtherInfoDetail_Link_Type;
        //                    otherInfoReportDetails[increment].OtherInfoLable_Lable_NM = otherinforeportDtl.OtherInfoLable_Lable_NM;
        //                    otherInfoReportDetails[increment].OtherInfoID = otherinforeportDtl.OtherInfoID;
        //                    otherInfoReportDetails[increment].OtherInfoDetailID = otherinforeportDtl.OtherInfoDetailID;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.OtherInfoReportDetails[0];
        //                }
        //            }
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return response;
        //}

        //public PopulateFeedbackType Convert(Buss.FeedbackType[] input)
        //{
        //    PopulateFeedbackType populateFeedbackType = new PopulateFeedbackType();
        //    Serv.FeedbackType[] servFeedbackType = new Serv.FeedbackType[input.Count];
        //    populateFeedbackType.PopulateResponse = servFeedbackType;
        //    int increment = 0;
        //    try
        //    {
        //        foreach (Buss.FeedbackType  feedbackType in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].FeedbackTypeCode))
        //                {
        //                    servFeedbackType[increment] = new AmericanExpress.GDU.Service.DataContracts.FeedbackType();
        //                    servFeedbackType[increment].FeedBackTypeCode = feedbackType.FeedbackTypeCode;
        //                    servFeedbackType[increment].FeedBackTypeDesc = feedbackType.FeedbackTypeDesc;
        //                }
        //            }
        //        }
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch(Exception ex)
        //    {

        //    }

        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public FeedbackTypeReportResponse Convert(Buss.FeedbackTypeDetails[] input)
        //{
        //    FeedbackTypeReportResponse response = new FeedbackTypeReportResponse();
        //    int increment = 0;
        //    Serv.FeedBackDetails[] objDetails = new Serv.FeedBackDetails[input.Length];
        //    response.PopulateResponse = objDetails;
        //    try
        //    {
        //        foreach (Buss.FeedbackTypeDetails feedbackDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (input[increment].FeedbackAds != null)
        //                {
        //                    objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.FeedBackDetails();
        //                    objDetails[increment].FeedBackId = feedbackDetails.FeedBackId;
        //                    objDetails[increment].FeedbackRemark = feedbackDetails.FeedbackRemark;
        //                    objDetails[increment].AdsId = feedbackDetails.FeedbackAdsId;
        //                    objDetails[increment].AdsName = feedbackDetails.FeedbackAds;
        //                    objDetails[increment].FeedBackType = feedbackDetails.FeedbackLinkTypeCode;
        //                    objDetails[increment].FeedBackTypeDesc = feedbackDetails.FeedBackType;
        //                    objDetails[increment].Label = feedbackDetails.FeedbackLabel;
        //                    objDetails[increment].LabelId = feedbackDetails.FeedbackLabelId;
        //                    objDetails[increment].FeedbackRemark = feedbackDetails.FeedbackRemark;
        //                    objDetails[increment].Rating = feedbackDetails.FeedbackRating;
        //                    objDetails[increment].CreatedDate = feedbackDetails.CreatedDate;
        //                    objDetails[increment].AdsEmailAdd = feedbackDetails.FeedbackUserEmailAdd;
        //                    objDetails[increment].FileURL = feedbackDetails.FeedbackFileURL;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.FeedBackDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return response;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public ClientDeploymentReportResponse Convert(Buss.ClientDeploymentReportDetail[] input)
        {
            ClientDeploymentReportResponse response = new ClientDeploymentReportResponse();
            int increment = 0;
            Serv.ClientDeploymentInfo[] objDetails = new Serv.ClientDeploymentInfo[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.ClientDeploymentReportDetail deploymentDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (input[increment].UserId != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ClientDeploymentInfo();
                            objDetails[increment].App_Name = deploymentDetails.App_Name;
                            objDetails[increment].UserId = deploymentDetails.UserId;
                            objDetails[increment].NACId = deploymentDetails.NACId;
                            objDetails[increment].ApplicationPath = deploymentDetails.ApplicationPath;
                            objDetails[increment].ComputerName = deploymentDetails.ComputerName;
                            objDetails[increment].ExeTimeStamp = deploymentDetails.ExeTimeStamp;
                            objDetails[increment].ExeVersionNo = deploymentDetails.ExeVersionNo;
                            objDetails[increment].IPAddress = deploymentDetails.IPAddress;
                            objDetails[increment].LatestVersionNo = deploymentDetails.LatestVersionNo;
                            objDetails[increment].TimeStamp = deploymentDetails.RecordTimeStamp;
                            objDetails[increment].ToatlRecords = deploymentDetails.TotalRecords;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.ClientDeploymentInfo[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }
        #endregion

        public ClientUsageReportResponse Convert(Buss.ClientUsageReportDetail[] input)
        {
            ClientUsageReportResponse response = new ClientUsageReportResponse();
            int increment = 0;
            Serv.ClientUsageInfo[] objDetails = new Serv.ClientUsageInfo[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.ClientUsageReportDetail usageDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (input[increment].NACId != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ClientUsageInfo();
                            objDetails[increment].App_Name = usageDetails.App_Name;
                            objDetails[increment].NACId = usageDetails.NACId;
                            objDetails[increment].TotalUsage = usageDetails.TotalUsage;
                            objDetails[increment].Start_DT = usageDetails.From_DT;
                            objDetails[increment].End_DT = usageDetails.To_DT;
                            objDetails[increment].IP = usageDetails.IP;
                            objDetails[increment].Version = usageDetails.Version;
                            objDetails[increment].ComputerName = usageDetails.ComputerName;
                            objDetails[increment].TotalRecord = usageDetails.TotalRecord;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.ClientUsageInfo[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        //#region AggregationRule

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="input"></param>
        ///// <returns></returns>
        //public Serv.AgggregationRule[] Convert(Buss.AggregationRule[] input)
        //{
        //    int increment = 0;
        //    Serv.AgggregationRule[] objRule = new Serv.AgggregationRule[input.Length];
        //    try
        //    {
        //        foreach (Buss.AggregationRule ruleDetails in input)
        //        {
        //            objRule[increment] = new AmericanExpress.GDU.Service.DataContracts.AgggregationRule();
        //            objRule[increment].Aggregation_Rule_Id = ruleDetails.Aggregation_Rule_Id;
        //            objRule[increment].Aggregation_Rule_NM = ruleDetails.Aggregation_Rule_NM;
        //            objRule[increment].Aggregation_Rule_Sequence = ruleDetails.Aggregation_Rule_Sequence;
        //            objRule[increment].MacID = ruleDetails.MacID;
        //            objRule[increment].IPAddress = ruleDetails.IPAddress;
        //            objRule[increment].ComputerName = ruleDetails.ComputerName;
        //            objRule[increment].CreatedUserID = ruleDetails.CreatedUserID;
        //            objRule[increment].CreatedUserDate = ruleDetails.CreatedUserDate;
        //            objRule[increment].ModifiedUserID = ruleDetails.ModifiedUserID;
        //            objRule[increment].ModifiedUserDate = ruleDetails.ModifiedUserDate;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objRule;
        //}
        //#endregion

        public PopulateApplicationResponse Convert(Buss.ApplicationDetailResponse[] input)
        {
            PopulateApplicationResponse response = new PopulateApplicationResponse();
            int increment = 0;
            Serv.ApplicationDetailsResponse[] objApplicationDetails = new Serv.ApplicationDetailsResponse[input.Length];
            response.PopulateResponse = objApplicationDetails;
            try
            {
                foreach (Buss.ApplicationDetailResponse applicationDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(input[increment].ApplicationNM.ToString()))
                        {
                            objApplicationDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ApplicationDetailsResponse();
                            objApplicationDetails[increment].ApplicationNM = applicationDtl.ApplicationNM;
                            objApplicationDetails[increment].ApplicationAbbr = applicationDtl.ApplicationAbbr;
                            objApplicationDetails[increment].ApplicationDeployPath = applicationDtl.ApplicationDeployPath;

                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.ApplicationDetailsResponse[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4006);
            }

            return response;
        }

        public AppUploadedReportResponse Convert(Buss.AppUploadedReportDetail[] input)
        {
            AppUploadedReportResponse response = new AppUploadedReportResponse();
            int increment = 0;
            Serv.AppUploadedInfo[] objDetails = new Serv.AppUploadedInfo[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.AppUploadedReportDetail AppUploaded in input)
                {
                    if (input.Length > 0)
                    {
                        if (AppUploaded.App_Name != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AppUploadedInfo();
                            objDetails[increment].App_Name = AppUploaded.App_Name;
                            objDetails[increment].User_Name = AppUploaded.User_Name;
                            objDetails[increment].Version = AppUploaded.Version;
                            objDetails[increment].IP = AppUploaded.IP;
                            objDetails[increment].Upload_Dt = AppUploaded.Upload_Dt;
                            objDetails[increment].RollBack = AppUploaded.RollBack;
                            objDetails[increment].Computer_NM = AppUploaded.Computer_NM;
                            objDetails[increment].App_ID = AppUploaded.App_ID;
                            objDetails[increment].APP_TYPE = AppUploaded.APP_TYPE;
                            objDetails[increment].TotalRecords = AppUploaded.TotalRecords;
                            increment++;
                        }
                        else
                            response.PopulateResponse = new AmericanExpress.GDU.Service.DataContracts.AppUploadedInfo[0];
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        public PilotAppUploadRepResponse Convert(Buss.PilotAppUploadDetails[] input)
        {
            PilotAppUploadRepResponse response = new PilotAppUploadRepResponse();
            int increment = 0;
            Serv.PilotAppRepDetails[] objDetails = new Serv.PilotAppRepDetails[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.PilotAppUploadDetails AppUploaded in input)
                {
                    if (input.Length > 0)
                    {
                        if (AppUploaded.MachineName != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.PilotAppRepDetails();
                            objDetails[increment].MachineName = AppUploaded.MachineName;
                            objDetails[increment].UserName = AppUploaded.UserName;
                            objDetails[increment].UserId = AppUploaded.UserId;
                            objDetails[increment].IPAddress = AppUploaded.IPAddress;
                            objDetails[increment].TotalRecords = AppUploaded.TotalRecords;
                            increment++;
                        }
                        else
                            response.PopulateResponse = new AmericanExpress.GDU.Service.DataContracts.PilotAppRepDetails[0];
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        public ApplicationInfoResponse Convert(Buss.ApplicationDetails[] input)
        {
            ApplicationInfoResponse response = new ApplicationInfoResponse();
            int increment = 0;
            Serv.ApplicationDetails[] objAppDetails = new Serv.ApplicationDetails[input.Length];
            response.PopulateResponse = objAppDetails;
            try
            {
                foreach (Buss.ApplicationDetails AppDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(input[increment].AppAbbrName))
                        {
                            objAppDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ApplicationDetails();
                            objAppDetails[increment].AppID = AppDtl.AppID;
                            objAppDetails[increment].AppDeployPath = AppDtl.AppDeployPath;
                            objAppDetails[increment].AppAbbrName = AppDtl.AppAbbrName;
                            objAppDetails[increment].AppExeName = AppDtl.AppExeName;
                            objAppDetails[increment].AppAbbr = AppDtl.AppAbbr;
                            objAppDetails[increment].EntryPoint = AppDtl.EntryPoint;
                            objAppDetails[increment].App_Type = AppDtl.App_Type;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.ApplicationDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4006);
            }

            return response;
        }

        public UserAuthenticationResponse Convert(Buss.UserAuthenticationDetails input)
        {
            int increment = 0;
            UserAuthenticationResponse response = new UserAuthenticationResponse();
            Serv.UserAuthenticationDetails userAuthenticationDetails = new Serv.UserAuthenticationDetails();
            response.UserAuthenticationDetails = userAuthenticationDetails;
            try
            {
                userAuthenticationDetails.IsAuthenticated = input.IsAuthenticated;
                userAuthenticationDetails.Description = input.Description;
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input.STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input.STDResponse.ResponseMessage;
            }

            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4012);
            }

            return response;
        }

        public Serv.AppUserDetails[] Convert(Buss.AppUserDetails[] input)
        {
            int increment = 0;
            Serv.AppUserDetails[] objAppUserDetails = new Serv.AppUserDetails[input.Length];
            try
            {
                foreach (Buss.AppUserDetails AppuserDtl in input)
                {
                    objAppUserDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AppUserDetails();
                    objAppUserDetails[increment].UserId = AppuserDtl.UserId;
                    objAppUserDetails[increment].AppName = AppuserDtl.AppName;
                    objAppUserDetails[increment].Role_CD = AppuserDtl.Role_CD;
                    objAppUserDetails[increment].UserName = AppuserDtl.UserName;
                    objAppUserDetails[increment].TotalRecords = AppuserDtl.TotalRecords;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppUserDetails;
        }

        #region search label

        //public SearchLabelResponse Convert(Buss.SearchLabelDetail[] input)
        //{
        //    int increment = 0;
        //    SearchLabelResponse response = new SearchLabelResponse();
        //    Serv.SearchLabelResult[] objDetails = new Serv.SearchLabelResult[input.Length];
        //    response.SearchLabelResult = objDetails;
        //    try
        //    {
        //        foreach (Buss.SearchLabelDetail searchLabelDetail in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.SearchLabelResult();
        //                objDetails[increment].Link_Txt = searchLabelDetail.Link_Txt;
        //                objDetails[increment].Label_NM = searchLabelDetail.Label_NM;
        //                objDetails[increment].Label_Id = searchLabelDetail.Label_Id;
        //                objDetails[increment].Link_Type = searchLabelDetail.Link_Type;
        //                objDetails[increment].Hover_Txt = searchLabelDetail.Hover_Txt;
        //                increment++;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4012);
        //    }

        //    return response;
        //}


        //public ClientInfoResponse Convert(Buss.ClientDetails[] input)
        //{
        //    ClientInfoResponse response = new ClientInfoResponse();
        //    int increment = 0;
        //    Serv.ClientDetails[] objClientDetails = new Serv.ClientDetails[input.Length];
        //    response.PopulateResponse = objClientDetails;
        //    try
        //    {
        //        foreach (Buss.ClientDetails ClientDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].ClientName))
        //                {
        //                    objClientDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ClientDetails();
        //                    objClientDetails[increment].ClientID = ClientDtl.ClientID;
        //                    objClientDetails[increment].ClientName = ClientDtl.ClientName;
        //                    objClientDetails[increment].ClientAbbreviation = ClientDtl.ClientAbbreviation;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.ClientDetails[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4006);
        //    }

        //    return response;
        //}
        #endregion

        #region Version

        /// <summary>
        /// <Description></Description> 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public Serv.VersionDetail[] Convert(Buss.VersionDetails[] input)
        {
            int increment = 0;
            Serv.VersionDetail[] objVersionDetails = new Serv.VersionDetail[input.Length];
            try
            {
                foreach (Buss.VersionDetails versionDtl in input)
                {
                    objVersionDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.VersionDetail();
                    objVersionDetails[increment].ReleaseId = versionDtl.VersionId;
                    objVersionDetails[increment].ReleaseVersion = versionDtl.Version;
                    objVersionDetails[increment].IsRollback = versionDtl.IsRollback;
                    objVersionDetails[increment].AppExeName = versionDtl.AppExeName;
                    objVersionDetails[increment].EntryPoint = versionDtl.EntryPoint;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objVersionDetails;
        }
        #endregion

        public Serv.ManageApplicationDetails[] Convert(Buss.ManageApplicationDetails[] input)
        {
            int increment = 0;
            Serv.ManageApplicationDetails[] objApplicationDetails = new Serv.ManageApplicationDetails[input.Length];
            try
            {
                foreach (Buss.ManageApplicationDetails ApplicationDtl in input)
                {
                    objApplicationDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageApplicationDetails();
                    objApplicationDetails[increment].ApplicationNM = ApplicationDtl.ApplicationNM;
                    objApplicationDetails[increment].ApplicationAbbr = ApplicationDtl.ApplicationAbbr;
                    objApplicationDetails[increment].ApplicationDeployPath = ApplicationDtl.ApplicationDeployPath;
                    objApplicationDetails[increment].ApplicationExeName = ApplicationDtl.AppExeName;
                    objApplicationDetails[increment].ApplicationType = ApplicationDtl.AppType;
                    objApplicationDetails[increment].AppId = ApplicationDtl.AppId;
                    objApplicationDetails[increment].EntryPoint = ApplicationDtl.EntryPoint;
                    objApplicationDetails[increment].TotalRecords = ApplicationDtl.TotalRecords;

                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objApplicationDetails;
        }

        //public PopulateClientResponse Convert(Buss.ClientDetailReponse[] input)
        //{
        //    PopulateClientResponse response = new PopulateClientResponse();
        //    int increment = 0;
        //    Serv.ClientDetailsResponse[] objClientDetails = new Serv.ClientDetailsResponse[input.Length];
        //    response.PopulateResponse = objClientDetails;
        //    try
        //    {
        //        foreach (Buss.ClientDetailReponse accountDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].ClientId.ToString()))
        //                {
        //                    objClientDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ClientDetailsResponse();
        //                    objClientDetails[increment].ClientId = accountDtl.ClientId;
        //                    objClientDetails[increment].ClientName = accountDtl.ClientName;
        //                    objClientDetails[increment].ClientAbbr = accountDtl.ClientAbbr;

        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.ClientDetailsResponse[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4006);
        //    }

        //    return response;
        //}

        //public Serv.ManageClientDetails[] Convert(Buss.ManageClientDetails[] input)
        //{
        //    int increment = 0;
        //    Serv.ManageClientDetails[] objClientDetails = new Serv.ManageClientDetails[input.Length];
        //    try
        //    {
        //        foreach (Buss.ManageClientDetails ClientDtl in input)
        //        {
        //            objClientDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageClientDetails();
        //            objClientDetails[increment].ClientId = ClientDtl.ClientId;
        //            objClientDetails[increment].ClientName = ClientDtl.ClientName;
        //            objClientDetails[increment].ClientAbbr = ClientDtl.ClientAbbr;
        //            objClientDetails[increment].CREATED_DT = ClientDtl.CREATED_DT;
        //            objClientDetails[increment].GlobalCD = ClientDtl.GlobalCD;
        //            increment++;
        //        }
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return objClientDetails;
        //}

        public Serv.ManageRoleDetails[] Convert(Buss.ManageRoleDetails[] input)
        {
            int increment = 0;
            Serv.ManageRoleDetails[] objRoleDetails = new Serv.ManageRoleDetails[input.Length];
            try
            {
                foreach (Buss.ManageRoleDetails RoleDtl in input)
                {
                    objRoleDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageRoleDetails();
                    objRoleDetails[increment].ClientId = RoleDtl.ClientId;
                    objRoleDetails[increment].ClientName = RoleDtl.ClientName;
                    objRoleDetails[increment].RoleCode = RoleDtl.RoleCode;
                    objRoleDetails[increment].RoleName = RoleDtl.RoleName;
                    objRoleDetails[increment].ModifiedDate = RoleDtl.ModifiedDate;
                    objRoleDetails[increment].RoleTypeCD = RoleDtl.RoleTypeCD;
                    objRoleDetails[increment].ClientAbbr = RoleDtl.ClientAbbr;
                    objRoleDetails[increment].SYSTEM_NAME = RoleDtl.SYSTEM_NAME;
                    objRoleDetails[increment].TotalRecord = RoleDtl.TotalRecord;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleDetails;
        }

        public Serv.ManageFunctionDetails[] Convert(Buss.FunctionDetails[] input)
        {
            int increment = 0;
            Serv.ManageFunctionDetails[] objFuncDetails = new Serv.ManageFunctionDetails[input.Length];
            try
            {
                foreach (Buss.FunctionDetails FuncDtl in input)
                {
                    objFuncDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ManageFunctionDetails();
                    objFuncDetails[increment].FuntionId = FuncDtl.FuntionId;
                    objFuncDetails[increment].FunctionName = FuncDtl.FunctionName;


                    increment++;
                }


            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objFuncDetails;
        }
        public Serv.RoleDetails[] Convert(Buss.RoleDetails[] input)
        {
            int increment = 0;
            Serv.RoleDetails[] objRoleDetails = new Serv.RoleDetails[input.Length];
            try
            {
                foreach (Buss.RoleDetails RoleDtl in input)
                {
                    objRoleDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.RoleDetails();
                    objRoleDetails[increment].RoleClientId = RoleDtl.RoleClientId;
                    objRoleDetails[increment].RoleName = RoleDtl.RoleName;


                    increment++;
                }


            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleDetails;
        }


        public Serv.RoleMasterDetails[] Convert(Buss.RoleMasterDetails[] input)
        {
            int increment = 0;
            Serv.RoleMasterDetails[] objRoleMasterDetails = new Serv.RoleMasterDetails[input.Length];
            try
            {
                foreach (Buss.RoleMasterDetails RoleMasterDtl in input)
                {
                    objRoleMasterDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.RoleMasterDetails();
                    objRoleMasterDetails[increment].RoleCD = RoleMasterDtl.RoleCD;
                    objRoleMasterDetails[increment].RoleName = RoleMasterDtl.RoleName;
                    increment++;
                }


            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objRoleMasterDetails;
        }

        public Serv.UserMenuDetails[] Convert(Buss.UserMenuDetails[] input)
        {
            int increment = 0;
            Serv.UserMenuDetails[] objUserMenuDetails = new Serv.UserMenuDetails[input.Length];
            try
            {
                foreach (Buss.UserMenuDetails UserMenuDtl in input)
                {
                    objUserMenuDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.UserMenuDetails();
                    objUserMenuDetails[increment].FunctionId = UserMenuDtl.FunctionId;
                    objUserMenuDetails[increment].FunctionName = UserMenuDtl.FunctionName;
                    objUserMenuDetails[increment].FunctionPageUrlTxt = UserMenuDtl.FunctionPageUrlTxt;
                    objUserMenuDetails[increment].FunctionParentId = UserMenuDtl.FunctionParentId;
                    objUserMenuDetails[increment].DispOrderNo = UserMenuDtl.DispOrderNo;

                    increment++;
                }


            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objUserMenuDetails;
        }

        //public PopulateClientAccResponse Convert(Buss.ClientDetailbyAcc[] input)
        //{
        //    PopulateClientAccResponse response = new PopulateClientAccResponse();
        //    int increment = 0;
        //    Serv.ClientDetailbyAcc[] objClientAccDetails = new Serv.ClientDetailbyAcc[input.Length];
        //    response.PopulateResponse = objClientAccDetails;
        //    try
        //    {
        //        foreach (Buss.ClientDetailbyAcc clientDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (!string.IsNullOrEmpty(input[increment].ClientID.ToString()))
        //                {
        //                    objClientAccDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ClientDetailbyAcc();
        //                    objClientAccDetails[increment].AccountCD = clientDtl.AccountCD;
        //                    objClientAccDetails[increment].ClientID = clientDtl.ClientID;
        //                    objClientAccDetails[increment].ClientName = clientDtl.ClientName;
        //                    objClientAccDetails[increment].ClientAbbreviation = clientDtl.ClientAbbreviation;
        //                    //objClientDetails[increment].AccountType = clientDtl.AccountType;
        //                    //objClientDetails[increment].IsGlobal = clientDtl.IsGlobal;

        //                    //objAccountDetails[increment].MacID = accountDtl.MacID;
        //                    //objAccountDetails[increment].IPAddress = accountDtl.IPAddress;
        //                    //objAccountDetails[increment].ComputerName = accountDtl.ComputerName;
        //                    //objAccountDetails[increment].CreatedUserID = accountDtl.CreatedUserID;
        //                    //objAccountDetails[increment].CreatedUserDate = accountDtl.CreatedUserDate;
        //                    //objAccountDetails[increment].ModifiedUserID = accountDtl.ModifiedUserID;
        //                    //objAccountDetails[increment].ModifiedUserDate = accountDtl.ModifiedUserDate;
        //                    //objAccountDetails[increment].DomainName = accountDtl.DomainName;
        //                    increment++;
        //                }
        //                else
        //                {
        //                    response.PopulateResponse = new Serv.ClientDetailbyAcc[0];
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4006);
        //    }

        //    return response;
        //}

        public Serv.TimeDurationDetails[] Convert(Buss.DurationTimeDetails[] input)
        {
            int increment = 0;
            Serv.TimeDurationDetails[] objAppUserDetails = new Serv.TimeDurationDetails[input.Length];
            try
            {
                foreach (Buss.DurationTimeDetails AppConfigDtl in input)
                {
                    objAppUserDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.TimeDurationDetails();
                    objAppUserDetails[increment].TimeDuration = AppConfigDtl.TimeDuration;
                    objAppUserDetails[increment].TimeFormat = AppConfigDtl.TimeFormat;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppUserDetails;
        }

        public AppFocusReportResponse Convert(Buss.AppFocusReportDetails[] input)
        {
            AppFocusReportResponse response = new AppFocusReportResponse();
            int increment = 0;
            Serv.AppFocusReportDetails[] objAppFocusDetails = new Serv.AppFocusReportDetails[input.Length];
            response.PopulateResponse = objAppFocusDetails;
            try
            {
                foreach (Buss.AppFocusReportDetails AppDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(input[increment].UserName))
                        {
                            objAppFocusDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AppFocusReportDetails();
                            objAppFocusDetails[increment].GroupSeqNo = AppDtl.GroupSeqNo;
                            objAppFocusDetails[increment].AppName = AppDtl.AppName;
                            objAppFocusDetails[increment].ComputerName = AppDtl.ComputerName;
                            objAppFocusDetails[increment].IpAddress = AppDtl.IpAddress;
                            objAppFocusDetails[increment].OfficeId = AppDtl.OfficeId;
                            objAppFocusDetails[increment].UserName = AppDtl.UserName;
                            objAppFocusDetails[increment].UsageDate = AppDtl.UsageDate;
                            objAppFocusDetails[increment].TotalUsage = AppDtl.TotalUsage;
                            objAppFocusDetails[increment].ProcessName = AppDtl.ProcessName;
                            objAppFocusDetails[increment].ToDate = AppDtl.ToDate;
                            objAppFocusDetails[increment].FromDate = AppDtl.FromDate;
                            objAppFocusDetails[increment].ApplEndDate = AppDtl.ApplEndDate;
                            objAppFocusDetails[increment].ADSId = AppDtl.ADS_ID;
                            objAppFocusDetails[increment].TotalRecords = AppDtl.TotalRecords;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.AppFocusReportDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                //response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                //response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4008);
            }

            return response;
        }

        public RptFocusAppNameResponse Convert(Buss.RptFocusAppDetails[] input)
        {
            RptFocusAppNameResponse response = new RptFocusAppNameResponse();
            int increment = 0;
            Serv.RptFocusAppDetails[] objApplicationDetails = new Serv.RptFocusAppDetails[input.Length];

            response.PopulateResponse = objApplicationDetails;
            try
            {
                foreach (Buss.RptFocusAppDetails applicationDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(System.Convert.ToString(input[increment].App_ID)))
                        {
                            objApplicationDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.RptFocusAppDetails();
                            objApplicationDetails[increment].ID = applicationDtl.ID;
                            objApplicationDetails[increment].AppID = applicationDtl.App_ID;
                            objApplicationDetails[increment].App_DESC = applicationDtl.App_DESC;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.RptFocusAppDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4006);
            }

            return response;
        }
        public RptFocusOfficeIDResponse Convert(Buss.RptFocusOfficeIdDetails[] input)
        {
            RptFocusOfficeIDResponse response = new RptFocusOfficeIDResponse();
            int increment = 0;
            Serv.RptFocusOfficeIdDetails[] objAPPFOfficeDetails = new Serv.RptFocusOfficeIdDetails[input.Length];

            response.PopulateResponse = objAPPFOfficeDetails;
            try
            {
                foreach (Buss.RptFocusOfficeIdDetails officeDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(System.Convert.ToString(input[increment].OfficeID)))
                        {
                            objAPPFOfficeDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.RptFocusOfficeIdDetails();
                            objAPPFOfficeDetails[increment].OfficeId = officeDtl.OfficeID;
                            objAPPFOfficeDetails[increment].Office_DESC = officeDtl.Office_DESC;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.RptFocusOfficeIdDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (Exception ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4006);
            }

            return response;
        }

        public Serv.FocusAppDetails[] Convert(Buss.FocusAppDetails[] input)
        {
            int increment = 0;
            Serv.FocusAppDetails[] objAppUserDetails = new Serv.FocusAppDetails[input.Length];
            try
            {
                foreach (Buss.FocusAppDetails AppuserDtl in input)
                {
                    objAppUserDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.FocusAppDetails();
                    objAppUserDetails[increment].App_Id = AppuserDtl.App_Id;
                    objAppUserDetails[increment].APP_DS = AppuserDtl.App_DESC;
                    objAppUserDetails[increment].ID = AppuserDtl.ID;
                    objAppUserDetails[increment].TotalRecords = AppuserDtl.TotalRecords;

                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppUserDetails;
        }

        public Serv.AppFocusOfficeDetails[] Convert(Buss.AppFocusOfficeDetails[] input)
        {
            int increment = 0;
            Serv.AppFocusOfficeDetails[] objAppFocusOfficeDetails = new Serv.AppFocusOfficeDetails[input.Length];
            try
            {
                foreach (Buss.AppFocusOfficeDetails AppOfficeDtl in input)
                {
                    objAppFocusOfficeDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AppFocusOfficeDetails();
                    objAppFocusOfficeDetails[increment].ID = AppOfficeDtl.ID;
                    objAppFocusOfficeDetails[increment].Office_ID = AppOfficeDtl.Office_ID;
                    objAppFocusOfficeDetails[increment].Office_Desc = AppOfficeDtl.Office_Desc;
                    objAppFocusOfficeDetails[increment].ISREPORT = AppOfficeDtl.IsReport;
                    objAppFocusOfficeDetails[increment].TotalRecords = AppOfficeDtl.TotalRecord;
                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppFocusOfficeDetails;
        }

        public Serv.FocusGroupDetails[] Convert(Buss.FocusGroupDetails[] input)
        {
            int increment = 0;
            Serv.FocusGroupDetails[] objAppfGroupDetails = new Serv.FocusGroupDetails[input.Length];
            try
            {
                foreach (Buss.FocusGroupDetails AppfgroupDtl in input)
                {
                    objAppfGroupDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.FocusGroupDetails();

                    objAppfGroupDetails[increment].GROUP_NM = AppfgroupDtl.Group_NM;
                    objAppfGroupDetails[increment].ID = AppfgroupDtl.ID;
                    objAppfGroupDetails[increment].TotalRecord = AppfgroupDtl.TotalRecord;

                    increment++;
                }
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return objAppfGroupDetails;
        }
        public PopulateFocusGroupResponse Convert(Buss.PopulateFocusGroupDetails[] input)
        {
            PopulateFocusGroupResponse response = new PopulateFocusGroupResponse();
            int increment = 0;
            Serv.PopulateFocusGroupDetails[] objGroupDetails = new Serv.PopulateFocusGroupDetails[input.Length];
            response.PopulateResponse = objGroupDetails;
            try
            {
                foreach (Buss.PopulateFocusGroupDetails groupDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(System.Convert.ToString(input[increment].ID)))
                        {
                            objGroupDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.PopulateFocusGroupDetails();
                            objGroupDetails[increment].ID = groupDtl.ID;
                            objGroupDetails[increment].GROUP_NM = groupDtl.Group_NM;

                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.PopulateFocusGroupDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4007);
            }

            return response;
        }

        public OfficeGroupMappingReportResponse Convert(Buss.OfficeGroupMappingReportDetail[] input)
        {
            OfficeGroupMappingReportResponse response = new OfficeGroupMappingReportResponse();
            int increment = 0;
            Serv.OfficeGroupMappingReportInfo[] objDetails = new Serv.OfficeGroupMappingReportInfo[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.OfficeGroupMappingReportDetail OfficeGroupMappingReportDetail in input)
                {
                    if (input.Length > 0)
                    {
                        if (OfficeGroupMappingReportDetail.GroupNM != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.OfficeGroupMappingReportInfo();
                            objDetails[increment].GroupNM = OfficeGroupMappingReportDetail.GroupNM;
                            objDetails[increment].OfficeID = OfficeGroupMappingReportDetail.OfficeID;
                            objDetails[increment].ADSID = OfficeGroupMappingReportDetail.ADSID;
                            objDetails[increment].USER_NM = OfficeGroupMappingReportDetail.USER_NM;
                            objDetails[increment].COMPUTER_NM = OfficeGroupMappingReportDetail.COMPUTER_NM;
                            objDetails[increment].IP_ADDR_TXT = OfficeGroupMappingReportDetail.IP_ADDR_TXT;
                            objDetails[increment].TotalRecords = OfficeGroupMappingReportDetail.TotalRecords;
                            increment++;
                        }
                        else
                            response.PopulateResponse = new AmericanExpress.GDU.Service.DataContracts.OfficeGroupMappingReportInfo[0];
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        public AppfOfficeAdsIDResponse Convert(Buss.AppFOfficeAdsID[] input)
        {
            AppfOfficeAdsIDResponse response = new AppfOfficeAdsIDResponse();
            int increment = 0;
            Serv.PopulateAppfOfficeAdsID[] objGroupDetails = new Serv.PopulateAppfOfficeAdsID[input.Length];
            response.PopulateResponse = objGroupDetails;
            try
            {
                foreach (Buss.AppFOfficeAdsID AdsIDDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(System.Convert.ToString(input[increment].ADS_ID)))
                        {
                            objGroupDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.PopulateAppfOfficeAdsID();
                            objGroupDetails[increment].ADS_ID = AdsIDDtl.ADS_ID;
                            objGroupDetails[increment].OFFICE_ID = AdsIDDtl.OFFICE_ID;
                            objGroupDetails[increment].MACHINE_NM = AdsIDDtl.MACHINE_NM;
                            objGroupDetails[increment].USER_NM = AdsIDDtl.USER_NM;
                            objGroupDetails[increment].OFFICE_DS = AdsIDDtl.OFFICE_DS;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.PopulateAppfOfficeAdsID[0];
                        }
                    }
                }
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4007);
            }

            return response;
        }

        public TravelSuiteAppFocusReportResponse Convert(Buss.TravelSuiteAppFocusReportDetails[] input)
        {
            TravelSuiteAppFocusReportResponse response = new TravelSuiteAppFocusReportResponse();
            int increment = 0;
            Serv.TravelSuiteAppFocusReportDetails[] objTravelSuiteAppFocusDetails = new Serv.TravelSuiteAppFocusReportDetails[input.Length];
            response.PopulateResponse = objTravelSuiteAppFocusDetails;
            try
            {
                foreach (Buss.TravelSuiteAppFocusReportDetails AppDtl in input)
                {
                    if (input.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(input[increment].UserName))
                        {
                            objTravelSuiteAppFocusDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.TravelSuiteAppFocusReportDetails();
                            objTravelSuiteAppFocusDetails[increment].GroupSeqNo = AppDtl.GroupSeqNo;
                            objTravelSuiteAppFocusDetails[increment].AppName = AppDtl.AppName;
                            objTravelSuiteAppFocusDetails[increment].ComputerName = AppDtl.ComputerName;
                            objTravelSuiteAppFocusDetails[increment].IpAddress = AppDtl.IpAddress;
                            objTravelSuiteAppFocusDetails[increment].OfficeId = AppDtl.OfficeId;
                            objTravelSuiteAppFocusDetails[increment].UserName = AppDtl.UserName;
                            objTravelSuiteAppFocusDetails[increment].UsageDate = AppDtl.UsageDate;
                            objTravelSuiteAppFocusDetails[increment].TotalUsage = AppDtl.TotalUsage;
                            objTravelSuiteAppFocusDetails[increment].ProcessName = AppDtl.ProcessName;
                            objTravelSuiteAppFocusDetails[increment].ToDate = AppDtl.ToDate;
                            objTravelSuiteAppFocusDetails[increment].FromDate = AppDtl.FromDate;
                            objTravelSuiteAppFocusDetails[increment].ApplEndDate = AppDtl.ApplEndDate;
                            objTravelSuiteAppFocusDetails[increment].ADSId = AppDtl.ADS_ID;
                            objTravelSuiteAppFocusDetails[increment].TotalRecord = AppDtl.TotalRecord;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.TravelSuiteAppFocusReportDetails[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                //response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                //response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                string msg = ExceptionManager.GetErrorMessage(8050);
                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
                response.ServiceResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 4008);
            }

            return response;
        }

        public PilotApplicationDeploymentReportResponse Convert(Buss.PilotApplicationDeploymentReportDetail[] input)
        {
            PilotApplicationDeploymentReportResponse response = new PilotApplicationDeploymentReportResponse();
            int increment = 0;
            Serv.PilotApplicationDeploymentReportInfo[] objDetails = new Serv.PilotApplicationDeploymentReportInfo[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.PilotApplicationDeploymentReportDetail deploymentDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (input[increment].UserId != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.PilotApplicationDeploymentReportInfo();
                            objDetails[increment].App_Name = deploymentDetails.App_Name;
                            objDetails[increment].UserId = deploymentDetails.UserId;
                            objDetails[increment].NACId = deploymentDetails.NACId;
                            objDetails[increment].ApplicationPath = deploymentDetails.ApplicationPath;
                            objDetails[increment].ComputerName = deploymentDetails.ComputerName;
                            objDetails[increment].ExeTimeStamp = deploymentDetails.ExeTimeStamp;
                            objDetails[increment].ExeVersionNo = deploymentDetails.ExeVersionNo;
                            objDetails[increment].IPAddress = deploymentDetails.IPAddress;
                            objDetails[increment].LatestVersionNo = deploymentDetails.LatestVersionNo;
                            objDetails[increment].TimeStamp = deploymentDetails.RecordTimeStamp;
                            objDetails[increment].TotalRecords = deploymentDetails.TotalRecords;
                            increment++;
                        }
                        else
                        {
                            response.PopulateResponse = new Serv.PilotApplicationDeploymentReportInfo[0];
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        public AddOfficeResponse Convert(Buss.AddOfficeDetails[] input)
        {
            AddOfficeResponse response = new AddOfficeResponse();
            int increment = 0;
            Serv.AddOfficeDetails[] objDetails = new Serv.AddOfficeDetails[input.Length];
            response.SearchResponse = objDetails;
            try
            {
                foreach (Buss.AddOfficeDetails AddOfficeDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (AddOfficeDetails.Active != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AddOfficeDetails();
                            objDetails[increment].Active = AddOfficeDetails.Active;

                            increment++;
                        }
                        else
                            response.SearchResponse = new AmericanExpress.GDU.Service.DataContracts.AddOfficeDetails[0];
                    }
                }

                response.ServiceResponse = new StandardResponse();
                response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        #region ACWReportConverter

        public ACWReportResponse Convert(Buss.ACWReportDetails[] input)
        {
            ACWReportResponse response = new ACWReportResponse();
            int increment = 0;
            Serv.ACWCoralReportDetails[] objDetails = new Serv.ACWCoralReportDetails[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.ACWReportDetails acwDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (input[increment].ADSId != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.ACWCoralReportDetails();
                            objDetails[increment].ACWDuration = acwDetails.ACWDuration;
                            objDetails[increment].Server = acwDetails.Server;
                            objDetails[increment].StartDt = acwDetails.StartDt;
                            objDetails[increment].EndDt = acwDetails.EndDt;
                            objDetails[increment].AdsId = acwDetails.ADSId;
                            objDetails[increment].TIMEZONE = acwDetails.TIMEZONE;
                            increment++;
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                //response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                // response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        #endregion

        #region AppFocusIndicator

        public AppFocusIndicatorResponse Convert(Buss.AppFocusIndicatorDetails[] input)
        {
            AppFocusIndicatorResponse response = new AppFocusIndicatorResponse();
            int increment = 0;
            Serv.AppFocusIndicator[] objDetails = new Serv.AppFocusIndicator[input.Length];
            response.PopulateResponse = objDetails;
            try
            {
                foreach (Buss.AppFocusIndicatorDetails IndiDetails in input)
                {
                    if (input.Length > 0)
                    {
                        if (input[increment].AppFocusIndicator != null)
                        {
                            objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.AppFocusIndicator();
                            objDetails[increment].AppFIndicator = IndiDetails.AppFocusIndicator;
                            objDetails[increment].IndicatorName = IndiDetails.IndicatorName;
                            increment++;
                        }
                    }
                }

                response.ServiceResponse = new StandardResponse();
                //response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
                // response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }

        #endregion

        #region GlobalAlertResponse

        //public GlobalAlertResponse Convert(Buss.SearchLinkDetails[] input)
        //{
        //    GlobalAlertResponse response = new GlobalAlertResponse();
        //    int increment = 0;
        //    Serv.SearchLinkDetails[] objDetails = new Serv.SearchLinkDetails[input.Length];
        //    response.PopulateResponse = objDetails;
        //    try
        //    {
        //        foreach (Buss.SearchLinkDetails IndiDetails in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (input[increment].AppFocusIndicator != null)
        //                {
        //                    objDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.SearchLinkDetails();
        //                    objDetails[increment].AppFIndicator = IndiDetails.AppFocusIndicator;
        //                    increment++;
        //                }
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();                 
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return response;
        //}

        #endregion

        //#region PendingApproval Report
        //public PendingApprovalResponse Convert(Buss.PendingApprovalDetails[] input)
        //{
        //    PendingApprovalResponse response = new PendingApprovalResponse();
        //    int increment = 0;
        //    Serv.PendingApprovalDetails[] objPendingApprovalDetails = new Serv.PendingApprovalDetails[input.Length];
        //    response.PopulatePendingApprovalResponse = objPendingApprovalDetails;

        //    try
        //    {
        //        foreach (Buss.PendingApprovalDetails details in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                if (details.DocLink != null)
        //                {
        //                    objPendingApprovalDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.PendingApprovalDetails();
        //                    objPendingApprovalDetails[increment].DocLink = details.DocLink;
        //                    objPendingApprovalDetails[increment].UploadedBy = details.UploadedBy;
        //                    objPendingApprovalDetails[increment].UploadedDate = details.UploadedDate;
        //                    objPendingApprovalDetails[increment].Label_Id = details.Label_Id;
        //                    objPendingApprovalDetails[increment].Link_Cat_Dtl_Id = details.Link_Cat_Dtl_Id;
        //                    objPendingApprovalDetails[increment].Link_Dtl_Id = details.Link_Dtl_Id;
        //                    objPendingApprovalDetails[increment].Link_Id = details.Link_Id;
        //                    objPendingApprovalDetails[increment].Mode = details.Mode;
        //                    objPendingApprovalDetails[increment].Upload_Type = details.Upload_Type;
        //                    objPendingApprovalDetails[increment].Link = details.Link;

        //                    increment++;
        //                }
        //                else
        //                    response.PopulatePendingApprovalResponse = new AmericanExpress.GDU.Service.DataContracts.PendingApprovalDetails[0];
        //            }
        //        }

        //        response.ServiceResponse = new StandardResponse();
        //        // response.ServiceResponse.ResponseCodeStatus = (StdResponseCode)Enum.Parse(typeof(StdResponseCode), input[0].STDResponse.ResponseCodeStatus.ToString());
        //        //response.ServiceResponse.ResponseMessage = input[0].STDResponse.ResponseMessage;
        //    }
        //    catch (GWizException ex)
        //    {
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = ex.ErrorMessage;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }
        //    catch (Exception ex)
        //    {
        //        GWizException GWizEx = new GWizException();
        //        string message = ExceptionManager.GetErrorMessage(8050);
        //        ExceptionManager.HandleException(GWizEx, 4000);
        //        CustomFaultMsg custmErr = new CustomFaultMsg();
        //        custmErr.MyCustomErrMsg = message;
        //        ////Raise the customized fault message exception to the client.
        //        throw new FaultException<CustomFaultMsg>(custmErr);
        //    }

        //    return response;
        //}
        //#endregion

        #region Transit Data
        public TransitDataResponse Convert(Buss.TransitDataDetails[] input)
        {
            TransitDataResponse response = new TransitDataResponse();
            int increment = 0;
            Serv.TransitDataDetails[] objTransitDataDetails = new Serv.TransitDataDetails[input.Length];
            response.PopulateTransitDataResponse = objTransitDataDetails;

            try
            {
                foreach (Buss.TransitDataDetails details in input)
                {
                    if (input.Length > 0)
                    {
                        objTransitDataDetails[increment] = new AmericanExpress.GDU.Service.DataContracts.TransitDataDetails();
                        objTransitDataDetails[increment].filePath = details.filePath;
                        increment++;
                    }
                }
                response.ServiceResponse = new StandardResponse();
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }
        #endregion

        //public SearchClientTotalAlertResponse Convert(Buss.SearchClientTotalAlert input)
        //{
        //    SearchClientTotalAlertResponse response = new SearchClientTotalAlertResponse();
        //    Serv.SearchClientTotalAlertDetails objSearchAlertResult = new Serv.SearchClientTotalAlertDetails();
        //    response.Response = objSearchAlertResult;
        //    try
        //    {
        //        objSearchAlertResult.TotalAlert = input.TotalAlert;
        //        objSearchAlertResult.AlertDate = input.AlertDate;

        //        response.ServiceResponse = new StandardResponse();
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4009);
        //    }
        //    return response;
        //}

        //public SearchOtherInfoTotalAlertResponse Convert(Buss.SearchInfoTotalAlert input)
        //{
        //    SearchOtherInfoTotalAlertResponse response = new SearchOtherInfoTotalAlertResponse();
        //    Serv.SearchOtherInfoTotalAlert objOtherInfoResult = new Serv.SearchOtherInfoTotalAlert();

        //    response.Response = objOtherInfoResult;
        //    try
        //    {
        //        objOtherInfoResult.TotalAlert = input.TotalAlert;
        //        objOtherInfoResult.AlertDate = input.AlertDate;
        //        response.ServiceResponse = new StandardResponse();
        //    }
        //    catch (GWizException ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        response.ServiceResponse = new StandardResponse();
        //        response.ServiceResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        response.ServiceResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 4000);
        //    }

        //    return response;
        //}

        //public AuditTrialResponse Convert(Buss.AuditTrialDetails[] input)
        //{
        //    AuditTrialResponse response = new AuditTrialResponse();
        //    Serv.AuditTrialDetails[] objAuditTrialDetail = new Serv.AuditTrialDetails[input.Length];
        //    int increment = 0;
        //    response.SearchResponse = objAuditTrialDetail;
        //    try
        //    {
        //        foreach (Buss.AuditTrialDetails atDtl in input)
        //        {
        //            if (input.Length > 0)
        //            {
        //                objAuditTrialDetail[increment] = new AmericanExpress.GDU.Service.DataContracts.AuditTrialDetails();
        //                objAuditTrialDetail[increment].Created_User_ID = atDtl.Created_User_ID;
        //                objAuditTrialDetail[increment].Created_DT = atDtl.Created_DT;
        //                objAuditTrialDetail[increment].Modified_User_ID = atDtl.Modified_User_ID;
        //                objAuditTrialDetail[increment].Modified_DT = atDtl.Modified_DT;
        //                increment++;
        //            }
        //        }               
        //    }
        //    catch (Exception ex)
        //    {
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        LogManager.LogErrorMessage(ex, 4006);
        //    }
        //    return response;
        //}

        public GetAppLatestVersionResponse Convert(Buss.GetAppLatestVersionInfo getAppLatestVersionInfo)
        {
            GetAppLatestVersionResponse response = new GetAppLatestVersionResponse();
            Serv.GetAppLatestVersionInfo details = new Serv.GetAppLatestVersionInfo();


            try
            {

                details.App_ID = getAppLatestVersionInfo.App_ID;
                details.App_Name = getAppLatestVersionInfo.App_Name;
                details.App_Type = getAppLatestVersionInfo.App_Type;
                details.App_Version = getAppLatestVersionInfo.App_Version;

                response.getAppLatestVersionInfo = details;
            }
            catch (GDUException ex)
            {
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = ex.ErrorMessage;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }
            catch (Exception ex)
            {
                GDUException GWizEx = new GDUException();
                string message = ExceptionManager.GetErrorMessage(8050);
                ExceptionManager.HandleException(GWizEx, 4000);
                CustomFaultMsg custmErr = new CustomFaultMsg();
                custmErr.MyCustomErrMsg = message;
                ////Raise the customized fault message exception to the client.
                throw new FaultException<CustomFaultMsg>(custmErr);
            }

            return response;
        }
    }
}

