﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.PushOnce
{
    public static class Constants
    {
        internal static string LogFileName
        {
            get
            {
                return "AmericanExpress.PushOnce.AutomaticUpdater.log";
            }
        }

        internal static string ApplicationEntryAssembly
        {
            get
            {
                return "AmericanExpress.PushOnce.Loader.exe";
            }

        }

        internal static string[] ApplicationAssemblies
        {
            get
            {
                return new string[] {
                
                "AmericanExpress.PushOnce.AutomaticUpdateManager.exe",
                "AmericanExpress.PushOnce.AutomaticUpdater.dll",
                "AmericanExpress.PushOnce.Loader.exe" };
            }
        }

        internal static string[] ApplicationFiles
        {
            get
            {
                return new string[] {

                    "AmericanExpress.PushOnce.AutomaticUpdateManager.exe.config",
                    "PushOnce.ico",
                    "Axp.GDU.Deployment_Utility.exe",
                    "Axp.GDU.Deployment_Utility.exe.config",
                    "Axp.GDU.Process.exe",
                    "Axp.GDU.Process.exe.config",
                    "Axp.CheckPilotUser.exe",
                    "Axp.CheckPilotUser.exe.config",
                    "Axp.ApplicationWatcher.exe",
                    "Axp.ApplicationWatcher.exe.config"
                };
            }
        }



        internal static string PushOnceProgID
        {
            get
            {
                return "AmericanExpress.PushOnce";
            }
        }

        internal static string PushOnceDescription
        {
            get
            {
                //return "American Express PushOnce Automatic Updater";
                return "PushOnce Automatic Updater";
            }
        }

        internal static string PushOnceApplicationType
        {
            get
            {
                return "Application/x-amex-application";
            }
        }

        internal static string PushOnceManifestExtension
        {
            get
            {
                return ".amexapplication";
            }
        }

        internal static string ApplicationInstallBase
        {
            get
            {
                return System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles) + "\\American Express\\PushOnce\\";
            }
        }

    }
}
