﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.PushOnce.Common;
using System.IO;
using System.Windows.Forms;
using System.Configuration;

namespace AmericanExpress.PushOnce
{
    public static class SelfInstaller
    {
        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;
        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;
        internal static void SelfInstall()
        {
            try
            {
                //LowTraceText.AppendLine("PO: HL in SelfInstall Method: Entered into SelfInstall method called from Dispatch Method(AgrgumentDispatcher class) defind in SelfInstaller class ", HighTraceInfo);
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO: HL in SelfInstall Method: Entered into SelfInstall method called from Dispatch Method(AgrgumentDispatcher class) defind in SelfInstaller class ");
                LowTraceText.AppendLine("PO: LL Step 28a in SelfInstall Method: Entered into SelfInstall method called from Dispatch Method(AgrgumentDispatcher class) defind in SelfInstaller class");
                Logger.Enter("Program.SelfInstall", new string[] { });
                //LowTraceText.AppendLine("Program.SelfInstall Step 1: Enter in SelfInstall");
                FileAssociationInfo fi = new FileAssociationInfo(Constants.PushOnceManifestExtension);
                if (fi.Exists)
                    fi.Delete();

                string path = Constants.ApplicationInstallBase;
                Uri uriCodebase = new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                string location = uriCodebase.LocalPath;
                FileInfo fiRunFolder = new System.IO.FileInfo(location);
                FileInfo fiInstallFolder = new FileInfo(path);

                if (!fiRunFolder.Directory.Equals(fiInstallFolder.Directory))
                {
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    LowTraceText.AppendLine("PO: LL Step 28b in SelfInstall Method: Calling TryAutoUpdateSelf method defined in SelfInstaller class ");
                    TryAutoUpdateSelf(fiRunFolder, fiInstallFolder);
                    LowTraceText.AppendLine("PO: LL Step 28d in SelfInstall Method: Came out of TryAutoUpdateSelf method defined in SelfInstaller class ");
                }

                if (!fi.Exists)
                {
                    fi.Create();
                    fi.ContentType = Constants.PushOnceApplicationType;
                    fi.ProgID = Constants.PushOnceProgID;
                    //fi.OpenWithList = new string[] { System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles) + "\\American Express\\Automatic Updater\\AmericanExpress.AutomaticUpdateManager.exe" };
                }
                string target = Path.Combine(path, Constants.ApplicationEntryAssembly);
                ProgramAssociationInfo pai = new ProgramAssociationInfo(Constants.PushOnceProgID);

                if (!pai.Exists)
                {

                    pai.Create();

                }
                pai.Description = Constants.PushOnceDescription;
                pai.DefaultIcon = new ProgramIcon(target, 1);
                pai.AddVerb(new ProgramVerb("open", "\"" + target + "\" \"%1\" %2 %3 %4"));


                // pai.ProgID = "{5BAC6A10-407B-4df8-A201-224EBDF9CCE6}";
            }
            finally
            {
                Logger.Exit("Program.SelfInstall");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        internal static void SelfUninstall()
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in SelfUninstall method: Entered into SelfUninstall method defined in SelfInstaller class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in SelfUninstall method: Entered into SelfUninstall method defined in SelfInstaller class");
                LowTraceText.AppendLine("PO: LL Step 30a in SelfUninstall method: Entered into SelfUninstall method defined in SelfInstaller class");
                FileAssociationInfo fi = new FileAssociationInfo(Constants.PushOnceManifestExtension);
                if (fi.Exists)
                    fi.Delete();


                ProgramAssociationInfo pai = new ProgramAssociationInfo(Constants.PushOnceProgID);
                if (!pai.Exists)
                    pai.Delete();

                DirectoryInfo di = new DirectoryInfo(Constants.ApplicationInstallBase);
                if (di.Exists)
                    di.Delete();


            }
            catch (Exception ex)
            {
                Logger.Log(ex);
                //LowTraceText.AppendLine("PO:: HL Step 10 in SelfUninstall method :SelfUninstall method Exception defined in SelfInstaller class" + ex.ToString(),HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL Step 10 in SelfUninstall method :SelfUninstall method Exception defined in SelfInstaller class" + ex.ToString());
                LowTraceText.AppendLine("PO:: LL in SelfUninstall method :SelfUninstall method Exception defined in SelfInstaller class" + ex.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }



        }

        private static void TryAutoUpdateSelf(FileInfo fiRunFolder, FileInfo fiInstallFolder)
        {

            try
            {


                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                string[] assemblies = Constants.ApplicationAssemblies;
                string[] files = Constants.ApplicationFiles;
                string source = "";
                string dest = "";
                bool rollback = false;

                List<string> AllFiles = new List<string>(assemblies);
                AllFiles.AddRange(files);
                HighTraceText.AppendLine("PO: HL in TryAutoUpdateSelf Method: Entered in TryAutoUpdateSelf defined in SelfInstaller class ");
                LowTraceText.AppendLine("PO: LL Step 28c in TryAutoUpdateSelf Method: Entered in TryAutoUpdateSelf defined in SelfInstaller class ");
                //LowTraceText.AppendLine("Program.SelfInstall Step 2: Enter in TryAutoUpdateSelf");
                foreach (string assembly in AllFiles)
                {
                    try
                    {
                        source = fiRunFolder.Directory.FullName + "\\" + assembly;
                        dest = fiInstallFolder.Directory.FullName + "\\" + assembly;
                        if (File.Exists(dest))
                        {
                            FileInfo fiDest = new FileInfo(dest);
                            FileInfo fiSrc = new FileInfo(source);
                            if (fiDest.LastWriteTime.CompareTo(fiSrc.LastWriteTime) < 0)
                            {
                                try
                                {
                                    File.Delete(fiDest.FullName);
                                    File.Copy(fiSrc.FullName, fiDest.FullName);
                                }
                                catch (Exception e)
                                {

                                    Logger.Log(e);
                                    //LowTraceText.AppendLine("PO:: HL Step 6 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-1 Exception defined in SelfInstaller class" + e.ToString(), HighTraceInfo);
                                    HighTraceText.AppendLine("PO:: HL Step 6 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-1 Exception defined in SelfInstaller class" + e.ToString());
                                    LowTraceText.AppendLine("PO:: LL in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-1 Exception defined in SelfInstaller class" + e.ToString());
                                    rollback = true;
                                }
                            }
                        }
                        else
                        {
                            if (File.Exists(source))
                                File.Copy(source, dest);
                        }
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                        //LowTraceText.AppendLine("PO:: HL Step 7 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-2 Exception defined in SelfInstaller class" + e.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO:: HL Step 7 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-2 Exception defined in SelfInstaller class" + e.ToString());
                        LowTraceText.AppendLine("PO:: LL in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-2 Exception defined in SelfInstaller class" + e.ToString());
                        rollback = true;
                    }
                    finally
                    {
                        if (rollback)
                        {
                            try
                            {
                                string original = "";
                                FileInfo[] fiList = fiInstallFolder.Directory.GetFiles("*.backup");
                                foreach (FileInfo fi in fiList)
                                {
                                    original = fi.FullName.Replace(".backup", "");
                                    if (File.Exists(original))
                                        File.Delete(original);

                                    File.Move(fi.FullName, original);
                                }

                            }
                            catch (Exception e)
                            {
                                Logger.Log(e);
                                //LowTraceText.AppendLine("PO:: HL Step 8 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-3 Exception defined in SelfInstaller class" + e.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("PO:: HL Step 8 in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-3 Exception defined in SelfInstaller class" + e.ToString());
                                LowTraceText.AppendLine("PO:: LL in TryAutoUpdateSelf method :TryAutoUpdateSelf catch-3 Exception defined in SelfInstaller class" + e.ToString());
                            }
                        }
                    }
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                mainDirectory = ConfigurationManager.AppSettings["MDPath"].ToString();
                string LowTraceInfo = ConfigurationManager.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationManager.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationManager.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!System.IO.File.Exists(FilePath))
                    {
                        using (fs = System.IO.File.Create(FilePath))
                        {

                        }
                    }
                    if (System.IO.File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationManager.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!System.IO.File.Exists(FilePath))
                    {
                        using (fs = System.IO.File.Create(FilePath))
                        {

                        }
                    }
                    if (System.IO.File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }

            }

            catch (Exception ex1)
            {

            }
        }
        //private static void LowTraceText.AppendLine(string ex)
        //{
        //    try
        //    {
        //        string TraceInfo = ConfigurationSettings.AppSettings["PushOnceTracFileInfo"].ToString();
        //        if (TraceInfo == "True")
        //        {
        //            string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceTracFile"].ToString());
        //            FileStream fs = null;
        //            if (!System.IO.File.Exists(TraceFile))
        //            {
        //                using (fs = System.IO.File.Create(TraceFile))
        //                {

        //                }
        //            }
        //            if (System.IO.File.Exists(TraceFile))
        //            {
        //                StringBuilder sb = new StringBuilder();
        //                StreamReader sr = new StreamReader(TraceFile);
        //                {
        //                    sb.Append(sr.ReadToEnd());
        //                    sb.AppendLine();
        //                }
        //                sr.Close();
        //                TextWriter tw = new StreamWriter(TraceFile);
        //                sb.AppendLine(ex.ToString());
        //                tw.WriteLine(sb.ToString());
        //                tw.Close();
        //            }
        //        }
        //    }
        //    catch (Exception ex1)
        //    {
        //    }
        //}
        //private static void LowTraceText.AppendLine(string ex, string traceinfotype)
        //{
        //    try
        //    {
        //        //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
        //        mainDirectory = ConfigurationSettings.AppSettings["MDPath"].ToString();
        //        string LowTraceInfo = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
        //        string HighTraceInfo = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

        //        if (LowTraceInfo == "True" && traceinfotype == "L")
        //        {
        //            //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
        //            string LowLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
        //            string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
        //            FilePath = Path.Combine(mainDirectory, FileNameSaved);
        //        }
        //        if (HighTraceInfo == "True" && traceinfotype == "H")
        //        {
        //            //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
        //            string HighLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
        //            string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
        //            FilePath = Path.Combine(mainDirectory, FileNameSaved);
        //        }
        //        FileStream fs = null;
        //        if (!File.Exists(FilePath))
        //        {
        //            using (fs = File.Create(FilePath))
        //            {

        //            }
        //        }
        //        if (File.Exists(FilePath))
        //        {
        //            StringBuilder sb = new StringBuilder();
        //            StreamReader sr = new StreamReader(FilePath);
        //            {
        //                sb.Append(sr.ReadToEnd());
        //                sb.AppendLine();
        //            }
        //            sr.Close();
        //            TextWriter tw = new StreamWriter(FilePath);
        //            sb.AppendLine(ex.ToString());
        //            tw.WriteLine(sb.ToString());
        //            tw.Close();
        //        }
        //    }

        //    catch (Exception ex1)
        //    {
                
        //    }
        //}




























    }
}
