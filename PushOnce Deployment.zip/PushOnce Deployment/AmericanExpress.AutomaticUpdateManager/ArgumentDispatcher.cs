﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.PushOnce;
using System.Text.RegularExpressions;
using AmericanExpress.PushOnce.Common;
using System.Xml.Linq;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Configuration;

namespace AmericanExpress.PushOnce
{

    /// <summary>
    /// Dispatches calls to other components based on the arguments passed in to
    /// the application
    /// </summary>
    public static class ArgumentDispatcher
    {
        private static int SelfUpdateWaitTime = 480000;

        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;

        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;



        /// <summary>
        /// Dispatches calls based on argument list values.
        /// </summary>
        /// <param name="args">Array of arguments passed in to the application on the command line.</param>
        public static void Dispatch(string[] args)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //System.Windows.Forms.MessageBox.Show("Attach");
                HighTraceText.AppendLine("PO: HL on Dispatch method: Entered into Dispatch method defined in ArgumentDispatcher class called from Main Method");
                LowTraceText.AppendLine("PO:: LL Step 25 in Dispatch Method: Entered into Dispatch method defined in ArgumentDispatcher class called from Main Method " + args.ToString());

                Logger.Enter("ArgumentDispatcher.Dispatch", new string[] { args.ToString() });
                foreach (string arg in args)
                {
                    if (arg.Contains("/load"))
                    {
                        LowTraceText.AppendLine("PO:: LL Step 26 in Dispatch Method: Calling StartLoader method if (arg.Contains = /load) ");
                        StartLoader(args);
                        LowTraceText.AppendLine("PO:: LL Step 26a in Dispatch Method: Came out of StartLoader method if (arg.Contains = /load) ");
                    }

                    if (arg.ToLower().StartsWith("/downloadtimeout="))
                        LowTraceText.AppendLine("PO:: LL Step 27 in Dispatch Method: Calling SetTimeoutValue method defined in ArgumentDispatcher class if (arg.ToLower().StartsWith(/downloadtimeout) ");
                    SetTimeoutValue(arg);
                    LowTraceText.AppendLine("PO:: LL Step 27b in Dispatch Method: Came out of SetTimeoutValue method defined in ArgumentDispatcher class if (arg.ToLower().StartsWith(/downloadtimeout) ");


                    if (arg.Contains("/selfinstall"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 28 in Dispatch Method: Calling SelfInstall method defined in SelfInstaller class if (arg.Contains(/selfinstall) ");
                        SelfInstaller.SelfInstall();
                        LowTraceText.AppendLine("PO: LL Step 28e in Dispatch Method: Came out of SelfInstall method defined in SelfInstaller class if (arg.Contains(/selfinstall) ");
                        //break;
                    }

                    if (arg.Contains("/selfupdate"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 29 in Dispatch Method: Calling UpdateSelf method defined in ArgumentDispatcher class if (arg.Contains(/selfupdate) ");
                        UpdateSelf(args);
                        LowTraceText.AppendLine("PO: LL Step 29d in Dispatch Method: Came out of UpdateSelf method defined in ArgumentDispatcher class if (arg.Contains(/selfupdate) ");
                        return;
                    }

                    if (arg.Contains("/selfuninstall"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 30 in Dispatch Method: Calling SelfUninstall method defined in SelfInstaller class if (arg.Contains(/selfuninstall) ");
                        SelfInstaller.SelfUninstall();
                        LowTraceText.AppendLine("PO: LL Step 30b in Dispatch method: Came out of SelfUninstall method defined in SelfInstaller class if (arg.Contains(/selfuninstall) ");
                        //break;
                    }

                    if (arg.StartsWith("/regasm"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 31 in Dispatch Method: Calling RegisterAssembly method defined in ComponentRegistrar class if (arg.Contains(/regasm) ");
                        ComponentRegistrar.RegisterAssembly(arg);
                        LowTraceText.AppendLine("PO: LL Step 31b in Dispatch Method: Came out of RegisterAssembly method defined in ComponentRegistrar class if (arg.Contains(/regasm) ");
                        return;
                    }

                    if (arg.StartsWith("/regsvr"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 32 in Dispatch Method: Calling RegisterCom method defined in ComponentRegistrar class if (arg.Contains(/regsvr) ");
                        ComponentRegistrar.RegisterCom(arg);
                        LowTraceText.AppendLine("PO: LL Step 32b in Dispatch Method: Came out of RegisterCom method defined in ComponentRegistrar class if (arg.Contains(/regsvr) ");
                        return;
                    }

                    if (arg.EndsWith(".amexapplication"))
                    {
                        LowTraceText.AppendLine("PO: LL Step 33 in Dispatch Method: In ArgumentDispatcher class if (arg.Contains(.amexapplication) ");
                        IEnumerable<string> s = args.Where(str => str.ToLower().StartsWith("/uninstall"));
                        IEnumerable<string> nolaunch = args.Where(str => str.ToLower().StartsWith("/nolaunch"));
                        if (s.Count() == 0)
                        {
                            LowTraceText.AppendLine("PO: LL Step 34 in Dispatch Method: Calling InstallOrUpdate method defined in ArgumentDispatcher class if (arg.Contains(.amexapplication) ");
                            InstallOrUpdate(args, arg, nolaunch.Count() == 0);
                            LowTraceText.AppendLine("PO: LL Step 34z-58.20 in Dispatch Method Method: Came out of InstallOrUpdate(in ArgumentDispatcher class) method ");
                        }
                        else
                        {
                            IEnumerable<string> quiets = args.Where(str => str.ToLower() == "/q");
                            DialogResult dr = DialogResult.Yes;
                            if (quiets.Count() == 0)
                            {
                                dr = MessageBox.Show("Are you sure you want to Remove this Application?", "PushOnce", MessageBoxButtons.YesNo);
                            }
                            if (dr == DialogResult.Yes)
                                LowTraceText.AppendLine("PO: LL Step 35 in Dispatch Method Method: Calling Uninstall method defined in ArgumentDispatcher class");
                            Uninstall(args, arg);
                            LowTraceText.AppendLine("PO: LL Step 35z-1 in Dispatch Method Method: Came out of Uninstall method defined in ArgumentDispatcher class");
                        }
                        return;
                    }


                }
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                Logger.Exit("ArgumentDispatcher.Dispatch");
            }

        }

        private static void StartLoader(string[] args)
        {

        }

        private static void UpdateSelf(string[] args)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                HighTraceText.AppendLine("PO: HL in UpdateSelf method: Entered into UpdateSelf method inside Dispatch Method defined in ArgumentDispatcher class ");
                LowTraceText.AppendLine("PO: LL Step 29a in UpdateSelf Method: Calling UpdateSelf method defined in Updater class");
                Updater.UpdateSelf(args);
                LowTraceText.AppendLine("PO: LL Step 29c in UpdateSelf Method: Came out of UpdateSelf method defined in Updater class");
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }

        }

        private static void Uninstall(string[] allArgs, string manifestArg)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                HighTraceText.AppendLine("PO: HL in Uninstall Method : Entered into Uninstall method defined in ArgumentDispatcher class");
                LowTraceText.AppendLine("PO: LL Step 35a in Uninstall Method : Entered into Uninstall method defined in ArgumentDispatcher class");
                Logger.Enter("ArgumentDispatcher.Uninstall", new string[] { allArgs.ToString() });
                Logger.Enter("ArgumentDispatcher.InstallOrUpdate", new string[] { allArgs.ToString(), manifestArg });
                string manifest = parseManifest(manifestArg);
                LowTraceText.AppendLine("PO: LL Step 35b in Uninstall Method : Calling Uninstall method defined in Updater class");
                Updater.Uninstall(manifest);
                LowTraceText.AppendLine("PO: LL Step 35z in Uninstall Method: Came out of Uninstall method defined in Updater class");
            }
            catch
            {
                Logger.Exit("ArgumentDispatcher.Uninstall");
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                Logger.Exit("ArgumentDispatcher.Uninstall");
            }
        }

        private static int InstallOrUpdate(string[] allArgs, string manifestArg, bool launch)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                HighTraceText.AppendLine("PO: HL on InstallOrUpdate Method: Entered into InstallOrUpdate method defined in ArgumentDispatcher class");
                LowTraceText.AppendLine("PO: LL Step 34a in InstallOrUpdate Method: Entered into InstallOrUpdate method defined in ArgumentDispatcher class");
                if (manifestArg.ToLower().EndsWith("americanexpress.pushonce.automaticupdatemanager.amexapplication"))
                {
                    //Sleep for awhile to reduce chance of collisions, unless nodelay is specified.
                    bool hasDelay = true;

                    if (null != allArgs)
                    {
                        IEnumerable<string> nodelay = allArgs.Where(s => s.ToLower() == "/nodelay");
                        hasDelay = nodelay.Count() == 0;
                    }

                    if (hasDelay)
                        System.Threading.Thread.Sleep(SelfUpdateWaitTime);
                }
                Logger.Enter("ArgumentDispatcher.InstallOrUpdate", new string[] { allArgs.ToString(), manifestArg, launch.ToString() });
                string manifest = parseManifest(manifestArg);
                LowTraceText.AppendLine("PO: LL Step 34b in InstallOrUpdate Method: Calling InstallOrUpdate method from ArgumentDispatcher class defined in Updater class");
                XElement deploymentManifest = Updater.InstallOrUpdate(manifest, launch, allArgs);
                LowTraceText.AppendLine("PO: LL Step 34z-58.4 in InstallOrUpdate Method: Came out of InstallOrUpdate method defined in Updater class ");
                if (null != deploymentManifest)
                    LowTraceText.AppendLine("PO: LL Step 34z-58.5 InstallOrUpdate Method: Calling InstallShortcutsAndAddRegistryInfo method defined in ArgumentDispatcher class ");
                InstallShortcutsAndAddRegistryInfo(allArgs, deploymentManifest);

                return 0;
            }
            catch (Exception e)
            {

                Logger.Log(e);
                //LogtoEvent("PO:: HL Step 13 in InstallOrUpdate method :InstallOrUpdate method Exception defined in ArgumentDispatcher class " + e.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL Step 13 in InstallOrUpdate method :InstallOrUpdate method defined in ArgumentDispatcher class ");
                LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :InstallOrUpdate method defined in ArgumentDispatcher class ");
                return 1;
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                Logger.Exit("ArgumentDispatcher.InstallOrUpdate");
            }
        }

        private static void InstallShortcutsAndAddRegistryInfo(string[] args, XElement deploymentManifest)
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                HighTraceText.AppendLine("PO: HL in InstallShortcutsAndAddRegistryInfo method: Entered into InstallShortcutsAndAddRegistryInfo method ");

                LowTraceText.AppendLine("PO: LL Step 34z-58.6 in InstallShortcutsAndAddRegistryInfo Method: Entered into InstallShortcutsAndAddRegistryInfo method ");
                LowTraceText.AppendLine("PO: LL Step 34z-58.7 in InstallShortcutsAndAddRegistryInfo Method: Calling InstallShortcutsAndAddRegistryInfo method defined in Updater class");
                Updater.InstallShortcutsAndAddRegistryInfo(args, deploymentManifest);
                LowTraceText.AppendLine("PO: LL Step 34z-58.19 in InstallShortcutsAndAddRegistryInfo Method: Came out of InstallShortcutsAndAddRegistryInfo(defined in Updater Class) method ");
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }

        private static string parseManifest(string args)
        {
            if (args.EndsWith(".amexapplication"))
                return args;

            return "";
        }

        private static void SetTimeoutValue(string arg)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                string pattern = "/downloadtimeout=(?<timeout>[0-9]{1,3})";
                Match m = Regex.Match(arg, pattern);
                if (m.Success)
                {
                    try
                    {
                        HighTraceText.AppendLine("PO: HL in SetTimeoutValue method: Entered into SetTimeoutValue method defined in ArgumentDispatcher class");
                        LowTraceText.AppendLine("PO:: LL Step 27a in Dispatch Method: Entered into SetTimeoutValue method defined in ArgumentDispatcher class ");
                        int toVal = Convert.ToInt32(m.Groups["timeout"].Value);
                        Updater.DownloadTimeout = toVal * 60 * 1000;
                    }
                    catch (Exception ex)
                    {
                        HighTraceText.AppendLine("PO:: HL Step 5 in SetTimeoutValue method :SetTimeoutValue Exception" + ex.ToString());
                        LowTraceText.AppendLine("PO:: LL in SetTimeoutValue method :SetTimeoutValue Exception" + ex.ToString());
                    }
                }
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }

        //private static void LogtoEvent(string ex, string traceinfotype)
        //{
        //    try
        //    {
        //        mainDirectory = ConfigurationSettings.AppSettings["MDPath"].ToString();
        //        //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
        //        string LowTraceInfo = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
        //        string HighTraceInfo = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

        //        if (LowTraceInfo == "True" && traceinfotype == "L")
        //        {
        //            //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
        //            string LowLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
        //            string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
        //            FilePath = Path.Combine(mainDirectory, FileNameSaved);
        //        }
        //        if (HighTraceInfo == "True" && traceinfotype == "H")
        //        {
        //            //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
        //            string HighLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
        //            string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
        //            FilePath = Path.Combine(mainDirectory, FileNameSaved);
        //        }
        //        FileStream fs = null;
        //        if (!File.Exists(FilePath))
        //        {
        //            using (fs = File.Create(FilePath))
        //            {

        //            }
        //        }
        //        if (File.Exists(FilePath))
        //        {
        //            StringBuilder sb = new StringBuilder();
        //            StreamReader sr = new StreamReader(FilePath);
        //            {
        //                sb.Append(sr.ReadToEnd());
        //                sb.AppendLine();
        //            }
        //            sr.Close();
        //            TextWriter tw = new StreamWriter(FilePath);
        //            sb.AppendLine(ex.ToString());
        //            tw.WriteLine(sb.ToString());
        //            tw.Close();
        //        }
        //    }

        //    catch (Exception ex1)
        //    {

        //    }
        //}

        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                mainDirectory = ConfigurationManager.AppSettings["MDPath"].ToString();
                string LowTraceInfo = ConfigurationManager.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationManager.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationManager.AppSettings["AxpApplicationWatcherLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationManager.AppSettings["AxpApplicationWatcherHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
            }
            catch (Exception ex1)
            {

            }
        }




































    }
}
