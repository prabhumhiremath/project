﻿using System;
namespace AmericanExpress.AutomaticUpdater
{
    internal interface IApplicationManifestReader
    {
        /// <summary>
        /// For a given assembly returns the custom action to run for it.
        /// </summary>
        /// <param name="actionEvent">Install,Commit,Rollback</param>
        /// <param name="assemblyName">Name of the assembly</param>
        /// <returns>Custom action.</returns>
        AmericanExpress.PushOnce.CustomAction GetAssemblyCustomAction(AmericanExpress.PushOnce.ActionEvent actionEvent, string assemblyName);

        /// <summary>
        /// Return all assembly elements that require some kind of registration, either
        /// as a COM component or registered assembly (REGASM)
        /// </summary>
        /// <param name="regType">Type of resgistration</param>
        /// <returns>List of assemblies that require registration.</returns>
        System.Collections.Generic.IEnumerable<System.Xml.Linq.XElement> GetAssemblyRegistrations(AmericanExpress.PushOnce.ApplicationManifestReader.RegistrationType regType);

        /// <summary>
        /// Returns a list of assembly files.
        /// </summary>
        /// <param name="isClickOnceManifest"></param>
        /// <param name="dir"></param>
        /// <returns></returns>
        System.IO.FileInfo[] GetCodeFiles(bool isClickOnceManifest, string dir);

        /// <summary>
        /// Returns a list of files that need COM registration.
        /// </summary>
        /// <returns></returns>
        System.Collections.Generic.IEnumerable<System.Xml.Linq.XElement> GetComRegistrations();

        /// <summary>
        /// Get the entry point command line file.
        /// </summary>
        /// <param name="isClickOnceManifest"></param>
        /// <returns></returns>
        string GetEntryPointCommandLineFile(bool isClickOnceManifest);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="isClickOnceManifest"></param>
        /// <returns></returns>
        string GetEntryPointCommandLineParameters(bool isClickOnceManifest);

        /// <summary>
        /// Gets the custom action for a given action and file.
        /// </summary>
        /// <param name="actionEvent"></param>
        /// <param name="xFile"></param>
        /// <returns></returns>
        AmericanExpress.PushOnce.CustomAction GetFileCustomAction(AmericanExpress.PushOnce.ActionEvent actionEvent, System.Xml.Linq.XElement xFile);

        /// <summary>
        /// Returns the list of assemblies to install.
        /// </summary>
        /// <param name="isClickOnceManifest"></param>
        /// <returns></returns>
        System.Collections.Generic.IEnumerable<System.Xml.Linq.XElement> GetInstallableDependencies(bool isClickOnceManifest);


        /// <summary>
        /// Returns a list of non-assembly files to install.
        /// </summary>
        /// <param name="isClickOnceManifest"></param>
        /// <returns></returns>
        System.Collections.Generic.IEnumerable<System.Xml.Linq.XElement> GetInstallableFiles(bool isClickOnceManifest);

        /// <summary>
        /// Should the application run in shadow copy mode.
        /// </summary>
        bool ShadowCopy { get; }

       
    }
}
