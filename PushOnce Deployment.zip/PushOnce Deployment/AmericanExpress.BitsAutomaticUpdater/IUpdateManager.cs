﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.PushOnce
{
    public interface IUpdateManager
    {
        void Register(string id, string name, int updateInterval, string basePath, bool autoComplete);
        void UnRegister(string id);
        UpdateStatus GetStatus();
        void UpdateSettings(string id, int updateInterval, bool autoComplete);
        void EnableUpdates(string id);
        void DisbaleUpdates(string id);
        void Install(string id);

    }

    public enum UpdateStatus
    {
        Available,
        CurrentVersion

    }
}
