﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using AmericanExpress.PushOnce;

namespace AmericanExpress.PushOnce
{
    public class ApplicationManifestReader : AmericanExpress.AutomaticUpdater.IApplicationManifestReader
    {
        private XElement xManifest;

        public ApplicationManifestReader(XElement xManifest)
        {
            this.xManifest = xManifest;
        }

        public string GetEntryPointCommandLineFile(bool isClickOnceManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:entryPoint/asmv2:commandLine";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:entryPointCommandLine";
            }

            XElement commandLine = xManifest.XPathSelectElement(xPath, namespaceManager);
            if (null != commandLine && null != commandLine.Attribute("file"))
                return commandLine.Attribute("file").Value;

            throw new ApplicationException("Missing Entry Point information in application manifest");
        }


        public bool ShadowCopy
        {
            get
            {
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                string xPath = "asmv2:entryPoint";
                XElement xEntryPoint = xManifest.XPathSelectElement(xPath, namespaceManager);
                if (null != xEntryPoint && null != xEntryPoint.Attribute("shadowCopy"))
                    return xEntryPoint.Attribute("shadowCopy").Value.ToLower() == "true";

                return false;
            }
        }

        public string GetEntryPointCommandLineParameters(bool isClickOnceManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:entryPoint/asmv2:commandLine";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:entryPointCommandLine";
            }

            XElement commandLine = xManifest.XPathSelectElement(xPath, namespaceManager);
            if (null != commandLine && null != commandLine.Attribute("parameters"))
                return commandLine.Attribute("parameters").Value;

            throw new ApplicationException("Missing Entry Point information in application manifest");
        }

        public IEnumerable<XElement> GetInstallableDependencies(bool isClickOnceManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:dependency/asmv2:dependentAssembly[@dependencyType='install']";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:ManifestFiles/ns1:File[@method='version' and @action='copy']";
            }
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }

        public enum RegistrationType
        {
            COM,
            RegAsm
        }

        public IEnumerable<XElement> GetAssemblyRegistrations(RegistrationType regType)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
            string xPath = "asmv2:dependency/asmv2:dependentAssembly[@dependencyType='install'][@" + regType.ToString() + "]";
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }

        public IEnumerable<XElement> GetComRegistrations()
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
            string xPath = "asmv2:file[@" + RegistrationType.COM.ToString() + "='true']";
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }



        public CustomAction GetAssemblyCustomAction(ActionEvent actionEvent, string assemblyName)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
            string xPath = "asmv2:dependency/asmv2:dependentAssembly[asmv2:assemblyIdentity/@name='" + assemblyName + "']/asmv2:customAction";
            XElement e = xManifest.XPathSelectElement(xPath, namespaceManager);
            if (null != e)
            {
                string aEvent = e.Attribute("event").Value;
                string aType = e.Attribute("action").Value;
                try
                {
                    ActionEvent ae = (ActionEvent)Enum.Parse(typeof(ActionEvent), aEvent);
                    ActionType at = (ActionType)Enum.Parse(typeof(ActionType), aType);
                    if (ae == actionEvent)
                        return new CustomAction(e.Attribute("type").Value, ae, at);
                }
                catch
                {

                }

            }

            return null;

        }

        public CustomAction GetFileCustomAction(ActionEvent actionEvent, XElement xFile)
        {
            XElement e = xFile.Element("asmv2:CustomAction");
            if (null != e)
            {
                string aEvent = e.Attribute("event").Value;
                string aType = e.Attribute("action").Value;
                try
                {
                    ActionEvent ae = (ActionEvent)Enum.Parse(typeof(ActionEvent), aEvent);
                    ActionType at = (ActionType)Enum.Parse(typeof(ActionType), aType);
                    if (ae == actionEvent)
                        return new CustomAction(e.Attribute("type").Value, ae, at);
                }
                catch
                {

                }

            }

            return null;

        }



        public IEnumerable<XElement> GetInstallableFiles(bool isClickOnceManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:file";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:ManifestFiles/ns1:File[@method='date' and @action='copy']";
            }
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }


        public FileInfo[] GetCodeFiles(bool isClickOnceManifest, string dir)
        {

            IEnumerable<XElement> codeFiles = GetInstallableDependencies(isClickOnceManifest);
            //foreach( XElement codeFile in codeFiles) {

            FileInfo[] files = new FileInfo[codeFiles.Count()];
            int index = 0;
            foreach (XElement codeFile in codeFiles)
            {
                string src = dir + "\\" + codeFile.Attribute("name").Value + ".deploy";
                files[index++] = new FileInfo(src);
            }

            return files;

        }



        internal bool IsAssemblyFailSafe(string assemblyName)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
            string xPath = "asmv2:dependency/asmv2:dependentAssembly[asmv2:assemblyIdentity/@name='" + assemblyName + "']";

            bool isFailSafe = true;
            XElement e = xManifest.XPathSelectElement(xPath, namespaceManager);
            if (null != e)
            {
                isFailSafe = e.Attribute("failSafe") != null && e.Attribute("failSafe").Value.ToLower() == "true" ? true : false;

            }

            return isFailSafe;

        }

        internal bool IsFileFailSafe(string fileName)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
            namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
            string xPath = "asmv2:file[@name='" + fileName + "']";

            XElement e = xManifest.XPathSelectElement(xPath, namespaceManager);

            return e != null && e.Attribute("failSafe") != null && e.Attribute("failSafe").Value.ToLower() == "true";

        }
    }
}
