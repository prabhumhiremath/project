﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Configuration;

namespace AmericanExpress.PushOnce
{
    public static class ComponentRegistrar
    {
        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;

        public static void RegisterAssembly(string arg)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO: HL in RegisterAssembly method: Entered into RegisterAssembly method called from ArgumentDispatcher class & defined in ComponentRegistrar class");
                LowTraceText.AppendLine("PO: LL Step 31a in RegisterAssembly method: Entered into RegisterAssembly method called from ArgumentDispatcher class & defined in ComponentRegistrar class");

                //LogtoEvent("PO: HL in RegisterAssembly method: Entered into RegisterAssembly method called from ArgumentDispatcher class & defined in ComponentRegistrar class", HighTraceInfo);
                //LogtoEvent("PO: LL Step 31a in RegisterAssembly method: Entered into RegisterAssembly method called from ArgumentDispatcher class & defined in ComponentRegistrar class", LowTraceInfo);
                string[] split = arg.Split('=');
                string dllPath = string.Empty;
                if (split.Length == 2)
                {
                    dllPath = split[1];
                }
                if (string.Empty != dllPath)
                {
                    Regasm(dllPath, "/u");
                    Regasm(dllPath, "/codebase");
                }
            }
            catch (Exception ex)
            {
                HighTraceText.AppendLine("PO:: HL Step 11 in RegisterAssembly method :RegisterAssembly method Exception defined in ComponentRegistrar class" + ex.ToString());
                LowTraceText.AppendLine("PO:: LL in RegisterAssembly method :RegisterAssembly method Exception defined in ComponentRegistrar class" + ex.ToString());
                //LogtoEvent("PO:: HL Step 11 in RegisterAssembly method :RegisterAssembly method Exception defined in ComponentRegistrar class" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("PO:: LL in RegisterAssembly method :RegisterAssembly method Exception defined in ComponentRegistrar class" + ex.ToString(), LowTraceInfo);
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        public static void RegisterCom(string arg)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO: HL in RegisterCom method: Entered into RegisterCom method called from ArgumentDispatcher class & defined in ComponentRegistrar class");
                LowTraceText.AppendLine("PO: LL Step 32a in RegisterCom method: Entered into RegisterCom method called from ArgumentDispatcher class & defined in ComponentRegistrar class");
                //LogtoEvent("PO: HL in RegisterCom method: Entered into RegisterCom method called from ArgumentDispatcher class & defined in ComponentRegistrar class", HighTraceInfo);
                //LogtoEvent("PO: LL Step 32a in RegisterCom method: Entered into RegisterCom method called from ArgumentDispatcher class & defined in ComponentRegistrar class", LowTraceInfo);
                string[] split = arg.Split('=');
                string dllPath = string.Empty;
                if (split.Length == 2)
                {
                    dllPath = split[1];
                }
                if (string.Empty != dllPath)
                    RegSvr32(dllPath, "/i");
            }
            catch (Exception ex)
            {
                HighTraceText.AppendLine("PO:: HL Step 12 in RegisterCom method :RegisterCom method Exception defined in ComponentRegistrar class " + ex.ToString());
                LowTraceText.AppendLine("PO:: LL in RegisterCom method :RegisterCom method Exception defined in ComponentRegistrar class " + ex.ToString());
                //LogtoEvent("PO:: HL Step 12 in RegisterCom method :RegisterCom method Exception defined in ComponentRegistrar class " +ex.ToString(), HighTraceInfo);
                //LogtoEvent("PO:: LL in RegisterCom method :RegisterCom method Exception defined in ComponentRegistrar class " + ex.ToString(), LowTraceInfo);
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }


        internal static void Regasm(string dllPath, string parameters)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO: HL in Regasm Method : Entered into Regasm method defined in ComponentRegistrar Class");
                LowTraceText.AppendLine("PO: LL Step 35k in Regasm Method : Entered into Regasm method defined in ComponentRegistrar Class");
                //LogtoEvent("PO: HL in Regasm Method : Entered into Regasm method defined in ComponentRegistrar Class", HighTraceInfo);
                //LogtoEvent("PO: LL Step 35k in Regasm Method : Entered into Regasm method defined in ComponentRegistrar Class", LowTraceInfo);
                string regasmPath = RuntimeEnvironment.GetRuntimeDirectory() + @"regasm.exe";
                if (!File.Exists(regasmPath))
                    throw new ApplicationException("Registering assembly failed - runtime path invalid.");
                if (!File.Exists(dllPath))
                    return;

                Process process = new Process();
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.UseShellExecute = false; // Hides console window      
                process.StartInfo.FileName = regasmPath;
                process.StartInfo.Arguments = string.Format("\"{0}\" {1}", dllPath, parameters);
                process.Start();
                process.WaitForExit();
            }
            catch (Exception ex)
            {
                HighTraceText.AppendLine("Po: HL Step 46 in Regasm method: Regasm method Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in Regasm method: Regasm method Exception" + ex.ToString());
                //LogtoEvent("Po: HL Step 46 in Regasm method: Regasm method Exception" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("Po: LL in Regasm method: Regasm method Exception" + ex.ToString(), LowTraceInfo);
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        internal static void RegSvr32(string dllPath, string parameters)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("Po: HL in RegSvr32 method: Entered into RegSvr32 method defined in  ComponentRegistrar class");
                LowTraceText.AppendLine("PO: LL Step 34z-49.3 in RegSvr32 Method: Entered into RegSvr32 method defined in  ComponentRegistrar class");
                //LogtoEvent("Po: HL in RegSvr32 method: Entered into RegSvr32 method defined in  ComponentRegistrar class", HighTraceInfo);
                //LogtoEvent("PO: LL Step 34z-49.3 in RegSvr32 Method: Entered into RegSvr32 method defined in  ComponentRegistrar class", LowTraceInfo);
                string regsvr32Path = @"Regsvr32.exe";

                if (!File.Exists(dllPath))
                    return;

                Process process = new Process();
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.UseShellExecute = false; // Hides console window      
                process.StartInfo.FileName = regsvr32Path;
                process.StartInfo.Arguments = string.Format("\"{0}\" {1} {2}", dllPath, parameters, "/s");
                process.Start();
                process.WaitForExit();
            }
            catch (Exception ex)
            {
                HighTraceText.AppendLine("Po: HL Step 27 in RegSvr32 method: RegSvr32 Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in RegSvr32 method: RegSvr32 Exception" + ex.ToString());
                //LogtoEvent("Po: HL Step 27 in RegSvr32 method: RegSvr32 Exception" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("Po: LL in RegSvr32 method: RegSvr32 Exception" + ex.ToString(), LowTraceInfo);
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {

                //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                mainDirectory = ConfigurationManager.AppSettings["MDPath"].ToString();
                string LowTraceInfo = ConfigurationManager.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationManager.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationManager.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationManager.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
            }

            catch (Exception ex1)
            {
                 
            }
        }

    }
}
