﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;

namespace AmericanExpress.PushOnce
{
    public class CustomAction
    {


        public CustomAction(string type, ActionEvent actionEvent, ActionType actionType)
        {
            this.type = type;
            this.actionEvent = actionEvent;
            this.actionType = actionType;
        }


        private ActionType actionType;

        public ActionType ActionType{
            get {
                return actionType;
            }
        }
        private string type = string.Empty;

        public string Type
        {
            get
            {
                return type;
            }
        }

        private ActionEvent actionEvent;

        public ActionEvent ActionEvent
        {
            get
            {
                return actionEvent;
            }
        }


    }


    /// <summary>
    /// Type of action to take on a file.
    /// </summary>
    public enum ActionType
    {

        /// <summary>
        /// Register COM
        /// </summary>
        COMReg,
        /// <summary>
        /// Unregister COM
        /// </summary>
        COMUnReg,
        /// <summary>
        /// RegAsm tool with -i argument
        /// </summary>
        RegAsm,
        /// <summary>
        /// RegAsm tool with -u argument
        /// </summary>
        UnRegAsm,

        /// <summary>
        /// Action run by class/method in the given assembly.
        /// </summary>
        CLR
    }

    /// <summary>
    /// Event for which a custom action is to be performed
    /// </summary>
    public enum ActionEvent
    {
        Install,
        Commit,
        Rollback,
        Uninstall,
    }


    public static class CustomActionImpl
    {

        public static void RegisterCom(string dllPath)
        {
            if (string.Empty != dllPath)
                RegSvr32(dllPath, "/i");
        }

        public static void UnRegisterCom(string dllPath)
        {
            if (string.Empty != dllPath)
                RegSvr32(dllPath, "/u");
        }

        public static void RegisterAsm(string dllPath)
        {
            Regasm(dllPath, "/u");
            Regasm(dllPath, "/codebase");
        }

        public static void UnRegisterAsm(string dllPath)
        {
            Regasm(dllPath, "/u");
        }

        private static void Regasm(string dllPath, string parameters)
        {
            ComponentRegistrar.Regasm(dllPath, parameters);
        }

        public static void RunCustomAction(FileInfo fileInfo, Assembly assembly, CustomAction action, ActionEvent evt)
        {
            switch (action.ActionType)
            {
                case ActionType.CLR:
                    try
                    {
                        Type t = assembly.GetType("System.Configuration.Install.Installer");
                        if (null != t)
                        {
                            t.InvokeMember(evt.ToString(), BindingFlags.Default, null, t,
                                new object[] { null });
                        }
                    }
                    catch (Exception ex)
                    {
                        AmericanExpress.PushOnce.Common.Logger.Log(ex);
                    }
                    break;


            }
        }

        public static void RunCustomAction(FileInfo fileInfo, CustomAction action)
        {
            switch (action.ActionType)
            {

                case ActionType.COMReg:
                    CustomActionImpl.RegisterCom(fileInfo.FullName);
                    break;
                case ActionType.COMUnReg:
                    CustomActionImpl.UnRegisterCom(fileInfo.FullName);
                    break;
                case ActionType.RegAsm:
                    CustomActionImpl.RegisterAsm(fileInfo.FullName);
                    break;
                case ActionType.UnRegAsm:
                    CustomActionImpl.UnRegisterAsm(fileInfo.FullName);
                    break;

            }
        }

        private static void RegSvr32(string dllPath, string parameters)
        {
            ComponentRegistrar.RegSvr32(dllPath, parameters);
        }
    }


}
