﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Diagnostics;

namespace AmericanExpress.PushOnce.Common
{

   

    static class UriExtension
    {
        public static string GetFileName(this Uri uri) {
                return uri.Segments.Last();
        }

        public static string GetVirtualRoot(this Uri uri)
        {
            string uriPath = uri.AbsoluteUri;
            int index = uriPath.LastIndexOf("/") + 1;
            int index2 = uriPath.LastIndexOf("\\")+1;
            string path = uriPath.Substring(0, index > index2 ? index : index2);
            if (!path.EndsWith("/") && !path.EndsWith("\\"))
                path += "/";
            return path;

        }
    }

   

    static class ArrayExtensions
    {
        /// <summary>
        /// Get the last element of an Array.
        /// </summary>
        public static TSource Last<TSource>(this TSource[] source)
        {
            return source[source.Length - 1];
        }
    }

    public static class DirectoryExtensions
    {
        public static bool IsVirtualDirectory(string path)
        {
            return  path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonApplicationData))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonProgramFiles))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.StartMenu))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Startup))
                 || path.Contains(System.Environment.GetFolderPath(System.Environment.SpecialFolder.System));
        }

        public static string ReplaceVirtualDirectory(string path)
        {
            path = path.Replace("{"+System.Environment.SpecialFolder.ApplicationData.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData));

            path = path.Replace("{"+System.Environment.SpecialFolder.CommonApplicationData.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonApplicationData));

            path = path.Replace("{" + System.Environment.SpecialFolder.CommonProgramFiles.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonProgramFiles));

            path = path.Replace("{" + System.Environment.SpecialFolder.Desktop.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop));

            path = path.Replace("{" + System.Environment.SpecialFolder.LocalApplicationData.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData));

            path = path.Replace("{" + System.Environment.SpecialFolder.MyDocuments.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments));

            path = path.Replace("{" + System.Environment.SpecialFolder.ProgramFiles.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles));

            path = path.Replace("{" + System.Environment.SpecialFolder.StartMenu.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.StartMenu));

            path = path.Replace("{" + System.Environment.SpecialFolder.Startup.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.Startup));

            path = path.Replace("{" + System.Environment.SpecialFolder.System.ToString()+"}",
                         System.Environment.GetFolderPath(System.Environment.SpecialFolder.System));


            return path;
        }
    }


    public static class Logger
    {
        public static void Log(string method, string message)
        {
            if(null!=message && null!=message)
                Debug.WriteLine(DateTime.Now.ToString("yyyyMMdd:hhmmssmm") + " METHOD: " + method + "   MESSAGE: " + message);
        }

        public static void Enter(string method, string[] parameters)
        {

            try
            {
                Debug.WriteLine(DateTime.Now.ToString("yyyyMMdd:hhmmssmm") + " ENTER>>> " + method);

                Debug.WriteLine("PARAMETERS: ");
                Debug.Indent();

                string p = "";
                StringBuilder sb = new StringBuilder("(");
                foreach (string s in parameters)
                {
                    p = s == null ? "null" : s;
                    sb.Append(p + ",");
                }
                sb.Append(")");
                if (parameters.Length > 0)
                    sb[sb.Length - 2] = ' ';

                Debug.WriteLine(sb.ToString());
                Debug.Unindent();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }

       }

        public static void Exit(string method)
        {
            Debug.WriteLine(DateTime.Now.ToString("yyyyMMdd:hhmmssmm")+ " EXIT>>> "+method);
            Debug.Unindent();

        }

        public static void Log(Exception e)
        {

            int indents = 0;
            try
            {
                Debug.WriteLine(DateTime.Now.ToString("yyyyMMdd:hhmmssmm") + " EXCEPTION:" + e.Message);
                Debug.Indent();
                indents++;
                Debug.WriteLine("STACK TRACE: " + e.StackTrace);

                e = e.InnerException;
                while (null != e)
                {
                    Debug.Indent();
                    indents++;
                    Debug.WriteLine(DateTime.Now.ToString("yyyyMMdd:hhmmssmm") + " EXCEPTION:" + e.Message);
                    Debug.WriteLine("STACK TRACE: " + e.StackTrace);
                    e = e.InnerException;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            finally
            {

                while (indents-- > 0)
                    Debug.Unindent();
            }
        }
    }

    

    public class Environment
    {

        public static string GetMachineName()
        {

            return Dns.GetHostName();
        }
        public static string GetIPAddress()
        {
            try
            {
                string strHostName = Dns.GetHostName();

                IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
                IPAddress[] addr = ipEntry.AddressList;

                if (null != addr && addr.Length > 0)
                    return addr[0].ToString();
                else
                    return "127.0.0.11";
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(" GetIpAddress(): " + e.Message);
                return "127.0.0.12";
            }
        }
    }

}
