﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;

namespace AmericanExpress.AutomaticUpdater
{
    public partial class Progress : Form
    {
        private static Progress form = null;
        private static Thread progressThread = null;
        private static ManualResetEvent wait = null;
        private static bool cancelClicked = false;
        private static string applicationName;

        public static Progress CreateProgressBar(string appName, string version)
        {
            if (form == null)
            {
                progressThread = new Thread(new ThreadStart(ShowForm));
                progressThread.IsBackground = true;
                progressThread.SetApartmentState(ApartmentState.STA);
                progressThread.Start();
            }
            applicationName = appName + " v" + version;
            wait = new ManualResetEvent(false);
            wait.WaitOne();
            return form;
        }

        public static bool UserCancelled
        {
            get
            {
                return cancelClicked;
            }
        }

        private static void ShowForm()
        {
            form = new Progress();
            wait.Set();
            Application.Run(form);
        }

        public Progress()
        {
            InitializeComponent();
        }

        private void Progress_Load(object sender, EventArgs e)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            lblVersion.Text = "Version: " + assembly.GetName().Version.ToString();
            lblAppName.Text = applicationName;
        }


        private delegate void SetMaxDelegate(int max);
        public void SetMax(int max)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new SetMaxDelegate(SetMax), new object[] { max });
                return;
            }
            progressBar.Maximum = max;
        }

        private delegate bool UpdateDelegateWithFileName(string currentFile);
        public bool UpdateProgress(string currentFile)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UpdateDelegateWithFileName(UpdateProgress), new object[] { currentFile });
                return cancelClicked;
            }
            lblFilename.Text = cancelClicked ? "User cancelled update." : currentFile;
            progressBar.Increment(1);
            return cancelClicked;
            //Application.DoEvents();
        }

        private delegate bool UpdateDelegate();
        public bool UpdateProgress()
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new UpdateDelegate(UpdateProgress));
                return cancelClicked;
            }
            if (cancelClicked) lblFilename.Text = "User cancelled update.";
            progressBar.Increment(1);
            return cancelClicked;
            //Application.DoEvents();
        }
        private delegate void SetCurrentOperationDelegate(string currentFile);
        public void SetCurrentOperation(string operation)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new SetCurrentOperationDelegate(SetCurrentOperation), new object[] { operation });
                return;
            }
            lblOperation.Text = operation;
        }


        private delegate void StopProgressDelegate();
        public void StopProgress()
        {
            this.BeginInvoke(new StopProgressDelegate(Close), null);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            cancelClicked = true;
        }


        private delegate void ReSetProgressBarDelegate(int currentPos);
        public void ReSetProgressBar(int currentPos)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new ReSetProgressBarDelegate(ReSetProgressBar), new object[] { currentPos });
                return;
            }
            progressBar.Value = currentPos;
        }

    }
}
