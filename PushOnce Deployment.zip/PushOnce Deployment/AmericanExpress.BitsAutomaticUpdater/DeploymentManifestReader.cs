﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Text.RegularExpressions;
using AmericanExpress.PushOnce.Common;
using AmericanExpress.AutomaticUpdater;

namespace AmericanExpress.PushOnce
{

    public enum UpdateUnits
    {
        hours,
        days,
        weeks
    }
    /// <summary>
    /// This class is responsible for reading the contents of the Deployment Manifest configuration file.
    /// </summary>
    public class DeploymentManifestReader :  IDeploymentManifestReader
    {
        private XElement xManifest = null;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="xManifest">Depoyment manifest.</param>
        public DeploymentManifestReader(XElement xManifest)
        {
            this.xManifest = xManifest;
        }

        public string[] IncludeAddressList
        {
            get
            {
                if (null == xManifest)
                    return new string[0];

                string xPath = "asmv2:deployment/asmv2:subscription/asmv2:update/asmv2:filter/asmv2:include";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? new string[0] : e.Value.Split(';');
            }
        }

        public string[] ExcludeAddressList
        {
            get
            {
                if (null == xManifest)
                    return new string[0];

                string xPath = "asmv2:deployment/asmv2:subscription/asmv2:update/asmv2:filter/asmv2:exclude";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? new string[0] : e.Value.Split(new char[] {';'}, StringSplitOptions.RemoveEmptyEntries);
            }
        }        

        public string ProductName
        {
            get
            {
                try
                {
                    XmlReader reader = xManifest.CreateReader();
                    XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    string xPath = "asmv1:description";

                    XElement e = xManifest.XPathSelectElement(xPath, namespaceManager);
                    if (null != e)
                    {
                        XAttribute attr = e.Attribute("{urn:schemas-microsoft-com:asm.v2}product");
                        if (null != attr)
                            return attr.Value;
                    }

                    return "";
                }
                catch
                {
                    return "";
                }

            }
        }

        public string Publisher
        {
            get
            {
                try
                {
                    XmlReader reader = xManifest.CreateReader();
                    XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    string xPath = "asmv2:description";

                    XElement e = xManifest.XPathSelectElement(xPath, namespaceManager);
                    if (null != e)
                    {
                        XAttribute attr = e.Attribute("{urn:schemas-microsoft-com:asm.v2}publisher");
                        if (null != attr)
                            return attr.Value;
                    }

                    return "";
                }
                catch
                {
                    return "";
                }

            }
        }

        public string Version
        {

            get
            {
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv1:assemblyIdentity";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? "" : e.Attribute("version").Value;

            }
        }

        public string Name
        {
            get
            {
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv1:assemblyIdentity";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                string name =  null == e ? "" : e.Attribute("name").Value;
                if (name.EndsWith(".application"))
                    name = name.Replace(".application", ".amexapplication");
                return name;

            }
        }

        

        
        
        
        

        public int UpdateMaximumAge
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                try
                {
                    string xPath = "asmv2:deployment/asmv2:subscription/asmv2:update/asmv2:expiration";
                    XmlReader reader = xManifest.CreateReader();
                    XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                    if (null == e)
                        return -1;

                    string xValue = e.Attribute("maximumAge").Value;

                    int val = -1;

                    int.TryParse(xValue, out val);

                    return val;


                }
                catch
                {
                    return -1;
                }

            }
        }


        public UpdateUnits UpdateUnit
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                try
                {
                    string xPath = "asmv2:deployment/asmv2:subscription/asmv2:update/asmv2:expiration";
                    XmlReader reader = xManifest.CreateReader();
                    XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                    if (null == e)
                        return UpdateUnits.days;

                    string xValue = e.Attribute("unit").Value;

                    return (UpdateUnits)Enum.Parse(typeof(UpdateUnits), xValue);


                }
                catch
                {
                    return UpdateUnits.days;
                }

            }
        }


        
        

        public bool MapFileExtensions
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e || null == e.Attribute("mapFileExtensions") ? false : e.Attribute("mapFileExtensions").Value.ToLower()=="true";


            }

        }

        public bool Launch
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e || null == e.Attribute("nolaunch") ? true : e.Attribute("nolaunch").Value.ToLower() != "true";


            }

        }


        public string Codebase
        {
            get
            {
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv2:deployment/asmv2:deploymentProvider";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? "" : e.Attribute("codebase").Value;
            }
        }

        public string TargetCodebase
        {
            get
            {
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv2:deployment/asmv2:deploymentProvider";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                string codebase = null == e ? "" : e.Attribute("targetcodebase").Value;
                codebase = DirectoryExtensions.ReplaceVirtualDirectory(codebase);
                return codebase;
            }
        }


        public bool ClickOnceManifest {
            get {
                if (null == xManifest)
                    return true;

                bool isClickOnceManifest = true;

                string xPath = "asmv2:deployment/asmv2:deploymentProvider";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                string clickOnceManifest = string.Empty;
                if (e != null && e.Attribute("clickOnceManifest") != null)
                    clickOnceManifest = e.Attribute("clickOnceManifest").Value;
            

                if (clickOnceManifest != string.Empty) {
                    isClickOnceManifest = bool.Parse(clickOnceManifest);
                }
                return isClickOnceManifest;
            }
        }

       
        public string ApplicationCodebase
        {
            get
            {   
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv2:dependency/asmv2:dependentAssembly";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? "" : e.Attribute("codebase").Value;
            }
        }


        public bool IsAddressFilteredOut()
        {
            // exclude automatically 
            string myip = AmericanExpress.PushOnce.Common.Environment.GetIPAddress();
            string mymachine = AmericanExpress.PushOnce.Common.Environment.GetMachineName();

            string[] excludes = this.ExcludeAddressList;
            if (excludes.Length > 0)
            {
                
                foreach (string exclude in excludes)
                {
                    if (Regex.IsMatch(myip, exclude))
                        return true;

                    if (Regex.IsMatch(mymachine, exclude))
                        return true;
                }
            }

            string[] includes = this.IncludeAddressList;

            if (includes.Length == 0)
                return false;

            foreach (string include in includes)
            {
                if (Regex.IsMatch(myip, include))
                    return false;

                if (Regex.IsMatch(mymachine, include))
                    return false;
            }

            return true;
        }

          #region IDeploymentManifestReader Members

        private const string desktopShortcutAttrName = "createDesktopShortcut";
        private const string desktopAllUsersShortcutAttrName = "createAllUsersDesktopShortcut";

        public bool? InstallDesktopShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(desktopShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;

            }
        }
       
        public string ShortcutIconFileName
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get("iconPath", "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return "";

                return (string)e.Attribute(xAttr) ?? "";

            }
        }

        public bool? InstallAllUsersDesktopShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(desktopAllUsersShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;

            }
        }


        private const string startupShortcutAttrName = "createStartupShortcut";
        private const string startupAllUsersShortcutAttrName = "createAllUsersStartupShortcut";
        public bool? InstallStartupShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(startupShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;
            }
        }

        public bool? InstallAllUsersStartupShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(startupAllUsersShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;
            }
        }

        public bool? InstallAllUsersProgramShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(programAllUsersShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;

            }
        }

        public bool? InstallProgramShortcut
        {
            get
            {
                if (null == xManifest)
                    throw new ApplicationException("Manifest is null");

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get(programShortcutAttrName, "urn:schemas-microsoft-com:clickonce.v1");
                if( null == e || null == e.Attribute(xAttr))
                    return null;

                return (bool?)e.Attribute(xAttr) ?? false;

            }
        }



        private const string programShortcutAttrName = "createProgramsShortcut";
        private const string programAllUsersShortcutAttrName = "createAllUsersProgramsShortcut";

        public bool? IsCriticalUpdate
        {
            get
            {
                if (null == xManifest)
                    return false;

                string xPath = "asmv2:deployment";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                namespaceManager.AddNamespace("co.v1", "urn:schemas-microsoft-com:clickonce.v1");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                XName xAttr = XName.Get("IsCriticalUpdate", "urn:schemas-microsoft-com:clickonce.v1");
                if (null == e || null == e.Attribute(xAttr))
                    return false;

                return (bool?)e.Attribute(xAttr) ?? false;

            }
        }
    

        #endregion

    }
}
