﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Diagnostics;
using System.Text;

namespace AmericanExpress.PushOnce.Loader
{
    static class Program
    {
        
            static string codebasePattern = "/codebase=\"{0,1}(?<codebase>.*)\"{0,1}";
            static string namePattern = "/name=\"{0,1}(?<name>.*)\"{0,1}";
            //static double minInterval = 3600000;
            //static System.Threading.Timer updateTimer;
            static AppDomain domain = null;
            //static string cachePath = string.Empty;
            /// <summary>
            /// The main entry point for the application.
            /// </summary>
            [STAThread]
            static void Main(string[] args)
            {
                Debug.WriteLine("PushOnce.Main()");
                System.AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
                if (null != args && args.Length > 0)
                {
                    IEnumerable<string> dbg = args.Where(s => s.ToLower() == "/debug");
                    if(dbg.Count()>0)
                        MessageBox.Show("PushOnce Main()");
                }

                string codebasePath = string.Empty;
                string name = "PushOnce Application";
                
                
              
                try
                {
                    
                    string[] pathArg = args.Where(s => s.StartsWith("/codebase")).ToArray();

                    if (pathArg.Count() > 0)
                    {


                        Match m = Regex.Match(pathArg[0], codebasePattern);

                        if (m.Success)
                        {

                            codebasePath = m.Groups["codebase"].Value;
                            if (!File.Exists(codebasePath))
                            {
                                codebasePath = string.Empty;
                            }
                        }
                    }


                    string[] names = args.Where(s => s.StartsWith("/name")).ToArray();
                    
                    if (names.Count() > 0)
                    {
                        Match m = Regex.Match(names[0], namePattern);
                        if (m.Success)
                            name = m.Groups["name"].Value;
                        if (name.Length > 10)
                            name = name.Substring(0, 10);
                    }

                    if (codebasePath == string.Empty)
                    {
                        string[] app = args.Where(s => s.EndsWith(".amexapplication")).ToArray();
                        if (app.Length > 0)
                        {
                            Uri uri = new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                            FileInfo fiUpdater = new FileInfo(uri.LocalPath);
                            codebasePath = Path.Combine(fiUpdater.DirectoryName, "AmericanExpress.PushOnce.AutomaticUpdateManager.exe");
                        }
                    }

                    FileInfo codebaseFile = new FileInfo(codebasePath);
                    //string cacheRoot = Path.GetRandomFileName();//Guid.NewGuid().ToString("N");
                    // cachePath = Path.Combine(
                    //    codebaseFile.Directory.FullName,
                    //    cacheRoot);

                    string configFile = codebaseFile + ".config";

                    domain = CreateAppDomain(name, string.Empty, configFile, codebaseFile.Directory.FullName);

                    /*
                     Below method/parameter is obsolete
                     domain.ExecuteAssembly(codebasePath, System.Reflection.Assembly.GetExecutingAssembly().Evidence, args);
                    Warning	1	'System.AppDomain.ExecuteAssembly(string, System.Security.Policy.Evidence, string[])' is obsolete: 'Methods which use evidence to sandbox are obsolete and will be removed in a future release of the .NET Framework. Please use an overload of ExecuteAssembly which does not take an Evidence parameter. See http://go.microsoft.com/fwlink/?LinkID=155570 for more information.
                     */

                    //commented for .NET 4.1
                    //domain.ExecuteAssembly(codebasePath, System.Reflection.Assembly.GetExecutingAssembly().Evidence, args);
                    domain.ExecuteAssembly(codebasePath, args);
                   
                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
        }

            private static void StartProcessInTempCache(string[] args)
            {
                Uri uri = new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                string path = uri.LocalPath;
                string tempPath = Path.Combine(path, "_cache");
                if (!Directory.Exists(tempPath))
                {
                    Directory.CreateDirectory(tempPath);
                }
                FileInfo fi = new FileInfo(path);
                string tempAssembly = Path.Combine(tempPath, fi.Name);
                if (File.Exists(tempAssembly))
                    File.Delete(tempAssembly);
                fi.CopyTo(tempAssembly);
                FileInfo fiTemp = new FileInfo(tempAssembly);

                StringBuilder sb = new StringBuilder();
                foreach (string s in args)
                {
                    bool spaces = s.Contains(" ");
                    if (spaces)
                        sb.Append("\"");
                    sb.Append(s);
                    if (spaces)
                        sb.Append("\"");
                    sb.Append(" ");
                }
                ProcessStartInfo psi = new ProcessStartInfo(tempAssembly, sb.ToString());
                psi.WorkingDirectory = fiTemp.DirectoryName;
                Process p = new Process();
                p.StartInfo = psi;
                p.Start();
            }

          
            static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
            {
                Debug.WriteLine(e.ExceptionObject.ToString());
            }

            


            
            private static AppDomain CreateAppDomain(string name, string cachePath, string configFile, string applicationBase)
            {
                AppDomainSetup setup = new AppDomainSetup();
                setup.ApplicationName = name;
                setup.ShadowCopyFiles = "true"; // note: it isn't a bool
                if(!string.IsNullOrEmpty(cachePath))
                    setup.CachePath = cachePath;

                setup.ConfigurationFile = configFile;
                //setup.PrivateBinPathProbe = codebaseFile.Directory.FullName;
                setup.ApplicationBase = applicationBase;


                // Create the application domain. The evidence of this
                // running assembly is used for the new domain:
                AppDomain domain = AppDomain.CreateDomain(
                   name,
                   AppDomain.CurrentDomain.Evidence,
                   setup);

                return domain;

            }
           
    }

   
}
