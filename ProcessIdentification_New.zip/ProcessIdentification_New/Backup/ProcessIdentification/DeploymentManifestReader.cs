﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Text.RegularExpressions;
//using AmericanExpress.AutomaticUpdater;

namespace Axp.GDU.Process
{

    public enum UpdateUnits
    {
        hours,
        days,
        weeks
    }
    /// <summary>
    /// This class is responsible for reading the contents of the Deployment Manifest configuration file.
    /// </summary>
    public class DeploymentManifestReader :  IDeploymentManifestReader
    {
        private XElement xManifest = null;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="xManifest">Depoyment manifest.</param>
        public DeploymentManifestReader(XElement xManifest)
        {
            this.xManifest = xManifest;
        }

        public string Codebase
        {
            get
            {
                if (null == xManifest)
                    return string.Empty;

                string xPath = "asmv2:deployment/asmv2:deploymentProvider";
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                XElement e = xManifest.XPathSelectElement(xPath, namespaceManager) as XElement;
                return null == e ? "" : e.Attribute("codebase").Value;
            }
        }

    }
}
