﻿using System;
namespace Axp.GDU.Process
{

    /// <summary>
    /// Defines the interface for reading a deployment manifest.
    /// </summary>
    interface IDeploymentManifestReader
    {

        /// <summary>
        /// Codebase is the path to the installation files on the server.
        /// </summary>
        string Codebase { get; }
        ///// <summary>
        ///// Codebase path to the installation files on the client machine.
        ///// </summary>
        //string ApplicationCodebase { get; }

        ///// <summary>
        ///// Is this a ClickOnce type manifest
        ///// </summary>
        //bool ClickOnceManifest { get; }

        

      //  /// <summary>
      //  /// List of excluded addresses.
      //  /// </summary>
      //  string[] ExcludeAddressList { get; }

      //  /// <summary>
      //  /// Returns true if a shortcut should be created in the All Users Desktop location.
      //  /// </summary>
      //  bool? InstallAllUsersDesktopShortcut { get; }
      //  /// <summary>
      //  /// Returns true if a shortcut should be created in the All Users Programs location
      //  /// </summary>
      //  bool? InstallAllUsersProgramShortcut { get; }

      //  /// <summary>
      //  /// Returns true if a shortcut should be created in the All Users Startup menu.
      //  /// </summary>
      //  bool? InstallAllUsersStartupShortcut { get; }

      //  /// <summary>
      //  /// Returns true if a shortcut should be created on the user's desktop.
      //  /// </summary>
      //  bool? InstallDesktopShortcut { get; }

      //  /// <summary>
      //  /// Returns true if a shortcut should be created in the user's startup menu.
      //  /// </summary>
      //  bool? InstallStartupShortcut { get; }

      //  /// <summary>
      //  /// Returns true if a shortcut should be created in the user's Programs menu.
      //  /// </summary>
      //  bool? InstallProgramShortcut { get; }

      //  /// <summary>
      //  /// List of included addreses for this update.
      //  /// </summary>
      //  string[] IncludeAddressList { get; }
        
        
      //  /// <summary>
      //  /// Launch the application after the update.
      //  /// </summary>
      //  bool Launch { get; }


      //  bool MapFileExtensions { get; }
      //  string Name { get; }
      //  string ProductName { get; }
      //  string Publisher { get; }
       
      //  int UpdateMaximumAge { get; }
      ////  AmericanExpress.PushOnce.UpdateUnits UpdateUnit { get; }
      //  string Version { get; }

      //  /// <summary>
      //  /// Is the manifest identifying a critical update
      //  /// </summary>
      //  bool? IsCriticalUpdate { get; }
    }
}
