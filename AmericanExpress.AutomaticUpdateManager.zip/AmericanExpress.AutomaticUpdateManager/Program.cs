﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using AmericanExpress.PushOnce;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using AmericanExpress.PushOnce.Common;
using System.Reflection;
using System.Configuration;
using System.Text;

namespace AmericanExpress.PushOnce
{

    /// <summary>
    /// Main entry point to the Auto Updater application.  This program queries the
    /// deployment server for updates to an application and downloads updates 
    /// automatically.
    /// </summary>
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 

        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO:: HL in Main Method: Enter PushOnceMain");
                LowTraceText.AppendLine("PO:: LL Step 1 in Main Method: Enter PushOnceMain");
                //LogtoEvent("PO:: HL in Main Method: Enter PushOnceMain" + System.Environment.NewLine, HighTraceInfo);
                //LogtoEvent("PO:: LL Step 1 in Main Method: Enter PushOnceMain" + System.Environment.NewLine, LowTraceInfo);

                try
                {
                    

                    LowTraceText.AppendLine("PO:: LL Step 2 in Main Method:");

                    HighTraceText.AppendLine("PO:: HL in Main Method: Calling DeleteFile method");
                    //LogtoEvent("PO:: LL Step 2 in Main Method:" + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("PO:: HL in Main Method: Calling DeleteFile method" , HighTraceInfo);
                    DeleteFile();

                    /// <summary>
                    ///Changes made for new enhancement
                    /// </summary>               
                    string appPath = Application.StartupPath.ToString();
                    bool IsProcessActive = Process.GetProcesses().Any(p => p.ProcessName.Contains("Axp.GDU.Process"));

     
 
                    ///<summary>
                    ///Added DateTime and arguments filed to the log file.
                    ///</summary>

                    LowTraceText.AppendLine("PO:: LL Step 3 in Main Method:" + " " + DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));
                    string arguments = "";
                    for (int i = 0; i < args.Length; i++)
                    {
                        arguments = arguments + " " + args[i];
                    }
                    LowTraceText.AppendLine("PO:: LL in Main Method: Arguments passed:" + arguments);
                    LowTraceText.AppendLine("PO:: LL Step 4 in Main Method: Process EXE Check App path");
                    //LogtoEvent("PO:: LL Step 3 in Main Method:" + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("PO:: LL Step 4 in Main Method: Process EXE Check App path" + appPath, LowTraceInfo);


                    if (IsProcessActive)
                    {
                        LowTraceText.AppendLine("PO:: LL Step 5 in Main Method: Process Active");
                        //LogtoEvent("PO:: LL Step 5 in Main Method: Process Active" , LowTraceInfo);
                        string ProcessTraceInfo = ConfigurationSettings.AppSettings["ReplaceProcess"].ToString();
                        if (ProcessTraceInfo == "True")
                        {
                            LowTraceText.AppendLine("PO:: LL Step 6 in Main Method: ProcessTraceInfo Indicator True");
                            //LogtoEvent("PO:: LL Step 6 in Main Method: ProcessTraceInfo Indicator True", LowTraceInfo);
                            string TMProcessVersion = String.Empty;
                            var pr1 = Process.GetProcesses().First(p => p.ProcessName.Contains("Axp.GDU.Process"));
                            TMProcessVersion = pr1.MainModule.FileVersionInfo.ProductVersion.ToString();
                            LowTraceText.AppendLine("PO:: LL Step 7 in Main Method: Process TM version" + TMProcessVersion);
                            //LogtoEvent("PO:: LL Step 7 in Main Method: Process TM version" + TMProcessVersion, LowTraceInfo);
                            FileVersionInfo fvi1 = FileVersionInfo.GetVersionInfo(appPath + @"\Axp.GDU.Process.exe");
                            string Version1 = fvi1.ProductVersion;
                            LowTraceText.AppendLine("PO:: LL Step 8 in Main Method: Process Physical version" + Version1);
                            //LogtoEvent("PO:: LL Step 8 in Main Method: Process Physical version" + Version1, LowTraceInfo);
                            if (TMProcessVersion != Version1)
                            {
                                LowTraceText.AppendLine("PO:: LL Step 9 in Main Method: Process Version not Match Going To kill");
                                //LogtoEvent("PO:: LL Step 9 in Main Method: Process Version not Match Going To kill", LowTraceInfo);
                                Process.GetProcesses().First(p => p.ProcessName.Contains("Axp.GDU.Process")).Kill();
                                LowTraceText.AppendLine("PO:: LL Step 10 in Main Method: Going To Start Process");
                                //LogtoEvent("PO:: LL Step 10 in Main Method: Going To Start Process", LowTraceInfo);
                                Process processB = new Process();
                                processB.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                                processB.StartInfo.FileName = appPath + @"\Axp.GDU.Process.exe";
                                processB.Start();
                                LowTraceText.AppendLine("PO:: LL Step 10 in Main Method: Process Started");
                                //LogtoEvent("PO:: LL Step 10 in Main Method: Process Started", LowTraceInfo);

                            }
                        }
                    }

                    if (!IsProcessActive)
                    {
                        LowTraceText.AppendLine("PO:: LL in Main Method: Step 4a Process Not Exist! Launching New");
                        //LogtoEvent("PO:: LL in Main Method: Step 4a Process Not Exist! Launching New", LowTraceInfo);
                        //LogtoEvent("Step 3a Process Not Exist! Launching New");
                        Process process = new Process();
                        process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        process.StartInfo.FileName = appPath + @"\Axp.GDU.Process.exe";
                        process.Start();
                        LowTraceText.AppendLine("PO:: LL in Main Method: Step 4b Process Started");
                        //LogtoEvent("PO:: LL in Main Method: Step 4b Process Started", LowTraceInfo);
                        //LogtoEvent("Step 3b Process Started");
                    }
                    //------ Application Watcher---------------
                    try
                    {
                        LowTraceText.AppendLine("PO:: LL Step 11 in Main Method: AppWatcher ");
                        //LogtoEvent("PO:: LL Step 11 in Main Method: AppWatcher " + System.Environment.NewLine, LowTraceInfo);
                        //LogtoEvent("AppWatcher Step1 " + System.Environment.NewLine);
                        LowTraceText.AppendLine("PO:: LL Step 11a in Main Method: AppWatcher calling StartUpAppWatcher method from Main Method");
                        //LogtoEvent("PO:: LL Step 11a in Main Method: AppWatcher calling StartUpAppWatcher method from Main Method" + System.Environment.NewLine, LowTraceInfo);
                        Updater.StartUpAppWatcher(appPath);
                        LowTraceText.AppendLine("PO:: LL Step 12 in Main Method: AppWatcher apppath:" + appPath);
                        //LogtoEvent("PO:: LL Step 12 in Main Method: AppWatcher apppath:" + appPath, LowTraceInfo);
                        //LogtoEvent(" AppWatcher Step2 appPath " + appPath);
                        //-----------To start----------------------
                        bool IsAppWatcherActive = Process.GetProcesses().Any(p => p.ProcessName.Contains("Axp.ApplicationWatcher"));
                        LowTraceText.AppendLine("PO:: LL Step 13 in Main Method: AppWatcher Check Active");
                        //LogtoEvent("PO:: LL Step 13 in Main Method: AppWatcher Check Active" , LowTraceInfo);
                        //LogtoEvent(" AppWatcher Step3 Check Active");

                        if (IsAppWatcherActive)
                        {
                            LowTraceText.AppendLine("PO:: LL Step 14 in Main Method: AppWatcher Active");
                            //LogtoEvent("PO:: LL Step 14 in Main Method: AppWatcher Active", LowTraceInfo);
                            //LogtoEvent(" AppWatcher Active");
                            string TraceInfo = ConfigurationSettings.AppSettings["ReplaceAppWatcher"].ToString();
                            if (TraceInfo == "True")
                            {
                                LowTraceText.AppendLine("PO:: LL Step 15 in Main Method: AppWatcher Indicator True");
                                //LogtoEvent("PO:: LL Step 15 in Main Method: AppWatcher Indicator True", LowTraceInfo);
                                //LogtoEvent(" AppWatcher Indicator True");
                                string TMAppWatcherVersion = String.Empty;
                                var pr = Process.GetProcesses().First(p => p.ProcessName.Contains("Axp.ApplicationWatcher"));
                                TMAppWatcherVersion = pr.MainModule.FileVersionInfo.ProductVersion.ToString();
                                LowTraceText.AppendLine("PO:: LL Step 16 in Main Method: AppWatcher TM version" + TMAppWatcherVersion);
                                //LogtoEvent("PO:: LL Step 16 in Main Method: AppWatcher TM version" + TMAppWatcherVersion, LowTraceInfo);
                                //LogtoEvent(" AppWatcher TM version" + TMAppWatcherVersion);
                                FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(appPath + @"\Axp.ApplicationWatcher.exe");
                                string Version = fvi.ProductVersion;
                                LowTraceText.AppendLine("PO:: LL Step 17 in Main Method: AppWatcher Physical version" + Version);
                                //LogtoEvent("PO:: LL Step 17 in Main Method: AppWatcher Physical version" + Version, LowTraceInfo);
                                //LogtoEvent(" AppWatcher Physical version" + Version);
                                if (TMAppWatcherVersion != Version)
                                {
                                    LowTraceText.AppendLine("PO:: LL Step 18 in Main Method: Version not Match Going To kill");
                                    //LogtoEvent("PO:: LL Step 18 in Main Method: Version not Match Going To kill", LowTraceInfo);
                                    //LogtoEvent("Version not Match Going To kill ");
                                    Process.GetProcesses().First(p => p.ProcessName.Contains("Axp.ApplicationWatcher")).Kill();
                                    LowTraceText.AppendLine("PO:: LL Step 19 in Main Method: Going To Start AppWatcher");
                                    //LogtoEvent("PO:: LL Step 19 in Main Method: Going To Start AppWatcher", LowTraceInfo);
                                    //LogtoEvent("Going To Start AppWatcher");
                                    Process processA = new Process();
                                    processA.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                                    processA.StartInfo.FileName = appPath + @"\Axp.ApplicationWatcher.exe";
                                    processA.Start();
                                    LowTraceText.AppendLine("PO:: LL Step 20 in Main Method: AppWatcher Started");
                                    //LogtoEvent("PO:: LL Step 20 in Main Method: AppWatcher Started", LowTraceInfo);
                                    //LogtoEvent("AppWatcher Started");
                                }
                            }
                        }

                        if (!IsAppWatcherActive)
                        {
                            LowTraceText.AppendLine("PO:: LL Step 21 in Main Method: AppWatcher Not Active");
                            //LogtoEvent("PO:: LL Step 21 in Main Method: AppWatcher Not Active", LowTraceInfo);
                            //LogtoEvent(" AppWatcher Step4 Not Active");
                            Process process = new Process();
                            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            process.StartInfo.FileName = appPath + @"\Axp.ApplicationWatcher.exe";
                            process.Start();
                        }
                    }
                    catch (Exception ex)
                    {
                        HighTraceText.AppendLine("PO:: HL Step 2 in Main Method :AppWatcher Exception: " + ex.ToString());
                        LowTraceText.AppendLine("PO:: LL in Main Method :AppWatcher Exception: " + ex.ToString());
                        //LogtoEvent("PO:: HL Step 2 in Main Method :AppWatcher Exception: " + ex.ToString(), HighTraceInfo);
                        //LogtoEvent("PO:: LL in Main Method :AppWatcher Exception: " + ex.ToString(), LowTraceInfo);
                        //LogtoEvent(" AppWatcher Exception " + ex.ToString());
                    }
                    //-----------------------------------------
                    LowTraceText.AppendLine("PO:: LL Step 22 in Main Method: Calling StartUpdateNotifications defined in Updater.cs method from Main Method ");
                    //LogtoEvent("PO:: LL Step 22 in Main Method: Calling StartUpdateNotifications defined in Updater.cs method from Main Method " + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 4" + System.Environment.NewLine);
                    Updater.StartUpdateNotifications();
                    LowTraceText.AppendLine("PO:: LL Step 22c in Main Method: Came out of StartUpdateNotifications defined in Updater.cs method & called from Main Method ");
                    //LogtoEvent("PO:: LL Step 22c in Main Method: Came out of StartUpdateNotifications defined in Updater.cs method & called from Main Method " + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 5" + System.Environment.NewLine);
                    if (null != args && args.Length > 0)
                    {
                        IEnumerable<string> dbg = args.Where(s => s.ToLower() == "/debug");
                        if (dbg.Count() > 0)
                            MessageBox.Show("Automatic Update Manager Main()");
                    }
                    LowTraceText.AppendLine("PO:: LL Step 23 in Main Method: Calling InitializeTracing method from Main Method ");
                    //LogtoEvent("PO:: LL Step 23 in Main Method: Calling InitializeTracing method from Main Method " + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 6" + System.Environment.NewLine);
                    InitializeTracing(args);
                    LowTraceText.AppendLine("PO:: LL Step 23b in Main Method: Came out of InitializeTracing method from Main Method ");
                    //LogtoEvent("PO:: LL Step 23b in Main Method: Came out of InitializeTracing method from Main Method " + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 7" + System.Environment.NewLine);
                    Logger.Enter("Program.Main", new string[] { args.ToString() });
                    LowTraceText.AppendLine("PO:: LL Step 24 in Main Method: Calling Dispatch method defined in ArgumentDispatcher.cs from Main Method ");
                    //LogtoEvent("PO:: LL Step 24 in Main Method: Calling Dispatch method defined in ArgumentDispatcher.cs from Main Method " + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 8" + System.Environment.NewLine);
                    ArgumentDispatcher.Dispatch(args);
                }
                catch (Exception e)
                {
                    try
                    {
                        //LogtoEvent("In Catch" + e.ToString());
                        Logger.Log(e);
                    }
                    catch
                    {
                        //LogtoEvent("In Second Catch" + e.ToString());
                    }
                }
                finally
                {
                    try
                    {
                        Logger.Exit("Program.Main");

                        if (null != tracer)
                            tracer.Close();

                    }
                    catch
                    {
                    }
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        //private static void LogtoEvent(string ex)
        //{
        //    string TraceInfo = ConfigurationSettings.AppSettings["PushOnceTracFileInfo"].ToString();
        //    if (TraceInfo == "True")
        //    {
        //        string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceTracFile"].ToString());
        //        FileStream fs = null;
        //        if (!System.IO.File.Exists(TraceFile))
        //        {
        //            using (fs = System.IO.File.Create(TraceFile))
        //            {

        //            }
        //        }
        //        if (System.IO.File.Exists(TraceFile))
        //        {
        //            StringBuilder sb = new StringBuilder();
        //            StreamReader sr = new StreamReader(TraceFile);
        //            {
        //                sb.Append(sr.ReadToEnd());
        //                sb.AppendLine();
        //            }
        //            sr.Close();
        //            TextWriter tw = new StreamWriter(TraceFile);
        //            sb.AppendLine(ex.ToString());
        //            tw.WriteLine(sb.ToString());
        //            tw.Close();
        //        }
        //    }
        //}
        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                mainDirectory = ConfigurationSettings.AppSettings["MDPath"].ToString();
                //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceInfo = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceInfo"].ToString();
                
                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);


                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
                
            }

            catch (Exception ex1)
            {
                
            }
        }



        private static void DeleteFile()
        {
            try
            {
                HighTraceText = new StringBuilder();
                LowTraceText = new StringBuilder();
                HighTraceText.AppendLine("PO: HL in DeleteFile method: Entered into DeleteFile method");
                LowTraceText.AppendLine("PO: LL Step 0.01 in DeleteFile method: Entered into DeleteFile method");
                //LogtoEvent("PO: HL in DeleteFile method: Entered into DeleteFile method", HighTraceInfo);
                //LogtoEvent("CPU: LL Step 0.01 in DeleteFile method: Entered into DeleteFile method", LowTraceInfo);
                mainDirectory = ConfigurationSettings.AppSettings["MDPath"].ToString();
                //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                string LowTraceFileName = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
                string HighTraceFileName = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
                string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                string LLDuration = ConfigurationManager.AppSettings["LLDuration"];
                foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.txt"))
                {
                    string contents = file.ToString();
                    if (contents.Contains(LowTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File name is" + fi.Name.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString());
                        //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        if (ts.TotalDays > Convert.ToInt32(LLDuration))
                        {
                            double diff = ts.TotalDays - Convert.ToInt32(LLDuration);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: Time difference " + diff.ToString());
                            //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff.ToString(), HighTraceInfo);
                            fi.Delete();
                            HighTraceText.AppendLine("PO: Low level file deleted ");
                            //LogtoEvent("PO: Low level file deleted " , HighTraceInfo);
                        }
                    }

                    if (contents.Contains(HighTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File name is" + fi.Name.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: TimeSpan is" + ts.TotalDays.ToString());
                        //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.TotalDays.ToString(), HighTraceInfo);
                        if (ts.TotalDays > Convert.ToInt32(HLDuration))
                        {
                            double diff1 = ts.TotalDays - Convert.ToInt32(HLDuration);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: Time difference " + diff1.ToString());
                            fi.Delete();
                            HighTraceText.AppendLine("PO: High level file deleted ");
                            //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff1.ToString(), HighTraceInfo);
                            //LogtoEvent("PO: High level file deleted ", HighTraceInfo);
                        }
                    }
                }

            }
            catch (Exception ex)
            {                
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }


        private static TextWriterTraceListener tracer = null;
        private static void InitializeTracing(string[] args)
        {
            try
            {
                HighTraceText.AppendLine("PO: HL in InitializeTracing method: Entered into InitializeTracing method ");
                LowTraceText.AppendLine("PO:: LL Step 23a in InitializeTracing Method: Entered into InitializeTracing method ");
                //LogtoEvent("PO: HL in InitializeTracing method: Entered into InitializeTracing method ", HighTraceInfo);
                //LogtoEvent("PO:: LL Step 23a in InitializeTracing Method: Entered into InitializeTracing method " + System.Environment.NewLine, LowTraceInfo);
                string specifiedPath = string.Empty;
                if (null != args && args.Length > 0)
                    specifiedPath = args.Where(s => s.Contains("/logpath=")).FirstOrDefault() ?? string.Empty;

                string codebase = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
                string path = Constants.LogFileName;
                if (specifiedPath.Length > 0)
                {
                    string[] parts = specifiedPath.Split('=');
                    if (parts.Length == 2)
                    {
                        path = parts[1];
                        path = path.Replace("\"", "");
                        if (Directory.Exists(path))
                            path = Path.Combine(path, Constants.LogFileName);
                        else
                            path = Constants.LogFileName;

                    }
                }
                else
                {
                    path = Constants.LogFileName;
                }

                string progFilePath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles);
                //if (!System.Environment.CurrentDirectory.Contains(progFilePath.ToLower() ))
                //{
                //    path = Path.Combine("c:\\temp\\",  path);
                //    if (!Directory.Exists("C:\\TEMP"))
                //    {
                //        Directory.CreateDirectory("C:\\temp");
                //    }
                //}
                if (File.Exists(path))
                    File.Delete(path);

                tracer = new TextWriterTraceListener(path);
                Debug.Listeners.Add(tracer);
            }
            catch (Exception e)
            {
                HighTraceText.AppendLine("PO:: HL Step 4 in InitializeTracing method :InitializeTracing Exception" + e.ToString());
                LowTraceText.AppendLine("PO:: LL in InitializeTracing method :InitializeTracing Exception" + e.ToString());
                //LogtoEvent("PO:: HL Step 4 in InitializeTracing method :InitializeTracing Exception" + e.ToString(), HighTraceInfo);
                //LogtoEvent("PO:: LL in InitializeTracing method :InitializeTracing Exception" + e.ToString(), LowTraceInfo);
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

    }
}
