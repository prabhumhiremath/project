﻿////-----------------------------------------------------------------------
//// <copyright file="IGDUProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of IGDUProcess Interface</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System.Data;
namespace AmericanExpress.Services.GDU.BusinessInterface
{
    public interface IGDUProcess
    {
        /// <summary>
        /// This method is used for starting the process
        /// </summary>
        void StartProcess(DataSet dsAppParam);
    }
}
