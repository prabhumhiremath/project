﻿////-----------------------------------------------------------------------
//// <copyright file="GDUProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of GDUProcess class.
////    It is defined for processing the Jobs for Cleaning/deleting the files</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------

using System;
using AmericanExpress.Services.GDU.BusinessInterface;
using System.Data;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
using System.Text;

namespace AmericanExpress.Services.GDU.Business
{
    public class GDUProcess : IGDUProcess
    {
        #region Variables
        private int _threadId = 0;
        private GDUDAC _GDUDAC;
        private string _infoLog = "Y";

        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread and GDUDac object in constructor
        /// </summary>
        /// <param name="threadId">int</param>
        /// <param name="GDUDB">GDUDAC</param>
        /// <param name="infoLog">string</param>
        public GDUProcess(int threadId, GDUDAC GDUDB)
        {
            this._threadId = threadId;
            this._GDUDAC = GDUDB;
        }
        #endregion

        #region Method

        /// <summary>
        /// Method to Replace Special Character
        /// Read the XML, 
        /// Check the Special character and replace them
        /// </summary>
        private string ReplaceSPLCharacters(string input)
        {
            string output = input.Replace("", "").Replace("", "").Replace(" ", "").Replace("􀂄", "").Replace("<c0>", "").Replace("</c0>", "").Replace("<ddd/>", "...").Replace("<-", "").Replace("\t", "").Replace("\f", "");
            output = Regex.Replace(output, @"[^\u0000-\u007F]", "");
            output = Encoding.ASCII.GetString(
                                    Encoding.Convert(
                                    Encoding.UTF8,
                                    Encoding.GetEncoding(
                                    Encoding.ASCII.EncodingName,
                                    new EncoderReplacementFallback(string.Empty),
                                    new DecoderExceptionFallback()
                                    ),
                                    Encoding.UTF8.GetBytes(output)
                                    )
                                    );

            return output;
        }


        /// <summary>
        /// Method to start process for cleaning files
        /// Read the folder one by one, 
        /// Check the Creation time and then delete 
        /// </summary>

        public void StartProcess(DataSet dsAppParam)
        {
            string errDesc = string.Empty;
            int count = 0; //for counting the total no. of files deleted        
            string folderPath = System.Configuration.ConfigurationManager.AppSettings["XMLFolderPath"].ToString();
            string fileExtension = string.Empty;
            DirectoryInfo objDir = new DirectoryInfo(folderPath);

            string _infoLog = System.Configuration.ConfigurationManager.AppSettings["InformationLog"].ToString(); // -- 20/11/2012

            //DataSet dsAppParam = null;

            try
            {
                LogManager.LogtoEvent("Process Start " + _threadId);
                if (_infoLog.ToUpper() == "Y")// -- 20/11/2012
                {
                    LogManager.LogInfoMessage(LogManager.source + " Started, threadid : " + _threadId, 2004);
                }
                //commented on 17/July/2012***********************
                // get the app params
                //dsAppParam = _GDUDAC.GetAppParamValues();
                //************************************************

                if (dsAppParam != null && dsAppParam.Tables.Count > 0 && dsAppParam.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in dsAppParam.Tables[0].Rows)
                    {
                        string xmlPath = string.Concat(folderPath, "\\", dr["FILE_NM"].ToString());
                        if (File.Exists(xmlPath))
                        {
                            XmlDocument doc = new XmlDocument();
                            doc.Load(xmlPath);
                            LogManager.LogtoEvent("Before call to DB, threadid = " + _threadId + " " + dr["FILE_NM"].ToString());
                            LogManager.LogtoEvent("File XML=" + ReplaceSPLCharacters(doc.InnerXml.ToString()));
                            LogManager.LogtoEvent("---------------------------------");

                            if (_GDUDAC.xmlFileInsertIntoDB(Convert.ToInt32(dr["ID"].ToString()), ReplaceSPLCharacters(doc.InnerXml.ToString()), dr["COMPUTER_NM"].ToString(), dr["IP_ADDR_TXT"].ToString(), dr["ADS_ID"].ToString(), Convert.ToInt32(dr["FILE_TYPE"].ToString())) != 0)
                            {
                                LogManager.LogtoEvent("Before deleting the file, threadid = " + _threadId);
                                File.Delete(xmlPath);
                                LogManager.LogtoEvent("File Deleted, threadid = " + _threadId);
                            }
                            else
                            {
                                LogManager.LogtoEvent("Insert Failed");
                            }
                        }
                        else
                        {
                            LogManager.LogtoEvent("File does not exist, SP call, threadid = " + _threadId + " ");// + dr["FILE_NM"].ToString());
                            _GDUDAC.xmlFileInsertIntoDB(Convert.ToInt32(dr["ID"].ToString()), "", "", "", "", 0);
                            LogManager.LogtoEvent("File does not exist, SP call complete , threadid = " + _threadId + " ");// + dr["FILE_NM"].ToString());
                        }

                    }

                }


            }
            catch (Exception e)
            {
                //LogManager.LogtoEvent("In Catch Block1 " + e.Message.ToString());
                //LogManager.LogErrorMessage("Catch: Error occured while processing " + LogManager.source + ", threadid : " + _threadId + ". " + count + " File(s) deleted. ", 5018, e);
                //LogManager.LogtoEvent("In Catch Block2 " + e.Message.ToString());
            }
            finally
            {
                LogManager.LogtoEvent("Process end " + _threadId);
            }

        }

        #endregion
    }
}
