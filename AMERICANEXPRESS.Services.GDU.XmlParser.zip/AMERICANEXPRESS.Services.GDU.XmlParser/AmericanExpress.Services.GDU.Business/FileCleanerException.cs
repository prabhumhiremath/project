﻿////-----------------------------------------------------------------------
//// <copyright file="XmlParserException.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of XmlParserException class.
////    It is defined for creating Custom Exceptions class</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;

namespace AmericanExpress.Services.GDU.Business
{
    class XmlParserException : Exception
    {
        #region variables
        /// <summary>
        /// Variable to store Error Code
        /// </summary>
        private int _errorCode;
        #endregion

        #region Property
        /// <summary>
        /// ErrorCode Property
        /// </summary>
        public int ErrorCode
        {
            get { return _errorCode; }
        }
        #endregion

        #region Overloaded Constructors
        /// <summary>
        /// Constructor with 2 parameters
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="innerException">Exception</param>
        public XmlParserException(string message, Exception innerException)
            : base(message, innerException)  {
                _errorCode = 0;
        }
        /// <summary>
        /// Constructor with 3 parameters
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="errorCode">int</param>
        /// <param name="innerException">Exception</param>
        public XmlParserException(string message, int errorCode, Exception innerException)
            : base(message, innerException)
        {
            this._errorCode = errorCode;

        }
        #endregion
    }
}
