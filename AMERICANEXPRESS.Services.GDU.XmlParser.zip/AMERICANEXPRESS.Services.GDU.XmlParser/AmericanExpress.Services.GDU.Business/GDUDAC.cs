﻿////-----------------------------------------------------------------------
//// <copyright file="GDUDAC.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of GDUDAC. This class is used
//// for interaction with database</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AmericanExpress.Services.GDU.Business
{
    /// <summary>
    /// GDUDAC Class Implementation
    /// </summary>
    public class GDUDAC
    {
        #region Variables

        private string _dbErrorCode; //to store DBError Code
        private SqlConnection _connGDU; //for sql connection
        private SqlDataReader _sqlResult; //for reading records
        private string _sql = string.Empty; //to store sql statement
        private int _threadId = 0; //to store thread id
        private string _infoLog = System.Configuration.ConfigurationManager.AppSettings["InformationLog"].ToString(); // -- 20/11/2012
        
        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread id number and ErrorCode in constructor
        /// </summary>
        /// <param name="threadID">int</param>
        /// <param name="infoLog">string</param>
        public GDUDAC(int threadID)
        {
            _threadId = threadID;
            _dbErrorCode = ConfigurationManager.AppSettings["Common_DBERRORCODE"];
        }
        #endregion

        #region Properties
        /// <summary>
        /// This will get and set the Execution ID
        /// </summary>
        public int ExecutionID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Organization Profile ID
        /// </summary>
        public string OrgnProfileID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Organization Code
        /// </summary>
        public string OrgnCode
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Booking Country Code
        /// </summary>
        public string BookCountryCode
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Preference ID
        /// </summary>
        public string PreferenceID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Report Preference
        /// </summary>
        public string ReportType
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Pos Tool
        /// </summary>
        public string PosTool
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Client Profile Name
        /// </summary>
        public string ClientProfileName
        {
            get;
            set;
        }
        #endregion

        #region Methods
        #region This will open the Database connection to the specified database in the app.config file.
        /// <summary>
        /// Method used to connect to the database. It returns true if connection open successfully else false
        /// </summary>
        /// <returns>bool</returns>
        public bool ConnectDatabase()
        {
            try
            {
                _connGDU = new SqlConnection(ConfigManager.ConnectionString(Common._DBNAME));
                OpenConnection();
            }
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Unable to connect to GDU Database to read thread count.", 5019, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Unable to connect to GDU Database for threadid : " + _threadId + ".", 5001, e);
                }
                return false;
            }
            return true;
        }
        /// <summary>
        /// Method used to open the connection and logged the info
        /// </summary>
        private void OpenConnection()
        {
            try
            {
                _connGDU.Open();
                if (_infoLog.ToUpper() == "Y")
                {
                    if (_threadId == 0)
                    {
                        LogManager.LogInfoMessage("Connected successfully to GDU Database to read the thread count from application param table.", 2006);
                    }
                    else
                    {
                        LogManager.LogInfoMessage("Connected successfully to GDU Database for threadid : " + _threadId + ".", 2007);
                    }
                }
            }
            catch (Exception e)
            {
                _connGDU.Dispose();
                throw new Exception("Unable to connect to GDU Database", e);
            }
        }
        #endregion

        #region This will close the Database connection.
        /// <summary>
        /// Method used to close the connection if it is open
        /// </summary>
        public void CloseConnection()
        {
            try
            {
                if (_connGDU != null && _connGDU.State == System.Data.ConnectionState.Open)
                    _connGDU.Close();
            }
            finally
            {
                _connGDU.Dispose();
            }
        }
        #endregion

        #region Read Mail Params
        /// <summary>
        /// Method used to retrieve the values from TBL_APPL_PARAM table related to EMail/ThreadCount
        /// </summary>
        /// <param name="criteria">string</param>
        /// <returns>DataSet</returns>
        /// 
        public int xmlFileInsertIntoDB(int id, string xmlFile, string computerNM, string ipAddress, string adsId, int File_Type)
        {
            LogManager.LogtoEvent("Call start xmlFileInsertIntoDB" );
            SqlCommand cmd;
            int executeRecord = 0;
            try
            {
                if (File_Type == 0)
                {
                    //_sql = "exec " + Common._SPINSERTXMLFILE + " " + id + ",'" + xmlFile.Replace("'", "''") + "','" + computerNM + "','" + ipAddress + "','" + adsId + "',null";

                    cmd = new SqlCommand(Common._SPINSERTXMLFILE, _connGDU);
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter parm = new SqlParameter("@ID", SqlDbType.Int);
                    parm.Value = id;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("ID = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@INXMLDATA", SqlDbType.VarChar);
                    parm.Value = xmlFile.Replace("'", "''");
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("INXMLDATA = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@COMPUTER_NM", SqlDbType.VarChar);
                    parm.Value = computerNM;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("COMPUTER_NM = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@IP_ADDR_TXT", SqlDbType.VarChar);
                    parm.Value = ipAddress;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("IP_ADDR_TXT = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@ADS_ID", SqlDbType.VarChar);
                    parm.Value = adsId;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("ADS_ID = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@OUTSTATUS", SqlDbType.Int);
                    parm.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(parm);

                    LogManager.LogtoEvent("Calling Insert SP, threadid = " + _threadId);
                    cmd.ExecuteNonQuery();
                    executeRecord =(int) cmd.Parameters["@OUTSTATUS"].Value;
                    LogManager.LogtoEvent(" executeRecord " + executeRecord + " " + cmd.Parameters["@OUTSTATUS"].Value);
                    LogManager.LogtoEvent("Calling Insert SP, complete, threadid = " + _threadId);

                }
                else
                {
                    cmd = new SqlCommand(Common._SPINSERTXMLFILETRAVELSUITE, _connGDU);
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter parm = new SqlParameter("@ID", SqlDbType.Int);
                    parm.Value = id;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("ID = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@INXMLDATA", SqlDbType.VarChar);
                    parm.Value = xmlFile.Replace("'", "''");
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("INXMLDATA = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@COMPUTER_NM", SqlDbType.VarChar);
                    parm.Value = computerNM;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("COMPUTER_NM = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@IP_ADDR_TXT", SqlDbType.VarChar);
                    parm.Value = ipAddress;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("IP_ADDR_TXT = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@ADS_ID", SqlDbType.VarChar);
                    parm.Value = adsId;
                    parm.Direction = ParameterDirection.Input;
                    LogManager.LogtoEvent("ADS_ID = " + parm.Value);
                    cmd.Parameters.Add(parm);

                    parm = new SqlParameter("@OUTSTATUS", SqlDbType.Int);
                    parm.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(parm);

                    LogManager.LogtoEvent("Calling Insert SP, threadid = " + _threadId);
                    cmd.ExecuteNonQuery();
                    executeRecord = (int)cmd.Parameters["@OUTSTATUS"].Value;
                    LogManager.LogtoEvent(" executeRecord " + executeRecord + " " + cmd.Parameters["@OUTSTATUS"].Value);
                    LogManager.LogtoEvent("Calling Insert SP, complete, threadid = " + _threadId);

                    //_sql = "exec " + Common._SPINSERTXMLFILETRAVELSUITE + " " + id + ",'" + xmlFile.Replace("'", "''") + "','" + computerNM + "','" + ipAddress + "','" + adsId + "',null";
                    //cmd = new SqlCommand(_sql, _connGDU);
                    //cmd.CommandTimeout = 0;

                    //LogManager.LogtoEvent("Calling Insert SP, threadid = " + _threadId);
                    //executeRecord = cmd.ExecuteNonQuery();
                    //LogManager.LogtoEvent(" executeRecord " + executeRecord);
                    //LogManager.LogtoEvent("Calling Insert SP, complete, threadid = " + _threadId);

                }

                return executeRecord;
            }
            catch (Exception Ex)
            {
                LogManager.LogtoEvent("Exception during call Insert SP, threadid = " + _threadId + " " + Ex.Message.ToString());
                return executeRecord;
            }
            finally
            {
                LogManager.LogtoEvent("Call end xmlFileInsertIntoDB");
            }
            
        }

        public DataSet GetAppParamValues()
        {
            DataSet paramData = null;
            try
            {
                paramData = new DataSet();
                _sql = "exec " + Common._SPAPPPARAMVALUES;
                SqlCommand cmd = new SqlCommand(_sql, _connGDU);
                cmd.CommandTimeout = 0;

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
                sqlDataAdapter.Fill(paramData);
                sqlDataAdapter.Dispose();
            }
            catch (SqlException sqlex)
            {
                //Checking the type of Sql Exception
                if (isDBConnectionError(sqlex.Number))
                {
                    if (_threadId == 0)
                    {
                        throw new XmlParserException("Unable to connect to GDU Database while executing " + Common._SPAPPPARAMVALUES + ".", 5003, sqlex);
                    }
                    else
                    {
                        throw new XmlParserException("Unable to connect to GDU Database while executing threadid : " + _threadId + ".", 5003, sqlex);
                    }
                }
                else
                {
                    if (_threadId == 0)
                    {
                        LogManager.LogErrorMessage("SQL Error while executing " + Common._SPAPPPARAMVALUES + ".", 5027, sqlex);
                    }
                    else
                    {
                        LogManager.LogErrorMessage("SQL Error while executing threadid : " + _threadId + ".", 5024, sqlex);
                    }
                }
            }
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Error while executing " + Common._SPAPPPARAMVALUES + ".", 5028, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Error while executing threadid : " + _threadId + ".", 5025, e);
                }
            }
            return paramData;
        }
        #endregion

        #region Check if its a DB COnnection error
        /// <summary>
        /// Method used to check the Error is database error which is defined in config file
        /// It returns true if it is DB Connection error else false
        /// </summary>
        /// <param name="SQLErrNumber">int</param>
        /// <returns>bool</returns>
        private bool isDBConnectionError(int SQLErrNumber)
        {
            try
            {
                string[] listedErrors = _dbErrorCode.Split(",".ToCharArray());
                for (int i = 0; i < listedErrors.Length; i++)
                {
                    if (listedErrors[i].Trim() == SQLErrNumber.ToString().Trim())
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Clean Up Resources
        /// <summary>
        /// Method used to clean up resources
        /// </summary>
        private void CleanUpResources()
        {
            if (_sqlResult != null)
            {
                if (!_sqlResult.IsClosed)
                    _sqlResult.Close();

                _sqlResult = null;
            }
        }
        #endregion
        #endregion
    }
}
