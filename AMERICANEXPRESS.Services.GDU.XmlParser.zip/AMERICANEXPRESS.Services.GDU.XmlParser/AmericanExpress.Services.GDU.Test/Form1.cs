﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AmericanExpress.Services.GDU.Business;
using System.Threading;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            DataSet dsAppParam = null;
            //Thread currentThread = Thread.CurrentThread;
            //_threadId = currentThread.ManagedThreadId;

            try
            {
                GDUDAC gduDAC = new GDUDAC(1);

                if (gduDAC.ConnectDatabase())
                {
                    try
                    {
                        //Added on 17/july/2012***************************
                        // get the app params
                        dsAppParam = gduDAC.GetAppParamValues();
                        //************************************************

                        //Initiate the FailSafe process
                        GDUProcess gduProcess = new GDUProcess(1, gduDAC);
                        gduProcess.StartProcess(dsAppParam);
                    }
                    catch (Exception eX)
                    {
                        //_message = "Error while processing in thread for threadid : " + _threadId + ".";
                        //LogManager.LogErrorMessage(_message, 5001, e);
                    }
                    gduDAC.CloseConnection();
                }
            }
            catch (Exception ex)
            {
                //_message = "Error while starting thread for threadid : " + _threadId + ".";
                //LogManager.LogErrorMessage(_message, 5002, e);
            }

            //GDUDAC dacDB = new GDUDAC(1);
            //LogManager.InitializeSource(); 
            //if (dacDB.ConnectDatabase())
            //{
            //    new GDUProcess(1, dacDB).StartProcess(null);                 
            //    dacDB.CloseConnection();                              
            //}
          
        }
      
    }
}
