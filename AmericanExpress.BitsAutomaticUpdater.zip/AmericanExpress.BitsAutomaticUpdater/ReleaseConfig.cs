﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.IO;
using System.Xml;
using AmericanExpress.PushOnce.Common;
using System.Configuration;

namespace AmericanExpress.PushOnce
{
    class ReleaseConfig
    {

        public static void DownloadConfiguration(string localPath, string serverPath)
        {
        PartialDownloadConfiguration:
            string filePathToSave = string.Empty;
            bool isReleaseConfigExist = false;
            try
            {

                XElement serverFile = XElement.Load(serverPath + "/Release.xml");
                if (serverFile != null)
                {
                    isReleaseConfigExist = true;
                    IEnumerable<XElement> configFileElements = serverFile.XPathSelectElements("ConfigFiles/AppConfigFile");
                    foreach (XElement fileElement in configFileElements)
                    {
                        if (fileElement.Attribute("isUsing").Value.ToUpper() == "TRUE")
                        {
                            //Load file from server
                            XElement file = XElement.Load(fileElement.Value);

                            //Ensure target directory exists
                            if (!localPath.EndsWith("\\")) localPath += "\\";
                            string filePath = fileElement.Attribute("target").Value.Substring(0, fileElement.Attribute("target").Value.LastIndexOf("\\") + 1);
                            DirectoryInfo di = new DirectoryInfo(localPath + filePath);
                            if (!di.Exists)
                            {
                                di.Create();
                            }
                            filePathToSave = localPath + fileElement.Attribute("target").Value;
                            //Save server file in local directory
                            file.Save(localPath + fileElement.Attribute("target").Value);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                try
                {
                    if (System.IO.File.Exists(filePathToSave))
                    {
                        System.IO.File.Delete(filePathToSave);
                    }
                    if (isReleaseConfigExist)
                    {
                        if (System.Windows.Forms.MessageBox.Show(ex.Message.ToString(), ConfigurationSettings.AppSettings["DownloadErrorMSG"].ToString(), System.Windows.Forms.MessageBoxButtons.RetryCancel) == System.Windows.Forms.DialogResult.Retry)
                        {
                            Logger.Log("ReleaseConfig.DownloadConfiguration", "Partial DownloadConfiguration 1# User Is Retrying");
                            goto PartialDownloadConfiguration;
                        }
                    }
                }
                catch (Exception ex1)
                {
                    Logger.Log("ReleaseConfig.DownloadConfiguration", ex1.Message.ToString());
                }

                //Logger.Log("ReleaseConfig.DownloadConfiguration", "Download configuration Failed.");
                Logger.Log("ReleaseConfig.DownloadConfiguration", "localPath: " + localPath);
                Logger.Log("ReleaseConfig.DownloadConfiguration", "serverPath: " + serverPath);
                //Logger.Log(ex);
            }
        }


    }
}
