﻿///////////////////////////////////////////////////////////////////////////////
//Updater.cs
// Implements automatic updating of applications.
//
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Diagnostics;
using System.Collections;
using System.Threading;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Security;
using System.Security.Policy;
using System.Xml.Linq;
using System.Linq;
using System.Xml;
using System.Windows.Forms;
using AmericanExpress.PushOnce.Bits;
using AmericanExpress.PushOnce.Common;
using System.Collections.Generic;
using AmericanExpress.PushOnce;
using System.Security.AccessControl;
using IWshRuntimeLibrary;
using Microsoft.Win32;
using AmericanExpress.AutomaticUpdater;
using System.Security.Principal;
using System.Net;
using System.Data;
using System.Configuration;
using System.Text;
//using AmericanExpress.AutomaticUpdater.GDUService;

/// <summary>
/// AutoUpdater: The type that exposes  public static methods for downloading application updates.
/// 
/// </summary>
/// 

namespace AmericanExpress.PushOnce
{
    //public enum DownloadUpdateStatus
    //{
    //    ContinueExecution,
    //    ApplyUpdate
    //}

    public class Updater
    {
        private static string tempDirectoryName = "__$$Update";
        private static string backupSuffix = ".aexpapp$$.backup";
        private static string localExeVersion = string.Empty;
        private static string serverExeVersion = string.Empty;
        //static ClientDeploymentInfo info;
        // Default to 8 minutes.
        public static int DownloadTimeout = 480000;


        private static System.Threading.Timer _updateInterval;


        public static event EventHandler UpdateAvailable;

        private static bool isClickOnceManifest = true;

        private static Progress progress = null;

        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;
        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;

        public static string GetIconPath
        {
            get;
            set;
        }
        public static string AppInstallType
        {
            get;
            set;
        }
        public static string IsException
        {
            get;
            set;
        }

        public static string downloadException
        {
            get;
            set;
        }

        public static string LocalManifestFileName
        {
            
                    get
                    {
                        try
                        {
                            LowTraceText = new StringBuilder();
                            HighTraceText = new StringBuilder();
                        DirectoryInfo di = new DirectoryInfo(System.Environment.CurrentDirectory);
                        FileInfo[] files = di.GetFiles("*.amexapplication");
                        if (files.Count() != 1)
                            return "";
                        //LowTraceText.AppendLine("PO:: LL Step 22a-1 in LocalManifestFileName property: SelfUpdate 1:" + files[0].FullName);
                        LowTraceText.AppendLine("PO:: LL Step 22a-1 in LocalManifestFileName property: SelfUpdate 1:" + files[0].FullName);
                        //LowTraceText.AppendLine("SelfUpdate 1:" + files[0].FullName);
                        return files[0].FullName;
                        }
                        finally
                        {
                            if (LowTraceText.Length > 0)
                            {
                                LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                            }
                            if (HighTraceText.Length > 0)
                            {
                                LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                            }

                        }
                    }
        }


        /// <summary>
        /// Stop firing the update event.
        /// </summary>
        public static void StopUpdateNotifications()
        {
            if (null == _updateInterval)
                return;

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: LL Step in StopUpdateNotifications(In Updater clas) Method: SelfUpdate 2:");
                LowTraceText.AppendLine("PO: LL Step in StopUpdateNotifications(In Updater clas) Method: SelfUpdate 2:");
                //LowTraceText.AppendLine("SelfUpdate 2:");
                _updateInterval.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            }
            catch
            {
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }


        /// <summary>
        /// Start notifications of update status.  When this is called, we create
        /// an timer interval to check for updates and notify clients when available.
        /// </summary>
        /// <returns></returns>
        public static bool StartUpdateNotifications()
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO:: HL in StartUpdateNotifications method: Entered into StartUpdateNotifications method in Updater.cs", HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL in StartUpdateNotifications method: Entered into StartUpdateNotifications method in Updater.cs");
                //LowTraceText.AppendLine("PO:: LL Step 22a in StartUpdateNotifications method: Entered into StartUpdateNotifications method(SelfUpdate) in Updater.cs called from Main Method");
                LowTraceText.AppendLine("PO:: LL Step 22a in StartUpdateNotifications method: Entered into StartUpdateNotifications method(SelfUpdate) in Updater.cs called from Main Method");
                //LowTraceText.AppendLine("SelfUpdate 3: In StartUpdateNotifications");
                XElement xDeploy = XElement.Load(LocalManifestFileName);

                DeploymentManifestReader dReader = new DeploymentManifestReader(xDeploy);

                int maxAge = dReader.UpdateMaximumAge;
                if (-1 == maxAge)
                    return false;

                int multiplier = 1;

                switch (dReader.UpdateUnit)
                {
                    case UpdateUnits.days:
                        multiplier = 24;
                        break;
                    case UpdateUnits.hours:
                        multiplier = 1;
                        break;
                    case UpdateUnits.weeks:
                        multiplier = 168;
                        break;
                }
                //LowTraceText.AppendLine("PO:: LL Step 22b in StartUpdateNotifications method: StartUpdateNotifications method(SelfUpdate) in Updater.cs called from Main Method, = multiplier:" + multiplier);
                LowTraceText.AppendLine("PO:: LL Step 22b in StartUpdateNotifications method: StartUpdateNotifications method(SelfUpdate) in Updater.cs called from Main Method, = multiplier:" + multiplier);
                //LowTraceText.AppendLine("SelfUpdate 3: In StartUpdateNotifications= multiplier: " + multiplier);
                TimeSpan ts = new TimeSpan(maxAge * multiplier, 0, 0);

                _updateInterval = new System.Threading.Timer(new TimerCallback(checkForUpdate), null, ts, ts);
                return true;
            }
            catch (Exception e)
            {
                Logger.Log(e);
                //LowTraceText.AppendLine("PO:: HL Step 3 in Main Method :StartUpdateNotifications Exception: " + e.ToString(), HighTraceInfo);
                //LowTraceText.AppendLine("PO:: HL Step 3 in Main Method :In StartUpdateNotifications ", HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL Step 3 in Main Method :In StartUpdateNotifications ");
                //LowTraceText.AppendLine("PO:: LL in Main Method :In StartUpdateNotifications ");
                LowTraceText.AppendLine("PO:: LL in Main Method :In StartUpdateNotifications ");
                return false;
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }


        /// <summary>
        /// Checks to see if an update is available.
        /// </summary>
        /// <param name="state"></param>
        internal static void checkForUpdate(object state)
        {
            
            string uri = string.Empty;

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                LowTraceText.AppendLine("PO:: LL Step 22b-1 in checkForUpdate method: checkForUpdate method - SelfUpdate 4: In checkForUpdate= :");
                XElement xManifest = XElement.Load(LocalManifestFileName);

                DeploymentManifestReader deploymentReader = new DeploymentManifestReader(xManifest);


                //  Get the corresponding deployment manifest on from the deployment server
                XElement xServerDeployment = XElement.Load(deploymentReader.Codebase);

                // Use a reader to read contents of deployment manifest
                DeploymentManifestReader svrReader = new DeploymentManifestReader(xServerDeployment);


                Logger.Log("Updater.checkForUpdate", "Compare Version " + svrReader.Version.ToString() + " vs. " + deploymentReader.Version.ToString());
                //LowTraceText.AppendLine("PO:: LL Step 22b-2 in checkForUpdate method: checkForUpdate method - SelfUpdate 5: svrReader.Version= : " + svrReader.Version);
                LowTraceText.AppendLine("PO:: LL Step 22b-2 in checkForUpdate method: checkForUpdate method - SelfUpdate 5: svrReader.Version= : " + svrReader.Version);
                //LowTraceText.AppendLine("PO:: LL Step 22b-3 in checkForUpdate method: checkForUpdate method - SelfUpdate 4: deploymentReader.Version= : " + deploymentReader.Version);
                LowTraceText.AppendLine("PO:: LL Step 22b-3 in checkForUpdate method: checkForUpdate method - SelfUpdate 4: deploymentReader.Version= : " + deploymentReader.Version);
                //LowTraceText.AppendLine("SelfUpdate 5: svrReader.Version= : " + svrReader.Version);
                //LowTraceText.AppendLine("SelfUpdate 5: deploymentReader.Version= : " + deploymentReader.Version);
                // if versions are the same, no update available, exit now.
                if (svrReader.Version != deploymentReader.Version)
                {
                    if (null != UpdateAvailable)
                        UpdateAvailable(null, null);
                }
            }
            catch (Exception e)
            {
                Logger.Log(e);
                //LowTraceText.AppendLine("Po: HL Step 51 in checkForUpdate Method: checkForUpdate method Exception" + e.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 51 in checkForUpdate Method: checkForUpdate method Exception" + e.ToString());
                //LowTraceText.AppendLine("Po: LL in checkForUpdate Method: checkForUpdate method Exception" + e.ToString());
                LowTraceText.AppendLine("Po: LL in checkForUpdate Method: checkForUpdate method Exception" + e.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }

        

        /// <summary>
        /// Installs (if it does not exist) or updates an application.
        /// </summary>
        /// <param name="deploymentManifestPath">URL to the deployment manifest file.  The deployment manifest
        /// contains metadata about an application and contains information such as the codebase of the files
        /// on the server.</param>
        /// <param name="applicationBasepath">URL to the application manifest file.  The application manifest is
        /// a list of all files required for an installation of an application.</param>
        /// <returns>Return code, 0 is success</returns>
        public static XElement InstallOrUpdate(string deploymentManifestPath, bool Launch, string[] args)
        {
            try
            {
                //deploymentManifestPath = deploymentManifestPath.Substring(0, deploymentManifestPath.LastIndexOf("\\") + 1) + deploymentManifestPath.Substring(deploymentManifestPath.LastIndexOf("\\") + 1).Replace(" ", "%20");
                //args[0] = args[0].Substring(0, args[0].LastIndexOf("\\") + 1) + args[0].Substring(args[0].LastIndexOf("\\") + 1).Replace(" ", "%20");
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL on InstallOrUpdate Method: Entered into InstallOrUpdate method defined in Updater class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL on InstallOrUpdate Method: Entered into InstallOrUpdate method defined in Updater class");
                //LowTraceText.AppendLine("Update Step 1: Enter in Updater");
                //LowTraceText.AppendLine("PO: LL Step 34c in InstallOrUpdate Method: Entered into InstallOrUpdate method defined in Updater class");
                LowTraceText.AppendLine("PO: LL Step 34c in InstallOrUpdate Method: Entered into InstallOrUpdate method defined in Updater class");
                Logger.Enter("Updater.InstallOrUpdate", new string[] { deploymentManifestPath, Launch.ToString() });


                // Set the manifest type for proper parsing
                setManifestType(args);
                if (string.IsNullOrEmpty(deploymentManifestPath))
                    throw new ArgumentException("Deployment manifest Path is blank or null");
                //System.Windows.Forms.MessageBox.Show("Attach");

                XElement xDeploymentManifest = null;
                string applicationBasepath = "";
                XElement appManifest = null;
                DeploymentManifestReader deploymentReader = null;

                string app_Type = string.Empty;
                string code = string.Empty;
                string localAppVersion = string.Empty;

                try
                {
                    // load the deployment manifest from the filename in the argument list.
                    xDeploymentManifest = XElement.Load(deploymentManifestPath);
                    // get a reader for the xml manifest.
                    deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                    //set Manifest type for update
                    isClickOnceManifest = deploymentReader.ClickOnceManifest;
                    // Get location to install on the target machine
                    applicationBasepath = deploymentReader.TargetCodebase;
                    Logger.Log("Updater.InstallOrUpdate", "Application base path: " + applicationBasepath);
                    if (!applicationBasepath.EndsWith("\\"))
                        applicationBasepath += "\\";
                    //LowTraceText.AppendLine("PO: LL Step 34d in InstallOrUpdate Method: In Updater class, ApplicationBasePath" + applicationBasepath);
                    LowTraceText.AppendLine("PO: LL Step 34d in InstallOrUpdate Method: In Updater class, ApplicationBasePath" + applicationBasepath);
                    //LowTraceText.AppendLine("Update Step 2: ApplicationBasePath" + applicationBasepath);
                    DirectoryInfo diBasePath = new DirectoryInfo(applicationBasepath);
                    //LowTraceText.AppendLine("PO: LL Step 34e in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34e in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    //LowTraceText.AppendLine("Update Step 3:");

                    if (!diBasePath.Exists)
                        diBasePath.Create();
                    //LowTraceText.AppendLine("PO: LL Step 34f in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34f in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    //LowTraceText.AppendLine("Update Step 4:");
                    Uri uri = new Uri(deploymentManifestPath);
                    //LowTraceText.AppendLine("PO: LL Step 34g in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34g in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    //LowTraceText.AppendLine("Update Step 5:");

                    string localManifestFilePath = string.Empty;
                    string ManifestFileType = string.Empty;
                    XElement xServerDeployment = null;
                    //LowTraceText.AppendLine("PO: LL Step 34h in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34h in InstallOrUpdate Method: InstallOrUpdate Method in Updater class");
                    //LowTraceText.AppendLine("Update Step 6:");

                    //LowTraceText.AppendLine("PO: LL Step 34i in InstallOrUpdate Method: InstallOrUpdate Method in Updater class *********Check Request is file or web request ***************");
                    LowTraceText.AppendLine("PO: LL Step 34i in InstallOrUpdate Method: InstallOrUpdate Method in Updater class *********Check Request is file or web request ***************");
                    //LowTraceText.AppendLine("*********Check Request is file or web request ***************");
                    // local or remote load.
                    // If local, need to get the remote location and update the local manifest.
                    if (uri.IsFile)
                    {
                        AppInstallType = "Update";
                        //LowTraceText.AppendLine("PO: LL Step 34j in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Request is File ");
                        LowTraceText.AppendLine("PO: LL Step 34j in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Request is File ");
                        //LowTraceText.AppendLine("Request is File");
                        Logger.Log("Updater.InstallOrUpdate", "URI is a file: " + uri.ToString());
                        // The passed in deployment manifest is a file (can be local machine or mapped drive)
                        //LowTraceText.AppendLine("PO: LL Step 34k in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        LowTraceText.AppendLine("PO: LL Step 34k in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        //LowTraceText.AppendLine("Update Step 6a In File:");


                        //  Get the corresponding deployment manifest on from the deployment server
                        //LowTraceText.AppendLine("PO: LL Step 34l in InstallOrUpdate Method: " + deploymentReader.Codebase);
                        LowTraceText.AppendLine("PO: LL Step 34l in InstallOrUpdate Method: " + deploymentReader.Codebase);
                        //LowTraceText.AppendLine(deploymentReader.Codebase);
                        xServerDeployment = XElement.Load(deploymentReader.Codebase);
                        //LowTraceText.AppendLine("PO: LL Step 34m in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        LowTraceText.AppendLine("PO: LL Step 34m in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        //LowTraceText.AppendLine("Update Step 6b In File:");

                        // Use a reader to read contents of deployment manifest
                        DeploymentManifestReader svrReader = new DeploymentManifestReader(xServerDeployment);
                        //LowTraceText.AppendLine("PO: LL Step 34n in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        LowTraceText.AppendLine("PO: LL Step 34n in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, In File ");
                        //LowTraceText.AppendLine("Update Step 6c In File:");



                        // If we are now pointing to a new location, load that manifest
                        if (svrReader.Codebase.ToLower() != deploymentReader.Codebase.ToLower())
                        {
                            try
                            {
                                xServerDeployment = XElement.Load(svrReader.Codebase);
                                svrReader = new DeploymentManifestReader(xServerDeployment);
                            }
                            catch
                            {
                                // failsafe, if new server is unavailable, revert to existing server
                                xServerDeployment = XElement.Load(deploymentReader.Codebase);
                                // Use a reader to read contents of deployment manifest
                                svrReader = new DeploymentManifestReader(xServerDeployment);
                            }
                        }


                        Logger.Log("Updater.InstallOrUpdate", "Compare Version " + svrReader.Version.ToString() + " vs. " + deploymentReader.Version.ToString());
                        // if versions are the same, no update available, exit now.
                        //LowTraceText.AppendLine("PO: LL Step 34o in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, svrReader.Version= " + svrReader.Version);
                        LowTraceText.AppendLine("PO: LL Step 34o in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, svrReader.Version= " + svrReader.Version);
                        //LowTraceText.AppendLine("svrReader.Version= " + svrReader.Version);
                        //LowTraceText.AppendLine("PO: LL Step 34p in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, deploymentReader.Version= " + deploymentReader.Version);
                        LowTraceText.AppendLine("PO: LL Step 34p in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, deploymentReader.Version= " + deploymentReader.Version);
                        //LowTraceText.AppendLine("deploymentReader.Version= " + deploymentReader.Version);
                        /// <summary>
                        ///Changes made for new enhancement
                        /// </summary> 
                        serverExeVersion = svrReader.Version.ToString();
                        localExeVersion = deploymentReader.Version.ToString();
                        localAppVersion = localExeVersion;
                        if (svrReader.Version == deploymentReader.Version)
                        {
                            //LowTraceText.AppendLine("PO: LL Step 34q in InstallOrUpdate Method: InstallOrUpdate Method in Updater class,Update Step In File ");
                            LowTraceText.AppendLine("PO: LL Step 34q in InstallOrUpdate Method: InstallOrUpdate Method in Updater class,Update Step In File ");
                            //LowTraceText.AppendLine("Update Step 6d In File:");
                            //LowTraceText.AppendLine("PO: LL Step 34r in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Prev Condition File Path=: " + svrReader.TargetCodebase + "\\" + uri.GetFileName());
                            LowTraceText.AppendLine("PO: LL Step 34r in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Prev Condition File Path=: " + svrReader.TargetCodebase + "\\" + uri.GetFileName());
                            //LowTraceText.AppendLine("Prev Condition File Path=:" + svrReader.TargetCodebase + "\\" + uri.GetFileName());
                            //LowTraceText.AppendLine("PO: LL Step 34s in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, New Condition File Path=: " + svrReader.TargetCodebase + "\\" + Uri.UnescapeDataString(uri.GetFileName()));
                            LowTraceText.AppendLine("PO: LL Step 34s in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, New Condition File Path=: " + svrReader.TargetCodebase + "\\" + Uri.UnescapeDataString(uri.GetFileName()));
                            //LowTraceText.AppendLine("New Condition File Path=:" + svrReader.TargetCodebase + "\\" + Uri.UnescapeDataString(uri.GetFileName()));

                            if (System.IO.File.Exists(svrReader.TargetCodebase + "\\" + Uri.UnescapeDataString(uri.GetFileName())))
                            {
                                //LowTraceText.AppendLine("PO: LL Step 34t in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Update Step In File ");
                                LowTraceText.AppendLine("PO: LL Step 34t in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Update Step In File ");
                                //LowTraceText.AppendLine("Update Step 6e In File:");


                                localManifestFilePath = applicationBasepath + Uri.UnescapeDataString(uri.GetFileName());
                                //LowTraceText.AppendLine("PO: LL Step 34u in InstallOrUpdate Method: InstallOrUpdate Method in Updater class,Update Step In File: " + localManifestFilePath);
                                LowTraceText.AppendLine("PO: LL Step 34u in InstallOrUpdate Method: InstallOrUpdate Method in Updater class,Update Step In File: " + localManifestFilePath);
                                //LowTraceText.AppendLine("Update Step 6f In File:" + localManifestFilePath);

                                if (System.IO.File.Exists(localManifestFilePath))
                                    return null;
                            }
                        }
                        //To Check Download with pilot/production user
                        //--------------------------------------------

                        try
                        {
                            string appPathURI = Application.StartupPath.ToString();
                            string CheckUserExePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + @"\Axp.CheckPilotUser.exe";
                            string checkUserClientExeName = deploymentReader.ApplicationCodebase.ToString().Substring(deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") + 1, (deploymentReader.ApplicationCodebase.ToString().LastIndexOf('.') - deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") - 1));

                            string appTargetServicePath = deploymentReader.Codebase;
                            //LowTraceText.AppendLine("PO: LL Step 34v in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Path 1" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34v in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Path 1" + appTargetServicePath);
                            //LowTraceText.AppendLine("File URI: Requested Amex Server Path 1" + appTargetServicePath);

                            //LowTraceText.AppendLine("PO: LL Step 34w in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@:" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34w in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@:" + appTargetServicePath);
                            //LowTraceText.AppendLine("@@@@" + appTargetServicePath);
                            string[] service_Attributes = appTargetServicePath.Split('/');
                            //LowTraceText.AppendLine("PO: LL Step 34x in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@:" + service_Attributes[0] + "//" + service_Attributes[2]);
                            LowTraceText.AppendLine("PO: LL Step 34x in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@:" + service_Attributes[0] + "//" + service_Attributes[2]);
                            //LowTraceText.AppendLine("@@@@" + service_Attributes[0] + "//" + service_Attributes[2]);
                            //LowTraceText.AppendLine("PO: LL Step 34y in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Path 1" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34y in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Path 1" + appTargetServicePath);
                            //LowTraceText.AppendLine("File URI: Requested Amex Server Path 1" + appTargetServicePath);
                            appTargetServicePath = service_Attributes[0] + "//" + service_Attributes[2];
                            //LowTraceText.AppendLine("PO: LL Step 34z in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34z in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            //LowTraceText.AppendLine("File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);

                            // appTargetServicePath = appTargetServicePath.Remove(appTargetServicePath.IndexOf("DeployedApplication") - 1);

                            //LowTraceText.AppendLine("PO: LL Step 34z-1 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-1 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            //LowTraceText.AppendLine("File URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            //Market Release
                            string checkUserParam = checkUserClientExeName.Replace(" ", "$") + " " + svrReader.Version.ToString() + " " + appTargetServicePath + " " + deploymentReader.Codebase.Replace(" ", "$");

                            //LowTraceText.AppendLine("PO: LL Step 34z-2 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@ Invoke checkUser @@@@");
                            LowTraceText.AppendLine("PO: LL Step 34z-2 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, @@@@ Invoke checkUser @@@@");
                            //LowTraceText.AppendLine("@@@@ Invoke checkUser @@@@");
                            //LowTraceText.AppendLine("PO: LL Step 34z-3 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Parameter :" + checkUserParam);
                            LowTraceText.AppendLine("PO: LL Step 34z-3 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Parameter :" + checkUserParam);
                            //LowTraceText.AppendLine("Parameter :" + checkUserParam);
                            Process chkUserProcess = new Process();
                            chkUserProcess.StartInfo.UseShellExecute = false;
                            chkUserProcess.StartInfo.RedirectStandardOutput = true;
                            //LowTraceText.AppendLine("PO: LL Step 34z-4 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1" + checkUserParam);
                            LowTraceText.AppendLine("PO: LL Step 34z-4 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1" + checkUserParam);
                            //LowTraceText.AppendLine("Check User URI 1");
                            //chkUserProcess.StartInfo.FileName = CheckUserExePath;
                            chkUserProcess.StartInfo.FileName = appPathURI + @"\Axp.CheckPilotUser.exe";
                            //LowTraceText.AppendLine("PO: LL Step 34z-5 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1 Old File Name=" + CheckUserExePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-5 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1 Old File Name=" + CheckUserExePath);
                            //LowTraceText.AppendLine("Check User URI 1 Old File Name=" + CheckUserExePath);
                            //LowTraceText.AppendLine("PO: LL Step 34z-6 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1 New File Name=" + chkUserProcess.StartInfo.FileName);
                            LowTraceText.AppendLine("PO: LL Step 34z-6 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 1 New File Name=" + chkUserProcess.StartInfo.FileName);
                            //LowTraceText.AppendLine("Check User URI 1 New File Name=" + chkUserProcess.StartInfo.FileName);

                            //chkUserProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            chkUserProcess.StartInfo.CreateNoWindow = true;

                            chkUserProcess.StartInfo.Arguments = checkUserParam;
                            //LowTraceText.AppendLine("PO: LL Step 34z-7 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 2");
                            LowTraceText.AppendLine("PO: LL Step 34z-7 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 2");
                            //LowTraceText.AppendLine("Check User URI 2");
                            chkUserProcess.Start();
                            //LowTraceText.AppendLine("PO: LL Step 34z-8 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 3");
                            LowTraceText.AppendLine("PO: LL Step 34z-8 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 3");
                            //LowTraceText.AppendLine("Check User URI 3");
                            code = chkUserProcess.StandardOutput.ReadToEnd();
                            chkUserProcess.WaitForExit();
                            //LowTraceText.AppendLine("PO: LL Step 34z-9 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 4");
                            LowTraceText.AppendLine("PO: LL Step 34z-9 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 4");
                            //LowTraceText.AppendLine("Check User URI 4");
                            //LowTraceText.AppendLine("PO: LL Step 34z-10 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 5");
                            LowTraceText.AppendLine("PO: LL Step 34z-10 in InstallOrUpdate Method: InstallOrUpdate Method in Updater class, Check User URI 5");
                            //LowTraceText.AppendLine("Check User URI 5");
                        }
                        catch (Exception ex)
                        {
                            code = "Exception";

                            //LowTraceText.AppendLine("PO:: HL Step 14 in InstallOrUpdate method :CHECK USER EXCEPTION" + ex.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO:: HL Step 14 in InstallOrUpdate method :CHECK USER EXCEPTION" + ex.ToString());
                            //LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :CHECK USER EXCEPTION" + ex.ToString());
                            LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :CHECK USER EXCEPTION" + ex.ToString());
                            //LowTraceText.AppendLine("CHECK USER EXCEPTION" + ex.ToString());
                            return null;
                        }
                        //LowTraceText.AppendLine("PO: LL Step 34z-11 in InstallOrUpdate Method: code :" + code);
                        LowTraceText.AppendLine("PO: LL Step 34z-11 in InstallOrUpdate Method: code :" + code);
                        //LowTraceText.AppendLine("code :" + code);
                        code = "Prod";
                        if (code.Contains("Exception"))
                        {
                            return null;
                        }
                        else if (code == "" || code == string.Empty)
                        {
                            return null;
                        }
                        else if (code.Contains("Prod"))
                        {
                            app_Type = "Prod";
                        }
                        else if (code != "Prod")
                        {
                            // Current App is Pilot and user not exist in Pilot Group
                            //return null;
                            app_Type = "Pilot";
                        }
                        //--------------------------------------------
                        //LowTraceText.AppendLine("PO: LL Step 34z-11 in InstallOrUpdate Method: Update Step In File:");
                        LowTraceText.AppendLine("PO: LL Step 34z-11 in InstallOrUpdate Method: Update Step In File:");
                        //LowTraceText.AppendLine("Update Step 6g In File:");
                        string appPath = Application.StartupPath.ToString();
                        //LowTraceText.AppendLine("PO: LL Step 34z-12 in InstallOrUpdate Method: Update Step In File:");
                        LowTraceText.AppendLine("PO: LL Step 34z-12 in InstallOrUpdate Method: Update Step In File:");
                        //LowTraceText.AppendLine("Update Step 6h In File:");
                        //LowTraceText.AppendLine("PO: LL Step 34z-13 in InstallOrUpdate Method: Update Step In File:");
                        LowTraceText.AppendLine("PO: LL Step 34z-13 in InstallOrUpdate Method: Update Step In File:");
                        //LowTraceText.AppendLine("Update Step 6i In File:");

                        // Manifest file passed in could be located in a temporary install folder,
                        // so get the actual location where it eventually needs to land.
                        FileInfo localFile = new FileInfo(deploymentManifestPath);
                        localManifestFilePath = applicationBasepath + localFile.Name;

                        // Deployment manifest contains IP address and machine name filtering.
                        // If this update is not intended for this workstation, exit.
                        if (svrReader.IsAddressFilteredOut())
                        {
                            Logger.Log("Updater.InstallOrUpdate", "This update is filtered by IP address and this machine does not match the filter.  Exit Update");
                            return null;
                        }

                        // Server manifest becomes the main manifest for the rest of the process
                        xDeploymentManifest = xServerDeployment;

                        // Instantiate a reader for the deployment manifest.
                        deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                    }
                    else // Determined that the passed in manifest path is a Web server (HTTP)
                    {
                        AppInstallType = "Fresh";
                        //LowTraceText.AppendLine("PO: LL Step 34z-14 in InstallOrUpdate Method: Request is WEB");
                        LowTraceText.AppendLine("PO: LL Step 34z-14 in InstallOrUpdate Method: Request is WEB");
                        //LowTraceText.AppendLine("Request is WEB");
                        //LowTraceText.AppendLine("PO: LL Step 34z-15 in InstallOrUpdate Method: Update Step In Web Request:");
                        LowTraceText.AppendLine("PO: LL Step 34z-15 in InstallOrUpdate Method: Update Step In Web Request:");
                        //LowTraceText.AppendLine("Update Step 6a In Web Request:");
                        Logger.Log("Updater.InstallOrUpdate", "URI is not a file: " + uri.ToString());

                        // check if local file exists, if not then this is a new install, skip the filter
                        localManifestFilePath = applicationBasepath + uri.GetFileName();

                        Uri uriCheck = new Uri(deploymentReader.Codebase);

                        // case where URI passed in is not the same as the codebase uri (moved servers)
                        // so point to the new manifest.

                        if (Uri.UnescapeDataString(uriCheck.AbsoluteUri.ToLower()) != Uri.UnescapeDataString(uri.AbsoluteUri.ToLower()))
                        {
                            try
                            {
                                xDeploymentManifest = XElement.Load(Uri.UnescapeDataString(uriCheck.AbsoluteUri));

                                // get a reader for the xml manifest.
                                deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                            }
                            // cannot reach the new server, try the old one
                            catch (Exception e)
                            {
                                Debug.WriteLine(e.Message);

                                xDeploymentManifest = XElement.Load(deploymentManifestPath);
                                deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                                //LowTraceText.AppendLine("PO:: HL Step 15 in InstallOrUpdate method :UnescapeDataString EXCEPTION" + e.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("PO:: HL Step 15 in InstallOrUpdate method :UnescapeDataString EXCEPTION" + e.ToString());
                                //LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :UnescapeDataString EXCEPTION" + e.ToString());
                                LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :UnescapeDataString EXCEPTION" + e.ToString());
                            }
                        }

                        // Is this workstation filtered out? If yes then early exit.
                        // only if the app is already installed (local manifest exists)
                        if (System.IO.File.Exists(localManifestFilePath))
                        {
                            if (deploymentReader.IsAddressFilteredOut())
                            {
                                Logger.Log("Updater.InstallOrUpdate", "This update is filtered by IP address and this machine does not match the filter.  Exit Update");
                                return null;
                            }
                        }
                        // local manifest file location


                        // may exist if application already installed.
                        if (System.IO.File.Exists(localManifestFilePath))
                        {
                            Logger.Log("Updater.InstallOrUpdate", "Local manifest exists: " + localManifestFilePath + ", application assumed to be previously installed");
                            XElement xLocalManifest = null;
                            try
                            {
                                xLocalManifest = XElement.Load(localManifestFilePath);
                            }
                            catch
                            {
                            }
                            if (null != xLocalManifest)
                            {
                                DeploymentManifestReader localReader = new DeploymentManifestReader(xLocalManifest);
                                serverExeVersion = deploymentReader.Version.ToString();
                                localExeVersion = localReader.Version.ToString();
                                localAppVersion = localExeVersion;
                                Logger.Log("Updater.InstallOrUpdate", "Compare server vs. local manifest version:  Server:" + deploymentReader.Version.ToString() + "  Local:" + localReader.Version.ToString());
                                if (localReader.Version == deploymentReader.Version)
                                {
                                    return null;
                                }
                            }

                        }

                        //To Check Download with pilot/production user
                        //--------------------------------------------                   
                        try
                        {
                            string appPathWeb = Application.StartupPath.ToString();

                            string CheckUserExePath_WEB = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + @"\Axp.CheckPilotUser.exe";
                            string checkUserClientExeName_WEB = deploymentReader.ApplicationCodebase.ToString().Substring(deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") + 1, (deploymentReader.ApplicationCodebase.ToString().LastIndexOf('.') - deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") - 1));

                            string appTargetServicePath = deploymentReader.Codebase;
                            //LowTraceText.AppendLine("PO: LL Step 34z-16 in InstallOrUpdate Method: @@@@" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-16 in InstallOrUpdate Method: @@@@" + appTargetServicePath);
                            //LowTraceText.AppendLine("@@@@" + appTargetServicePath);
                            string[] service_Attributes = appTargetServicePath.Split('/');
                            //LowTraceText.AppendLine("PO: LL Step 34z-17 in InstallOrUpdate Method: @@@@" + service_Attributes[0] + "//" + service_Attributes[2]);
                            LowTraceText.AppendLine("PO: LL Step 34z-17 in InstallOrUpdate Method: @@@@" + service_Attributes[0] + "//" + service_Attributes[2]);
                            //LowTraceText.AppendLine("@@@@" + service_Attributes[0] + "//" + service_Attributes[2]);

                            //LowTraceText.AppendLine("PO: LL Step 34z-18 in InstallOrUpdate Method: WEB URI: Requested Amex Server Path 1" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-18 in InstallOrUpdate Method: WEB URI: Requested Amex Server Path 1" + appTargetServicePath);
                            //LowTraceText.AppendLine("WEB URI: Requested Amex Server Path 1" + appTargetServicePath);
                            appTargetServicePath = service_Attributes[0] + "//" + service_Attributes[2]; //appTargetServicePath.Remove(appTargetServicePath.IndexOf("DeployedApplication") - 1);
                            //LowTraceText.AppendLine("PO: LL Step 34z-19 in InstallOrUpdate Method: WEB URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-19 in InstallOrUpdate Method: WEB URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            //LowTraceText.AppendLine("WEB URI: Requested Amex Server Modified Path 2" + appTargetServicePath);
                            //added on 24/July/2013 to handle case where the path contains space - Yogesh(market release)
                            string checkUserParam_WEB = checkUserClientExeName_WEB.Replace(" ", "$") + " " + deploymentReader.Version.ToString() + " " + appTargetServicePath + " " + deploymentReader.Codebase.Replace(" ", "$");


                            //LowTraceText.AppendLine("PO: LL Step 34z-20 in InstallOrUpdate Method: @@@@ Invoke checkUser @@@@");
                            LowTraceText.AppendLine("PO: LL Step 34z-20 in InstallOrUpdate Method: @@@@ Invoke checkUser @@@@");
                            //LowTraceText.AppendLine("@@@@ Invoke checkUser @@@@");
                            //LowTraceText.AppendLine("PO: LL Step 34z-21 in InstallOrUpdate Method: Parameter :" + checkUserParam_WEB);
                            LowTraceText.AppendLine("PO: LL Step 34z-21 in InstallOrUpdate Method: Parameter :" + checkUserParam_WEB);
                            //LowTraceText.AppendLine("Parameter :" + checkUserParam_WEB);
                            Process chkUserProcess = new Process();
                            chkUserProcess.StartInfo.UseShellExecute = false;
                            chkUserProcess.StartInfo.RedirectStandardOutput = true;
                            //chkUserProcess.StartInfo.RedirectStandardError = true;

                            //LowTraceText.AppendLine("PO: LL Step 34z-22 in InstallOrUpdate Method: Check User WEB 1");
                            LowTraceText.AppendLine("PO: LL Step 34z-22 in InstallOrUpdate Method: Check User WEB 1");
                            //LowTraceText.AppendLine("Check User WEB 1");
                            //chkUserProcess.StartInfo.FileName = CheckUserExePath_WEB;
                            chkUserProcess.StartInfo.FileName = appPathWeb + @"\Axp.CheckPilotUser.exe";
                            //LowTraceText.AppendLine("PO: LL Step 34z-23 in InstallOrUpdate Method: Check User WEB 1 Old File Name=" + CheckUserExePath_WEB);
                            LowTraceText.AppendLine("PO: LL Step 34z-23 in InstallOrUpdate Method: Check User WEB 1 Old File Name=" + CheckUserExePath_WEB);
                            //LowTraceText.AppendLine("Check User WEB 1 Old File Name=" + CheckUserExePath_WEB);
                            //LowTraceText.AppendLine("PO: LL Step 34z-24 in InstallOrUpdate Method: Check User WEB 1 New File Name=" + chkUserProcess.StartInfo.FileName);
                            LowTraceText.AppendLine("PO: LL Step 34z-24 in InstallOrUpdate Method: Check User WEB 1 New File Name=" + chkUserProcess.StartInfo.FileName);
                            //LowTraceText.AppendLine("Check User WEB 1 New File Name=" + chkUserProcess.StartInfo.FileName);
                            //chkUserProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

                            chkUserProcess.StartInfo.CreateNoWindow = true;
                            chkUserProcess.StartInfo.Arguments = checkUserParam_WEB;
                            //LowTraceText.AppendLine("PO: LL Step 34z-25 in InstallOrUpdate Method: Check User WEB 2");
                            LowTraceText.AppendLine("PO: LL Step 34z-25 in InstallOrUpdate Method: Check User WEB 2");
                            //LowTraceText.AppendLine("Check User WEB 2");
                            chkUserProcess.Start();
                            //string error = chkUserProcess.StandardError.ReadToEnd();
                            code = chkUserProcess.StandardOutput.ReadToEnd();
                            //LowTraceText.AppendLine("PO: LL Step 34z-26 in InstallOrUpdate Method: Check User WEB 3" + code);
                            LowTraceText.AppendLine("PO: LL Step 34z-26 in InstallOrUpdate Method: Check User WEB 3" + code);
                            //LowTraceText.AppendLine("Check User WEB 3" + code);
                            //code = chkUserProcess.StandardOutput.ReadToEnd(); 
                            chkUserProcess.WaitForExit();
                            chkUserProcess.Close();
                            //LowTraceText.AppendLine("PO: LL Step 34z-27 in InstallOrUpdate Method: Check User WEB 4");
                            LowTraceText.AppendLine("PO: LL Step 34z-27 in InstallOrUpdate Method: Check User WEB 4");
                            //LowTraceText.AppendLine("Check User WEB 4");
                            //code = chkUserProcess.ExitCode;
                            //LowTraceText.AppendLine("PO: LL Step 34z-28 in InstallOrUpdate Method: Check User WEB 5");
                            LowTraceText.AppendLine("PO: LL Step 34z-28 in InstallOrUpdate Method: Check User WEB 5");
                            //LowTraceText.AppendLine("Check User WEB 5");
                        }
                        catch (Exception ex)
                        {
                            code = "Exception";
                            //LowTraceText.AppendLine("PO:: HL Step 16 in InstallOrUpdate method :CHECK USER EXCEPTION:" + ex.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO:: HL Step 16 in InstallOrUpdate method :CHECK USER EXCEPTION:" + ex.ToString());
                            //LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :CHECK USER EXCEPTION:" + ex.ToString());
                            LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :CHECK USER EXCEPTION:" + ex.ToString());
                            //LowTraceText.AppendLine("CHECK USER EXCEPTION:" + ex.ToString());
                            return null;
                        }
                        //LowTraceText.AppendLine("PO: LL Step 34z-29 in InstallOrUpdate Method: code: " + code);
                        LowTraceText.AppendLine("PO: LL Step 34z-29 in InstallOrUpdate Method: code: " + code);
                        //LowTraceText.AppendLine("code: " + code);
                        code = "Prod";
                        if (code.Contains("Exception"))
                        {
                            return null;
                        }
                        else if (code == "" || code == string.Empty)
                        {
                            return null;
                        }
                        else if (code.Contains("Prod"))
                        {
                            app_Type = "Prod";
                        }
                        else if (code != "Prod")
                        {
                            app_Type = "Pilot";
                        }
                    }


                    Uri uriBase = new Uri(deploymentReader.Codebase);
                    //LowTraceText.AppendLine("PO: LL Step 34z-34 in InstallOrUpdate Method: %" + deploymentReader.Codebase + "%");
                    LowTraceText.AppendLine("PO: LL Step 34z-34 in InstallOrUpdate Method: %" + deploymentReader.Codebase + "%");
                    //LowTraceText.AppendLine("%" + deploymentReader.Codebase + "%");

                    Logger.Log("Updater.InstallOrUpdate", "Codebase:" + uriBase.ToString());
                    string url = uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase;
                    url = url.Replace("\\", "/");

                    //LowTraceText.AppendLine("PO: LL Step 34z-35 in InstallOrUpdate Method: %url= " + url + "%");
                    LowTraceText.AppendLine("PO: LL Step 34z-35 in InstallOrUpdate Method: %url= " + url + "%");
                    //LowTraceText.AppendLine("%url= " + url + "%");
                    if (app_Type == "Pilot")
                    {
                        //LowTraceText.AppendLine("PO: LL Step 34z-36 in InstallOrUpdate Method: %app_Type= " + app_Type + "%");
                        LowTraceText.AppendLine("PO: LL Step 34z-36 in InstallOrUpdate Method: %app_Type= " + app_Type + "%");
                        //LowTraceText.AppendLine("%app_Type= " + app_Type + "%");
                        if (localAppVersion != string.Empty)
                        {
                            if (localAppVersion == code)
                            {
                                return null;
                            }
                            else
                            {
                                string changed = code.Replace(".", "_");
                                string originalModified = url.Remove(url.IndexOf("_") + 1, url.LastIndexOf("/") - url.IndexOf("_") - 1);
                                url = originalModified.Insert(originalModified.IndexOf("_") + 1, changed);
                                //LowTraceText.AppendLine("PO: LL Step 34z-37 in InstallOrUpdate Method: * url1 = " + url);
                                LowTraceText.AppendLine("PO: LL Step 34z-37 in InstallOrUpdate Method: * url1 = " + url);
                                //LowTraceText.AppendLine("* url1 = " + url);
                                appManifest = XElement.Load(url);
                            }
                        }
                        else
                        {
                            string changed = code.Replace(".", "_");
                            string originalModified = url.Remove(url.IndexOf("_") + 1, url.LastIndexOf("/") - url.IndexOf("_") - 1);
                            url = originalModified.Insert(originalModified.IndexOf("_") + 1, changed);
                            //LowTraceText.AppendLine("PO: LL Step 34z-38 in InstallOrUpdate Method: * url2= " + url);
                            LowTraceText.AppendLine("PO: LL Step 34z-38 in InstallOrUpdate Method: * url2= " + url);
                            //LowTraceText.AppendLine("* url2= " + url);
                            appManifest = XElement.Load(url);
                        }
                    }
                    else
                    {
                        appManifest = XElement.Load(url);
                    }

                    //Deployement Call
                    //==========================
                    //LowTraceText.AppendLine("PO: LL Step 34z-30 in InstallOrUpdate Method: Update Step ");
                    LowTraceText.AppendLine("PO: LL Step 34z-30 in InstallOrUpdate Method: Update Step ");
                    //LowTraceText.AppendLine("Update Step 7 :");

                    /// <summary>
                    ///Changes made for new enhancement
                    /// </summary> 
                    string DeployExePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + @"\Axp.GDU.Deployment_Utility.exe";

                    string ClientExeName = deploymentReader.ApplicationCodebase.ToString().Substring(deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") + 1, (deploymentReader.ApplicationCodebase.ToString().LastIndexOf('.') - deploymentReader.ApplicationCodebase.ToString().LastIndexOf(@"\") - 1));
                    if (localExeVersion == string.Empty)
                        localExeVersion = deploymentReader.Version.ToString();


                    string deployParam = string.Empty;

                    if (!code.Contains("Prod"))
                        deployParam = deploymentReader.TargetCodebase.Replace(" ", "$") + "\\" + ClientExeName.Replace(" ", "$") + " " + localExeVersion + " " + code + " " + ClientExeName.Replace(" ", "$") + " " + deploymentReader.Codebase.Replace(" ", "$");
                    else
                        deployParam = deploymentReader.TargetCodebase.Replace(" ", "$") + "\\" + ClientExeName.Replace(" ", "$") + " " + localExeVersion + " " + deploymentReader.Version.ToString() + " " + ClientExeName.Replace(" ", "$") + " " + deploymentReader.Codebase.Replace(" ", "$");

                    //LowTraceText.AppendLine("PO: LL Step 34z-31 in InstallOrUpdate Method: ######## Invoke Deployment #############");
                    LowTraceText.AppendLine("PO: LL Step 34z-31 in InstallOrUpdate Method: ######## Invoke Deployment #############");
                    //LowTraceText.AppendLine("######## Invoke Deployment #############");
                    //LowTraceText.AppendLine("PO: LL Step 34z-32 in InstallOrUpdate Method: Parameter :" + deployParam);
                    LowTraceText.AppendLine("PO: LL Step 34z-32 in InstallOrUpdate Method: Parameter :" + deployParam);
                    //LowTraceText.AppendLine("Parameter :" + deployParam);
                    Process process = new Process();
                    process.StartInfo.FileName = DeployExePath;
                    process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    process.StartInfo.Arguments = deployParam;
                    process.Start();

                    //LowTraceText.AppendLine("PO: LL Step 34z-33 in InstallOrUpdate Method: ## Deployment Done ##");
                    LowTraceText.AppendLine("PO: LL Step 34z-33 in InstallOrUpdate Method: ## Deployment Done ##");
                    //LowTraceText.AppendLine("## Deployment Done ##");
                    //System.Diagnostics.Process.Start(DeployExePath, deployParam);

                    //==========================
                    /// <summary>
                    ///Changes made for new enhancement
                    /// </summary> 
                    try
                    {
                        GetIconPath = deploymentReader.TargetCodebase + @"\" + ((System.Xml.Linq.XElement)(appManifest.FirstNode.NextNode)).FirstAttribute.Value;
                        //LowTraceText.AppendLine("PO: LL Step 34z-39 in InstallOrUpdate Method: Icon Path :" + GetIconPath);
                        LowTraceText.AppendLine("PO: LL Step 34z-39 in InstallOrUpdate Method: Icon Path :" + GetIconPath);
                        //LowTraceText.AppendLine("Icon Path :" + GetIconPath);
                    }
                    catch
                    {
                    }
                    //LowTraceText.AppendLine("PO: LL Step 34z-40 in InstallOrUpdate Method: #####################");
                    LowTraceText.AppendLine("PO: LL Step 34z-40 in InstallOrUpdate Method: #####################");
                    //LowTraceText.AppendLine("#####################");
                    string localAppManifest = Path.Combine("", deploymentReader.ApplicationCodebase);

                    string tempDest = "";
                    bool bDownloadOk = false;
                    bool bProcessOk = false;
                    bool bCommitOk = false;
                    bool bSaveAppManifestOk = false;
                    bool bSaveDepManifestOk = false;
                    bool bRegisterOk = false;
                    try
                    {
                        Uri localApp = new Uri(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                        string localAppManifestPath = applicationBasepath + localApp.GetFileName();
                        XElement xLocalAppManifest = null;
                        if (System.IO.File.Exists(localAppManifestPath))
                        {
                            try
                            {

                                xLocalAppManifest = XElement.Load(localAppManifestPath);
                            }
                            catch (Exception e)
                            {
                                //LowTraceText.AppendLine("PO:: HL Step 17 in InstallOrUpdate method :System.IO.File.Exists(localAppManifestPath) Exception" + e.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("PO:: HL Step 17 in InstallOrUpdate method :System.IO.File.Exists(localAppManifestPath) Exception" + e.ToString());
                                //LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :System.IO.File.Exists(localAppManifestPath) Exception" + e.ToString());
                                LowTraceText.AppendLine("PO:: LL in InstallOrUpdate method :System.IO.File.Exists(localAppManifestPath) Exception" + e.ToString());
                                Logger.Log(e);
                            }
                        }

                        //setup progress bar
                        //LowTraceText.AppendLine("PO: LL Step 34z-41 in InstallOrUpdate Method: Enter In Progress bar");
                        LowTraceText.AppendLine("PO: LL Step 34z-41 in InstallOrUpdate Method: Enter In Progress bar");
                        // LowTraceText.AppendLine("Step 8: Enter In Progress bar");

                        if (!code.Contains("Prod"))
                            progress = Progress.CreateProgressBar(deploymentReader.Name, code);
                        else
                            progress = Progress.CreateProgressBar(deploymentReader.Name, deploymentReader.Version);

                        // Start the download of the application files.
                        //LowTraceText.AppendLine("PO: LL Step 34z-42 in InstallOrUpdate Method: Calling  Download method - Start Download Files");
                        LowTraceText.AppendLine("PO: LL Step 34z-42 in InstallOrUpdate Method: Calling  Download method - Start Download Files");
                    //LowTraceText.AppendLine("Step 9: Start Download Files");
                    Partial:
                        IsException = null;
                        tempDest = Download(appManifest, xLocalAppManifest, xDeploymentManifest, applicationBasepath, code);
                        LowTraceText.AppendLine("PO: LL Step 34z-42.23 in InstallOrUpdate Method: Came out of  Download method in Updater Class ");

                        if (IsException == "DownloadingException" && AppInstallType == "Update")
                        {
                            LowTraceText.AppendLine("PO: LL Step 34z-43 in InstallOrUpdate Method: Partial Changes 1# IsException= " + IsException + " & AppInstallType= " + AppInstallType);
                            LowTraceText.AppendLine("PO: LL Step 34z-43 in InstallOrUpdate Method: Partial Changes 1# IsException= " + ConfigurationSettings.AppSettings["DownloadErrorMSG"].ToString());

                            if (System.Windows.Forms.MessageBox.Show(downloadException, ConfigurationSettings.AppSettings["DownloadErrorMSG"].ToString(), MessageBoxButtons.RetryCancel) == System.Windows.Forms.DialogResult.Retry)
                            {
                                LowTraceText.AppendLine("PO: LL Step 34z-44 in InstallOrUpdate Method: Partial Changes 2# User Is Retrying");

                                if (progress != null)
                                {
                                    progress.ReSetProgressBar(0);
                                }
                                goto Partial;
                            }
                            else
                            {
                                try
                                {
                                    Directory.Delete(tempDest, true);
                                }
                                catch (Exception ex)
                                {
                                }
                            }
                        }

                        if ((IsException != "DownloadingException") || (IsException == "DownloadingException" && AppInstallType == "Fresh"))
                        {
                            LowTraceText.AppendLine("PO: LL Step 34z-45 in InstallOrUpdate Method: Partial Changes 3# IsException= " + IsException + " & AppInstallType= " + AppInstallType);
                            //LowTraceText.AppendLine("Partial Changes 3# IsException= " + IsException + " & AppInstallType= " + AppInstallType);
                            bDownloadOk = true;
                            // Application fils have been downloaded, move them to target location
                            LowTraceText.AppendLine("PO: LL Step 34z-47 in InstallOrUpdate Method: Calling MoveAndProcessFiles method in Updater class");
                            MoveAndProcessFiles(appManifest, applicationBasepath, tempDest);
                            LowTraceText.AppendLine("PO: LL Step 34z-47.2 in InstallOrUpdate Method: Came out of MoveAndProcessFiles method in Updater class");
                            bProcessOk = true;
                            // Up to now all good, commit the downloaded files.
                            LowTraceText.AppendLine("PO: LL Step 34z-48 in InstallOrUpdate Method: Calling CommitInstall method in Updater class");
                            CommitInstall(appManifest, applicationBasepath, tempDest);
                            LowTraceText.AppendLine("PO: LL Step 34z-48.2 in InstallOrUpdate Method: Came out of CommitInstall method in Updater class");
                            bCommitOk = true;
                            // Register any COM or IE add-ins.
                            LowTraceText.AppendLine("PO: LL Step 34z-49 in InstallOrUpdate Method: Calling RegisterFiles method in Updater class");
                            RegisterFiles(appManifest, xDeploymentManifest, applicationBasepath);
                            LowTraceText.AppendLine("PO: LL Step 34z-49.3 in InstallOrUpdate Method: Came out of RegisterFiles method ");
                            bSaveDepManifestOk = true;


                            //Added for handling space in file name
                            LowTraceText.AppendLine("PO: LL Step 34z-50 in InstallOrUpdate Method: Amex File  Destination Path1= " + localManifestFilePath);
                            //LowTraceText.AppendLine("Amex File  Destination Path1= " + localManifestFilePath);
                            localManifestFilePath = Uri.UnescapeDataString(localManifestFilePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-51 in InstallOrUpdate Method: Amex File Destination Path2= " + Uri.UnescapeDataString(localManifestFilePath));
                            //LowTraceText.AppendLine("Amex File Destination Path2= " + Uri.UnescapeDataString(localManifestFilePath));


                            // save deployment & Application manifests locally
                            xDeploymentManifest.Save(localManifestFilePath);
                            LowTraceText.AppendLine("PO: LL Step 34z-52 in InstallOrUpdate Method: App Type AMEX SAVE" + code);
                            //LowTraceText.AppendLine("App Type AMEX SAVE" + code);



                            if ((!code.Contains("Prod")) || (IsException == "DownloadingException" && AppInstallType == "Fresh"))
                            {
                                if (IsException == "DownloadingException" && AppInstallType == "Fresh")
                                {
                                    code = "0.0.0.1";
                                }

                                StringBuilder newFile = new StringBuilder();
                                string UpdatedVer = string.Empty;
                                string temp = "";

                                string[] file = System.IO.File.ReadAllLines(localManifestFilePath);
                                foreach (string line in file)
                                {

                                    if (line.Contains(deploymentReader.Version.ToString()))
                                    {
                                        temp = line.Replace(deploymentReader.Version.ToString(), code);
                                        newFile.Append(temp + "\r\n");
                                        continue;
                                    }
                                    else if (line.Contains(deploymentReader.Version.ToString().Replace('.', '_')))
                                    {
                                        temp = line.Replace(deploymentReader.Version.ToString().Replace('.', '_'), code.Replace('.', '_'));
                                        newFile.Append(temp + "\r\n");
                                        continue;
                                    }
                                    newFile.Append(line + "\r\n");
                                }
                                System.IO.File.WriteAllText(localManifestFilePath, newFile.ToString());

                            }


                            bSaveDepManifestOk = true;
                            //Uri localApp = new Uri(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                            //string localAppManifestPath = applicationBasepath + localApp.GetFileName();
                            //if(System.IO.File.Exists(localAppManifestPath))
                            //    System.IO.File.Delete(localAppManifestPath);

                            //Added for handling space in file name                    
                            //LowTraceText.AppendLine("Manifest File  Destination Path1= " + localAppManifestPath);
                            //localAppManifestPath = Uri.UnescapeDataString(localAppManifestPath);
                            //LowTraceText.AppendLine("Manifest File Destination Path2= " + Uri.UnescapeDataString(localAppManifestPath));

                            //LowTraceText.AppendLine("** Manifest File type" + ManifestFileType);

                            //if (ManifestFileType == ".appmanifest")
                            //    appManifest.Save(localAppManifestPath.Remove(localAppManifestPath.LastIndexOf('.')) + ".appmanifest");
                            //else
                            //    appManifest.Save(localAppManifestPath.Remove(localAppManifestPath.LastIndexOf('.')) + ".manifest");

                            //bSaveAppManifestOk = true;

                            //Added for handling space in file name 
                            LowTraceText.AppendLine("PO: LL Step 34z-53 in InstallOrUpdate Method: Manifest File  Destination Path1= " + localAppManifestPath);
                            //LowTraceText.AppendLine("Manifest File  Destination Path1= " + localAppManifestPath);
                            localAppManifestPath = Uri.UnescapeDataString(localAppManifestPath);
                            LowTraceText.AppendLine("PO: LL Step 34z-54 in InstallOrUpdate Method: Manifest File Destination Path2= " + Uri.UnescapeDataString(localAppManifestPath));
                            //LowTraceText.AppendLine("Manifest File Destination Path2= " + Uri.UnescapeDataString(localAppManifestPath));
                            appManifest.Save(localAppManifestPath);

                            //To remove custom attribute in manifets file

                            try
                            {
                                XmlDocument xmldoc = new XmlDocument();
                                xmldoc.Load(localAppManifestPath);
                                XmlNodeList xmlRootnode = xmldoc.GetElementsByTagName("asmv2:file");
                                foreach (XmlNode xNode in xmlRootnode)
                                {
                                    xNode.Attributes.RemoveNamedItem("NeverOverwrite");
                                    xNode.Attributes.RemoveNamedItem("AutoExtract");
                                    //xNode.Attributes.Remove(xNode.Attributes["AutoExtract"]);
                                }
                                xmldoc.Save(localAppManifestPath);
                            }
                            catch (Exception ex)
                            {

                                //LowTraceText.AppendLine("Po: HL Step 28 in InstallOrUpdate method: localAppManifestPath Exception" + ex.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("Po: LL in InstallOrUpdate method: localAppManifestPath Exception" + ex.ToString());
                            }
                            bSaveAppManifestOk = true;

                        }
                    }
                    catch (Exception ex)
                    {
                        // If we reach here, we need to rollback, something went wrong.
                        Logger.Log(ex);
                        //LowTraceText.AppendLine("Po: HL Step 29 in InstallOrUpdate method: Exception  And Rollback=" + ex.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("Po: HL Step 29 in InstallOrUpdate method: Exception  And Rollback=" + ex.ToString());
                        LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: Exception  And Rollback=" + ex.ToString());
                        //LowTraceText.AppendLine("Step 10: Exception And Rollback= " + ex);
                        RollbackInstall(appManifest,
                                        applicationBasepath,
                                        tempDest,
                                        bDownloadOk,
                                        bProcessOk,
                                        bCommitOk,
                                        bSaveAppManifestOk,
                                        bSaveDepManifestOk,
                                        bRegisterOk);

                        if (!Progress.UserCancelled)
                        {
                            if (xDeploymentManifest != null && string.Empty != localManifestFilePath)
                            {
                                try
                                {
                                    Uri uriLocal = new Uri(localManifestFilePath);
                                    if (uri.IsFile)
                                        xDeploymentManifest.Save(localManifestFilePath);
                                }
                                catch (Exception e)
                                {
                                    Logger.Log(e);
                                    //LowTraceText.AppendLine("Po: HL Step 30 in InstallOrUpdate method: Exception(if(!Progress.UserCancelled) " + ex.ToString(), HighTraceInfo);
                                    HighTraceText.AppendLine("Po: HL Step 30 in InstallOrUpdate method: Exception(if(!Progress.UserCancelled) " + ex.ToString());
                                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: Exception(if(!Progress.UserCancelled) " + ex.ToString());
                                }
                            }
                            try
                            {
                                if (null != appManifest && string.Empty != localManifestFilePath)
                                {
                                    Uri localApp = new Uri(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    string localAppManifestPath = applicationBasepath + localApp.GetFileName();
                                    appManifest.Save(localAppManifestPath);
                                }
                            }
                            catch (Exception ex1)
                            {

                                Logger.Log(ex1);
                                //LowTraceText.AppendLine("Po: HL Step 31 in InstallOrUpdate method: Exception " + ex1.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("Po: HL Step 31 in InstallOrUpdate method: Exception " + ex1.ToString());
                                LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: Exception " + ex1.ToString());
                            }
                        }
                    }

                    return xDeploymentManifest;
                }
                catch (Exception ex2)
                {
                    //LowTraceText.AppendLine("Exception:" + ex2.ToString());
                    //LowTraceText.AppendLine("Po: HL Step 32 in InstallOrUpdate method: Exception:" + ex2.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 32 in InstallOrUpdate method: Exception:" + ex2.ToString());
                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: Exception:" + ex2.ToString());
                    //LowTraceText.AppendLine("$$$$$$$$$");
                    //LowTraceText.AppendLine("Po: HL Step 33 in InstallOrUpdate method: Exception:" + ex2.StackTrace, HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 33 in InstallOrUpdate method: Exception:" + ex2.StackTrace);
                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: Exception:" + ex2.StackTrace);
                    //LowTraceText.AppendLine("Exception:" + ex2.StackTrace);
                    Logger.Log(ex2);
                    throw;
                }
                finally
                {
                    if (null != deploymentReader)
                    {
                        Launch &= deploymentReader.Launch;
                        if (Launch)
                        {

                            //Download Configurations from server
                            try
                            {
                                string serverUri = deploymentReader.Codebase.Substring(0, deploymentReader.Codebase.LastIndexOf("/") + 1);
                                ReleaseConfig.DownloadConfiguration(deploymentReader.TargetCodebase, serverUri);
                            }
                            catch (Exception ex)
                            {

                                Logger.Log("ReleaseConfig.DownloadConfiguration", "Download configuration Failed.");
                                Logger.Log("ReleaseConfig.DownloadConfiguration", "localPath: " + deploymentReader.TargetCodebase);
                                Logger.Log("ReleaseConfig.DownloadConfiguration", "serverPath: " + deploymentReader.Codebase);
                                Logger.Log(ex);
                                //LowTraceText.AppendLine("Po: HL Step 34 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration :Download configuration Failed:" + ex.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("Po: HL Step 34 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration :Download configuration Failed:" + ex.ToString());
                                LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration :Download configuration Failed:" + ex.ToString());
                                //LowTraceText.AppendLine("Po: HL Step 35 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration: localPath: " + deploymentReader.TargetCodebase, HighTraceInfo);
                                HighTraceText.AppendLine("Po: HL Step 35 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration: localPath: " + deploymentReader.TargetCodebase);
                                LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration: localPath: " + deploymentReader.TargetCodebase);
                                //LowTraceText.AppendLine("Po: HL Step 36 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration:: serverPath: " + deploymentReader.Codebase, HighTraceInfo);
                                HighTraceText.AppendLine("Po: HL Step 36 in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration:: serverPath: " + deploymentReader.Codebase);
                                LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ReleaseConfig.DownloadConfiguration:: serverPath: " + deploymentReader.Codebase);
                            }

                            if (null == appManifest)
                            {
                                Uri uriBase = new Uri(deploymentReader.Codebase);
                                try
                                {
                                    LowTraceText.AppendLine("PO: LL Step 34z-55 in InstallOrUpdate Method: ** Manifest File path **");
                                    //LowTraceText.AppendLine("** Manifest File path **");
                                    LowTraceText.AppendLine("PO: LL Step 34z-56 in InstallOrUpdate Method: Manifest File path " + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    //LowTraceText.AppendLine(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    appManifest = XElement.Load(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                }
                                catch (Exception ex)
                                {
                                    //LowTraceText.AppendLine("Po: HL Step 37 in InstallOrUpdate method: ## Reading Manifest Exception", HighTraceInfo);
                                    HighTraceText.AppendLine("Po: HL Step 37 in InstallOrUpdate method: ## Reading Manifest Exception");
                                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ## Reading Manifest Exception");
                                    //LowTraceText.AppendLine("## Reading Manifest Exception:");
                                    //LowTraceText.AppendLine("Po: HL Step 38 in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase, HighTraceInfo);
                                    HighTraceText.AppendLine("Po: HL Step 38 in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    //LowTraceText.AppendLine(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    //LowTraceText.AppendLine("Po: HL Step 39 in InstallOrUpdate method: ## Reading Manifest Exception" + ex.ToString(), HighTraceInfo);
                                    HighTraceText.AppendLine("Po: HL Step 39 in InstallOrUpdate method: ## Reading Manifest Exception" + ex.ToString());
                                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ## Reading Manifest Exception" + ex.ToString());
                                    //LowTraceText.AppendLine(ex.ToString());
                                    //LowTraceText.AppendLine("Po: HL Step 40 in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase, HighTraceInfo);
                                    HighTraceText.AppendLine("Po: HL Step 40 in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    LowTraceText.AppendLine("Po: LL in InstallOrUpdate method: ## Reading Manifest Exception" + uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    //LowTraceText.AppendLine(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                }
                                if (null == appManifest)
                                {
                                    LowTraceText.AppendLine("PO: LL Step 34z-57 in InstallOrUpdate Method: In Check Manifest null: ");
                                    //LowTraceText.AppendLine("In Check Manifest null:");
                                    Uri localApp = new Uri(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                                    string localAppManifestPath = applicationBasepath + localApp.GetFileName();
                                    uriBase = new Uri(localAppManifestPath);
                                    appManifest = XElement.Load(uriBase.LocalPath);
                                }
                            }
                            if (null != appManifest)
                                LowTraceText.AppendLine("PO: LL Step 34z-58 in InstallOrUpdate Method: Calling LaunchExe method defined in Updater class ");
                            Updater.LaunchExe(applicationBasepath, appManifest, xDeploymentManifest, args);
                            LowTraceText.AppendLine("PO: LL Step 34z-58.3 in InstallOrUpdate Method: Came out of LaunchExe method defined in Updater class ");
                        }
                    }
                    progress.StopProgress();
                    Logger.Exit("Updater.InstallOrUpdate");
                }
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void RegisterFiles(XElement appManifest, XElement xDeploymentManifest, string applicationBasepath)
        {

            try
            {

                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                ApplicationManifestReader aReader = new ApplicationManifestReader(appManifest);
                DeploymentManifestReader dReader = new DeploymentManifestReader(xDeploymentManifest);
                IEnumerable<XElement> comRegs = aReader.GetAssemblyRegistrations(ApplicationManifestReader.RegistrationType.COM);
                IEnumerable<XElement> asmRegs = aReader.GetAssemblyRegistrations(ApplicationManifestReader.RegistrationType.RegAsm);
                IEnumerable<XElement> comUnManaged = aReader.GetComRegistrations();
                //LowTraceText.AppendLine("PO: HL in RegisterFiles method: Entered into RegisterFiles method in Updater class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in RegisterFiles method: Entered into RegisterFiles method in Updater class");
                LowTraceText.AppendLine("PO: LL Step 34z-49.1 in RegisterFiles method: Entered into RegisterFiles method in Updater class");
                foreach (XElement comReg in comRegs)
                {
                    try
                    {
                        LowTraceText.AppendLine("PO: LL Step 34z-49.2 in RegisterFiles Method: Calling RegSvr32 method defined in  ComponentRegistrar class");
                        ComponentRegistrar.RegSvr32(applicationBasepath + comReg.Attribute("codebase").Value, "/i");

                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                        //LowTraceText.AppendLine("PO:: HL Step 25 in RegisterFiles method :RegisterFiles method, Catch-1 Exception" + e.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO:: HL Step 25 in RegisterFiles method :RegisterFiles method, Catch-1 Exception" + e.ToString());
                        LowTraceText.AppendLine("PO:: LL in RegisterFiles method :RegisterFiles method, Catch-1 Exception" + e.ToString());
                    }

                }
                foreach (XElement asmReg in asmRegs)
                {
                    try
                    {
                        ComponentRegistrar.Regasm(applicationBasepath + asmReg.Attribute("codebase").Value, "/u");
                        ComponentRegistrar.Regasm(applicationBasepath + asmReg.Attribute("codebase").Value, "/codebase");
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                        //LowTraceText.AppendLine("PO:: HL Step 26 in RegisterFiles method :RegisterFiles method, Catch-2 Exception" + e.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO:: HL Step 26 in RegisterFiles method :RegisterFiles method, Catch-2 Exception" + e.ToString());
                        LowTraceText.AppendLine("PO:: LL in RegisterFiles method :RegisterFiles method, Catch-2 Exception" + e.ToString());
                    }

                }
                foreach (XElement unmanCom in comUnManaged)
                {
                    string dll = unmanCom.Attribute("name").Value;
                    string dllPath = Path.Combine(applicationBasepath, dll);
                    ComponentRegistrar.RegSvr32(dllPath, "/i");
                }
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void UnRegisterFiles(XElement appManifest, XElement xDeploymentManifest, string applicationBasepath)
        {
            try
            {

                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
            ApplicationManifestReader aReader = new ApplicationManifestReader(appManifest);
            DeploymentManifestReader dReader = new DeploymentManifestReader(xDeploymentManifest);
            IEnumerable<XElement> comRegs = aReader.GetAssemblyRegistrations(ApplicationManifestReader.RegistrationType.COM);
            IEnumerable<XElement> asmRegs = aReader.GetAssemblyRegistrations(ApplicationManifestReader.RegistrationType.RegAsm);
            //LowTraceText.AppendLine("PO: HL in UnRegisterFiles Method : Entered into UnRegisterFiles method defined in Updater Class", HighTraceInfo);
            HighTraceText.AppendLine("PO: HL in UnRegisterFiles Method : Entered into UnRegisterFiles method defined in Updater Class");
            LowTraceText.AppendLine("PO: LL Step 35g in UnRegisterFiles Method : Entered into UnRegisterFiles method defined in Updater Class");
            foreach (XElement comReg in comRegs)
            {
                try
                {
                    LowTraceText.AppendLine("PO: LL Step 35h in UnRegisterFiles Method : Calling RegSvr32 method defined in ComponentRegistrar Class");
                    ComponentRegistrar.RegSvr32(applicationBasepath + comReg.Attribute("codebase").Value, "/u");
                    LowTraceText.AppendLine("PO: LL Step 35i in UnRegisterFiles Method : Came out of RegSvr32 method defined in ComponentRegistrar Class");
                }
                catch (Exception e)
                {
                    Logger.Log(e);
                    //LowTraceText.AppendLine("Po: HL Step 44 in UnRegisterFiles method: UnRegisterFiles method Catch-1 Exception" + e.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 44 in UnRegisterFiles method: UnRegisterFiles method Catch-1 Exception" + e.ToString());
                    LowTraceText.AppendLine("Po: LL in UnRegisterFiles method: UnRegisterFiles method Catch-1 Exception" + e.ToString());
                }

            }
            foreach (XElement asmReg in asmRegs)
            {
                try
                {
                    LowTraceText.AppendLine("PO: LL Step 35j in UnRegisterFiles Method : Calling Regasm method defined in ComponentRegistrar Class");
                    ComponentRegistrar.Regasm(applicationBasepath + asmReg.Attribute("codebase").Value, "/u");
                    LowTraceText.AppendLine("PO: LL Step 35l in UnRegisterFiles Method : Came out of Regasm method defined in ComponentRegistrar Class");
                }
                catch (Exception e)
                {
                    Logger.Log(e);
                    //LowTraceText.AppendLine("Po: HL Step 45 in UnRegisterFiles method: UnRegisterFiles method Catch-2 Exception" + e.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 45 in UnRegisterFiles method: UnRegisterFiles method Catch-2 Exception" + e.ToString());
                    LowTraceText.AppendLine("Po: LL in UnRegisterFiles method: UnRegisterFiles method Catch-2 Exception" + e.ToString());
                }

            }
            IEnumerable<XElement> comUnManaged = aReader.GetComRegistrations();
            foreach (XElement unmanCom in comUnManaged)
            {
                string dll = unmanCom.Attribute("name").Value;
                string dllPath = Path.Combine(applicationBasepath, dll);
                LowTraceText.AppendLine("PO: LL Step 35m in UnRegisterFiles Method : Calling RegSvr32 method defined in ComponentRegistrar Class");
                ComponentRegistrar.RegSvr32(dllPath, "/u");
                LowTraceText.AppendLine("PO: LL Step 35n in UnRegisterFiles Method : Came out of RegSvr32 method defined in ComponentRegistrar Class");
            }
        }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(),LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }


        /// <summary>
        /// Synchronous download of application files.
        /// </summary>
        /// <returns>Location where files are temporarily copied.</returns>
        /// <param name="applicationManifestUrl"></param>
        public static string Download(XElement xAppManifest, XElement xLocalAppManifest, XElement xDeployManifest, string destPath, string app_Type)
        {
            try
            {

                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in Download Method : Entered into Download method defined in Updater Class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in Download Method : Entered into Download method defined in Updater Class");
                LowTraceText.AppendLine("PO: LL Step 34z-42.1 in Download Method: Entered into Download method defined in Updater Class");
                Logger.Enter("Updater.Download", new string[] { xDeployManifest.ToString(), destPath });

                string tempDest = destPath + tempDirectoryName;
                if (!Directory.Exists(tempDest))
                    Directory.CreateDirectory(tempDest);
                LowTraceText.AppendLine("PO: LL Step 34z-42.2 in Download Method: Calling DownloadSyncInternal method defined in Updater Class");
                //LowTraceText.AppendLine("Step 9a: Call Download");
                DownloadSyncInternal(xAppManifest, xLocalAppManifest, xDeployManifest, destPath, tempDest, app_Type);
                LowTraceText.AppendLine("PO: LL Step 34z-42.22 in Download Method: Came out of  DownloadSyncInternal method in Updater Class ");
                return tempDest;

            }
            finally
            {
                Logger.Exit("Updater.Download");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }


        /// <summary>
        /// Moves files from the temporary download folder to the final folder. Each of these files
        /// will contain a .deploy extension as to not conflict with exiting... Then the existing
        /// files will be renamed to include a .backup extension (for rollback if necessary) 
        /// 
        /// Finally, custom actions if they exist are run.
        /// </summary>
        /// <param name="appManifest">Application manifest XML</param>
        /// <param name="appBaseDirectory">Base folder of the application.</param>
        private static void MoveAndProcessFiles(XElement appManifest, string appBaseDirectory, string tempDirectory)
        {
            try
            {
                Logger.Enter("Updater.MoveAndProcessFiles", new string[] { appManifest.ToString(), appBaseDirectory });
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                // name of the temporary folder where files were downloaded.
                //string tempDirectory = appBaseDirectory+tempDirectoryName;
                try
                {
                    //LowTraceText.AppendLine("AW:: HL in MoveAndProcessFiles method: Entered into MoveAndProcessFiles method in Updater class", HighTraceInfo);
                    HighTraceText.AppendLine("AW:: HL in MoveAndProcessFiles method: Entered into MoveAndProcessFiles method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34z-47.1 in InstallOrUpdate Method: Entered into MoveAndProcessFiles method in Updater class");
                    DirectoryInfo di = new DirectoryInfo(tempDirectory);

                    Logger.Log("Updater.MoveAndProcessFiles", "Temp Folder: " + di.FullName);

                    // Load the application manifest XML into a reader to get the values.
                    ApplicationManifestReader reader = new ApplicationManifestReader(appManifest);
                    // first move files in the root folder, only these files will have possible code to run.
                    //<<<<<<< .mine
                    //FileInfo[] files = di.GetFiles();
                    //IEnumerable<XElement> xDependencies =  reader.GetInstallableDependencies();
                    IEnumerable<XElement> codeFiles = reader.GetInstallableDependencies(isClickOnceManifest);
                    FileInfo file = null;

                    string codebaseXpath = isClickOnceManifest ? "codebase" : "name";

                    if (progress != null)
                    {
                        progress.SetCurrentOperation("Committing assemblies...");
                    }

                    foreach (XElement codeFile in codeFiles)
                    {
                        string codebase = (string)codeFile.Attribute(codebaseXpath);
                        string destination = Path.Combine(appBaseDirectory, codebase);
                        string finalDest = destination;
                        destination += ".deploy";
                        //=======
                        //                IEnumerable<XElement> codeFiles = reader.GetInstallableDependencies(isClickOnceManifest);
                        //Move assembly and root files 1 by 1
                        //>>>>>>> .r10628

                        //<<<<<<< .mine
                        string srcFile = Path.Combine(tempDirectory, codebase + ".deploy");
                        file = new FileInfo(srcFile);
                        if (System.IO.File.Exists(srcFile))
                        {

                            //}
                            ////Move assembly and root files 1 by 1

                            //foreach (FileInfo file in files)
                            //{
                            //=======
                            //string codebaseXpath = isClickOnceManifest ? "codebase" : "name";

                            //if (progress != null) {
                            //    progress.SetCurrentOperation("Committing assemblies...");
                            //}
                            //foreach (XElement codeFile in codeFiles)
                            //{
                            //>>>>>>> .r10628

                            if (progress != null)
                            {
                                if (progress.UpdateProgress(codeFile.Attribute(codebaseXpath).Value))
                                    throw new Exception("User cancelled update.");
                            }

                            //                    string srcDir = tempDirectory + "\\" + codeFile.Attribute(codebaseXpath).Value + ".deploy";
                            //                    FileInfo file = new FileInfo(srcDir);

                            bool isAssembly = false;
                            //<<<<<<< .mine
                            //string destination = appBaseDirectory + file.Name;
                            //string finalDest = destination.Replace(".deploy", "");
                            //=======
                            //string destination = appBaseDirectory + codeFile.Attribute(codebaseXpath).Value + ".deploy";
                            //string finalDest = destination.Replace(".deploy", "");
                            //>>>>>>> .r10628

                            FileInfo destFi = new FileInfo(finalDest);
                            if (!destFi.Directory.Exists)
                            {
                                destFi.Directory.Create();
                            }

                            // Does the destination exist?
                            if (System.IO.File.Exists(finalDest))
                            {
                                // check version if assembly, datetime otherwise

                                if (file.Name.EndsWith(".dll.deploy") || file.Name.EndsWith(".exe.deploy"))
                                {
                                    Assembly assembly = null;
                                    byte[] AssemblyByteArray = null;
                                    try
                                    {
                                        // This is a test to determine if the file is a .NET assembly
                                        Uri dst = new Uri(finalDest);
                                        Uri src = new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                                        if (src.GetFileName().ToLower() == dst.GetFileName().ToLower())
                                        {
                                            assembly = System.Reflection.Assembly.GetExecutingAssembly();
                                        }
                                        else
                                        {
                                            AssemblyByteArray =
                                            System.IO.File.ReadAllBytes(finalDest);
                                            assembly = Assembly.Load(AssemblyByteArray);
                                        }
                                        isAssembly = true;
                                    }
                                    catch (Exception e)
                                    {
                                        Logger.Log(e);
                                        //LowTraceText.AppendLine("PO:: HL Step 18 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-1 Exception" + e.ToString(), HighTraceInfo);
                                        HighTraceText.AppendLine("PO:: HL Step 18 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-1 Exception" + e.ToString());
                                        LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-1 Exception" + e.ToString());
                                    }
                                    // .NET Assembly Processing
                                    if (isAssembly)
                                    {
                                        Logger.Log("Updater.MoveAndProcessFiles", "File " + file.FullName + " is a .NET Assembly file");
                                        byte[] AssemblyNewByteArray =
                                        System.IO.File.ReadAllBytes(file.FullName);

                                        Assembly newAssembly = Assembly.Load(AssemblyNewByteArray);

                                        Logger.Log("Updater.MoveAndProcessFiles", "Compare assembly versions" + "CURRENT:" + assembly.GetName().Version.ToString() + "   NEW:" + newAssembly.GetName().Version.ToString());
                                        // Check version to see if need to update.
                                        if (assembly.GetName().Version != newAssembly.GetName().Version)
                                        {
                                            Logger.Log("Updater.MoveAndProcessFiles", "Rename file " + finalDest + " to " + finalDest + backupSuffix);
                                            //File.Replace(file.FullName, destination, destination + backupSuffix);
                                            string backup = finalDest + backupSuffix;
                                            try
                                            {
                                                Logger.Log("Updater.MoveAndProcessFiles", "Clear out backup file if it exists from previous operation");
                                                if (System.IO.File.Exists(backup))
                                                    System.IO.File.Delete(backup);
                                            }
                                            catch (Exception bkE)
                                            {

                                                Logger.Log(bkE);
                                                //LowTraceText.AppendLine("PO:: HL Step 19 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-2 Exception" + bkE.ToString(), HighTraceInfo);
                                                HighTraceText.AppendLine("PO:: HL Step 19 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-2 Exception" + bkE.ToString());
                                                LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-2 Exception" + bkE.ToString());
                                            }
                                            //bool skipCopy = false;
                                            System.IO.File.Move(finalDest, backup);
                                            Logger.Log("Updater.MoveAndProcessFiles", "Delete file " + finalDest);
                                            Logger.Log("Updater.MoveAndProcessFiles", "Copy File " + file.FullName + " to " + destination);
                                            // copy new file with a .deploy extension - later to be renamed.
                                            try
                                            {
                                                System.IO.File.Copy(file.FullName, destination);
                                            }
                                            catch (Exception cpyEx)
                                            {
                                                Logger.Log(cpyEx);
                                                //LowTraceText.AppendLine("PO:: HL Step 20 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-3 Exception" + cpyEx.ToString(), HighTraceInfo);
                                                HighTraceText.AppendLine("PO:: HL Step 20 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-3 Exception" + cpyEx.ToString());
                                                LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-3 Exception" + cpyEx.ToString());
                                                bool failSafe = reader.IsAssemblyFailSafe(assembly.GetName().Name);
                                                if (!failSafe)
                                                    throw;
                                            }
                                        }
                                    }
                                    else // not an assembly
                                    {
                                        FileInfo fiDest = new FileInfo(finalDest);
                                        if (fiDest.LastWriteTime.CompareTo(file.LastWriteTime) != 0)
                                        {
                                            string backupFile = finalDest + backupSuffix;
                                            //File.Replace(file.FullName, destination, destination + backupSuffix);
                                            Logger.Log("Updater.MoveAndProcessFiles", "Rename file " + finalDest + " to " + backupFile);
                                            try
                                            {
                                                if (System.IO.File.Exists(backupFile))
                                                    System.IO.File.Delete(backupFile);
                                            }
                                            catch (Exception e)
                                            {
                                                Logger.Log(e);
                                                //LowTraceText.AppendLine("PO:: HL Step 21 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-4 Exception" + e.ToString(), HighTraceInfo);
                                                HighTraceText.AppendLine("PO:: HL Step 21 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-4 Exception" + e.ToString());
                                                LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-4 Exception" + e.ToString());
                                            }
                                            //
                                            bool skipCopy = false;
                                            try
                                            {
                                                System.IO.File.Move(finalDest, backupFile);
                                            }
                                            catch (Exception delExp)
                                            {
                                                Logger.Log(delExp);
                                                //LowTraceText.AppendLine("PO:: HL Step 22 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-5 Exception" + delExp.ToString(), HighTraceInfo);
                                                HighTraceText.AppendLine("PO:: HL Step 22 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-5 Exception" + delExp.ToString());
                                                LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-5 Exception" + delExp.ToString());
                                                bool failSafe = reader.IsFileFailSafe(file.FullName);
                                                if (!failSafe)
                                                    throw;
                                                skipCopy = false;
                                            }
                                            if (!skipCopy)
                                            {
                                                Logger.Log("Updater.MoveAndProcessFiles", "Copy File " + file.FullName + " to " + destination);
                                                try
                                                {
                                                    System.IO.File.Copy(file.FullName, destination);
                                                }
                                                catch (Exception cpyEx)
                                                {
                                                    Logger.Log(cpyEx);
                                                    //LowTraceText.AppendLine("PO:: HL Step 23 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + cpyEx.ToString(), HighTraceInfo);
                                                    HighTraceText.AppendLine("PO:: HL Step 23 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + cpyEx.ToString());
                                                    LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + cpyEx.ToString());
                                                    bool failSafe = reader.IsFileFailSafe(file.FullName);
                                                    if (!failSafe)
                                                        throw;
                                                }
                                            }

                                        }
                                    }
                                }
                                // Not a DLL, replace if newer
                                else
                                {
                                    FileInfo fiDest = new FileInfo(finalDest);
                                    if (fiDest.LastWriteTime.CompareTo(file.LastWriteTime) != 0)
                                    {
                                        //File.Replace(file.FullName, destination, destination + backupSuffix);
                                        Logger.Log("Updater.MoveAndProcessFiles", "Rename file " + finalDest + " to " + finalDest + backupSuffix);
                                        try
                                        {
                                            System.IO.File.Move(finalDest, finalDest + backupSuffix);
                                            System.IO.File.Copy(file.FullName, destination);
                                        }
                                        catch (Exception e)
                                        {
                                            Logger.Log(e);
                                            //LowTraceText.AppendLine("PO:: HL Step 24 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + e.ToString(), HighTraceInfo);
                                            HighTraceText.AppendLine("PO:: HL Step 24 in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + e.ToString());
                                            LowTraceText.AppendLine("PO:: LL in MoveAndProcessFiles method :MoveAndProcessFiles Catch-6 Exception" + e.ToString());
                                        }
                                    }
                                }

                            }
                            // new file... copy it.
                            else
                            {
                                Logger.Log("Updater.MoveAndProcessFiles", "Copy File " + file.FullName + " to " + destination);
                                FileInfo fiDest = new FileInfo(destination);
                                if (!fiDest.Directory.Exists)
                                {
                                    fiDest.Directory.Create();
                                }
                                System.IO.File.Copy(file.FullName, destination, false);
                            }
                        }
                    }
                    // TODO: run custom actions after all have copied
                    //foreach (FileInfo fiAct in copied.Where(f => f.Extension == ".dll").ToArray())
                    //{
                    //    CustomAction action = null;
                    //    try
                    //    {
                    //        Assembly asm = Assembly.LoadFile(fiAct.FullName);
                    //        action = reader.GetAssemblyCustomAction(ActionEvent.Commit, asm.GetName().Name);
                    //        if (null != action)
                    //            CustomActionImpl.RunCustomAction(fiAct, action);
                    //    }
                    //    catch
                    //    {
                    //    }
                    //}


                    // now do the content files (Previous were program files.
                    MoveContentFiles(reader, appBaseDirectory, tempDirectory);
                }
                finally
                {
                    Logger.Exit("Updater.MoveAndProcessFiles");
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }



        private static void MoveContentFiles(ApplicationManifestReader reader, string appBaseDirectory, string tempFilePath)
        {
            try
            {

                Logger.Enter("Updater.MoveContentFiles", new string[] { reader.ToString(), appBaseDirectory, tempDirectoryName });
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                try
                {
                    IEnumerable<XElement> xFiles = reader.GetInstallableFiles(isClickOnceManifest);
                    string codebase = string.Empty;
                    string path = string.Empty;

                    string localDestPath = string.Empty;

                    FileInfo fiNew = null;
                    FileInfo fiExist = null;


                    if (progress != null)
                    {
                        progress.SetCurrentOperation("Committing supporting files...");
                        if (progress.UpdateProgress("Copying..."))
                            throw new Exception("User cancelled update.");
                    }

                    foreach (XElement xFile in xFiles)
                    {
                        codebase = xFile.Attribute("name").Value;
                        if (System.IO.File.Exists(tempFilePath + "\\" + codebase + ".deploy"))
                        {
                            if (progress != null)
                            {
                                if (progress.UpdateProgress())
                                    throw new Exception("User cancelled update.");
                            }
                            if (!codebase.Contains("\\"))
                            {
                                localDestPath = appBaseDirectory + codebase;
                            }
                            else
                            {
                                if (DirectoryExtensions.IsVirtualDirectory(codebase))
                                {
                                    localDestPath = DirectoryExtensions.ReplaceVirtualDirectory(codebase);

                                    localDestPath = appBaseDirectory + codebase;
                                }
                                else
                                {
                                    localDestPath = appBaseDirectory + codebase;
                                }
                            }

                            fiExist = new FileInfo(localDestPath);

                            if (!tempFilePath.EndsWith("\\"))
                                tempFilePath = tempFilePath + "\\";

                            fiNew = new FileInfo(tempFilePath + codebase + ".deploy");
                            if (!fiNew.Exists)
                            {
                                if (!isClickOnceManifest && fiExist.LastWriteTimeUtc.CompareTo(DateTime.Parse(xFile.Attribute("version").Value)) > 0)
                                    throw new ApplicationException("Missing installation file: " + fiNew.FullName);
                            }

                            // check attributes on the element to see if special processing.
                            if (fiNew.FullName.ToLower().EndsWith(".zip.deploy") && xFile.Attribute("AutoExtract") != null && xFile.Attribute("AutoExtract").Value.ToLower() == "true")
                            {

                                // special never overwrite attribute.
                                bool doNotOverwrite = xFile.Attribute("NeverOverwrite") != null && xFile.Attribute("NeverOverwrite").Value.ToLower() == "true";


                                // check for ZIP archive attribute.
                                FileInfo fiZip = new FileInfo(localDestPath);
                                ExtractArchive(fiNew, fiZip.DirectoryName, doNotOverwrite);
                                try
                                {
                                    System.IO.File.Delete(fiExist.FullName + ".deploy");
                                }
                                catch (Exception zipEx)
                                {
                                    Logger.Log(zipEx);
                                }
                            }
                            else
                                if (fiExist.Exists && fiNew.Exists)
                                {
                                    if (fiExist.Length != fiNew.Length || fiExist.LastWriteTime.CompareTo(fiNew.LastWriteTime) != 0)
                                    {
                                        bool doNotOverwrite = xFile.Attribute("NeverOverwrite") != null && xFile.Attribute("NeverOverwrite").Value.ToLower() == "true";

                                        if (false == doNotOverwrite)
                                        {
                                            //File.Replace(fiNew.FullName, fiExist.FullName, fiExist.FullName + backupSuffix);
                                            if (System.IO.File.Exists(fiExist.FullName + backupSuffix))
                                                System.IO.File.Delete(fiExist.FullName + backupSuffix);
                                            Logger.Log("Updater.MoveContentFiles", "Move file " + fiExist.FullName + " to " + fiExist.FullName + backupSuffix);
                                            System.IO.File.Move(fiExist.FullName, fiExist.FullName + backupSuffix);
                                            Logger.Log("Updater.MoveContentFiles", "Delete File " + fiExist.FullName);
                                            System.IO.File.Delete(fiExist.FullName);
                                            Logger.Log("Updater.MoveContentFiles", "Copy File " + fiExist.FullName + " to " + fiExist.FullName + ".deploy");
                                            if (System.IO.File.Exists(fiExist.FullName + ".deploy"))
                                                System.IO.File.Delete(fiExist.FullName + ".deploy");
                                            System.IO.File.Copy(fiNew.FullName, fiExist.FullName + ".deploy");
                                        }
                                    }
                                }
                                else
                                {

                                    if (!fiExist.Directory.Exists)
                                    {
                                        fiExist.Directory.Create();
                                    }
                                    if (fiNew.Exists)
                                    {
                                        Logger.Log("Updater.MoveContentFiles", "Copy file " + fiNew.FullName + " to " + localDestPath + ".deploy");
                                        System.IO.File.Copy(fiNew.FullName, localDestPath + ".deploy", true);
                                    }
                                }
                        }
                    }
                }
                finally
                {
                    Logger.Exit("Updater.MoveContentFiles");
                }
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void ExtractArchive(FileInfo fiNew, string localDestPath, bool doNotOverwrite)
        {
            using (Ionic.Zip.ZipFile zFile = new Ionic.Zip.ZipFile(fiNew.FullName))
            {
                try
                {
                    zFile.ExtractAll(localDestPath, false == doNotOverwrite);
                }
                catch (Exception e)
                {
                    Logger.Log(e);
                }

            }
        }

        /// <summary>
        /// Commit essentially removes the .deploy from the file extension of new files
        /// and peforms a clean up of temp files created.
        /// </summary>
        /// <param name="appManifest"></param>
        /// <param name="appBasePath"></param>
        /// <param name="tempFilePath"></param>
        private static void CommitInstall(XElement appManifest, string appBasePath, string tempFilePath)
        {

            try
            {

                Logger.Enter("Updater.CommitInstall", new string[] { appManifest.ToString(), appBasePath, tempFilePath });
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                try
                {
                    //LowTraceText.AppendLine("PO: HL on CommitInstall method: Entered into CommitInstall method in Updater class", HighTraceInfo);
                    HighTraceText.AppendLine("PO: HL on CommitInstall method: Entered into CommitInstall method in Updater class");
                    LowTraceText.AppendLine("PO: LL Step 34z-48.1 in InstallOrUpdate Method: Entered into CommitInstall method in Updater class");
                    ApplicationManifestReader appReader = new ApplicationManifestReader(appManifest);


                    // rename .deploy to remove extension.
                    string file = string.Empty;
                    string newFile = string.Empty;
                    IEnumerable<XElement> dependentAssemblies = appReader.GetInstallableDependencies(isClickOnceManifest);
                    string codebase = string.Empty;

                    string codebaseXpath = isClickOnceManifest ? "codebase" : "name";

                    foreach (XElement assembly in dependentAssemblies)
                    {
                        codebase = assembly.Attribute(codebaseXpath).Value;
                        newFile = Path.Combine(appBasePath, codebase);
                        file = newFile + ".deploy";

                        if (System.IO.File.Exists(file))
                        {
                            Logger.Log("Updater.CommitInstall", "Move file " + file + " to " + newFile);

                            System.IO.File.Move(file, newFile);
                        }

                    }


                    IEnumerable<XElement> xFiles = appReader.GetInstallableFiles(isClickOnceManifest);

                    string localDestPath = "";
                    // Next do content files.
                    foreach (XElement xFile in xFiles)
                    {
                        codebase = xFile.Attribute("name").Value;
                        if (!codebase.Contains("\\"))
                        {
                            localDestPath = appBasePath + codebase;
                        }
                        else
                        {
                            if (DirectoryExtensions.IsVirtualDirectory(codebase))
                            {
                                //localDestPath = DirectoryExtensions.ReplaceVirtualDirectory(codebase);
                                localDestPath = appBasePath + codebase;
                            }
                            else
                            {
                                localDestPath = appBasePath + codebase;
                            }
                        }
                        localDestPath += ".deploy";
                        newFile = localDestPath.Replace(".deploy", "");
                        if (localDestPath.ToLower().EndsWith(".zip.deploy") && xFile.Attribute("AutoExtract") != null && xFile.Attribute("AutoExtract").Value.ToLower() == "true")
                        { }
                        else
                            if (System.IO.File.Exists(localDestPath))
                            {
                                Logger.Log("Updater.CommitInstall", "Move file " + localDestPath + " to " + newFile);
                                System.IO.File.Move(localDestPath, newFile);
                            }
                    }

                    try
                    {
                        CleanupTemps(appReader, appBasePath, tempFilePath);
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                        //LowTraceText.AppendLine("PO:: HL Step 24 in CommitInstall method :CommitInstall Catch Exception:" + e.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO:: HL Step 24 in CommitInstall method :CommitInstall Catch Exception:" + e.ToString());
                        LowTraceText.AppendLine("PO:: LL in CommitInstall method :CommitInstall Catch Exception:" + e.ToString());
                    }
                }
                finally
                {
                    Logger.Exit("Updater.CommitInstall");
                }
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void RollbackInstall(XElement appManifest,
                                            string appBasePath,
                                            string tempFilePath,
                                            bool bDownloaded,
                                            bool bProcessed,
                                            bool bCommited,
                                            bool bSavedAppManifest,
                                            bool bSavedDepManifest,
                                            bool bRegistered)
        {

            Logger.Enter("Updater.RollbackInstall", new string[] { appManifest.ToString(), appBasePath, tempFilePath });

            try
            {

                ApplicationManifestReader appReader = new ApplicationManifestReader(appManifest);
                string codebaseXpath = isClickOnceManifest ? "codebase" : "name";

                string codebase = "";
                IEnumerable<XElement> xAssemblies = appReader.GetInstallableDependencies(isClickOnceManifest);
                foreach (XElement xAssembly in xAssemblies)
                {
                    codebase = (string)xAssembly.Attribute(codebaseXpath);
                    if (DirectoryExtensions.IsVirtualDirectory(codebase))
                        codebase = DirectoryExtensions.ReplaceVirtualDirectory(codebase);

                    string file = Path.Combine(appBasePath, codebase);
                    string deployFile = file + ".deploy";
                    string bkupFile = file + backupSuffix;
                    try
                    {
                        System.IO.File.Delete(deployFile);
                        if (System.IO.File.Exists(bkupFile))
                        {
                            try
                            {
                                System.IO.File.Delete(file);
                                System.IO.File.Move(bkupFile, file);
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                    }
                }
                IEnumerable<XElement> xFiles = appReader.GetInstallableFiles(isClickOnceManifest);

                string localDestPath = "";
                // next all content files
                foreach (XElement xFile in xFiles)
                {
                    codebase = xFile.Attribute("name").Value;
                    //codebase = Path.Combine(appBasePath, codebase);
                    if (DirectoryExtensions.IsVirtualDirectory(codebase))
                        codebase = DirectoryExtensions.ReplaceVirtualDirectory(codebase);

                    string file = Path.Combine(appBasePath, codebase);
                    string deployFile = file + ".deploy";
                    string bkupFile = file + backupSuffix;

                    Logger.Log("Updater.RollbackInstall", "Delete File " + localDestPath);
                    try
                    {
                        System.IO.File.Delete(deployFile);
                        if (System.IO.File.Exists(bkupFile))
                        {
                            try
                            {
                                System.IO.File.Delete(file);
                                System.IO.File.Move(bkupFile, file);
                            }
                            catch { }
                        }

                    }
                    catch (Exception e)
                    {
                        Logger.Log("Updater.RollbackInstall", "Unable to Delete: " + localDestPath + " durring rollback--> " + e.Message);
                    }
                }

                // rename .backup to original -- orginal files were previosly renamed to .backup.
                string[] tempFiles = Directory.GetFiles(appBasePath, "*.backup");
                string newFile = string.Empty;
                foreach (string tempFile in tempFiles)
                {
                    newFile = tempFile.Replace(backupSuffix, "");
                    Logger.Log("Updater.RollbackInstall", "Move file " + tempFile + " to " + newFile);
                    try
                    {
                        System.IO.File.Move(tempFile, newFile);
                    }
                    catch (Exception e)
                    {
                        Logger.Log("Updater.RollbackInstall", "Unable to move file " + tempFile + " to " + newFile + "--> " + e.Message);
                    }
                }

                // cleanup temps
                CleanupTemps(appReader, appBasePath, tempFilePath);
            }
            finally
            {
                Logger.Exit("Updater.RollbackInstall");
            }

        }


        //private static string createJob(string jobName, XElement xDeploy, string urlBase, string localDestPath)
        //{



        //    Logger.Enter("Updater.createJob", new string[] { jobName, xDeploy.ToString(), urlBase, localDestPath });

        //    try
        //    {
        //        IBackgroundCopyManager bcm = new BackgroundCopyManager() as IBackgroundCopyManager;
        //        IBackgroundCopyJob job = null;
        //        Guid guid;


        //        bcm.CreateJob(jobName, BG_JOB_TYPE.BG_JOB_TYPE_DOWNLOAD, out guid, out job);
        //        job.SetPriority(BG_JOB_PRIORITY.BG_JOB_PRIORITY_NORMAL);
        //        ApplicationManifestReader reader = new ApplicationManifestReader(xDeploy);
        //        IEnumerable<XElement> dependentAssemblies = reader.GetInstallableDependencies(isClickOnceManifest);

        //        string remoteUrl = string.Empty;
        //        string codebase = string.Empty;

        //        if (!localDestPath.EndsWith("\\"))
        //            localDestPath += "\\";

        //        // do assemblies first
        //        string source = "";
        //        string dest = "";
        //        string codebaseXpath = isClickOnceManifest ? "codebase" : "name";
        //        foreach (XElement assembly in dependentAssemblies)
        //        {
        //            codebase = assembly.Attribute(codebaseXpath).Value;
        //            source = urlBase + codebase + ".deploy";
        //            dest = localDestPath + codebase + ".deploy";
        //            Logger.Log("Updater.createJob", "Add file to job: SOURCE:" + source + "  DEST:" + dest);
        //            job.AddFile(source, dest);

        //        }

        //        IEnumerable<XElement> files = reader.GetInstallableFiles(isClickOnceManifest);
        //        string path = "";
        //        FileInfo fi = null;

        //        foreach (XElement file in files)
        //        {
        //            codebase = file.Attribute("name").Value;
        //            path = localDestPath + codebase;
        //            fi = new FileInfo(path);
        //            fi.Directory.Create();
        //            source = urlBase + codebase + ".deploy";
        //            dest = path + ".deploy";
        //            Logger.Log("Updater.createJob", "Add file to job: SOURCE:" + source + "  DEST:" + dest);
        //            job.AddFile(source, dest);
        //        }
        //        //job.SetNotifyInterface(new BackgroundCopyCallback(evtSuccess, evtError));
        //        job.Resume();
        //        return guid.ToString("B");
        //    }
        //    finally
        //    {
        //        Logger.Exit("Updater.createJob");
        //    }
        //}

        private static void DownloadSyncInternal(XElement xApp, XElement xLocalAppManifest, XElement xDeploy, string finalDestPath, string localDestPath, string app_Type)
        {
            try
            {

                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                object _lock = new object();
            //Dictionary<string, string> downloadAssembly = new Dictionary<string, string>();
            //Dictionary<string, string> downloadFile = new Dictionary<string, string>();

            Logger.Enter("Updater.DownloadSyncInternal", new string[] { xApp.ToString(), xDeploy.ToString(), localDestPath });
            //LowTraceText.AppendLine("PO: HL in DownloadSyncInternal Method : Entered into DownloadSyncInternal method defined in Updater Class", HighTraceInfo);
            HighTraceText.AppendLine("PO: HL in DownloadSyncInternal Method : Entered into DownloadSyncInternal method defined in Updater Class");
            LowTraceText.AppendLine("PO: LL Step 34z-42.3 in DownloadSyncInternal Method: Entered into DownloadSyncInternal method defined in Updater Class");

            try
            {
                //IBackgroundCopyManager bcm = new BackgroundCopyManager() as IBackgroundCopyManager;
                //IBackgroundCopyJob job = null;
                //Guid guid;


                //bcm.CreateJob("Download Application Manifest", BG_JOB_TYPE.BG_JOB_TYPE_DOWNLOAD, out guid, out job);
                //job.SetPriority(BG_JOB_PRIORITY.BG_JOB_PRIORITY_FOREGROUND);

                ApplicationManifestReader appReader = new ApplicationManifestReader(xApp);
                ApplicationManifestReader localAppReader = new ApplicationManifestReader(xLocalAppManifest);

                DeploymentManifestReader deployReader = new DeploymentManifestReader(xDeploy);
                Uri myUri = new Uri(deployReader.Codebase);
                Uri appUri = new Uri(myUri.GetVirtualRoot() + deployReader.ApplicationCodebase);

                IEnumerable<XElement> dependentAssemblies = appReader.GetInstallableDependencies(isClickOnceManifest);
                IEnumerable<XElement> files = appReader.GetInstallableFiles(isClickOnceManifest);

                if (progress != null)
                {
                    progress.SetMax((dependentAssemblies.Count() + files.Count()) * 2);
                    progress.SetCurrentOperation("Downloading Assemblies...");
                }

                string remoteUrl = string.Empty;
                string codebase = string.Empty;

                if (!localDestPath.EndsWith("\\"))
                    localDestPath += "\\";

                // do assemblies first
                string source = "";
                string dest = "";
                string path = "";
                string currentFile = "";
                string src = "";
                FileInfo fi = null;
                string codebaseXpath = isClickOnceManifest ? "codebase" : "name";
                LowTraceText.AppendLine("PO: LL Step 34z-42.4 in DownloadSyncInternal Method: Check assembly to download");
                //LowTraceText.AppendLine("Step 9b: Check assembly to download");
                //LowTraceText.AppendLine("-----------------------------------");

                string app_URL = appUri.GetVirtualRoot();
                if (!app_Type.Contains("Prod"))
                {
                    app_URL = app_URL.Remove(app_URL.LastIndexOf("/"));
                    string split = app_URL.Substring(app_URL.LastIndexOf("/")) + "/";
                    app_URL = app_URL.Remove(app_URL.LastIndexOf("/"));
                    string originalModified = split.Remove(split.IndexOf("_") + 1, split.LastIndexOf("/") - split.IndexOf("_") - 1);
                    src = app_URL + originalModified.Insert(originalModified.IndexOf("_") + 1, app_Type.Replace(".", "_"));
                }
                else
                {
                    src = appUri.GetVirtualRoot();
                }

                //                XElement xlocalManifest = null == localAppReader? localAppReader.GetInstallableDependencies(isClickOnceManifest)

                //XElement xAssemblyListRoot = null;
                //if (isClickOnceManifest)
                //{
                //    xAssemblyListRoot =
                //        new XElement("Assemblies",
                //   from a in dependentAssemblies
                //   join ax in 
                //   on (string)a.Element("name") equals (string)ax.Element("name")
                //   select new { a, ax });
                //}


                foreach (XElement assembly in dependentAssemblies)
                {
                    codebase = assembly.Attribute(codebaseXpath).Value;
                    path = localDestPath + codebase;
                    fi = new FileInfo(path);
                    fi.Directory.Create();

                    //source = appUri.GetVirtualRoot() + codebase + ".deploy";
                    source = src + codebase + ".deploy";

                    dest = localDestPath + codebase + ".deploy";
                    fi = new FileInfo(dest);
                    fi.Directory.Create();

                    Logger.Log("Updater.DownloadSyncInternal", "Add Job File, SOURCE:" + source + "  DEST:" + dest);


                    if (progress != null)
                    {
                        if (progress.UpdateProgress(codebase))
                            throw new Exception("User cancelled update.");
                    }
                    if (progress != null)
                    {
                        progress.SetMax((dependentAssemblies.Count() + files.Count()) * 2);
                        progress.SetCurrentOperation("Comparing Assemblies...");
                    }
                    LowTraceText.AppendLine("PO: LL Step 34z-42.6 in DownloadSyncInternal Method: Check assembly Exist");
                    //LowTraceText.AppendLine("Step 9d: Check assembly Exist");
                    /// <summary>
                    ///Changes made for new enhancement
                    /// </summary> 
                    if (System.IO.File.Exists(finalDestPath + codebase))
                    {
                        LowTraceText.AppendLine("PO: LL Step 34z-42.7 in DownloadSyncInternal Method: assembly Exist");
                        //LowTraceText.AppendLine("Step 9e: assembly Exist");
                        //Get local assembly information
                        Assembly assemblyLocal = null;
                        byte[] AssemblyByteArrayLocal = null;
                        AssemblyByteArrayLocal = System.IO.File.ReadAllBytes(finalDestPath + codebase);
                        assemblyLocal = Assembly.Load(AssemblyByteArrayLocal);

                        //Get and compare server and local assembly version
                        try
                        {
                            string versionServer = string.Empty;
                            IEnumerable<XNode> dnas = from node in assembly.DescendantNodes()
                                                      select node;
                            foreach (XNode node in dnas)
                            {
                                if (node is XElement)
                                    if ((node as XElement).Name.LocalName == "assemblyIdentity")
                                        versionServer = (node as XElement).Attributes("version").ElementAt(0).Value;
                            }

                            if (assemblyLocal.GetName().Version.ToString() != versionServer)
                            {
                                lock (_lock)
                                {
                                    if (progress != null)
                                    {
                                        progress.SetMax((dependentAssemblies.Count() + files.Count()) * 2);
                                        progress.SetCurrentOperation("Downloading Assemblies...");
                                    }
                                    LowTraceText.AppendLine("PO: LL Step 34z-42.8 in DownloadSyncInternal Method: assembly Exist with different version start download");
                                    //LowTraceText.AppendLine("Step 9e: assembly Exist with different version start download");
                                    LowTraceText.AppendLine("PO: LL Step 34z-42.9 in DownloadSyncInternal Method: Calling DownloadSingleFile method defined in Updater Class");
                                    DownloadSingleFile(source, dest);
                                    LowTraceText.AppendLine("PO: LL Step 34z-42.11 in DownloadSingleFile Method: Came otu of DownloadSingleFile method defined in Updater Class");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            lock (_lock)
                            {
                                if (progress != null)
                                {
                                    progress.SetMax((dependentAssemblies.Count() + files.Count()) * 2);
                                    progress.SetCurrentOperation("Downloading Assemblies...");
                                }
                                LowTraceText.AppendLine("PO: LL Step 34z-42.12 in DownloadSyncInternal Method: Calling DownloadSingleFile method(defined in Updater Class) again in Catch block ");
                                DownloadSingleFile(source, dest);
                            }
                        }
                    }
                    else
                    {
                        lock (_lock)
                        {
                            if (progress != null)
                            {
                                progress.SetMax((dependentAssemblies.Count() + files.Count()) * 2);
                                progress.SetCurrentOperation("Downloading Assemblies...");
                            }
                            LowTraceText.AppendLine("PO: LL Step 34z-42.12 in DownloadSyncInternal Method: assembly Not Exist Download Start ");
                            //LowTraceText.AppendLine("Step 9e: assembly Not Exist Download Start");
                            DownloadSingleFile(source, dest);
                        }
                    }
                }
                LowTraceText.AppendLine("-----------------------------------");
                //LowTraceText.AppendLine("-----------------------------------");
                if (progress != null)
                {
                    progress.SetCurrentOperation("Downloading supporting files...");
                }
                LowTraceText.AppendLine("PO: LL Step 34z-42.13 in DownloadSyncInternal Method: Check file to download ");
                //LowTraceText.AppendLine("Step 10a: Check file to download");
                LowTraceText.AppendLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                //LowTraceText.AppendLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                foreach (XElement file in files)
                {
                    if (!isClickOnceManifest && file.Attribute("action").Value == "delete")
                        continue;

                    codebase = file.Attribute("name").Value;
                    LowTraceText.AppendLine("PO: LL Step 34z-42.14 in DownloadSyncInternal Method: Check file to download= " + codebase);
                    //LowTraceText.AppendLine("Step 10a: Check file to download= " + codebase);

                    //path = localDestPath + codebase;
                    path = (localDestPath + codebase.Replace(@"/", @"\"));

                    //fi = new FileInfo(path);
                    fi = new FileInfo(path.Replace(@"/", @"\"));

                    fi.Directory.Create();

                    //source = appUri.GetVirtualRoot() + codebase + ".deploy";
                    //source = (appUri.GetVirtualRoot() + codebase.Replace(@"\", @"/") + ".deploy");

                    source = (src + codebase.Replace(@"\", @"/") + ".deploy");

                    dest = path + ".deploy";
                    currentFile = finalDestPath + codebase;
                    Logger.Log("Updater.DownloadSyncInternal", "Add Job File, SOURCE:" + source + "  DEST:" + dest);
                    LowTraceText.AppendLine("PO: LL Step 34z-42.15 in DownloadSyncInternal Method: Updater.DownloadSyncInternal - Add Job File, SOURCE & DEST:" + source + dest);
                    //job.AddFile(source, dest);
                    //if (file.Attribute("size").Value != string.Empty) {

                    //We will only download newer content files. This does not work for
                    // clickonce manifests
                    if (!isClickOnceManifest && file.Attribute("method").Value == "date")
                    {
                        FileInfo existingFile = new FileInfo(currentFile);
                        if (existingFile.Exists && existingFile.LastWriteTimeUtc.CompareTo(DateTime.Parse(file.Attribute("version").Value)) == 0)
                        {
                            if (progress.UpdateProgress())
                                throw new Exception("User cancelled update.");

                            continue;
                        }
                    }

                    if (progress != null)
                    {
                        if (progress.UpdateProgress(codebase))
                            throw new Exception("User cancelled update.");
                    }
                    if (progress != null)
                    {
                        progress.SetCurrentOperation("Comparing supporting files...");
                    }
                    LowTraceText.AppendLine("PO: LL Step 34z-42.16 in DownloadSyncInternal Method: Check file already exist");
                    //LowTraceText.AppendLine("Step 10a: Check file already exist");
                    /// <summary>
                    ///Changes made for new enhancement
                    /// </summary> 
                    if (System.IO.File.Exists(currentFile))
                    {
                        LowTraceText.AppendLine("PO: LL Step 34z-42.17 in DownloadSyncInternal Method: File Exists");
                        //LowTraceText.AppendLine("Step 10a: File Exists");
                        //Get Local file information
                        FileInfo fileLocal = null;
                        fileLocal = new FileInfo(currentFile);

                        //Get and compare Server and local file information
                        lock (_lock)
                        {
                            System.Net.WebRequest reqFile1;
                            byte[] dlBuffer = new byte[BUFFERSIZE];
                            reqFile1 = System.Net.WebRequest.Create(source);
                            reqFile1.Headers.Add("cache-control", "no-cache");

                            try
                            {
                                DateTime localFileDT = fileLocal.LastWriteTime;
                                DateTime serverFileDT = DateTime.Parse(reqFile1.GetResponse().Headers["Last-Modified"]);
                                //if (localFileDT.CompareTo(serverFileDT) < 0)
                                if (fileLocal.Length != reqFile1.GetResponse().ContentLength || localFileDT.CompareTo(serverFileDT) != 0)
                                {
                                    if (progress != null)
                                    {
                                        progress.SetCurrentOperation("Downloading supporting files...");
                                    }
                                    LowTraceText.AppendLine("PO: LL Step 34z-42.17 in DownloadSyncInternal Method: File Exists With upated Start Download");
                                    //LowTraceText.AppendLine("Step 10a: File Exists With upated Start Download");
                                    LowTraceText.AppendLine("PO: LL Step 34z-42.18 in DownloadSyncInternal Method: Calling DownloadSingleFile method again defind in Updater Class");
                                    DownloadSingleFile(source, dest);
                                }
                            }
                            catch (Exception ex)
                            {
                                if (progress != null)
                                {
                                    progress.SetCurrentOperation("Downloading supporting files...");
                                }
                                LowTraceText.AppendLine("PO: LL Step 34z-42.19 in DownloadSyncInternal Method: Calling DownloadSingleFile method again defind in Updater Class inside Catch block");
                                DownloadSingleFile(source, dest);
                            }
                            finally
                            {
                                reqFile1.GetResponse().Close();
                            }
                        }

                    }
                    else
                    {
                        lock (_lock)
                        {
                            if (progress != null)
                            {
                                progress.SetCurrentOperation("Downloading supporting files...");
                            }
                            LowTraceText.AppendLine("PO: LL Step 34z-42.20 in DownloadSyncInternal Method: File not exist start Download");
                            //LowTraceText.AppendLine("Step 10a: File not exist start Download");

                            LowTraceText.AppendLine("PO: LL Step 34z-42.21 in DownloadSyncInternal Method: Calling DownloadSingleFile method again defind in Updater Class inside else condition");
                            DownloadSingleFile(source, dest);

                        }
                    }
                }
                //LowTraceText.AppendLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                //ManualResetEvent evtSuccess = new ManualResetEvent(false);
                //ManualResetEvent evtError = new ManualResetEvent(false);

                //job.SetNotifyInterface(new BackgroundCopyCallback(evtSuccess, evtError));
                //job.Resume();
                //int evt = ManualResetEvent.WaitAny(new WaitHandle[] { evtSuccess, evtError }, DownloadTimeout, false);
                //bool success = evt == 0;

                //if (success)
                //{
                //    BG_JOB_STATE pVal;
                //    job.GetState(out pVal);
                //    if (pVal == BG_JOB_STATE.BG_JOB_STATE_TRANSFERRED)
                //        job.Complete();
                //}
                //else
                //{
                //    BG_JOB_STATE pVal;
                //    job.GetState(out pVal);
                //    throw new ApplicationException("Timeout downloading application.  Current state is " + pVal.ToString());
                //}
            }
            catch (Exception ex)
            {
                downloadException = ex.Message.ToString();
                //IsException = "DownloadingException";
                //LowTraceText.AppendLine("%%%%%%%%%%%%%%%%%%%%");
                //LowTraceText.AppendLine("Po: HL Step 53 in DownloadSyncInternal Method: DownloadSyncInternal method- Exception in Download File" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 53 in DownloadSyncInternal Method: DownloadSyncInternal method- Exception in Download File" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in DownloadSyncInternal Method: DownloadSyncInternal method- Exception in Download File" + ex.ToString());
                //LowTraceText.AppendLine("Exception in Download File" + ex.Message.ToString());
                //LowTraceText.AppendLine("%%%%%%%%%%%%%%%%%%%%");
                //throw new ApplicationException("Error downloading file //", ex);
            }
                    finally
                    {
                        Logger.Exit("Updater.DownloadSyncInternal");
                    }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }

        // Re-run the application either in another AppDomain or in another process
        public static void LaunchExe(string exePath, XElement applicationManifest, XElement deploymentManifest, string[] args)
        {

            LowTraceText = new StringBuilder();
            HighTraceText = new StringBuilder();
            //LowTraceText.AppendLine("PO: HL on LaunchExe method: Entered into LaunchExe method defined in Updater class", HighTraceInfo);
            HighTraceText.AppendLine("PO: HL on LaunchExe method: Entered into LaunchExe method defined in Updater class");
            LowTraceText.AppendLine("PO: LL Step 34z-58.1 in InstallOrUpdate Method: Entered into LaunchExe method defined in Updater class ");
            bool shadowCopy = false;
            Logger.Enter("Updater.LaunchExe", new string[] { exePath, shadowCopy.ToString(), applicationManifest.ToString() });
            // Get assembly that started it all
            //Assembly entry = Assembly.GetEntryAssembly();
            // "Intuit" its exe name
            String name = "";// entry.GetName().Name + ".exe";
            string parameters = "";

            try
            {
                ApplicationManifestReader appReader = new ApplicationManifestReader(applicationManifest);
                DeploymentManifestReader depReader = new DeploymentManifestReader(deploymentManifest);

                if (appReader.ShadowCopy)
                {
                    string codebase = exePath + appReader.GetEntryPointCommandLineFile(isClickOnceManifest);
                    parameters = appReader.GetEntryPointCommandLineParameters(isClickOnceManifest);
                    string appName = depReader.Name;
                    parameters = "/codebase=\"" + codebase + "\" /name=\"" + appName + "\" " + parameters;
                    Uri uri = new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
                    System.IO.FileInfo fi = new FileInfo(uri.LocalPath);
                    string path = Path.Combine(fi.DirectoryName, "AmericanExpress.PushOnce.Loader.exe");
                    ProcessStartInfo psi = new ProcessStartInfo(path, parameters);
                    psi.WorkingDirectory = exePath;
                    Process.Start(psi);
                }
                else
                {
                    name = exePath + appReader.GetEntryPointCommandLineFile(isClickOnceManifest);
                    parameters = appReader.GetEntryPointCommandLineParameters(isClickOnceManifest);
                    // For passing parameters dynamically
                    if (string.IsNullOrEmpty(parameters))
                    {
                        for (int i = 1; i < args.Length; i++)
                        {
                            parameters = parameters + args[i] + " ";
                        }
                    }
                    // Create a new process and relaunch the application
                    Logger.Enter("Updater.LaunchEXE", new string[] { name, parameters });
                    LowTraceText.AppendLine("PO: LL Step 34z-58.2 in InstallOrUpdate Method: Updater.LaunchEXE " + name + parameters);
                    Process.Start(name, parameters);

                }
            }
            finally
            {
                Logger.Exit("Updater.LaunchExe");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
            }
        }

        static void CleanupTemps(ApplicationManifestReader reader, string appBasePath, string tempPath)
        {
            Logger.Enter("Updater.CleanupTemps", new string[] { reader.ToString(), appBasePath, tempPath });

            try
            {

                string[] tempFiles = Directory.GetFiles(appBasePath, "*.backup");
                foreach (string tempFile in tempFiles)
                {
                    Logger.Log("Updater.CleanupTemps", "Delete File " + tempFile);
                    try
                    {
                        if (System.IO.File.Exists(tempFile))
                            System.IO.File.Delete(tempFile);
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                    }
                }

                IEnumerable<XElement> xFiles = reader.GetInstallableFiles(isClickOnceManifest);
                string codebase = string.Empty;
                string path = string.Empty;

                string localDestPath = string.Empty;

                FileInfo fiTemp = null;

                foreach (XElement xFile in xFiles)
                {
                    codebase = xFile.Attribute("name").Value;
                    if (!codebase.Contains("\\"))
                    {
                        localDestPath = appBasePath + codebase;
                    }
                    else
                    {
                        if (DirectoryExtensions.IsVirtualDirectory(codebase))
                        {
                            localDestPath = DirectoryExtensions.ReplaceVirtualDirectory(codebase);
                        }
                        else
                        {
                            localDestPath = appBasePath + codebase;
                        }
                    }
                    string nodeployPath = localDestPath + backupSuffix;
                    localDestPath += ".deploy";
                    localDestPath += backupSuffix;
                    fiTemp = new FileInfo(nodeployPath);
                    if (fiTemp.Exists)
                    {
                        Logger.Log("Updater.CleanupTemps", "Delete File " + fiTemp.FullName);
                        try
                        {
                            fiTemp.Delete();
                        }
                        catch (Exception e)
                        {
                            Logger.Log(e);
                        }
                    }
                    else
                    {
                        fiTemp = new FileInfo(localDestPath);
                        if (fiTemp.Exists)
                        {
                            Logger.Log("Updater.CleanupTemps", "Delete File " + fiTemp.FullName);
                            try
                            {
                                fiTemp.Delete();
                            }
                            catch (Exception e)
                            {
                                Logger.Log(e);
                            }
                        }

                    }
                }
                try
                {
                    Logger.Log("Updater.CleanupTemps", "Delete Directory " + tempPath);
                    Directory.Delete(tempPath, true);
                }
                catch (Exception e)
                {
                    Logger.Log(e);
                }
            }
            finally
            {
                Logger.Exit("Updater.CleanupTemps");
            }

        }

        public static void RemoveShortcut(string shortcutPath, XElement deploymentManfest)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in RemoveShortcut Method: Entered inot RemoveShortcut method defined in Updater class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in RemoveShortcut Method: Entered inot RemoveShortcut method defined in Updater class");
                LowTraceText.AppendLine("PO: LL Step 34z-58.14 in RemoveShortcut Method: Entered inot RemoveShortcut method defined in Updater Class");
                Logger.Enter("Updater.RemoveShortcut", new string[] { shortcutPath, deploymentManfest.ToString() });
                DeploymentManifestReader depReader = new DeploymentManifestReader(deploymentManfest);
                string linkName = Path.Combine(shortcutPath, depReader.ProductName + ".lnk");
                if (System.IO.File.Exists(linkName))
                    System.IO.File.Delete(linkName);
            }
            catch (Exception e)
            {
                Logger.Log(e);
                //LowTraceText.AppendLine("Po: HL Step 42 in RemoveShortcut method: ## RemoveShortcut method Exception" + e.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 42 in RemoveShortcut method: ## RemoveShortcut method Exception" + e.ToString());
                LowTraceText.AppendLine("Po: LL in RemoveShortcut method: ## RemoveShortcut method Exception" + e.ToString());
            }
            finally
            {
                Logger.Exit("Updater.RemoveShortcut");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
            }

        }

        public static void CreateShortcut(string shortcutPath, string iconLocation, XElement deploymentManfest, string arguments)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in CreateShortcut Method: Entered into CreateShortcut method(defined in Updater class) called from InstallShortcutsAndAddRegistryInfo method", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in CreateShortcut Method: Entered into CreateShortcut method(defined in Updater class) called from InstallShortcutsAndAddRegistryInfo method");
                LowTraceText.AppendLine("PO: LL Step 34z-58.10 in CreateShortcut Method: Entered into CreateShortcut method(defined in Updater class) called from InstallShortcutsAndAddRegistryInfo method ");
                WshShell shell = new WshShell();
                DeploymentManifestReader depReader = new DeploymentManifestReader(deploymentManfest);

                if (!shortcutPath.EndsWith("\\"))
                    shortcutPath += "\\";

                string linkName = shortcutPath + depReader.ProductName + ".lnk";

                //// If the shortcut exists, remove it and re-create with new info.
                //if (System.IO.File.Exists(linkName))
                //{
                //    try
                //    {
                //        System.IO.File.Delete(linkName);
                //    }
                //    catch { }
                //}

                //IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(linkName);

                IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(linkName);
                // If the shortcut exists, remove it and re-create with new info.
                //if (System.IO.File.Exists(linkName))
                //{

                //    try
                //    {
                //        System.IO.File.Delete(linkName);
                //    }
                //    catch { }
                //}

                Uri uri = new Uri(depReader.Codebase);

                //shortcut.TargetPath = depReader.TargetCodebase + "\\" + uri.GetFileName();
                LowTraceText.AppendLine("PO: LL Step 34z-58.11 in CreateShortcut Method: Shortcut Creation Path1= " + uri.GetFileName());
                //LowTraceText.AppendLine("Shortcut Creation Path1= " + uri.GetFileName());
                shortcut.TargetPath = depReader.TargetCodebase + "\\" + Uri.UnescapeDataString(uri.GetFileName());
                LowTraceText.AppendLine("PO: LL Step 34z-58.12 in CreateShortcut Method: Shortcut Creation Path1= " + Uri.UnescapeDataString(uri.GetFileName()));
                //LowTraceText.AppendLine("Shortcut Creation Path1= " + Uri.UnescapeDataString(uri.GetFileName()));

                if (string.Empty != arguments)
                    shortcut.Arguments = arguments;

                shortcut.WorkingDirectory = depReader.TargetCodebase;
                LowTraceText.AppendLine("PO: LL Step 34z-58.13 in CreateShortcut Method: Shortcut Creation Working Directory Path1= " + depReader.TargetCodebase);
                //LowTraceText.AppendLine("Shortcut Creation Working Directory Path1= " + depReader.TargetCodebase);
                shortcut.Description = depReader.Publisher + " - " + depReader.ProductName;
                if (!string.IsNullOrEmpty(iconLocation))
                    shortcut.IconLocation = iconLocation;
                else
                {
                    if (!string.IsNullOrEmpty(GetIconPath))
                        shortcut.IconLocation = GetIconPath;
                }


                shortcut.Save();
            }
                
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("Po: HL Step 41 in CreateShortcut method: ## CreateShortcut method Exception" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 41 in CreateShortcut method: ## CreateShortcut method Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in CreateShortcut method: ## CreateShortcut method Exception" + ex.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }

        public static void RemoveAddRemoveProgramEntry(XElement deploymentManifest)
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in RemoveAddRemoveProgramEntry Method : Entered into RemoveAddRemoveProgramEntry in Updater Class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in RemoveAddRemoveProgramEntry Method : Entered into RemoveAddRemoveProgramEntry in Updater Class");
                LowTraceText.AppendLine("PO: LL Step 35q in RemoveAddRemoveProgramEntry Method : Entered into RemoveAddRemoveProgramEntry method defined in Updater Class");
                RegistryKey lmKey = Registry.LocalMachine;
                RegistryKey uninstKey = lmKey.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", true);

                DeploymentManifestReader depReader = new DeploymentManifestReader(deploymentManifest);

                string name = depReader.ProductName;
                RegistryKey productKey = uninstKey.OpenSubKey(name);

                if (null == productKey)
                {
                    return;
                }

                productKey.Close();
                uninstKey.DeleteSubKeyTree(name);
            }
            catch (Exception e)
            {
                Logger.Log(e);
                //LowTraceText.AppendLine("Po: HL Step 47 in RemoveAddRemoveProgramEntry Method: RemoveAddRemoveProgramEntry method Exception" + e.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 47 in RemoveAddRemoveProgramEntry Method: RemoveAddRemoveProgramEntry method Exception" + e.ToString());
                LowTraceText.AppendLine("Po: LL in RemoveAddRemoveProgramEntry Method: RemoveAddRemoveProgramEntry method Exception" + e.ToString());
            }
            finally
            {
                Logger.Exit("Updater.RemoveAddRemoveProgramEntry");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
            }

        }

        public static void CreateAddRemoveProgramEntry(XElement deploymentManifest, string iconPath, bool always)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in CreateAddRemoveProgramEntry Method: Entered into CreateAddRemoveProgramEntry method defined in Updater Class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in CreateAddRemoveProgramEntry Method: Entered into CreateAddRemoveProgramEntry method defined in Updater Class");
                LowTraceText.AppendLine("PO: LL Step 34z-58.17 in CreateAddRemoveProgramEntry Method: Entered into CreateAddRemoveProgramEntry method defined in Updater Class");
                RegistryKey lmKey = Registry.LocalMachine;
                RegistryKey uninstKey = lmKey.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", true);

                DeploymentManifestReader depReader = new DeploymentManifestReader(deploymentManifest);

                string name = depReader.ProductName;
                RegistryKey productKey = uninstKey.OpenSubKey(name);

                if (null == productKey && false == always)
                    return;

                if (productKey != null)
                {
                    uninstKey.DeleteSubKeyTree(name);
                    productKey = null;
                }

                if (null == productKey)
                {
                    productKey = uninstKey.CreateSubKey(name);
                }

                if (!string.IsNullOrEmpty(iconPath))
                    productKey.SetValue("DisplayIcon", iconPath);

                productKey.SetValue("DisplayName", depReader.ProductName);
                productKey.SetValue("InstallLocation", depReader.TargetCodebase);
                productKey.SetValue("Publisher", depReader.Publisher);
                string uninstallPath = "c:\\program files\\american express\\pushonce\\AmericanExpress.PushOnce.AutomaticUpdateManager.exe\" ";
                //string uninstallPath = "C:\\Dev\\Releases\\PushOnce\\PushOnce Deployment\\AmericanExpress.PushOnce.Loader\\bin\\Debug\" ";

                uninstallPath += " \"" + depReader.TargetCodebase;
                if (!uninstallPath.EndsWith("\\"))
                    uninstallPath += "\\";

                Uri uri = new Uri(depReader.Codebase);

                uninstallPath += uri.GetFileName();
                uninstallPath = "\"" + uninstallPath + "\" /uninstall";

                productKey.SetValue("UninstallPath", uninstallPath);
                productKey.SetValue("UninstallString", uninstallPath);
                //productKey.SetValue("URLUpdateInfo", "");
                Version ver = new Version(depReader.Version);
                productKey.SetValue("VersionMajor", ver.Major.ToString());
                productKey.SetValue("VersionMinor", ver.Minor.ToString());
                productKey.SetValue("DisplayVersion", ver.ToString());
            }
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("Po: HL Step 43 in CreateAddRemoveProgramEntry method: ## CreateAddRemoveProgramEntry method Exception" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 43 in CreateAddRemoveProgramEntry method: ## CreateAddRemoveProgramEntry method Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in CreateAddRemoveProgramEntry method: ## CreateAddRemoveProgramEntry method Exception" + ex.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }

        }

        // Do the file download and polling logic
        //static void HandleBits(Object o)
        //{
        //    IBackgroundCopyManager bcm = null;
        //    IBackgroundCopyJob job = null;
        //    try
        //    {
        //        // Create BITS object
        //        bcm = (IBackgroundCopyManager)new BackgroundCopyManager();
        //        Guid jobID = Guid.Empty;
        //        if (xml.BitsJob != Guid.Empty)
        //        { // Do we already have a job in place?
        //            jobID = xml.BitsJob;
        //            BG_JOB_STATE state;
        //            try
        //            {
        //                bcm.GetJob(ref jobID, out job); // Get the BITS job object
        //                job.GetState(out state);        // check its state
        //                switch (state)
        //                {
        //                    case BG_JOB_STATE.BG_JOB_STATE_ERROR: // If it is an error, re-poll
        //                        job.Complete();
        //                        xml.BitsJob = Guid.Empty;
        //                        Marshal.ReleaseComObject(job);
        //                        job = null;
        //                        break;
        //                    case BG_JOB_STATE.BG_JOB_STATE_TRANSFERRED: // If we got the job
        //                        job.Complete();                          // then complete it
        //                        xml.BitsJob = Guid.Empty;
        //                        return;
        //                    default:
        //                        return;
        //                }
        //            }
        //            catch (COMException e)
        //            {
        //                if (e.ErrorCode == unchecked((Int32)0x80200001))
        //                { // Job doesn't exist
        //                    xml.BitsJob = Guid.Empty;
        //                }
        //                else
        //                    throw; // Some other error we didn't expect
        //            }
        //            catch (UnauthorizedAccessException)
        //            {
        //                return; // We don't have access to the current job... no biggie
        //            }
        //        }

        //        // Create a bits job to download the next expected update
        //        bcm.CreateJob("Application Update",
        //           BG_JOB_TYPE.BG_JOB_TYPE_DOWNLOAD, out jobID, out job);
        //        job.SetDescription("Updating application at " + baseDir);
        //        String resource;
        //        if (xml.PatchUrl[xml.PatchUrl.Length - 1] == '/')
        //        {
        //            resource = xml.PatchUrl + patchName;
        //        }
        //        else
        //        {
        //            resource =
        //               String.Format("{0}/{1}", xml.PatchUrl, patchName);
        //        }
        //        // Add the file to the job
        //        job.AddFile(resource, baseDir + patchName);
        //        job.Resume(); // start the job in action
        //        xml.BitsJob = jobID; // save the Job Guid
        //    }
        //    finally
        //    {
        //        // cleanup
        //        if (job != null)
        //            Marshal.ReleaseComObject(job);
        //        if (bcm != null)
        //            Marshal.ReleaseComObject(bcm);
        //    }
        //}

        // Test to see if the next patch is already in the file system
        //static Boolean PatchExists(Boolean async)
        //{
        //    if (File.Exists(patchName))
        //        return true;
        //    if (async)
        //    {
        //        ThreadPool.QueueUserWorkItem(new WaitCallback(HandleBits));
        //        return false;
        //    }
        //    else
        //    {
        //        HandleBits(null);
        //        return File.Exists(patchName);
        //    }
        //}

        //static String patchName = null;
        // static XmlState xml = null;
        //  static String baseDir = null;

        public static void Uninstall(string deploymentManifestPath)
        {
            //MessageBox.Show("Attach");
            LowTraceText = new StringBuilder();
            HighTraceText = new StringBuilder();
            Logger.Enter("Updater.Uninstall", new string[] { deploymentManifestPath });
            //LowTraceText.AppendLine("PO: HL in Uninstall Method: Entered into Uninstall method method", HighTraceInfo);
            HighTraceText.AppendLine("PO: HL in Uninstall Method: Entered into Uninstall method method");
            LowTraceText.AppendLine("PO: LL Step 35c in Uninstall Method : Entered into Uninstall method method");

            if (string.IsNullOrEmpty(deploymentManifestPath))
                throw new ArgumentException("Deployment manifest Path is blank or null");


            XElement xDeploymentManifest = null;
            string applicationBasepath = "";
            XElement xAppManifest = null;
            DeploymentManifestReader deploymentReader = null;

            try
            {
                // load the deployment manifest from the filename in the argument list.
                xDeploymentManifest = XElement.Load(deploymentManifestPath);

                // get a reader for the xml manifest.
                deploymentReader = new DeploymentManifestReader(xDeploymentManifest);

                // Get location to install on the target machine
                applicationBasepath = deploymentReader.TargetCodebase;

                Logger.Log("Updater.Uninstall", "Application base path: " + applicationBasepath);
                LowTraceText.AppendLine("PO: LL Step 35d in Uninstall Method : Application base path: " + applicationBasepath);

                if (!applicationBasepath.EndsWith("\\"))
                    applicationBasepath += "\\";

                DirectoryInfo diBasePath = new DirectoryInfo(applicationBasepath);

                Uri uri = new Uri(deploymentManifestPath);

                Uri uriBase = new Uri(deploymentReader.Codebase);
                Logger.Log("Updater.Uninstall", "Codebase:" + uriBase.ToString());
                LowTraceText.AppendLine("PO: LL Step 35e in Uninstall Method : Codebase:: " + uriBase.ToString());
                Uri localApp = new Uri(uriBase.GetVirtualRoot() + deploymentReader.ApplicationCodebase);
                string localAppManifestPath = applicationBasepath + localApp.GetFileName();
                xAppManifest = XElement.Load(localAppManifestPath);
                try
                {
                    ApplicationManifestReader appReader = new ApplicationManifestReader(xAppManifest);
                    string processName = appReader.GetEntryPointCommandLineFile(isClickOnceManifest);
                    processName = processName.Substring(0, processName.Length - 4);
                    Process[] processes = Process.GetProcessesByName(processName);
                    try
                    {
                        if (System.Reflection.Assembly.GetExecutingAssembly().CodeBase.ToLower().Contains(processName.ToLower()))
                        {
                            if (processes.Length > 0)
                            {
                                processes[0].Kill();
                                processes[0].WaitForExit(20000);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Logger.Log(e);
                        //LowTraceText.AppendLine("Po: HL Step 43 in Uninstall method: Uninstall method Catch-1 Exception" + e.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("Po: HL Step 43 in Uninstall method: Uninstall method Catch-1 Exception" + e.ToString());
                        LowTraceText.AppendLine("Po: LL in Uninstall method: Uninstall method Catch-1 Exception" + e.ToString());
                    }
                    bool success = true;
                    LowTraceText.AppendLine("PO: LL Step 35f in Uninstall Method : Calling UnRegisterFiles method defined in Updater Class");
                    UnRegisterFiles(xAppManifest, xDeploymentManifest, applicationBasepath);
                    LowTraceText.AppendLine("PO: LL Step 35o in Uninstall Method : Came out of UnRegisterFiles method defined in Updater Class");
                    success &= RemoveAssemblyFiles(xDeploymentManifest, xAppManifest, applicationBasepath);
                    success &= RemoveContentFiles(xDeploymentManifest, xAppManifest, applicationBasepath);
                    LowTraceText.AppendLine("PO: LL Step 35p in Uninstall Method : Calling RemoveAddRemoveProgramEntry method defined in Updater Class");
                    RemoveAddRemoveProgramEntry(xDeploymentManifest);
                    LowTraceText.AppendLine("PO: LL Step 35r in Uninstall Method : Came out of RemoveAddRemoveProgramEntry method defined in Updater Class");

                    LowTraceText.AppendLine("PO: LL Step 35s in Uninstall Method : Calling RemoveAllShortcutsForApplication method defined in Updater Class");
                    RemoveAllShortcutsForApplication(xDeploymentManifest);
                    LowTraceText.AppendLine("PO: LL Step 35v in Uninstall Method : Came out of RemoveAllShortcutsForApplication method defined in Updater Class");
                    success &= RemoveRemainingFiles(xDeploymentManifest, xAppManifest, applicationBasepath, success);
                    LowTraceText.AppendLine("PO: LL Step 35w in Uninstall Method : Calling RemoveFolders method defined in Updater Class");
                    RemoveFolders(xDeploymentManifest, xAppManifest, applicationBasepath);
                    LowTraceText.AppendLine("PO: LL Step 35y in Uninstall Method : Came out of RemoveFolders method defined in Updater Class");

                    //if (false == success)
                    //{
                    //    // add to startup menu with -uninstall argument.
                    //    shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                    //    if (!shortcutDest.EndsWith("\\"))
                    //        shortcutDest += "\\";
                    //    shortcutDest += "Start Menu\\Programs\\Startup";
                    //    CreateShortcut(shortcutDest, "", xDeploymentManifest, "/uninstall /q");
                    //}

                }
                catch (Exception ex)
                {
                    Logger.Log(ex);
                    //LowTraceText.AppendLine("Po: HL Step 50 in Updater.Uninstall Method: Updater.Uninstall method Exception" + ex.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 50 in Updater.Uninstall Method: Updater.Uninstall method Exception" + ex.ToString());
                    LowTraceText.AppendLine("Po: LL in Updater.Uninstall Method: Updater.Uninstall method Exception" + ex.ToString());
                }

                return;
            }
            finally
            {
                Logger.Exit("Updater.Uninstall");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void RemoveFolders(XElement xDeploymentManifest, XElement xAppManifest, string applicationBasepath)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in RemoveFolders Method : Entered into RemoveFolders method defined in Updater Class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in RemoveFolders Method : Entered into RemoveFolders method defined in Updater Class");
                LowTraceText.AppendLine("PO: LL Step 35x in RemoveFolders Method : Entered into RemoveFolders method defined in Updater Class");
                DirectoryInfo di = new DirectoryInfo(applicationBasepath);

                RemoveFoldersRecursive(di);
            }
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("Po: HL Step 49 in RemoveFolders Method: RemoveFolders method Exception" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 49 in RemoveFolders Method: RemoveFolders method Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in RemoveFolders Method: RemoveFolders method Exception" + ex.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static bool RemoveFoldersRecursive(DirectoryInfo di)
        {
            if (di.GetFiles().Length > 0)
                return false;

            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                if (false == RemoveFoldersRecursive(dir))
                    return false;
            }

            try
            {
                di.Delete();
            }
            catch
            {
                return false;
            }

            return true;
        }

        private static bool RemoveRemainingFiles(XElement xDeploymentManifest, XElement xAppManifest, string applicationBasepath, bool removeManifests)
        {
            bool success = true;

            DeploymentManifestReader depReader = new DeploymentManifestReader(xDeploymentManifest);

            Uri uri = new Uri(depReader.Codebase);

            if (!applicationBasepath.EndsWith("\\"))
                applicationBasepath += "\\";



            try
            {
                string path = applicationBasepath + uri.GetFileName();

                if (!System.IO.File.Exists(path))
                    throw new ApplicationException("Application Manifest File Missing");

                if (removeManifests)
                    System.IO.File.Delete(path);
                Uri localApp = new Uri(uri.GetVirtualRoot() + depReader.ApplicationCodebase);
                string localAppManifestPath = applicationBasepath + localApp.GetFileName();

                if (!System.IO.File.Exists(localAppManifestPath))
                    throw new ApplicationException("Deployment Manifest File Missing");

                if (removeManifests)
                    System.IO.File.Delete(localAppManifestPath);




            }
            catch (Exception e)
            {
                Logger.Log(e);
                success = false;
            }



            return success;
        }

        private static bool RemoveContentFiles(XElement xDeploymentManifest, XElement xAppManifest, string applicationBasepath)
        {
            Logger.Enter("Updater.RemoveContentFiles", new string[0]);

            try
            {
                bool success = true;
                ApplicationManifestReader appReader = new ApplicationManifestReader(xAppManifest);
                IEnumerable<XElement> xFiles = appReader.GetInstallableFiles(isClickOnceManifest);

                string codebase = string.Empty;
                string path = string.Empty;
                string localDestPath = string.Empty;

                foreach (XElement xFile in xFiles)
                {
                    codebase = xFile.Attribute("name").Value;
                    if (!codebase.Contains("\\"))
                    {
                        localDestPath = applicationBasepath + codebase;
                    }
                    else
                    {
                        if (DirectoryExtensions.IsVirtualDirectory(codebase))
                        {
                            localDestPath = DirectoryExtensions.ReplaceVirtualDirectory(codebase);
                        }
                        else
                        {
                            localDestPath = applicationBasepath + codebase;
                        }
                    }

                    if (localDestPath.EndsWith(".deploy"))
                        localDestPath = localDestPath.Replace(".deploy", "");
                    try
                    {
                        if (System.IO.File.Exists(localDestPath))
                        {
                            System.IO.File.Delete(localDestPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        Logger.Log(ex);
                    }
                }
                return success;
            }
            finally
            {
                Logger.Exit("Updater.RemoveContentFiles");
            }
        }

        private static bool RemoveAssemblyFiles(XElement xDeploymentManifest, XElement xAppManifest, string applicationBasepath)
        {
            ApplicationManifestReader appReader = new ApplicationManifestReader(xAppManifest);
            IEnumerable<XElement> dependentAssemblies = appReader.GetInstallableDependencies(isClickOnceManifest);
            string path = string.Empty;
            string codebase = string.Empty;
            bool success = true;
            string codebaseXpath = isClickOnceManifest ? "codebase" : "name";
            foreach (XElement e in dependentAssemblies)
            {
                codebase = e.Attribute(codebaseXpath).Value;
                path = applicationBasepath + codebase;
                try
                {
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                }
                catch (Exception ex)
                {
                    success = false;
                    Logger.Log(ex);
                }
            }
            return success;
        }

        public static void UpdateSelf(string[] args)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL on UpdateSelf method: Entered into UpdateSelf method defined in Updater class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL on UpdateSelf method: Entered into UpdateSelf method defined in Updater class");
                LowTraceText.AppendLine("PO: LL Step 29b in UpdateSelf Method: Entered into UpdateSelf method defined in Updater class ");
                string location = System.Reflection.Assembly.GetExecutingAssembly().Location;
                FileInfo fi = new FileInfo(location);
                DirectoryInfo di = new DirectoryInfo(location);
                string tempPath = fi.Directory.ToString() + "\\update";
                if (Directory.Exists(tempPath))
                    Directory.Delete(tempPath, true);

                DirectoryInfo diNew = Directory.CreateDirectory(tempPath);

                string destPath = diNew.FullName + "\\";

                System.IO.File.Copy(location, destPath + fi.Name);
                System.IO.File.Copy(fi.Directory.ToString() + "\\AmericanExpress.AutomaticUpdater.dll", destPath + "AmericanExpress.AutomaticUpdater.dll");
                //File.Copy(fi.Directory.ToString() + "\\Interop.IWshRuntimeLibrary.dll", destPath + "Interop.IWshRuntimeLibrary.dll");

                Process p = new Process();
                ProcessStartInfo psi = new ProcessStartInfo(destPath + fi.Name);
                //Directory.Delete(destPath, true);
            }
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("PO:: HL Step 9 in UpdateSelf method :UpdateSelf method Exception defined in Updater class" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL Step 9 in UpdateSelf method :UpdateSelf method Exception defined in Updater class" + ex.ToString());
                LowTraceText.AppendLine("PO:: LL in UpdateSelf method :UpdateSelf method Exception defined in Updater class" + ex.ToString());
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void RemoveAllShortcutsForApplication(XElement deploymentManifest)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in RemoveAllShortcutsForApplication Method : Entered into RemoveAllShortcutsForApplication method defined in Updater Class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in RemoveAllShortcutsForApplication Method : Entered into RemoveAllShortcutsForApplication method defined in Updater Class");
                LowTraceText.AppendLine("PO: LL Step 35t in RemoveAllShortcutsForApplication Method : Entered into RemoveAllShortcutsForApplication method defined in Updater Class");
                string shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                shortcutDest = Path.Combine(shortcutDest, "Desktop");
                LowTraceText.AppendLine("PO: LL Step 35u in RemoveAllShortcutsForApplication Method : Calling RemoveShortcut method defined in Updater Class");
                Updater.RemoveShortcut(shortcutDest, deploymentManifest);


                shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs\\Startup");
                Updater.RemoveShortcut(shortcutDest, deploymentManifest);

                shortcutDest = shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);
                Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Startup);
                Updater.RemoveShortcut(shortcutDest, deploymentManifest);
            }
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("Po: HL Step 48 in RemoveAllShortcutsForApplication Method: RemoveAllShortcutsForApplication method Exception" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 48 in RemoveAllShortcutsForApplication Method: RemoveAllShortcutsForApplication method Exception" + ex.ToString());
                LowTraceText.AppendLine("Po: LL in RemoveAllShortcutsForApplication Method: RemoveAllShortcutsForApplication method Exception" + ex.ToString());
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }



        }

        public static void InstallShortcutsAndAddRegistryInfo(string[] args, XElement deploymentManifest)
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO: HL in InstallShortcutsAndAddRegistryInfo method: Entered into InstallShortcutsAndAddRegistryInfo method in Updater class", HighTraceInfo);
                HighTraceText.AppendLine("PO: HL in InstallShortcutsAndAddRegistryInfo method: Entered into InstallShortcutsAndAddRegistryInfo method in Updater class");
                LowTraceText.AppendLine("PO: LL Step 34z-58.8 in InstallShortcutsAndAddRegistryInfo Method: Entered into InstallShortcutsAndAddRegistryInfo method in Updater class");
                Logger.Enter("ArgumentDispatcher.InstallShortcutsAndAddRegistryInfo", new string[] { args.ToString(), null == deploymentManifest ? "" : deploymentManifest.ToString() });
                string iconPattern = "/icon=\"{0,1}(?<path>.*)\"{0,1}";
                Match m = null;
                string iconPath = string.Empty;
                DeploymentManifestReader reader = new DeploymentManifestReader(deploymentManifest);
                IEnumerable<string> strIcon = args.Where(s => s.StartsWith("/icon"));
                if (strIcon.Count() > 0)
                {
                    m = Regex.Match(strIcon.First(), iconPattern);
                    iconPath = string.Empty;
                    if (m.Success)
                    {
                        iconPath = reader.TargetCodebase;
                        iconPath = Path.Combine(iconPath, m.Groups["path"].Value);
                    }
                }

                string shortcutDest = "";

                // First do requests from the command line.
                bool alwaysAddRemovePrograms = args.Where(s => s.Contains("/addremoveprograms")).Count() > 0;
                foreach (string arg in args)
                {
                    // /desktopshortcut command line option places 
                    // a desktop shortcut in the All Users profile.
                    LowTraceText.AppendLine("PO: LL Step 34z-58.9 in InstallShortcutsAndAddRegistryInfo Method: Calling CreateShortcut method(defined in Updater class) from InstallShortcutsAndAddRegistryInfo method ");
                    if (arg.Contains("/allusersdesktopshortcut"))
                    {
                        shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                        shortcutDest = Path.Combine(shortcutDest, "Desktop");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }

                    if (arg.Contains("/allusersstartupshortcut"))
                    {
                        shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                        shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs\\Startup");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }

                    if (arg.Contains("/allusersprogramshortcut"))
                    {
                        shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                        shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }

                    if (arg.Contains("/userdesktopshortcut"))
                    {
                        shortcutDest = shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }

                    if (arg.Contains("/userstartupshortcut"))
                    {
                        shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Startup);
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }

                    if (arg.Contains("/userprogramshorcut"))
                    {
                        shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Programs);
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                }

                // Next do requests from the manifest
                if (reader.InstallStartupShortcut != null)
                {
                    shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Startup);
                    if (reader.InstallStartupShortcut == true)
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Creating user startup shortcut for app");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Removing user startup shortcut for app");
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }
                }


                if (reader.InstallAllUsersStartupShortcut != null)
                {
                    shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                    shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs\\Startup");
                    if (reader.InstallAllUsersStartupShortcut == true)
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Creating all users startup shortcut for app");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Removing all users startup shortcut for app");
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }

                }

                // Programs group icon needed? (per user)
                if (reader.InstallProgramShortcut != null)
                {
                    shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Programs);
                    if (reader.InstallProgramShortcut == true)
                    {
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }
                }

                // Programs group icon needed? (ALL USERS)
                if (reader.InstallAllUsersProgramShortcut != null)
                {

                    shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                    shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs");
                    if (reader.InstallAllUsersProgramShortcut == true)
                    {
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }

                }

                if (reader.InstallDesktopShortcut != null)
                {
                    shortcutDest = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory);
                    if (reader.InstallDesktopShortcut == true)
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Creating user desktop shortcut for app");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Removing desktop shortcut for app");
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }
                }

                if (reader.InstallAllUsersDesktopShortcut != null)
                {
                    shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                    shortcutDest = Path.Combine(shortcutDest, "Desktop");

                    if (reader.InstallAllUsersDesktopShortcut == true)
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Creating all users desktop shortcut for app");
                        Updater.CreateShortcut(shortcutDest, iconPath, deploymentManifest, "");
                    }
                    else
                    {
                        Logger.Log("InstallShortcutsAndAddRegistryInfo", "Removing all users desktop shortcut for app");
                        Updater.RemoveShortcut(shortcutDest, deploymentManifest);
                    }

                }
                LowTraceText.AppendLine("PO: LL Step 34z-58.15 in InstallShortcutsAndAddRegistryInfo Method: Came out of CreateShortcut method & RemoveShortcut method");

                LowTraceText.AppendLine("PO: LL Step 34z-58.16 in InstallShortcutsAndAddRegistryInfo Method: Calling CreateAddRemoveProgramEntry method defined in Updater Class");
                Updater.CreateAddRemoveProgramEntry(deploymentManifest, iconPath, alwaysAddRemovePrograms);
                LowTraceText.AppendLine("PO: LL Step 34z-58.18 in InstallShortcutsAndAddRegistryInfo Method: Came out of CreateAddRemoveProgramEntry method defined in Updater Class");


            }
            catch (Exception e)
            {
                Logger.Log(e);
                //LowTraceText.AppendLine("Po: HL Step 42 in CreateShortcut method: ## InstallShortcutsAndAddRegistryInfo method Exception" + e.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("Po: HL Step 42 in CreateShortcut method: ## InstallShortcutsAndAddRegistryInfo method Exception" + e.ToString());
                LowTraceText.AppendLine("Po: LL in CreateShortcut method: ## InstallShortcutsAndAddRegistryInfo method Exception" + e.ToString());
            }
            finally
            {
                Logger.Exit("ArgumentDispatcher.InstallShortcutsAndAddRegistryInfo");
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
            }
        }

        //long mlngTotalBytesRead = 0;
        const int BUFFERSIZE = 16384;
        //bool mblnCancel = false;

        private static void DownloadSingleFile(string source, string dest)
        {
            // Download a single file from the source to the staging directory in
            // 16k chunks, raising UpgradeProgress events to indicate progress.
            System.Net.WebRequest reqFile;
            string strSourceFilePath;
            string strLocalPath;
            //string strServerPath;
            byte[] dlBuffer = new byte[BUFFERSIZE];
            FileStream localFile = null;
            int lngBytesRead;

            //if ( null == strDescription ) {
            //    strDescription = "";
            //}

            strSourceFilePath = source;
            reqFile = System.Net.WebRequest.Create(strSourceFilePath);
            reqFile.Headers.Add("cache-control", "no-cache");
            strLocalPath = dest;

            LowTraceText = new StringBuilder();
            HighTraceText = new StringBuilder();
            try
            {
                // The localpath may be a subdirectory of UpgradeDirectory, so we have
                // to make sure it exists
                //if (!Directory.Exists(Path.GetDirectoryName(strLocalPath)) ) {
                //    Directory.CreateDirectory(Path.GetDirectoryName(strLocalPath));
                //}
                //if ( !Directory.Exists(Path.GetDirectoryName(strServerPath)) ) {
                //    Directory.CreateDirectory(Path.GetDirectoryName(strServerPath));
                //}
                //LowTraceText.AppendLine("PO: HL in DownloadSingleFile Method: Entered into DownloadSingleFile method defined in Updater Class", HighTraceInfo);
                //LowTraceText.AppendLine("PO: LL Step 34z-42.10 in DownloadSingleFile Method: Entered into DownloadSingleFile method defined in Updater Class");

                localFile = new FileStream(strLocalPath, FileMode.OpenOrCreate);

                //if (strDescription.Trim().Length == 0 ) {
                //    strDescription = Path.GetFileName(strFileName);
                //}
                //if ( null != UpgradeProgress ) {
                //    UpgradeProgress("Downloading " + strDescription, strFileName, 
                //        this.PercentComplete, 0, ref mblnCancel);
                //}

                // Download the file in 16k chunks
                Stream stream = reqFile.GetResponse().GetResponseStream();

                do
                {
                    lngBytesRead = stream.Read(dlBuffer, 0, BUFFERSIZE);
                    //mlngTotalBytesRead = mlngTotalBytesRead + lngBytesRead;
                    localFile.Write(dlBuffer, 0, lngBytesRead);

                    //if ( null != UpgradeProgress ) {
                    //    UpgradeProgress( "Downloading " + strDescription, strFileName,
                    //        this.PercentComplete, this.EstimatedTimeRemaining, ref mblnCancel);
                    //}
                }
                while (lngBytesRead != 0 /*&& mblnCancel == false*/ );

                stream.Close();

                localFile.Flush();
                localFile.Close();
                localFile = null;

                //if ( !mblnCancel ) {
                // Set the date on the downloaded file to the date of the source
                System.IO.File.SetLastWriteTime(strLocalPath,
                    DateTime.Parse(reqFile.GetResponse().Headers["Last-Modified"]));
                //}                

            }

            catch (Exception exc)
            {
                try
                {
                    if (localFile != null)
                    {
                        localFile.Flush();
                        localFile.Close();
                        localFile = null;
                    }
                    if (System.IO.File.Exists(dest))
                        System.IO.File.Delete(dest);

                }
                catch (Exception ex)
                {
                    //LowTraceText.AppendLine("Po: HL Step 52 in DownloadSingleFile Method: DownloadSingleFile method Exception" + ex.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("Po: HL Step 52 in DownloadSingleFile Method: DownloadSingleFile method Exception" + ex.ToString());
                    LowTraceText.AppendLine("Po: LL in DownloadSingleFile Method: DownloadSingleFile method Exception" + ex.ToString());
                }


                IsException = "DownloadingException";
                downloadException = exc.Message.ToString();
                throw new ApplicationException("Error downloading file //" + source + "//", exc);
            }

            finally
            {
                if (localFile != null)
                {
                    localFile.Flush();
                    localFile.Close();
                }
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                reqFile.GetResponse().Close();
            }

        }

        private static void setManifestType(string[] args)
        {
            foreach (string arg in args)
            {
                if (arg == "/useAmexManifest")
                {
                    isClickOnceManifest = false;
                }
            }
        }

        public static void StartUpAppWatcher(string appPath)
        {

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
                //LowTraceText.AppendLine("PO:: HL in StartUpAppWatcher method: Entered into StartUpAppWatcher method in Updater.cs", HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL in StartUpAppWatcher method: Entered into StartUpAppWatcher method in Updater.cs");
                LowTraceText.AppendLine("PO:: LL Step 11b in StartUpAppWatcher method: StartUpAppWatcher method in Updater.cs called from Main Method");
                string shortcutDest = "";
                shortcutDest = System.Environment.GetEnvironmentVariable("ALLUSERSPROFILE");
                shortcutDest = Path.Combine(shortcutDest, "Start Menu\\Programs\\Startup");
                IWshRuntimeLibrary.WshShell shell = new IWshRuntimeLibrary.WshShell();
                string linkName = shortcutDest + "\\Axp.ApplicationWatcher" + ".lnk";
                IWshRuntimeLibrary.IWshShortcut shortcut = (IWshRuntimeLibrary.IWshShortcut)shell.CreateShortcut(linkName);
                shortcut.TargetPath = appPath + @"\Axp.ApplicationWatcher.exe";
                shortcut.WorkingDirectory = appPath;
                shortcut.Description = "Axp.ApplicationWatcher";
                shortcut.IconLocation = appPath + @"\AppWatcherfavicon.ico";
                shortcut.Save();
            }
            catch (Exception ex)
            {
                //LowTraceText.AppendLine("PO:: HL Step 1 in StartUpAppWatcher method :StartUpAppWatcher Exception" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PO:: HL Step 1 in StartUpAppWatcher method :StartUpAppWatcher Exception" + ex.ToString());
                LowTraceText.AppendLine("PO:: LL in StartUpAppWatcher method :StartUpAppWatcher Exception" + ex.ToString());

            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

            }
        }

        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                //mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                mainDirectory = ConfigurationSettings.AppSettings["MDPath"].ToString();
                string LowTraceInfo = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceInfo"].ToString();

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!System.IO.File.Exists(FilePath))
                    {
                        using (fs = System.IO.File.Create(FilePath))
                        {

                        }
                    }
                    if (System.IO.File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["PushOnceLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["PushOnceHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!System.IO.File.Exists(FilePath))
                    {
                        using (fs = System.IO.File.Create(FilePath))
                        {

                        }
                    }
                    if (System.IO.File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
            }

            catch (Exception ex1)
            {

            }
        }














    }
}

public class BackgroundCopyCallback : IBackgroundCopyCallback
{
    private ManualResetEvent evtSuccess = null;
    private ManualResetEvent evtError = null;
    public BackgroundCopyCallback(ManualResetEvent evtSuccess, ManualResetEvent evtError)
    {
        this.evtSuccess = evtSuccess;
        this.evtError = evtError;
    }

    #region IBackgroundCopyCallback Members

    public void JobTransferred(IBackgroundCopyJob pJob)
    {
        Debug.WriteLine("Job transferred");
        if (null != evtSuccess)
            evtSuccess.Set();
    }

    public void JobError(IBackgroundCopyJob pJob, IBackgroundCopyError pError)
    {
        Debug.WriteLine("Job Error");
        if (null != evtError)
            evtError.Set();

    }

    public void JobModification(IBackgroundCopyJob pJob, uint dwReserved)
    {
        Debug.WriteLine("Job Modified");
    }

    #endregion
}

