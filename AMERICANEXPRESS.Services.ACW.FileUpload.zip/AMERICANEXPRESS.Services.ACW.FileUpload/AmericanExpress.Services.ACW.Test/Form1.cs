﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AmericanExpress.Services.ACW.Business;



namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            ACWDAC dacDB = new ACWDAC(1);
            LogManager.InitializeSource(); 
            if (dacDB.ConnectDatabase())
            {
                //new ACWProcess(1, dacDB).StartProcess(null);
                new ACWProcess(1, dacDB).StartProcess(); 
                dacDB.CloseConnection();                              
            }
          
        }
      
    }
}
