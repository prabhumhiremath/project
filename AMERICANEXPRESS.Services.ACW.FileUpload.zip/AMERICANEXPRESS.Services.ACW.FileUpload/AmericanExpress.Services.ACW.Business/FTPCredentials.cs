﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.Services.ACW.Business
{



    class FTPCredentials
    {

        public string ServerName
        {
            get;
            set;
        }

        public string UserId
        {
            get;
            set;
        }

        public string Password
        {
            get;
            set;
        }

        public string RemoteFileName
        {
            get;
            set;
        }

        public string HandleMultipleFiles
        {
            get;
            set;
        }

        public string LocalDirectory
        {
            get;
            set;
        }
        public string LocalMoveDirectory
        {
            get;
            set;
        }

        public string RemoteDirectory
        {
            get;
            set;
        }

        public string Operation
        {
            get;
            set;
        }

        public string FileType
        {
            get;
            set;
        }

        public string Protocol
        {
            get;
            set;
        }

        public string FtpClient
        {
            get;
            set;
        }

        public int Port
        {
            get;
            set;
        }

        public string TumbleweedClientLocation
        {
            get;
            set;
        }

        public int WaitForExitDuration
        {
            get;
            set;
        }

        public string DownloadLog
        {
            get;
            set;
        }

        public string UploadLog
        {
            get;
            set;
        }

        //not used
        public string TumbleweebCommandParams
        {
            get;
            set;
        }
        
        //Additional properties for OUT & MOVED folders

        public string OutFolder
        {
            get;
            set;
        }

        public string MovedFolder
        {
            get;
            set;
        }

        public string FileFormatType
        {
            get;
            set;
        }
        public FTPCredentials()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }

       

    }

