////-----------------------------------------------------------------------
//// <copyright file="ConfigManager.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description> This file contains the Implementation of ConfigManager class</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
#region Imported Namespace
using System;
using System.Configuration;
#endregion

namespace AmericanExpress.Services.ACW.Business
{
	/// <summary>
	/// ConfigManager Class implementation
	/// </summary>
	class ConfigManager
    {
        #region Config Manager Constructor
        public ConfigManager()
		{

        }
        #endregion

        #region This will return the Connection String 
        public static String ConnectionString(string encCS) 
		{
			string decCS;
            decCS = ConfigurationManager.ConnectionStrings[encCS].ConnectionString;
            return decCS;
        }
        #endregion
    }

}
