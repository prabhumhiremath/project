﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.Services.ACW.Business
{
    public class FTPException : Exception
    {
        private int errorCode;

        public int ErrorCode
        {
            get { return errorCode; }
        }
        public FTPException()
            : base()
        {
            errorCode = 0;
        }

        public FTPException(string message)
            : base(message)
        {
            errorCode = 0;
        }

        public FTPException(string message, FTPException innerException)
            : base(message, innerException)
        {
            this.errorCode = 0;
        }

        public FTPException(string message, int errorCode, FTPException innerException)
            : base(message, innerException)
        {
            this.errorCode = errorCode;

        }
        public FTPException(string message, int errorCode, Exception innerException)
            : base(message, innerException)
        {
            this.errorCode = errorCode;

        }
    }
}
