﻿////-----------------------------------------------------------------------
//// <copyright file="Program.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This main class of window service from where window service will start</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
 

using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;
using AmericanExpress.Services.ACW.Business;

namespace AmericanExpress.Services.ACW.FileUpload
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            //Initialise the Log Manager
            LogManager.InitializeSource(); 

            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                LogManager.LogUnhandledError(LogManager.source + " IsTerminating =" + e.IsTerminating.ToString(), 0, e.ExceptionObject.ToString());
            };

            //running the service
            ServiceBase[] ServicesToRun;

            ServicesToRun = new ServiceBase[] { new AppScheduler() };
            
            ServiceBase.Run(ServicesToRun);
        }
    }
}
