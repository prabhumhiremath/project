﻿////-----------------------------------------------------------------------
//// <copyright file="AppScheduler.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This class which start the execution of window service.</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------

using System.ServiceProcess;
using System.Timers;
using ACWBusiness = AmericanExpress.Services.ACW.Business;
using AmericanExpress.Services.ACW.Business;
using System.Configuration;
using System;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Data;



namespace AmericanExpress.Services.ACW.FileUpload
{
    public partial class AppScheduler : ServiceBase
    {
        #region Declarations Variables
        System.Timers.Timer myTimer;
                
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor to initialise the component and to add event handler
        /// </summary>
        public AppScheduler()
        {
            InitializeComponent();
            this.CanPauseAndContinue = true;
            this.ServiceName = ConfigurationManager.AppSettings["EventSource"].ToString(); 
            myTimer = new System.Timers.Timer();
            myTimer.Elapsed += new ElapsedEventHandler(myTimer_Elapsed);
            myTimer.Interval = 30000; //time elapses for 30 sec
        }
        #endregion

        #region Events
        /// <summary>
        /// Event invoke after time elapsed
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">ElapsedEventArgs</param>
        protected void myTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            myTimer.Stop();
            ScheduleStarter appScheduler = new ScheduleStarter();
            appScheduler.StartApp();
        }
        /// <summary>
        /// Event invoked when service is started first time
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {
            ACWBusiness.LogManager.LogInfoMessage(ACWBusiness.LogManager.source + " Started LaunchThread is over", 2001,"Y");
            myTimer.Start();
        }
        /// <summary>
        /// Event invoked when service is stopped
        /// Stopping the Timer
        /// </summary>
        protected override void OnStop()
        {
            myTimer.Stop();
        }


        


        #endregion
    }
}
