﻿////-----------------------------------------------------------------------
//// <copyright file="IACWProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of IACWProcess Interface</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>10/09/2012</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System.Data;
namespace AmericanExpress.Services.ACW.BusinessInterface
{
    /// <summary>
    /// This method is used for starting the process
    /// </summary>
    public interface IACWProcess
    {        
        void StartProcess();
    }
}
