﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Xml;
using System.IO;
using System.Collections;
using Axp.ApplicationWatcher.GDUService;
using System.Security.Principal;
using System.Net;
using System.Configuration;
using System.ServiceModel;
using System.DirectoryServices;
using System.Threading;

namespace Axp.ApplicationWatcher
{
    public partial class Form1 : Form
    {
        #region Variables Declaration

        public static string appName, prevvalue;
        public static string appltitle;
        public static Form1 form1;
        public static string tempstr;
        public static Hashtable applhash2;
        //System.DateTime dataInsertTime;
        private string FilePath;
        private string FileName;
        private string FileToSave;
        StandardResponse std = new StandardResponse();
        GDUServiceClient gduApp = new GDUServiceClient();
        ManageAppFocusQuery appFocusInput = new ManageAppFocusQuery();
        DurationTime durationTime;
        TimeDurationDetails[] tdDetails;
        string TimeDuration;
        string timeFormat;
        string fileContents;
        public string strActive = "0";
        private static string ProductId = "travelsuite_application_monitor_fileio_mutex";
        private static Mutex appMutex = null;

        AppFocusIndicator[] AppFIndicator;
        string AppFocusIndicator;
        string TravelSuiteIndicator;
        string ACWIndicator;

        DataTable dtAppfIndicator = new DataTable();
        DataRow drAppfInfo;

        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string AWFilePath = string.Empty;
        private static string mainDirectory = string.Empty;

        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;


        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        [STAThread]
        static void Main()
        {
            applhash2 = new Hashtable();
            form1 = new Form1();
            Application.Run(form1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {

                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //added on 29/July/2013 to set timer interval from app.config
                timer1.Interval = Int32.Parse(ConfigurationSettings.AppSettings["Interval"].ToString());
                timer1.Enabled = true;

                DeleteFile();
                //LogtoEvent("AW:: HL on Form Load method: Entered into Form Load method", HighTraceInfo);
                HighTraceText.AppendLine("AW:: HL on Form Load method: Entered into Form Load method" );


                this.WindowState = FormWindowState.Minimized;
                this.ShowInTaskbar = false;
                this.Hide();

                //LogtoEvent("AW:: LL Step 1 on Form Load : Capturing the todays date time**************************" + System.DateTime.Now, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 1 on Form Load : Capturing the todays date time**************************" + System.DateTime.Now);

                Process[] localByName = Process.GetProcessesByName("Axp.ApplicationWatcher");
                //LogtoEvent("AW:: LL Step 2 on Form Load : Length=" + localByName.Length, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 2 on Form Load : Length=" + localByName.Length);

                if (localByName.Length > 1)
                {
                    //LogtoEvent("AW:: LL Step 3 on Form Load : Length=" + localByName.Length, LowTraceInfo);
                    //LogtoEvent("AW:: LL Step 4 on Form Load : Length > 1 ", LowTraceInfo);

                    LowTraceText.AppendLine("AW:: LL Step 3 on Form Load : Length=" + localByName.Length);
                    LowTraceText.AppendLine("AW:: LL Step 4 on Form Load : Length > 1 ");

                    this.Close();
                }

                try
                {
                    //LogtoEvent("AW:: LL Step 5 on Form Load : In Form Load Check Office Active or Not", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 5 on Form Load : In Form Load Check Office Active or Not");

                    AddOfficeQuery AddOfficeInput = new AddOfficeQuery();
                    std = new StandardResponse();
                    gduApp = new GDUServiceClient();
                    //LogtoEvent("AW:: LL Step 5a on Form Load : Calling GetUserName() method from Form Load method ", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 5a on Form Load : Calling GetUserName() method from Form Load method ");

                    AddOfficeInput.ADSId = GetUserName();
                    //LogtoEvent("AW:: LL Step 5d on Form Load : Came out of GetUserName() method inside Form Load method ", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 5d on Form Load : Came out of GetUserName() method inside Form Load method ");

                    AddOfficeInput.OfficeId = (System.Net.Dns.GetHostName()).Substring(0, 3).ToString();
                    //LogtoEvent("AW:: LL Step 5e on Form Load : ADS_ID=" + AddOfficeInput.ADSId, LowTraceInfo);
                    //LogtoEvent("AW:: LL Step 5f on Form Load : OfficeId=" + AddOfficeInput.OfficeId, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 5e on Form Load : ADS_ID=" + AddOfficeInput.ADSId);
                    LowTraceText.AppendLine("AW:: LL Step 5f on Form Load : OfficeId=" + AddOfficeInput.OfficeId);

                    std = gduApp.AddOffice(AddOfficeInput);
                    strActive = std.ResponseMessage;
                    //LogtoEvent("AW:: LL Step 6 on Form Load : Form Load strActive=" + strActive, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 6 on Form Load : Form Load strActive=" + strActive);


                }
                catch (Exception ex)
                {
                    this.WindowState = FormWindowState.Minimized;
                    this.ShowInTaskbar = false;
                    this.Hide();
                    //LogtoEvent("AW:: HL Step 1 on Form Load method: Form Load Check Office Active EXCEPTION=" + ex.Message.ToString(), HighTraceInfo);
                    //LogtoEvent("AW:: LL on Form Load method: Form Load Check Office Active EXCEPTION=" + ex.Message.ToString(), LowTraceInfo);
                    HighTraceText.AppendLine("AW:: HL Step 1 on Form Load method: Form Load Check Office Active EXCEPTION=" + ex.Message.ToString());
                    LowTraceText.AppendLine("AW:: LL on Form Load method: Form Load Check Office Active EXCEPTION=" + ex.Message.ToString());


                }
                try
                {
                    //LogtoEvent("AW:: LL Step 7 on Form Load : Create directory for FilePath & TravelSuiteFilePath incase it doesn't exist", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 7 on Form Load : Create directory for FilePath & TravelSuiteFilePath incase it doesn't exist");

                    if (!Directory.Exists(ConfigurationSettings.AppSettings["FilePath"].ToString()))
                        Directory.CreateDirectory(ConfigurationSettings.AppSettings["FilePath"].ToString());

                    if (!Directory.Exists(ConfigurationSettings.AppSettings["TravelSuiteFilePath"].ToString()))
                        Directory.CreateDirectory(ConfigurationSettings.AppSettings["TravelSuiteFilePath"].ToString());

                    //dataInsertTime = System.DateTime.Now;
                    gduApp = new GDUServiceClient();
                    durationTime = new DurationTime();

                    try
                    {
                        //LogtoEvent("AW:: LL Step 8 on Form Load : Check User Exist", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 8 on Form Load : Check User Exist");


                        bool UserExists = CheckUserExists();
                        if (UserExists == false)
                        {
                            //LogtoEvent("AW:: LL Step 9 on Form Load : Calling Add User method", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 9 on Form Load : Calling Add User method");

                            AddUser();
                        }
                    }
                    catch (Exception ex)
                    {
                        this.WindowState = FormWindowState.Minimized;
                        this.ShowInTaskbar = false;
                        this.Hide();
                        //LogtoEvent("AW:: HL Step 4 on Form Load : Add User Exception :" + ex.ToString(), HighTraceInfo);
                        //LogtoEvent("AW:: LL on Form Load : Add User Exception :" + ex.ToString(), LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 4 on Form Load : Add User Exception :" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL on Form Load : Add User Exception :" + ex.Message.ToString());

                    }
                    //LogtoEvent("AW:: LL Step 10 on Form Load : Calling SearchTimeDuration method using GDU service", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 10 on Form Load : Calling SearchTimeDuration method using GDU service");

                    tdDetails = gduApp.SearchTimeDuration(durationTime);
                    TimeDuration = tdDetails[0].TimeDuration.ToString();
                    timeFormat = tdDetails[0].TimeFormat.ToString();
                    //LogtoEvent("AW:: LL Step 11 on Form Load : TimeDuration=" + TimeDuration, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 11 on Form Load : TimeDuration=" + TimeDuration);


                    //------------------------------------------------------------
                    try
                    {
                        //LogtoEvent("AW:: LL Step 12 on Form Load : In Check indicator", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 12 on Form Load : In Check indicator");

                        std = new StandardResponse();
                        gduApp = new GDUServiceClient();
                        //LogtoEvent("AW:: LL Step 13 on Form Load : Calling PopulateAppFIndicator method using GDU service", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 13 on Form Load : Calling PopulateAppFIndicator method using GDU service");


                        std = gduApp.PopulateAppFIndicator(out AppFIndicator);

                        dtAppfIndicator = new DataTable();
                        dtAppfIndicator.Columns.Add("IND_NAME", Type.GetType("System.String"));
                        dtAppfIndicator.Columns.Add("IND_VALUE", Type.GetType("System.String"));


                        for (int iCount = 0; iCount < AppFIndicator.Length; iCount++)
                        {
                            drAppfInfo = dtAppfIndicator.NewRow();
                            drAppfInfo["IND_NAME"] = AppFIndicator[iCount].IndicatorName;
                            drAppfInfo["IND_VALUE"] = AppFIndicator[iCount].AppFIndicator;
                            dtAppfIndicator.Rows.Add(drAppfInfo);
                        }

                        if (!object.Equals(dtAppfIndicator, null))
                        {
                            if (dtAppfIndicator.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtAppfIndicator.Rows.Count; i++)
                                {
                                    if (dtAppfIndicator.Rows[i]["IND_NAME"].ToString() == "AppFocus")
                                    {
                                        AppFocusIndicator = dtAppfIndicator.Rows[i]["IND_VALUE"].ToString();
                                    }
                                    if (dtAppfIndicator.Rows[i]["IND_NAME"].ToString() == "TravelSuite")
                                    {
                                        TravelSuiteIndicator = dtAppfIndicator.Rows[i]["IND_VALUE"].ToString();
                                    }
                                    if (dtAppfIndicator.Rows[i]["IND_NAME"].ToString() == "ACWAppInd")
                                    {
                                        ACWIndicator = dtAppfIndicator.Rows[i]["IND_VALUE"].ToString();
                                    }
                                }
                            }
                        }

                        //LogtoEvent("AW:: LL Step 14 on Form Load : AppFocusIndicator =" + AppFocusIndicator, LowTraceInfo);
                        //LogtoEvent("AW:: LL Step 15 on Form Load : TravelSuiteIndicator =" + TravelSuiteIndicator, LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 14 on Form Load : AppFocusIndicator =" + AppFocusIndicator);
                        LowTraceText.AppendLine("AW:: LL Step 15 on Form Load : TravelSuiteIndicator =" + TravelSuiteIndicator);


                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("AW:: HL Step 5 on Form Load: Check indicator Exception :" + ex.ToString(), HighTraceInfo);
                        //LogtoEvent("AW:: LL on Form Load: Check indicator Exception :" + ex.ToString(), LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 5 on Form Load: Check indicator Exception :" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL on Form Load: Check indicator Exception :" + ex.Message.ToString());

                    }
                    //------------------------------------------------------------

                    //if (ConfigurationSettings.AppSettings["TimeDurationType"].ToString() == "M")
                    //    dataInsertTime = dataInsertTime.AddMinutes(double.Parse(TimeDuration));
                    //else
                    //    dataInsertTime = dataInsertTime.AddHours(double.Parse(TimeDuration));

                    string[] files = Directory.GetFiles(ConfigurationSettings.AppSettings["FilePath"].ToString(), ConfigurationSettings.AppSettings["FileName"].ToString() + "*.xml", SearchOption.AllDirectories);
                    for (int i = 0; i < files.Length; i++)
                    {
                        System.IO.File.Delete(files[i]);
                    }
                    FilePath = ConfigurationSettings.AppSettings["FilePath"].ToString() + "\\" + ConfigurationSettings.AppSettings["FileName"].ToString() + "~";
                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                    //System.IO.File.Create(FilePath + FileName).Close();
                    //LogtoEvent("AW:: LL Step 16 on Form Load : Calling System.IO.File.Create()", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 16 on Form Load : Calling System.IO.File.Create()");

                    System.IO.File.Create(FilePath + "FW_" + FileToSave).Close();
                    //LogtoEvent("AW:: LL Step 17 on Form Load : Step 17a: FilePath=" + FilePath + "Step 17b: FileName=" + FileName + "Step 17c: FileToSave=" + FileToSave, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 17 on Form Load : Step 17a: FilePath=" + FilePath + "Step 17b: FileName=" + FileName + "Step 17c: FileToSave=" + FileToSave);


                }
                catch (Exception ex)
                {
                    this.WindowState = FormWindowState.Minimized;
                    this.ShowInTaskbar = false;
                    this.Hide();
                    //LogtoEvent("AW:: HL Step 6 on Form Load: Form1_Load Exception" + ex.ToString(), HighTraceInfo);
                    //LogtoEvent("AW:: LL on Form Load: Form1_Load Exception" + ex.ToString(), LowTraceInfo);
                    HighTraceText.AppendLine("AW:: HL Step 6 on Form Load: Form1_Load Exception" + ex.Message.ToString());
                    LowTraceText.AppendLine("AW:: LL on Form Load: Form1_Load Exception" + ex.Message.ToString());

                }

                this.WindowState = FormWindowState.Minimized;
                this.ShowInTaskbar = false;
                this.Hide();
            }
            
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
    
        }

        private void timer1_Tick(object sender, System.EventArgs e)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                string configTime = ConfigurationSettings.AppSettings["Time"].ToString();
                string systemTime = String.Format("{0:HH:mm:ss}", System.DateTime.Now);
                if (configTime == systemTime)
                {

                    DeleteFile();
                    if ((strActive) == "0")
                    {
                        try
                        {

                            AddOfficeQuery AddOfficeInput = new AddOfficeQuery();
                            std = new StandardResponse();
                            gduApp = new GDUServiceClient();

                            AddOfficeInput.ADSId = GetUserName();

                            AddOfficeInput.OfficeId = (System.Net.Dns.GetHostName()).Substring(0, 3).ToString();

                            std = gduApp.AddOffice(AddOfficeInput);
                            strActive = std.ResponseMessage;
                        }
                        catch (Exception ex)
                        {
                            //LogtoEvent("AW:: HL Step 7 on timer1_Tick method: strActive EXCEPTION=" + ex.Message, HighTraceInfo);
                            //LogtoEvent("AW:: LL on timer1_Tick method: strActive EXCEPTION=" + ex.Message, LowTraceInfo);
                            HighTraceText.AppendLine("AW:: HL Step 7 on timer1_Tick method: strActive EXCEPTION=" + ex.Message.ToString());
                            LowTraceText.AppendLine("AW:: LL on timer1_Tick method: strActive EXCEPTION=" + ex.Message.ToString());

                        }
                    }

                    try
                    {

                        std = new StandardResponse();
                        gduApp = new GDUServiceClient();
                        std = gduApp.PopulateAppFIndicator(out AppFIndicator);
                        //AppFocusIndicator = AppFIndicator[0].AppFIndicator.ToString();
                        //TravelSuiteIndicator = AppFIndicator[1].AppFIndicator.ToString();
                        //ACWIndicator = AppFIndicator[2].AppFIndicator.ToString();

                        dtAppfIndicator = new DataTable();
                        dtAppfIndicator.Columns.Add("IND_NAME", Type.GetType("System.String"));
                        dtAppfIndicator.Columns.Add("IND_VALUE", Type.GetType("System.String"));

                        for (int iCount = 0; iCount < AppFIndicator.Length; iCount++)
                        {
                            drAppfInfo = dtAppfIndicator.NewRow();
                            drAppfInfo["IND_NAME"] = AppFIndicator[iCount].IndicatorName;
                            drAppfInfo["IND_VALUE"] = AppFIndicator[iCount].AppFIndicator;
                            dtAppfIndicator.Rows.Add(drAppfInfo);
                        }

                        if (!object.Equals(dtAppfIndicator, null))
                        {
                            if (dtAppfIndicator.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtAppfIndicator.Rows.Count; i++)
                                {
                                    if (dtAppfIndicator.Rows[i]["APP_TYPE"].ToString() == "AppFocus")
                                    {
                                        AppFocusIndicator = dtAppfIndicator.Rows[i]["APPF_INDICATOR"].ToString();
                                    }
                                    if (dtAppfIndicator.Rows[i]["APP_TYPE"].ToString() == "TravelSuite")
                                    {
                                        TravelSuiteIndicator = dtAppfIndicator.Rows[i]["APPF_INDICATOR"].ToString();
                                    }
                                    if (dtAppfIndicator.Rows[i]["APP_TYPE"].ToString() == "ACWAppInd")
                                    {
                                        ACWIndicator = dtAppfIndicator.Rows[i]["APPF_INDICATOR"].ToString();
                                    }
                                }
                            }
                        }

                        //LogtoEvent("AW:: LL Step 27 on timer1_Tick method: Value of AppFocusIndicator from PopulateAppFIndicator method(called from GDU service) is:  AppFocusIndicator =" + AppFocusIndicator, LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 27 on timer1_Tick method: Value of AppFocusIndicator from PopulateAppFIndicator method(called from GDU service) is:  AppFocusIndicator =" + AppFocusIndicator);

                        //LogtoEvent("AppFocusIndicator =" + AppFocusIndicator);
                        //LogtoEvent("AW:: LL Step 28 on timer1_Tick method: Value of AppFocusIndicator from PopulateAppFIndicator method(called from GDU service) is:  TravelSuiteIndicator=" + TravelSuiteIndicator, LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 28 on timer1_Tick method: Value of AppFocusIndicator from PopulateAppFIndicator method(called from GDU service) is:  TravelSuiteIndicator=" + TravelSuiteIndicator);


                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("AW:: HL Step 8 on timer1_Tick method: Check indicator EXCEPTION is:=" + ex.Message, HighTraceInfo);
                        //LogtoEvent("AW:: LL on timer1_Tick method: Check indicator EXCEPTION is:=" + ex.Message, LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 8 on timer1_Tick method: Check indicator EXCEPTION is:=" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL on timer1_Tick method: Check indicator EXCEPTION is:=" + ex.Message.ToString());


                    }
                }
                if ((strActive) == "1")
                {
                    try
                    {
                        if (((TravelSuiteIndicator) != "False") || ((ACWIndicator) != "False"))
                        {
                            string[] files = Directory.GetFiles(ConfigurationSettings.AppSettings["TravelSuiteFilePath"].ToString(), "*.xml", SearchOption.AllDirectories);
                            for (int i = 0; i < files.Length; i++)
                            {
                                //LogtoEvent("AW:: LL Step 29 in timer1_Tick method: Travel Suite File Path= " + files[i], LowTraceInfo);
                                //LogtoEvent("AW:: LL Step 29a in timer1_Tick method: Calling TravelSuiteFileRead method", LowTraceInfo);

                                TravelSuiteFileRead(files[i]);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("AW:: HL Step 9 on timer1_Tick method: Travel Suite Exception is:=" + ex.Message, HighTraceInfo);
                        //LogtoEvent("AW:: LL on timer1_Tick method: Travel Suite Exception is:=" + ex.Message, LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 9 on timer1_Tick method: Travel Suite Exception is:=" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL on timer1_Tick method: Travel Suite Exception is:=" + ex.Message.ToString());

                    }
                    try
                    {
                        if ((AppFocusIndicator) == "True")
                        {
                            IntPtr hwnd = APIFuncs.getforegroundWindow();
                            Int32 pid = APIFuncs.GetWindowProcessID(hwnd);
                            Process p = Process.GetProcessById(pid);
                            appName = p.ProcessName;
                            appltitle = APIFuncs.ActiveApplTitle().Trim().Replace("\0", "");
                            //LogtoEvent("AW:: LL Step 30 on timer1_Tick method: appName=" + appName, LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 30 on timer1_Tick method: appName=" + appName);

                            if (!applhash2.Contains(appltitle + "$$$!!!" + appName))
                                applhash2.Add(appltitle + "$$$!!!" + appName, System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                            if (prevvalue != (appltitle + "$$$!!!" + appName))
                            {
                                //LogtoEvent("AW:: LL Step 31 on timer1_Tick method: Focus Changed prevvalue=" + prevvalue + " - New App: " + appltitle + "$$$!!!" + appName, LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 31 on timer1_Tick method: Focus Changed prevvalue=" + prevvalue + " - New App: " + appltitle + "$$$!!!" + appName);

                                IDictionaryEnumerator en = applhash2.GetEnumerator();
                                while (en.MoveNext())
                                {
                                    if (en.Key.ToString() == prevvalue)
                                    {
                                        //LogtoEvent("AW:: LL Step 32 on timer1_Tick method: In Timer Tick Values Match= " + prevvalue, LowTraceInfo);
                                        LowTraceText.AppendLine("AW:: LL Step 32 on timer1_Tick method: In Timer Tick Values Match= " + prevvalue);

                                        string pValue = (string)applhash2[prevvalue];
                                        applhash2.Remove(prevvalue);
                                        string _nkey = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss").ToString();
                                        if (!applhash2.Contains(prevvalue + "-" + _nkey))
                                            applhash2.Add(prevvalue + "-" + _nkey, pValue + "~" + _nkey);
                                        break;
                                    }

                                }
                                prevvalue = appltitle + "$$$!!!" + appName;

                            }
                            //LogtoEvent("AW:: LL Step 33 in timer1_Tick method: Calling SaveandShowDetails() method", LowTraceInfo);
                            SaveandShowDetails(FilePath + "FW_" + FileToSave);
                            //LogtoEvent("AW:: LL Step 35 in timer1_Tick method: Came out of SaveandShowDetails method called from timer1_Tick method", LowTraceInfo);

                            string FileTime = FileName.Substring(FileName.LastIndexOf('~') + 1, 8).Replace('_', ':');
                            DateTime interval = new DateTime(int.Parse(FileName.Substring(6, 4)), int.Parse(FileName.Substring(3, 2)), int.Parse(FileName.Substring(0, 2)), int.Parse(FileTime.Substring(0, 2)), int.Parse(FileTime.Substring(3, 2)), int.Parse(FileTime.Substring(6, 2)));

                            if (timeFormat == "M")
                                interval = interval.AddMinutes(double.Parse(TimeDuration));
                            else
                                interval = interval.AddHours(double.Parse(TimeDuration));

                            if (System.DateTime.Now > interval)
                            {
                                try
                                {
                                    string CurrentFile = FilePath + "FW_" + FileToSave;
                                    //LogtoEvent("AW:: LL Step 36 in timer1_Tick method: In TimeDuration Match: CurrentFile=" + CurrentFile, LowTraceInfo);

                                    applhash2 = new Hashtable();
                                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                    //LogtoEvent("AW:: LL Step 37 in timer1_Tick method: Calling saveAppFocusData method again(second time) from timer1_Tick method", LowTraceInfo);

                                    saveAppFocusData(CurrentFile);

                                    if (((TravelSuiteIndicator) != "False") || ((ACWIndicator) != "False"))
                                    {
                                        string[] files = Directory.GetFiles(ConfigurationSettings.AppSettings["TravelSuiteFilePath"].ToString(), "*.xml", SearchOption.AllDirectories);
                                        for (int i = 0; i < files.Length; i++)
                                        {
                                            //LogtoEvent("AW:: LL Step 39 in timer1_Tick method: TS File Path=" + files[i], LowTraceInfo);
                                            LowTraceText.AppendLine("AW:: LL Step 39 in timer1_Tick method: TS File Path=" + files[i]);

                                            //LogtoEvent("AW:: LL Step 40 in timer1_Tick method: Calling TravelSuiteFileReadByDefaultTime method from timer1_Tick method", LowTraceInfo);
                                            TravelSuiteFileReadByDefaultTime(files[i]);
                                            //LogtoEvent("AW:: LL Step 41 in timer1_Tick method: Came out of TravelSuiteFileReadByDefaultTime method called from timer1_Tick method", LowTraceInfo);
                                            //LowTraceText.AppendLine("AW:: LL Step 41 in timer1_Tick method: Came out of TravelSuiteFileReadByDefaultTime method called from timer1_Tick method");

                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //LogtoEvent("AW:: HL Step 13 in timer1_Tick method : ( In TimeDuration Match)Inside if (System.DateTime.Now > interval) condition & Exception is:=" + ex.ToString(), HighTraceInfo);
                                    //LogtoEvent("AW:: LL in timer1_Tick method : ( In TimeDuration Match)Inside if (System.DateTime.Now > interval) condition & Exception is:=" + ex.ToString(), LowTraceInfo);
                                    HighTraceText.AppendLine("AW:: HL Step 13 in timer1_Tick method : ( In TimeDuration Match)Inside if (System.DateTime.Now > interval) condition & Exception is:=" + ex.Message.ToString());
                                    LowTraceText.AppendLine("AW:: LL in timer1_Tick method : ( In TimeDuration Match)Inside if (System.DateTime.Now > interval) condition & Exception is:=" + ex.Message.ToString());

                                    applhash2 = new Hashtable();
                                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                }
                            }
                        }
                        else if (((TravelSuiteIndicator) != "False") || ((ACWIndicator) != "False"))
                        {
                            //LogtoEvent("AW:: LL Step 42 in timer1_Tick method: App Focus F & TS is T", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 42 in timer1_Tick method: App Focus F & TS is T");

                            string FileTime = FileName.Substring(FileName.LastIndexOf('~') + 1, 8).Replace('_', ':');
                            DateTime interval = new DateTime(int.Parse(FileName.Substring(6, 4)), int.Parse(FileName.Substring(3, 2)), int.Parse(FileName.Substring(0, 2)), int.Parse(FileTime.Substring(0, 2)), int.Parse(FileTime.Substring(3, 2)), int.Parse(FileTime.Substring(6, 2)));

                            if (timeFormat == "M")
                                interval = interval.AddMinutes(double.Parse(TimeDuration));
                            else
                                interval = interval.AddHours(double.Parse(TimeDuration));

                            if (System.DateTime.Now > interval)
                            {
                                try
                                {
                                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();

                                    string[] files = Directory.GetFiles(ConfigurationSettings.AppSettings["TravelSuiteFilePath"].ToString(), "*.xml", SearchOption.AllDirectories);
                                    for (int i = 0; i < files.Length; i++)
                                    {
                                        LogtoEvent("AW:: LL Step 43 in timer1_Tick method: TS FT File Path= " + files[i], LowTraceInfo);
                                        LowTraceText.AppendLine("AW:: LL Step 43 in timer1_Tick method: TS FT File Path= " + files[i]);
                                        
                                        //LogtoEvent("AW:: LL Step 44 in timer1_Tick method: Calling TravelSuiteFileReadByDefaultTime method again from timer1_Tick method", LowTraceInfo);
                                        TravelSuiteFileReadByDefaultTime(files[i]);
                                        //LogtoEvent("AW:: LL Step 45 in timer1_Tick method: Came out of TravelSuiteFileReadByDefaultTime method again called from timer1_Tick method", LowTraceInfo);
                                        LowTraceText.AppendLine("AW:: LL Step 45 in timer1_Tick method: Came out of TravelSuiteFileReadByDefaultTime method again called from timer1_Tick method");


                                    }
                                }
                                catch (Exception ex)
                                {
                                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("AW:: HL Step 16 in timer1_Tick method :timer1_Tick for if ((AppFocusIndicator) == True) condition, Exception" + ex.ToString(), HighTraceInfo);
                        //LogtoEvent("AW:: LL in timer1_Tick method :timer1_Tick for if ((AppFocusIndicator) == True) condition, Exception" + ex.ToString(), LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 16 in timer1_Tick method :timer1_Tick for if ((AppFocusIndicator) == True) condition, Exception" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL in timer1_Tick method :timer1_Tick for if ((AppFocusIndicator) == True) condition, Exception" + ex.Message.ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 17 in timer1_Tick method :timer1_Tick Exception" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL in timer1_Tick method :timer1_Tick Exception" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 17 in timer1_Tick method :timer1_Tick Exception" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL in timer1_Tick method :timer1_Tick Exception" + ex.Message.ToString());

            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        private void GetFirstFocusedChangedApp()
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL on GetFirstFocusedChangedApp method: Entered into GetFirstFocusedChangedApp method called from SaveandShowDetails method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 33b-1 in GetFirstFocusedChangedApp method: Entered into GetFirstFocusedChangedApp method called from SaveandShowDetails method", LowTraceInfo);
                //LowTraceText.AppendLine("AW:: LL Step 33b-1 in GetFirstFocusedChangedApp method: Entered into GetFirstFocusedChangedApp method called from SaveandShowDetails method");
                
                if (applhash2.Count == 1)
                {
                    IDictionaryEnumerator en = applhash2.GetEnumerator();
                    while (en.MoveNext())
                    {
                        if (en.Key.ToString() == appltitle + "$$$!!!" + appName)
                        {
                            string pValue = en.Value.ToString();
                            applhash2.Remove(appltitle + "$$$!!!" + appName);
                            applhash2.Add(appltitle + "$$$!!!" + appName + "-" + System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), pValue + "~" + System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 10 on GetFirstFocusedChangedApp method: GetFirstFocusedChangedApp Exception is:=" + ex.Message, HighTraceInfo);
                //LogtoEvent("AW:: LL on GetFirstFocusedChangedApp method: GetFirstFocusedChangedApp Exception is:=" + ex.Message, LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 10 on GetFirstFocusedChangedApp method: GetFirstFocusedChangedApp Exception is:=" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL on GetFirstFocusedChangedApp method: GetFirstFocusedChangedApp Exception is:=" + ex.Message.ToString());

            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        private void SaveandShowDetails(string FileToWrite)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL on SaveandShowDetails method: Entered into SaveandShowDetails method called from timer1_Tick method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 33a in SaveandShowDetails method: Entered into SaveandShowDetails called from timer1_Tick method=", LowTraceInfo);

                //LogtoEvent("Step 8: In SaveandShowDetails= ");
                //LogtoEvent("AW:: LL Step 33b in SaveandShowDetails method: Calling GetFirstFocusedChangedApp method from SaveandShowDetails method", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 33b in SaveandShowDetails method: Calling GetFirstFocusedChangedApp method from SaveandShowDetails method");
               
                GetFirstFocusedChangedApp();
                System.IO.StreamWriter writer2 = new System.IO.StreamWriter(FileToWrite, false);
                IDictionaryEnumerator en = applhash2.GetEnumerator();
                writer2.Write("<?xml version=\"1.0\"?>");
                writer2.WriteLine("");
                writer2.WriteLine("");
                writer2.Write("<ApplDetails>");
                while (en.MoveNext())
                {
                    //if (!en.Value.ToString().Trim().StartsWith("0"))
                    //{
                    writer2.Write("<Application_Info>");
                    writer2.Write("<INSTANCE_NM>");
                    string processname2 = en.Key.ToString().Trim().Substring(0, en.Key.ToString().Trim().LastIndexOf("$$$!!!")).Trim();
                    processname2 = processname2.Replace("\0", "");
                    processname2 = processname2.Replace("'", "''");
                    writer2.Write(processname2);
                    writer2.Write("</INSTANCE_NM>");
                    writer2.Write("<UTILITY_NM>");
                    writer2.Write("</UTILITY_NM>");
                    writer2.Write("<APP_NM>");
                    string applname2 = en.Key.ToString().Trim().Substring(en.Key.ToString().Trim().LastIndexOf("$$$!!!") + 6).Trim();

                    writer2.Write(applname2);
                    writer2.Write("</APP_NM>");

                    writer2.Write("<ActiveDeactiveTime>");
                    writer2.Write(en.Value);

                    writer2.Write("</ActiveDeactiveTime>");
                    writer2.Write("<ADS_ID>");

                    writer2.Write(GetUserName());

                    writer2.Write("</ADS_ID>");
                    writer2.Write("</Application_Info>");
                }
                //}
                writer2.Write("</ApplDetails>");
                writer2.Flush();
                writer2.Close();

                FileInfo f2 = new FileInfo(FileToWrite);
                long s2 = f2.Length;
                if (s2 > Convert.ToInt32(ConfigurationSettings.AppSettings["FileSize"].ToString()))
                {
                    //LogtoEvent("AW:: LL Step 33d in SaveandShowDetails method: File Length= " + s2, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33d in SaveandShowDetails method: File Length= " + s2);
                   
                    applhash2 = new Hashtable();
                    //LogtoEvent("AW:: LL Step 33e in SaveandShowDetails method: Calling saveAppFocusData method from SaveandShowDetails method", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e in SaveandShowDetails method: Calling saveAppFocusData method from SaveandShowDetails method");
                   
                    saveAppFocusData(FileToWrite);
                    //LogtoEvent("AW:: LL Step 34 in SaveandShowDetails method: Came out of saveAppFocusData method called from SaveandShowDetails method", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 34 in SaveandShowDetails method: Came out of saveAppFocusData method called from SaveandShowDetails method");
                    
                    FileToSave = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                    FileName = System.DateTime.Now.ToString("dd_MM_yyyy~HH_mm_ss") + ConfigurationSettings.AppSettings["FileExt"].ToString();
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 12 in SaveandShowDetails method: SaveandShowDetails Exception is:=" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL in SaveandShowDetails method: SaveandShowDetails Exception is:=" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 12 in SaveandShowDetails method: SaveandShowDetails Exception is:=" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL in SaveandShowDetails method: SaveandShowDetails Exception is:=" + ex.Message.ToString());

            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        private void saveAppFocusData(string FileToRead)
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL in saveAppFocusData method: Entered into saveAppFocusData method called from SaveandShowDetails method", HighTraceInfo);
                LogtoEvent("AW:: LL Step 33e-1 in saveAppFocusData method: Entered into saveAppFocusData method called from SaveandShowDetails method", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 33e-1 in saveAppFocusData method: Entered into saveAppFocusData method called from SaveandShowDetails method");
                

                FileInfo f2 = new FileInfo(FileToRead);
                long s2 = f2.Length;
                if (ConfigurationSettings.AppSettings["IdelEntry"].ToString() == "True")
                {
                    LogtoEvent("AW:: LL Step 33e-2 in saveAppFocusData method: Idle Entry True", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-2 in saveAppFocusData method: Idle Entry True");
                   
                    appFocusInput = new ManageAppFocusQuery();
                    std = new StandardResponse();
                    gduApp = new GDUServiceClient();
                    //LogtoEvent("AW:: LL Step 33e-2.1 in saveAppFocusData method:  Calling GetUserName() method from saveAppFocusData method", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-2.1 in saveAppFocusData method:  Calling GetUserName() method from saveAppFocusData method");
                    
                    appFocusInput.ADSId = GetUserName();
                    //LogtoEvent("AW:: LL Step 33e-2.2 in saveAppFocusData method:  Came out of GetUserName() method inside saveAppFocusData method", LowTraceInfo);
                    LogtoEvent("AW:: LL Step 33e-2.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-2.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ");
                    
                    appFocusInput.IPAddress = GetIP();
                    //LogtoEvent("AW:: LL Step 33e-2.5 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method ", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-2.5 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method ");
                    
                    appFocusInput.FILE_TYPE = 0;
                    appFocusInput.currentEndDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    XmlDocument doc = new XmlDocument();
                    doc.Load(FileToRead);
                    appFocusInput.XmlData = doc.InnerXml.ToString();
                    appFocusInput.ComputerName = System.Net.Dns.GetHostName();
                    std = gduApp.ManageAppFocus(appFocusInput);
                    //LogtoEvent("AW:: LL Step 33e-3 in saveAppFocusData method: ResponseCode Status in case of Idle Entry True from GDU service is:" + std.ResponseCodeStatus.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-3 in saveAppFocusData method: ResponseCode Status in case of Idle Entry True from GDU service is:" + std.ResponseCodeStatus.ToString());
                   
                }
                else
                {
                    //LogtoEvent("AW:: LL Step 33e-4 in saveAppFocusData method: Idle Entry False", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 33e-4 in saveAppFocusData method: Idle Entry False");

                    if (s2 > Convert.ToInt32(ConfigurationSettings.AppSettings["IdleFileSize"].ToString()))
                    {
                        //LogtoEvent("AW:: LL Step 33e-5 in saveAppFocusData method: Entry File Size:", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-5 in saveAppFocusData method: Entry File Size:");
                        
                        appFocusInput = new ManageAppFocusQuery();
                        std = new StandardResponse();
                        gduApp = new GDUServiceClient();
                        //LogtoEvent("AW:: LL Step 33e-5.1 in saveAppFocusData method: Calling GetUserName() method from saveAppFocusData method", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-5.1 in saveAppFocusData method: Calling GetUserName() method from saveAppFocusData method");
                        
                        appFocusInput.ADSId = GetUserName();
                        //LogtoEvent("AW:: LL Step 33e-5.2 in saveAppFocusData method: Came out of GetUserName() method inside saveAppFocusData method", LowTraceInfo);
                        //LogtoEvent("AW:: LL Step 33e-5.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-5.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ");
                        
                        appFocusInput.IPAddress = GetIP();
                        //LogtoEvent("AW:: LL Step 33e-5.4 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method ", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-5.4 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method "  );
                        
                        appFocusInput.FILE_TYPE = 0;
                        appFocusInput.currentEndDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        XmlDocument doc = new XmlDocument();
                        doc.Load(FileToRead);
                        appFocusInput.XmlData = doc.InnerXml.ToString();
                        appFocusInput.ComputerName = System.Net.Dns.GetHostName();
                        std = gduApp.ManageAppFocus(appFocusInput);
                        //LogtoEvent("AW:: LL Step 33e-6 in saveAppFocusData method: ResponseCode Status from GDU service is:" + std.ResponseCodeStatus.ToString(), LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-6 in saveAppFocusData method: ResponseCode Status from GDU service is:" + std.ResponseCodeStatus.ToString());

                        
                    }
                    else
                    {
                        //LogtoEvent("AW:: LL Step 33e-7 in saveAppFocusData method: Check Idle File or not:", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-7 in saveAppFocusData method: Check Idle File or not:");
                        
                        appFocusInput = new ManageAppFocusQuery();
                        std = new StandardResponse();
                        gduApp = new GDUServiceClient();
                        //LogtoEvent("AW:: LL Step 33e-7.1 in saveAppFocusData method: Calling GetUserName() method from saveAppFocusData method", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-7.1 in saveAppFocusData method: Calling GetUserName() method from saveAppFocusData method");
                        
                        appFocusInput.ADSId = GetUserName();
                        
                        //LogtoEvent("AW:: LL Step 33e-7.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-7.3 in saveAppFocusData method: Calling GetIP() method from saveAppFocusData method ");
                        
                        appFocusInput.IPAddress = GetIP();
                        //LogtoEvent("AW:: LL Step 33e-7.4 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method ", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 33e-7.4 in saveAppFocusData method: Came out of GetIP() method inside saveAppFocusData method ");
                        
                        appFocusInput.FILE_TYPE = 0;
                        appFocusInput.currentEndDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        XmlDocument doc = new XmlDocument();
                        doc.Load(FileToRead);
                        if (!doc.InnerXml.ToString().Contains("Idle"))
                        {
                            appFocusInput.XmlData = doc.InnerXml.ToString();
                            appFocusInput.ComputerName = System.Net.Dns.GetHostName();
                            std = gduApp.ManageAppFocus(appFocusInput);
                            //LogtoEvent("AW:: LL Step 33e-8 in saveAppFocusData method: ResponseCode Status from GDU service is:" + std.ResponseCodeStatus.ToString(), LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 33e-8 in saveAppFocusData method: ResponseCode Status from GDU service is:" + std.ResponseCodeStatus.ToString());
                           
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 11 on saveAppFocusData method: saveAppFocusData Exception Exception is:=" + ex.Message, HighTraceInfo);
                //LogtoEvent("AW:: LL on saveAppFocusData method: saveAppFocusData Exception Exception is:=" + ex.Message, LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 11 on saveAppFocusData method: saveAppFocusData Exception Exception is:=" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL on saveAppFocusData method: saveAppFocusData Exception Exception is:=" + ex.Message.ToString());

            }
            finally
            {
                System.IO.File.Delete(FileToRead);
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        private string GetUserName()
        {
            string UserName = string.Empty;
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

               
                UserName = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                //LogtoEvent("AW:: LL Step 5c in GetUserName : In GetUserName method, UserName=" + UserName, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 5c in GetUserName : In GetUserName method, UserName=" + UserName);
           
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL in GetUserName method: GetUserName method exception is" + ex.Message.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL in GetUserName method: GetUserName method exception is" + ex.Message.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL in GetUserName method: GetUserName method exception is" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL in GetUserName method: GetUserName method exception is" + ex.Message.ToString());

                UserName = "";
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
            return UserName;
        }
        private string GetIP()
        {

            string strHostName = "";
            string str = string.Empty;

            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL in GetIP method: Entered into GetIP method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 33e-2.4 in GetIP method: Entered into GetIP method", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 33e-2.4 in GetIP method: Entered into GetIP method");

                
                for (int i = 0; i < addr.Length; i++)
                {
                    str = addr[i].ToString();
                    string[] words = str.Split('.');
                    if (words.Length == 4)
                    {
                        str = addr[i].ToString();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 10.1 on GetIP() method: Exception is  :" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL on GetIP() method: Exception is  :" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 10.1 on GetIP() method: Exception is  :" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL on GetIP() method: Exception is  :" + ex.Message.ToString());
                str = addr[addr.Length - 1].ToString();
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
            return str;
        }

        /// <summary>
        /// Method for logging the log
        /// </summary>
        /// <param name="ex"></param>
        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceInfo = ConfigurationSettings.AppSettings["AxpApplicationWatcherLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["AxpApplicationWatcherHighLevelTraceInfo"].ToString();
                
                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["AxpApplicationWatcherLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    AWFilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(AWFilePath))
                    {
                        using (fs = File.Create(AWFilePath))
                        {

                        }
                    }
                    if (File.Exists(AWFilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(AWFilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(AWFilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["AxpApplicationWatcherHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    AWFilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(AWFilePath))
                    {
                        using (fs = File.Create(AWFilePath))
                        {

                        }
                    }
                    if (File.Exists(AWFilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(AWFilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(AWFilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }

               
                
            }

            catch (Exception ex1)
            {
                
            }
        }

        private static bool CheckUserExists()
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL on CheckUserExists method: Entered into CheckUserExists() method", HighTraceInfo);
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                //LogtoEvent("AW:: LL Step 8a on CheckUserExists method: In CheckUserExists method, userId= " + userId, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 8a on CheckUserExists method: In CheckUserExists method, userId= " + userId);

                //LogtoEvent("AW:: LL Step 8a-1 in CheckUserExists method: Calling GetUserDetails method", LowTraceInfo);
                DataTable userDetail = GetUserDetails(null, userId, false);
                //LogtoEvent("AW:: LL Step 8a-2 in CheckUserExists method: Came out of GetUserDetails method inside CheckUserExists method", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 8a-2 in CheckUserExists method: Came out of GetUserDetails method inside CheckUserExists method");

                if (userDetail.Rows.Count > 0)
                {
                    //LogtoEvent("AW:: LL Step 8b on CheckUserExists method: In CheckUserExists userId Exist=", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 8b on CheckUserExists method: In CheckUserExists userId Exist=");

                    //LogtoEvent("In CheckUserExists userId Exist=");
                    return true;
                }
                //LogtoEvent("AW:: LL Step 8c on CheckUserExists method: In CheckUserExists userId Not Exist=", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 8c on CheckUserExists method: In CheckUserExists userId Not Exist=");

                //LogtoEvent("In CheckUserExists userId Not Exist=");
                return false;
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 2 on CheckUserExists method: Exception is  :" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL on CheckUserExists method: Exception is  :" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 2 on CheckUserExists method: Exception is  :" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL on CheckUserExists method: Exception is  :" + ex.Message.ToString());

                return false;
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        private static void AddUser()
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                LogtoEvent("AW:: HL on AddUser() method: Entered into AddUser() method", HighTraceInfo);
                HighTraceText.AppendLine("AW:: HL on AddUser() method: Entered into AddUser() method");

                GDUServiceClient gduApp = new GDUServiceClient();
                UserQuery userDetails = new UserQuery();
                string userEmail = string.Empty;
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                string userName = WindowsIdentity.GetCurrent().Name;
                //LogtoEvent("AW:: LL Step 9a on AddUser method: In AddUser method, userId= " + userId, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9a on AddUser method: In AddUser method, userId= " + userId.ToString());

                //LogtoEvent("In AddUser Step 1 userId= " + userId);
                //LogtoEvent("AW:: LL Step 9b on AddUser method: In AddUser method, userName= " + userName, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9b on AddUser method: In AddUser method, userName= " + userName.ToString());

                int len = userName.LastIndexOf(@"\");
                string principal = userName.Remove(0, len + 1);
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", principal);
                string domain = ConfigurationSettings.AppSettings["DomainName"].ToString();
                string[] properties = new string[] { "fullname" };
                DirectoryEntry adRoot = new DirectoryEntry("LDAP://" + domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(adRoot);
                searcher.SearchScope = SearchScope.Subtree;
                searcher.ReferralChasing = ReferralChasingOption.All;
                searcher.PropertiesToLoad.AddRange(properties);
                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();
                string displayName = directoryEntry.Properties["displayName"][0].ToString();
                userEmail = directoryEntry.Properties["mail"][0].ToString();
                LogtoEvent("AW:: LL Step 9c on AddUser method: In AddUser method, displayName= " + displayName, LowTraceInfo);
                LogtoEvent("AW:: LL Step 9d on AddUser method: In AddUser method, userEmail= " + userEmail, LowTraceInfo);
                //LogtoEvent("In AddUser Step 4 userEmail= " + userEmail);
                userDetails.UserId = userId;
                userDetails.UserName = displayName;
                userDetails.LanguageCode = "ENG";
                userDetails.UserRoleCode = "DC";
                userDetails.EmailAddress = userEmail;
                userDetails.ModifiedUserDate = DateTime.Now;
                userDetails.ModifiedUserID = userId;
                userDetails.Mode = "ADD";

                //LogtoEvent("AW:: LL Step 9e on AddUser method: In AddUser method, userDetails.UserId= " + userDetails.UserId, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9e on AddUser method: In AddUser method, userDetails.UserId= " + userDetails.UserId.ToString());

                //LogtoEvent("AW:: LL Step 9f on AddUser method: In AddUser method, userDetails.UserName= " + userDetails.UserName, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9f on AddUser method: In AddUser method, userDetails.UserName= " + userDetails.UserName.ToString());

                //LogtoEvent("AW:: LL Step 9g on AddUser method: In AddUser method, userDetails.LanguageCode= " + userDetails.LanguageCode, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9g on AddUser method: In AddUser method, userDetails.LanguageCode= " + userDetails.LanguageCode.ToString());

                LogtoEvent("AW:: LL Step 9h on AddUser method: In AddUser method, userDetails.UserRoleCode= " + userDetails.UserRoleCode, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9h on AddUser method: In AddUser method, userDetails.UserRoleCode= " + userDetails.UserRoleCode.ToString());
                
                //LogtoEvent("AW:: LL Step 9i on AddUser method: In AddUser method, userDetails.EmailAddress= " + userDetails.EmailAddress, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9i on AddUser method: In AddUser method, userDetails.EmailAddress= " + userDetails.EmailAddress.ToString());
                
                //LogtoEvent("AW:: LL Step 9j on AddUser method: In AddUser method, userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9j on AddUser method: In AddUser method, userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate.ToString());
                
                //LogtoEvent("AW:: LL Step 9k on AddUser method: In AddUser method, userDetails.ModifiedUserID= " + userDetails.ModifiedUserID, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9k on AddUser method: In AddUser method, userDetails.ModifiedUserID= " + userDetails.ModifiedUserID.ToString());
                
                //LogtoEvent("AW:: LL Step 9l on AddUser method: In AddUser method, userDetails.Mode= " + userDetails.Mode, LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 9l on AddUser method: In AddUser method, userDetails.Mode= " + userDetails.Mode.ToString());


                gduApp.ManageUsers(userDetails);
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 3 on AddUser method: Exception is  :" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL on AddUser method: Exception is  :" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 3 on AddUser method: Exception is  :" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL on AddUser method: Exception is  :" + ex.Message.ToString());

                //LogtoEvent("In AddUser  Exception= " + ex.ToString());
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
        public static DataTable GetUserDetails(string userName, string userId, bool isDeactive)
        {
            DataTable dtUser = new DataTable();
            UserDetails[] userDetails;
            DataRow drUserInfo;
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL on GetUserDetails method: Entered into GetUserDetails method", HighTraceInfo);
                HighTraceText.AppendLine("AW:: HL on GetUserDetails method: Entered into GetUserDetails method");

                //LogtoEvent("AW:: LL Step 8a-2 in GetUserDetails method: Entered into GetUserDetails method", LowTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 8a-2 in GetUserDetails method: Entered into GetUserDetails method");

                
                try
                {
                    GDUServiceClient gduApp = new GDUServiceClient();

                    dtUser.Columns.Add("UserID", Type.GetType("System.String"));
                    dtUser.Columns.Add("UserName", Type.GetType("System.String"));
                    dtUser.Columns.Add("EmailAddress", Type.GetType("System.String"));
                    dtUser.Columns.Add("Language", Type.GetType("System.String"));
                    dtUser.Columns.Add("Role", Type.GetType("System.String"));
                    dtUser.Columns.Add("LanguageCode", Type.GetType("System.String"));
                    dtUser.Columns.Add("RoleCode", Type.GetType("System.String"));
                    dtUser.Columns.Add("ModifiedDT", Type.GetType("System.DateTime"));
                    dtUser.Columns.Add("DefaultClientID", Type.GetType("System.Int32"));
                    UserQuery userQuery = new UserQuery();
                    userQuery.UserId = userId;
                    userQuery.UserName = userName;
                    userQuery.IsDeactive = isDeactive;
                    userDetails = gduApp.SearchUsers(userQuery);

                    for (int iCount = 0; iCount < userDetails.Length; iCount++)
                    {
                        drUserInfo = dtUser.NewRow();
                        drUserInfo["UserID"] = userDetails[iCount].UserId;
                        drUserInfo["UserName"] = userDetails[iCount].UserName;
                        drUserInfo["EmailAddress"] = userDetails[iCount].EmailAddress;
                        drUserInfo["LanguageCode"] = userDetails[iCount].LanguageCode;
                        drUserInfo["Language"] = userDetails[iCount].Language;
                        drUserInfo["Role"] = userDetails[iCount].UserRole;
                        drUserInfo["RoleCode"] = userDetails[iCount].UserRoleCode;
                        drUserInfo["ModifiedDT"] = userDetails[iCount].ModifiedUserDate;
                        drUserInfo["DefaultClientID"] = userDetails[iCount].DefaultClientID;
                        dtUser.Rows.Add(drUserInfo);
                    }
                }
                catch (Exception ex)
                {
                    //LogtoEvent("DU:: HL Step 4.1 on GetUserDetails method: In GetUserDetails  Exception= :" + ex.ToString(), HighTraceInfo);
                    //LogtoEvent("DU:: LL on GetUserDetails method: In GetUserDetails  Exception= :" + ex.ToString(), LowTraceInfo);
                    HighTraceText.AppendLine("DU:: HL Step 4.1 on GetUserDetails method: In GetUserDetails  Exception= :" + ex.Message.ToString());
                    LowTraceText.AppendLine("DU:: LL on GetUserDetails method: In GetUserDetails  Exception= :" + ex.Message.ToString());
                    //LogtoEvent("In GetUserDetails  Exception= " + ex.ToString());
                }
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
            return dtUser;
        }

        private void TravelSuiteFileRead(string FilePath)
        {
            FileStream stream = null;
            XmlDocument XmlDoc = new XmlDocument();
            string fileType = string.Empty;

            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();


                //LogtoEvent("AW:: HL in TravelSuiteFileRead method: Entered into TravelSuiteFileRead method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 29b in TravelSuiteFileRead method: Entered into TravelSuiteFileRead method", LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL in TravelSuiteFileRead method: Entered into TravelSuiteFileRead method");
                LowTraceText.AppendLine("AW:: LL Step 29b in TravelSuiteFileRead method: Entered into TravelSuiteFileRead method");
                
                appMutex = new Mutex(false, @"Global\" + ProductId);
                bool Running = appMutex.WaitOne(0, false);
                if (Running)
                {
                    FileInfo f2 = new FileInfo(FilePath);
                    long s2 = f2.Length;
                    //LogtoEvent("AW:: LL Step 29c in TravelSuiteFileRead method: Travel Suite File Path:" + FilePath, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 29c in TravelSuiteFileRead method: Travel Suite File Path:" + FilePath.ToString());

                    LogtoEvent("AW:: LL Step 29d in TravelSuiteFileRead method: File Size:" + s2.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 29d in TravelSuiteFileRead method: File Size:" + s2.ToString());
                    

                    if (s2 > Convert.ToInt32(ConfigurationSettings.AppSettings["TravelSuiteFileSize"].ToString()))
                    {
                        try
                        {
                            //LogtoEvent("AW:: LL Step 29e in TravelSuiteFileRead method : Trvael Suite:..", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 29e in TravelSuiteFileRead method : Trvael Suite:..");
                            
                            appFocusInput = new ManageAppFocusQuery();

                            XmlDocument doc = new XmlDocument();
                            doc.Load(FilePath);

                            if (doc.InnerXml.ToString().ToLower().Contains("shell.exe"))
                            {
                                appFocusInput.FILE_TYPE = 1;
                                fileType = "TravelSuite";
                            }
                            else
                            {
                                appFocusInput.FILE_TYPE = 2;
                                fileType = "ACW";
                            }
                            if (((fileType == "TravelSuite") && TravelSuiteIndicator == "True") || ((fileType == "ACW") && ACWIndicator == "True"))
                            {
                                std = new StandardResponse();
                                gduApp = new GDUServiceClient();
                                //LogtoEvent("AW:: LL Step 29f in TravelSuiteFileRead method : Calling GetUserName() method from TravelSuiteFileRead method", LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 29f in TravelSuiteFileRead method : Calling GetUserName() method from TravelSuiteFileRead method");
                            
                                appFocusInput.ADSId = GetUserName();
                                //LogtoEvent("AW:: LL Step 29g.1 in TravelSuiteFileRead method : Calling GetIP() method from TravelSuiteFileRead method", LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 29g.1 in TravelSuiteFileRead method : Calling GetIP() method from TravelSuiteFileRead method");

                            
                                appFocusInput.IPAddress = GetIP();
                                //LogtoEvent("AW:: LL Step 29g.2 in TravelSuiteFileRead method : Came out of GetIP() method inside TravelSuiteFileRead method", LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 29g.2 in TravelSuiteFileRead method : Came out of GetIP() method inside TravelSuiteFileRead method");
                            
                                //appFocusInput.FILE_TYPE = 1;
                                appFocusInput.currentEndDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                                appFocusInput.XmlData = doc.InnerXml.ToString();
                                appFocusInput.ComputerName = System.Net.Dns.GetHostName();
                                std = gduApp.ManageAppFocus(appFocusInput);
                                LogtoEvent("AW:: LL Step 29h in TravelSuiteFileRead method : Travel Suite :" + std.ResponseCodeStatus.ToString(), LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 29h in TravelSuiteFileRead method : Travel Suite :" + std.ResponseCodeStatus.ToString());
                                
                                System.IO.File.Delete(FilePath);
                                //LogtoEvent("AW:: LL Step 29j.1 :Travel Suite File Deleted ", LowTraceInfo);
                                LowTraceText.AppendLine("AW:: LL Step 29j.1 :Travel Suite File Deleted ");

                            }

                        }
                        catch (Exception ex)
                        {

                            //LogtoEvent("AW:: HL step 8.0.1 in TravelSuiteFileRead method :Travel Suite Inner: Exception" + ex.ToString(), HighTraceInfo);
                            //LogtoEvent("AW:: LL in TravelSuiteFileRead method :Travel Suite Inner: Exception" + ex.ToString(), LowTraceInfo);
                            HighTraceText.AppendLine("AW:: HL step 8.0.1 in TravelSuiteFileRead method :Travel Suite Inner: Exception" + ex.Message.ToString());
                            LowTraceText.AppendLine("AW:: LL in TravelSuiteFileRead method :Travel Suite Inner: Exception" + ex.Message.ToString());

                            System.IO.File.Delete(FilePath);
                        }
                        //finally
                        //{
                        //    System.IO.File.Delete(FilePath);
                        //}

                    }
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL step 8.1 in TravelSuiteFileRead method : Travel Suite Outer: Exception" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL in TravelSuiteFileRead method : Travel Suite Outer: Exception" + ex.ToString(), LowTraceInfo);

                HighTraceText.AppendLine("AW:: HL step 8.1 in TravelSuiteFileRead method : Travel Suite Outer: Exception" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL in TravelSuiteFileRead method : Travel Suite Outer: Exception" + ex.Message.ToString());
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }

                if (stream != null)
                    stream.Close();
                ReleaseApplicationMutex();

            }

        }

        private void TravelSuiteFileReadByDefaultTime(string FilePath)
        {
            
            FileStream stream = null;
            XmlDocument XmlDoc = new XmlDocument();
            string fileType = string.Empty;
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL on TravelSuiteFileReadByDefaultTime method: Entered into TravelSuiteFileReadByDefaultTime method called from Timer_tick method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 40a in TravelSuiteFileReadByDefaultTime method: Entered into TravelSuiteFileReadByDefaultTime method called from Timer_tick method", LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL on TravelSuiteFileReadByDefaultTime method: Entered into TravelSuiteFileReadByDefaultTime method called from Timer_tick method");
                LowTraceText.AppendLine("AW:: LL Step 40a in TravelSuiteFileReadByDefaultTime method: Entered into TravelSuiteFileReadByDefaultTime method called from Timer_tick method");

                appMutex = new Mutex(false, @"Global\" + ProductId);
                bool Running = appMutex.WaitOne(0, false);
                if (Running)
                {
                    //LogtoEvent("AW:: LL Step 40b in TravelSuiteFileReadByDefaultTime method: Travel Suite By Default Time:" + FilePath, LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 40b in TravelSuiteFileReadByDefaultTime method: Travel Suite By Default Time:" + FilePath.ToString());
                   
                    try
                    {
                        //LogtoEvent("AW:: LL Step 40c in TravelSuiteFileReadByDefaultTime method: TS By Default:", LowTraceInfo);
                        LowTraceText.AppendLine("AW:: LL Step 40c in TravelSuiteFileReadByDefaultTime method: TS By Default:");
                       
                        appFocusInput = new ManageAppFocusQuery();
                        XmlDocument doc = new XmlDocument();

                        doc.Load(FilePath);

                        if (doc.InnerXml.ToString().ToLower().Contains("shell.exe")) //Shell mean TravelSuite
                        {
                            appFocusInput.FILE_TYPE = 1;
                            fileType = "TravelSuite";
                        }
                        else
                        {
                            appFocusInput.FILE_TYPE = 2;
                            fileType = "ACW";
                        }

                        if (((fileType == "TravelSuite") && TravelSuiteIndicator == "True") || ((fileType == "ACW") && ACWIndicator == "True"))
                        {
                            std = new StandardResponse();
                            gduApp = new GDUServiceClient();
                            //LogtoEvent("AW:: LL Step 40c-1 in TravelSuiteFileReadByDefaultTime method: Calling GetUserName() method from TravelSuiteFileReadByDefaultTime method ", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 40c-1 in TravelSuiteFileReadByDefaultTime method: Calling GetUserName() method from TravelSuiteFileReadByDefaultTime method ");
                        
                            appFocusInput.ADSId = GetUserName();
                            //LogtoEvent("AW:: LL Step 40c-2 in TravelSuiteFileReadByDefaultTime method: Came out of GetUserName() method inside TravelSuiteFileReadByDefaultTime method ", LowTraceInfo);
                            //LogtoEvent("AW:: LL Step 40c-3 in TravelSuiteFileReadByDefaultTime method: Calling GetIP() method from TravelSuiteFileReadByDefaultTime method ", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 40c-3 in TravelSuiteFileReadByDefaultTime method: Calling GetIP() method from TravelSuiteFileReadByDefaultTime method ");
                        
                            appFocusInput.IPAddress = GetIP();
                            //LogtoEvent("AW:: LL Step 40c-4 in TravelSuiteFileReadByDefaultTime method: Came out of GetIP() method insdie TravelSuiteFileReadByDefaultTime method ", LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 40c-4 in TravelSuiteFileReadByDefaultTime method: Came out of GetIP() method insdie TravelSuiteFileReadByDefaultTime method ");
                        
                            //appFocusInput.FILE_TYPE = 1;
                            appFocusInput.currentEndDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            appFocusInput.XmlData = doc.InnerXml.ToString();
                            appFocusInput.ComputerName = System.Net.Dns.GetHostName();
                            std = gduApp.ManageAppFocus(appFocusInput);
                            //LogtoEvent("AW:: LL Step 40d in TravelSuiteFileReadByDefaultTime method: TS By Default, ResponseCodeStatus is :" + std.ResponseCodeStatus.ToString(), LowTraceInfo);
                            LowTraceText.AppendLine("AW:: LL Step 40d in TravelSuiteFileReadByDefaultTime method: TS By Default, ResponseCodeStatus is :" + std.ResponseCodeStatus.ToString());

                            //LogtoEvent("AW:: LL Step 40d in TravelSuiteFileReadByDefaultTime method: TS By Default, ResponseMessage is :" + std.ResponseMessage.ToString(), LowTraceInfo);
                        
                            System.IO.File.Delete(FilePath);
                        }
                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("AW:: HL Step 14 in TravelSuiteFileReadByDefaultTime method : TS By Default Inner: Exception" + ex.ToString(), HighTraceInfo);
                        //LogtoEvent("AW:: LL in TravelSuiteFileReadByDefaultTime method : TS By Default Inner: Exception" + ex.ToString(), LowTraceInfo);
                        HighTraceText.AppendLine("AW:: HL Step 14 in TravelSuiteFileReadByDefaultTime method : TS By Default Inner: Exception" + ex.Message.ToString());
                        LowTraceText.AppendLine("AW:: LL in TravelSuiteFileReadByDefaultTime method : TS By Default Inner: Exception" + ex.Message.ToString());
                        
                        System.IO.File.Delete(FilePath);
                    }
                    //finally
                    //{
                    //    System.IO.File.Delete(FilePath);
                    //}
                }

            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 12.1 in TravelSuiteFileReadByDefaultTime method:TS By Default Outer: Exception" + ex.ToString(), HighTraceInfo);
                //LogtoEvent("AW:: LL in TravelSuiteFileReadByDefaultTime method:TS By Default Outer: Exception" + ex.ToString(), LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL Step 12.1 in TravelSuiteFileReadByDefaultTime method:TS By Default Outer: Exception" + ex.Message.ToString());
                LowTraceText.AppendLine("AW:: LL in TravelSuiteFileReadByDefaultTime method:TS By Default Outer: Exception" + ex.Message.ToString());
 
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }

                if (stream != null)
                    stream.Close();
                ReleaseApplicationMutex();
            }

        }

        private static void ReleaseApplicationMutex()
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW:: HL in ReleaseApplicationMutex method: Entered into ReleaseApplicationMutex method", HighTraceInfo);
                //LogtoEvent("AW:: LL Step 29L in ReleaseApplicationMutex method: Entered into ReleaseApplicationMutex method", LowTraceInfo);
                HighTraceText.AppendLine("AW:: HL in ReleaseApplicationMutex method: Entered into ReleaseApplicationMutex method");
                LowTraceText.AppendLine("AW:: LL Step 29L in ReleaseApplicationMutex method: Entered into ReleaseApplicationMutex method");

                if (null != appMutex)
                {
                    //LogtoEvent("AW:: LL Step 29m in ReleaseApplicationMutex method : if (null != appMutex) condition stisfies in ReleaseApplicationMutex methos", LowTraceInfo);
                    LowTraceText.AppendLine("AW:: LL Step 29m in ReleaseApplicationMutex method : if (null != appMutex) condition stisfies in ReleaseApplicationMutex method");

                    appMutex.ReleaseMutex();
                    appMutex = null;
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("AW:: HL Step 8.2 in ReleaseApplicationMutex method : In ReleaseApplicationMutex method, Exception" + ex.ToString(), HighTraceInfo);
                LowTraceText.AppendLine("AW:: LL Step 8.2 in ReleaseApplicationMutex method : In ReleaseApplicationMutex method, Exception" + ex.Message.ToString());

            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }

        private static void DeleteFile()
        {
            try
            {
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

                //LogtoEvent("AW: HL in DeleteFile method: Entered into DeleteFile method", HighTraceInfo);
                //LogtoEvent("AW: LL Step 0.01 in DeleteFile method: Entered into DeleteFile method", LowTraceInfo);
                HighTraceText.AppendLine("AW: HL in DeleteFile method: Entered into DeleteFile method");
                LowTraceText.AppendLine("AW: LL Step 0.01 in DeleteFile method: Entered into DeleteFile method");

                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceFileName = ConfigurationSettings.AppSettings["AxpApplicationWatcherLowLevelTraceFileName"].ToString();
                string HighTraceFileName = ConfigurationSettings.AppSettings["AxpApplicationWatcherHighLevelTraceFileName"].ToString();
                string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                string LLDuration = ConfigurationManager.AppSettings["LLDuration"];
                foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.txt"))
                {
                    string contents = file.ToString();
                    if (contents.Contains(LowTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File name is" + fi.Name.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString());

                        if (ts.TotalDays > Convert.ToInt32(LLDuration))
                        {
                            double diff = ts.TotalDays - Convert.ToInt32(LLDuration);
                            //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: Time difference " + diff.ToString());

                            fi.Delete();
                            //LogtoEvent("PO: Low level file deleted ", HighTraceInfo);
                            HighTraceText.AppendLine("PO: Low level file deleted ");

                        }
                    }

                    if (contents.Contains(HighTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.TotalDays.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File name is" + fi.Name.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                        HighTraceText.AppendLine("PO: HL in DeleteFile method: TimeSpan is" + ts.TotalDays.ToString());

                        if (ts.TotalDays > Convert.ToInt32(HLDuration))
                        {
                            double diff1 = ts.TotalDays - Convert.ToInt32(HLDuration);
                            //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff1.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: Time difference " + diff1.ToString());

                            fi.Delete();
                            //LogtoEvent("PO: High level file deleted ", HighTraceInfo);
                            HighTraceText.AppendLine("PO: High level file deleted ");

                        }
                    }
                 }

            }

            catch (Exception ex2)
            {
                
            }
            finally
            {
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }

                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
            }
        }
    }
}
